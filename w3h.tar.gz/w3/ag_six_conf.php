<?php


include("conf/config_admin.php");

$co_ary = Array("scid","winloss_sc","winloss","winloss_min","winloss_min_sw","winloss_occupy","back","winloss_bak","fix8");
$su_ary = Array("cid","winloss_sc","winloss_c","winloss","back","winloss_bak","fix8");
$ag_ary = Array("sid","winloss_sc","winloss_c","winloss_s","winloss_a");


/*

sc_conf
id	scid	gtype	rtype	SC	SO	W_WAR	L_WAR	ST

co_conf
id	cid	gtype	rtype	SC	SO	W_WAR	L_WAR	ST

su_conf
id	sid	gtype	rtype	SC	SO	W_WAR	L_WAR

ag_conf
id	aid	gtype	rtype	SC	SO	W_WAR	L_WAR


mem_conf
id	mid	gtype	rtype	SC	SO	W_WAR	L_WAR

http://ctliiti566.cvssp2017.com/ag_six_conf.php?uid=3ec228fb2a18e53b
http://ctlti566.cvssp2017.com/ag_six_conf.php?uid=50b642372ff9e52
*/



$sql = "SELECT aid FROM outsource_ag WHERE 1;";
$dbr->query($sql);
$i=0;
while($dbr->next_record()){
    $aid_Ary[$i]=$dbr->f("aid");
    $i++;
}
$sql_num = 0;
for($c=0;$c<count($aid_Ary);$c++){
    $sql = "SELECT * FROM ag_conf WHERE aid='".$aid_Ary[$c]."' and grp='7'";
    $dbr->query($sql);
    if($dbr->num_rows()*1>0) continue;

    $sql = "SELECT * FROM ag_conf WHERE aid='".$aid_Ary[$c]."' and grp='1'";
    $dbr->query($sql);
    $conf_data = $dbr->get_total_data();

    

    for($g=2;$g<=7;$g++){
        $sql = "SELECT * FROM ag_conf WHERE aid='".$aid_Ary[$c]."' and grp='".$g."'";
        $dbr->query($sql);
        if($dbr->num_rows()*1>0) continue;

        for($j=0;$j < count($conf_data);$j++){
            $sql_sc=  "INSERT INTO ag_conf set ";
            $sql_sc.= " aid='".$conf_data[$j]["aid"]."'";
            $sql_sc.= ",gtype='".$conf_data[$j]["gtype"]."'";
            $sql_sc.= ",rtype='".$conf_data[$j]["rtype"]."'";
            $sql_sc.= ",SC='".$conf_data[$j]["SC"]."'";
            $sql_sc.= ",SO='".$conf_data[$j]["SO"]."'";
            $sql_sc.= ",W_WAR='".$conf_data[$j]["W_WAR"]."'";
            $sql_sc.= ",L_WAR='".$conf_data[$j]["L_WAR"]."'";
            $sql_sc.= ",grp='".$g."'";
            // $db->query($sql_sc);
            $sql_num++;
            echo $sql_sc."\n";
        }
    }
}
echo $sql_num;
?>