<?php

include("./conf/config_ctl.php");
include("./lib/mysqllib_pic.php");


$sql = "SELECT tbid, name_c FROM BA_lobby WHERE tbid > '0' and server_no='1' order by tbid ";
$dbr->query($sql);
$i=0;
while($dbr->next_record()){
  $tb_id_ary[$i] .=  $dbr->f("tbid");
  $tb_name_ary[$i] .=  $dbr->f("name_c");
  $i++;
}
$totalTableCount = $i;

for($i = 0; $i < $totalTableCount; $i++){
  if($tb_name_ary[$i] == $tablename){
    $tableId = $tb_id_ary[$i];
    break;
  }
}

if($tableId >= 50){
 $dbGame = new proc_DB_pic(DB_HOST_GAME3,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME_3); 
}else if($tableId > 20){
  $dbGame = new proc_DB_pic(DB_HOST_GAME2,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME); 
 }else{
 $dbGame = new proc_DB_pic(DB_HOST_GAME,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME); 
}


define("WEB_PATH" ,substr($_SERVER['DOCUMENT_ROOT'],0,strlen($_SERVER['DOCUMENT_ROOT'])-3) );
define("WEB_TIME_ZONE",-4);


// $filename = "2103_7_82_11777";
$base64_string = $_REQUEST["base64_string"]; //避免被 SQL_injection 取代掉
$MD5 = $_REQUEST["MD5"]; //避免被 SQL_injection 取代掉
$hash =md5($base64_string);

if($MD5 != $hash){
  echo "HASH ERR MD5 = ".$MD5. "     php MD5 = ".$hash;
  exit();
}else{
  // echo "HASH SUCCESS  MD5 = ".$MD5. "     php MD5 = ".$hash;
}
// echo $base64_string;
// $tablename = $tablename*1;
$boots = $boots*1;
$inning = $inning*1;
$gid = $gid*1;
$result = $result;

$today=getdate();
$today_gmt=gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
$today_ymt=gmdate("Ymd",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
$daytime=gmdate("Y-m-d H:i:s",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));

$sql = "";
$orderdate = preg_replace("/-/","",$orderdate);
$table = "pic_".$orderdate;
$sql =  "CREATE TABLE IF NOT EXISTS ".$table." LIKE `pic`;";
$dbGame->query($sql);

$sql ="insert IGNORE into ".$table." set";
$sql .=" tbid='".$tableId."'";
$sql .=",btid='".$boots."'";
$sql .=",gmid='".$inning."'";
$sql .=",gid='".$gid."'";
$sql .=",result='".$result."'";
$sql .=",content='".$base64_string."'";
$sql .=",pic_user='".$MEM_DATA["username"]."'";
$sql .=",adddate=Date_add( now( ) , INTERVAL -12 HOUR );";
// echo $sql."<br>\n";
$dbGame->query($sql);

/*
CREATE TABLE IF NOT EXISTS `reload_username` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL DEFAULT '',
  `reload` enum('Y','N') NOT NULL DEFAULT 'Y',
  `adddate` datetime NOT NULL,
  `lastdate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 MAX_ROWS=1000000000 AVG_ROW_LENGTH=15000;
*/

if($result == "stopTime"){
  $sql = "";
  $sql .= " select * from reload_username where username='".$MEM_DATA["username"]."' ";
  // echo $sql."<br>\n";
  $dbGame->query($sql);

  if($dbGame->next_record()){
    if($dbGame->f("reload")=="N"){
        $sql = "update reload_username set reload='Y' , lastdate=Date_add( now( ) , INTERVAL -12 HOUR )";
        $sql .= " where username='".$MEM_DATA["username"]."'"; 
        // echo $sql."<br>\n";
        $dbGame->query($sql);
        echo "<script>window.location.reload(true)</script>";
    }else if(preg_match("/amvideo/",$MEM_DATA["username"])){
        $db_lastdate = $dbGame->f("lastdate");
        $db_date = preg_split("/ /",$db_lastdate);
        
        // $diff = diffDayTime($db_lastdate,$daytime);
        // if($diff*1 >= 86400){
        if($db_date[0] != $today_gmt){
            $sql = "update reload_username set reload='Y' , lastdate=Date_add( now( ) , INTERVAL -12 HOUR )";
            $sql .= " where username='".$MEM_DATA["username"]."'"; 
            // echo $sql."<br>\n";
            $dbGame->query($sql);
            //echo "<script>opener.re_show_flashcontrol();</script>";
        }
    }else{
        //echo "<script>console.log('".(preg_match("/amvideo/",$MEM_DATA["username"]))."');</script>";
    }
  }else{
    $sql = "insert into reload_username set";
    $sql .=" username='".$MEM_DATA["username"]."'";
    $sql .=",reload='Y'";
    $sql .=",adddate=Date_add( now( ) , INTERVAL -12 HOUR );";
    // echo $sql."<br>\n";
    $dbGame->query($sql);
  }
}

/*
drop table pic;
CREATE TABLE IF NOT EXISTS `pic` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tbid` int(11) NOT NULL,
  `btid` int(11) NOT NULL,
  `gmid` int(11) NOT NULL,
  `gid` bigint(20) NOT NULL,
  `result` varchar(20) default NULL,
  `content` mediumtext NOT NULL,
  `pic_user` varchar(10) NOT NULL DEFAULT '',
  `adddate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY (`gid`,`result`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 MAX_ROWS=1000000000 AVG_ROW_LENGTH=15000 COMMENT='百2 拍照圖' ;
*/
exit;

$dir_date = WEB_PATH."/log/images/".$today_gmt."/".$tbno;

$fname =  $dir_date."/".$filename.".jpeg" ;

echo $fname."<br>\n";

if($_REQUEST["delete"]=="Y"){
  delFile($fname,"log");
}else if($_REQUEST["rmdir"]=="Y"){
  unlinkTxt($dir_date,-1);
  rmdir($dir_date);
}else{
  $image = writeFile($fname,$base64_string);
}
function delFile($fileName,$break="ro_test"){
	$file_path = preg_split("/\//",$fileName);

	$tmp_path = $fileName;
	if(file_exists($fileName)){
		unlink($fileName);
	}
	for($i = count($file_path)-1;$i >=0;$i--){
		$v = $file_path[$i];
		if($file_path[$i-1] == $break)break;
		$tmp_path = preg_replace("/\/".$v."/","",$tmp_path);
		if(!is_dir($tmp_path)){
			echo $tmp_path." no exist"."<br>\n";
		}else{
			echo $tmp_path." is exist"."<br>\n";
			rmdir($tmp_path);
		}
	}
}

//unlinkTxt($path, $delday);
//刪除七天以前的txt
function unlinkTxt($path, $rday) {
	$files = glob($path.'/*', GLOB_MARK);
	foreach ($files as $file) {
		//date("Y-m-d H:i:s", filemtime($file)."\n"); //用檔案路徑 取得timestap 再轉換成時間
		//date("Y-m-d H:i:s", mktime(0, 0, 0, date("m"), date("d")-7, date("Y"))) //取得以今天開始七天前的日期
		if (date("Y-m-d H:i:s", filemtime($file)) <= date("Y-m-d H:i:s", mktime(0, 0, 0, date("m"), date("d")-$rday, date("Y")))) {
			unlink($file);//只要日期小於七天前的都砍掉
		} else {
			//print "false";
		}
	}
}
function writeFile($fileName,$file_str){
	$file_path = preg_split("/\//",$fileName);
	//print_r($file_path);
	$tmp_path = "/";
	for($i=0;$i< count($file_path)-1;$i++){
		$v = $file_path[$i];
		if($v=="" || $v=="." || $v =="..")continue;
		$tmp_path .= $v."/"; 
		if(!is_dir($tmp_path)){
			echo $tmp_path." no exist"."<br>\n";
			mkdir($tmp_path,0777);
		}else{
			//echo $tmp_path." is exist"."<br>\n";
		}
	}
	if(file_exists($fileName)){
		unlink($fileName);
	}
	// $fp = fopen(WEB_PATH."/".$fileName,"a+");
	// echo $fileName." : ".fputs($fp,$file_str)." words"."<br>\n";
	// fclose($fp);
  base64_to_jpeg($fileName,$file_str);
	chmod($fileName,0777);
}
function base64_to_jpeg($fileName,$base64_string) {
    // open the output file for writing
    $ifp = fopen( $fileName, "wb" ); 
    // split the string on commas
    // $data[ 0 ] == "data:image/png;base64"
    // $data[ 1 ] == <actual base64 string>
    $data = explode( ',', $base64_string );
    // we could add validation here with ensuring count( $data ) > 1
    fwrite( $ifp, base64_decode( $data[ 1 ] ) );
    // clean up the file resource
    fclose( $ifp ); 
    return $fileName; 
}
function diffDayTime($time1,$time2){
    $ymt_his = preg_split("/ /",$time1);
    $ymt = preg_split("/-/",$ymt_his[0]);
    $his = preg_split("/:/",$ymt_his[1]);
    $diff1 = mktime($his[0],$his[1],$his[2],$ymt[1],$ymt[2],$ymt[0]);
    $ymt_his = preg_split("/ /",$time2);
    $ymt = preg_split("/-/",$ymt_his[0]);
    $his = preg_split("/:/",$ymt_his[1]);
    $diff2 = mktime($his[0],$his[1],$his[2],$ymt[1],$ymt[2],$ymt[0]);
    
    return $diff2 - $diff1;
}
?>
