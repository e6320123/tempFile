<?php
if(empty($_SERVER['DOCUMENT_ROOT'])) $server_root = $_SERVER["PWD"];
else $server_root = $_SERVER['DOCUMENT_ROOT'];

include substr($_SERVER['DOCUMENT_ROOT'],0,strlen($_SERVER['DOCUMENT_ROOT'])-3)."/config/pub_config_ctl.php";
include $server_root."/lib/mysqllib.php";

foreach ($_REQUEST as $key => $value) {
	if(is_array($value))   {
		foreach($value as $mkey => $mval){
			$value[$mkey] = defend_SQL_injection($mval);
		}
		try{
			$$key = $value;
		}catch(Exception $e){
			$$key = "";
		}
	}else{
		try{
			$$key = defend_SQL_injection($value);
		}catch(Exception $e){
			$$key = "";
		}
	}
}

$uid = $uid;
$tablename = $tablename*1;
$base64_string = $_REQUEST["base64_string"]; //避免被 SQL_injection 取代掉
$tablename = $tablename*1;
$boots = $boots*1;
$inning = $inning*1;
$gid = $gid*1;
$result = $result;
$MEM_DATA["username"] = $username;

if($tablename*1 > 3007){
 $dbGame = new proc_DB_pic(DB_HOST_GAME2,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME); 
}else{
 $dbGame = new proc_DB_pic(DB_HOST_GAME,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME); 
}


define("WEB_PATH" ,substr($_SERVER['DOCUMENT_ROOT'],0,strlen($_SERVER['DOCUMENT_ROOT'])-3) );
define("WEB_TIME_ZONE",-4);




$today=getdate();
$today_gmt=gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
$today_ymt=gmdate("Ymd",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));


$sql = "";
$orderdate = preg_replace("/-/","",$orderdate);
$table = "pic_".$orderdate;
$sql =  "CREATE TABLE IF NOT EXISTS ".$table." LIKE `pic`;";
// echo $sql."<br>\n";
$dbGame->query($sql);

$sql ="insert into ".$table." set";
$sql .=" tbid='".$tablename."'";
$sql .=",btid='".$boots."'";
$sql .=",gmid='".$inning."'";
$sql .=",gid='".$gid."'";
$sql .=",result='".$result."'";
$sql .=",content='".$base64_string."'";
$sql .=",pic_user='".$MEM_DATA["username"]."'";
$sql .=",adddate=Date_add( now( ) , INTERVAL -12 HOUR );";
// echo $sql."<br>\n";
$dbGame->query($sql);


if($result == "stopTime"){
  $sql = "";
  $sql .= " select * from reload_username where username='".$MEM_DATA["username"]."' ";
  // echo $sql."<br>\n";
  $dbGame->query($sql);

  if($dbGame->next_record()){
    if($dbGame->f("reload")=="Y"){
      //do nothing
      $sql="";
    }else{
      $sql = "update reload_username set reload='Y' , lastdate=Date_add( now( ) , INTERVAL -12 HOUR )";
      $sql .= " where username='".$MEM_DATA["username"]."'"; 
      // echo $sql."<br>\n";
      $dbGame->query($sql);
      echo "<script>window.location.reload(true)</script>";
    }
  }else{
    $sql = "insert into reload_username set";
    $sql .=" username='".$MEM_DATA["username"]."'";
    $sql .=",reload='Y'";
    $sql .=",adddate=Date_add( now( ) , INTERVAL -12 HOUR );";
    // echo $sql."<br>\n";
    $dbGame->query($sql);
  }
}


exit;

$dir_date = WEB_PATH."/log/images/".$today_gmt."/".$tbno;

$fname =  $dir_date."/".$filename.".jpeg" ;

echo $fname."<br>\n";

if($_REQUEST["delete"]=="Y"){
  delFile($fname,"log");
}else if($_REQUEST["rmdir"]=="Y"){
  unlinkTxt($dir_date,-1);
  rmdir($dir_date);
}else{
  $image = writeFile($fname,$base64_string);
}
function delFile($fileName,$break="ro_test"){
	$file_path = preg_split("/\//",$fileName);

	$tmp_path = $fileName;
	if(file_exists($fileName)){
		unlink($fileName);
	}
	for($i = count($file_path)-1;$i >=0;$i--){
		$v = $file_path[$i];
		if($file_path[$i-1] == $break)break;
		$tmp_path = preg_replace("/\/".$v."/","",$tmp_path);
		if(!is_dir($tmp_path)){
			echo $tmp_path." no exist"."<br>\n";
		}else{
			echo $tmp_path." is exist"."<br>\n";
			rmdir($tmp_path);
		}
	}
}

//unlinkTxt($path, $delday);
//刪除七天以前的txt
function unlinkTxt($path, $rday) {
	$files = glob($path.'/*', GLOB_MARK);
	foreach ($files as $file) {
		//date("Y-m-d H:i:s", filemtime($file)."\n"); //用檔案路徑 取得timestap 再轉換成時間
		//date("Y-m-d H:i:s", mktime(0, 0, 0, date("m"), date("d")-7, date("Y"))) //取得以今天開始七天前的日期
		if (date("Y-m-d H:i:s", filemtime($file)) <= date("Y-m-d H:i:s", mktime(0, 0, 0, date("m"), date("d")-$rday, date("Y")))) {
			unlink($file);//只要日期小於七天前的都砍掉
		} else {
			//print "false";
		}
	}
}
function writeFile($fileName,$file_str){
	$file_path = preg_split("/\//",$fileName);
	//print_r($file_path);
	$tmp_path = "/";
	for($i=0;$i< count($file_path)-1;$i++){
		$v = $file_path[$i];
		if($v=="" || $v=="." || $v =="..")continue;
		$tmp_path .= $v."/"; 
		if(!is_dir($tmp_path)){
			echo $tmp_path." no exist"."<br>\n";
			mkdir($tmp_path,0777);
		}else{
			//echo $tmp_path." is exist"."<br>\n";
		}
	}
	if(file_exists($fileName)){
		unlink($fileName);
	}
	// $fp = fopen(WEB_PATH."/".$fileName,"a+");
	// echo $fileName." : ".fputs($fp,$file_str)." words"."<br>\n";
	// fclose($fp);
  base64_to_jpeg($fileName,$file_str);
	chmod($fileName,0777);
}
function base64_to_jpeg($fileName,$base64_string) {
    // open the output file for writing
    $ifp = fopen( $fileName, "wb" ); 
    // split the string on commas
    // $data[ 0 ] == "data:image/png;base64"
    // $data[ 1 ] == <actual base64 string>
    $data = explode( ',', $base64_string );
    // we could add validation here with ensuring count( $data ) > 1
    fwrite( $ifp, base64_decode( $data[ 1 ] ) );
    // clean up the file resource
    fclose( $ifp ); 
    return $fileName; 
}


function defend_SQL_injection($word) {
	$word = trim($word);
	$word = preg_replace('/\"/','',$word);
	$word = preg_replace('/\'/','',$word);
	$word = preg_replace('/#/','',$word);
	$word = preg_replace('/[\\\\]/','',$word);
	$word = preg_replace('/=/','',$word);
	$word = preg_replace('/--/','',$word);
	$word = preg_replace('/\(/','',$word);
	$word = preg_replace('/\)/','',$word);
	$word = preg_replace('/%/','',$word);
	$word = preg_replace('/\*/','',$word);
	$word = preg_replace('/\|\|/i','',$word);
	$word = preg_replace('/\bor\b/i','',$word);
	$word = preg_replace('/\band\b/i','',$word);
	$word = preg_replace('/\bunion\b/i','',$word);
	$word = preg_replace('/\bupdate\b/i','',$word);
	$word = preg_replace('/\bdelete\b/i','',$word);
	$word = preg_replace('/\bselect\b/i','',$word);
	$word = preg_replace('/\bascii\b/i','',$word);
	$word = preg_replace('/_schema/i','',$word);
	$word = preg_replace('/\s+/','&nbsp;',$word); //在PHP  把它顯示出來html_entity_decode($$key)
	return $word;
}

?>