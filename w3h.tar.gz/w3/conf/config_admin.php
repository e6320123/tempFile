<?php
//開始------定義程式所需常數------
ignore_user_abort(true);// 2017-05-05 強制設定不中斷
// $global_vars = array(
// 	"WEB_HOST"              =>  	$_SERVER['SERVER_NAME'],
// 	"BROWSER_IP"            =>  	"http://".$_SERVER['SERVER_NAME'],
//         "DB_HOST"               =>      "192.168.201.120",
//         "DB_HOST_R"             =>	"192.168.201.121",
//         "DB_HOST_FT"            =>      "192.168.201.120",
// 	"DB_HOST_FT_R"          =>      "192.168.201.121",
//         "DB_WAGERS_HOST_R"      =>      "192.168.201.121",
//         "DB_WAGERS_HOST"        =>      "192.168.201.120",
//         "DB_TICKET_HOST_R"      =>      "192.168.201.121",
//         "DB_TICKET_HOST"        =>      "192.168.201.120",
//         "DB_RECORD_HOST"        =>      "192.168.201.120",
// 	//"JAVA_SERVER_IP"        =>  	"192.168.1.138",
// 	//"JAVA_SERVER_PORT"      =>  	"12050",
// 	//"OPERATION_PORT"        =>  	"12060",
// 	"DB_WAGERS_NAME"        =>  	"tiReport",
// 	"DB_TICKET_NAME"	=>	"tiTicket",
// 	"DB_RECORD_NAME"	=>	"tiMain",
// 	"DB_NAME"               =>  	"tiMain",
// 	"DB_NAME_FT_TMP"        =>  	"tiMain_tmp",
// 	"DB_NAME_FT"            =>	"tibaGame",
// 	"DB_NAME_FT_BO"         =>	"tiboGame",
//         "DB_NAME_FT_RO"         =>      "tiroGame",
//         "DB_NAME_FT_DT"         =>      "tidtGame",
// 	"DB_USER"               =>  	"kang_2php",
// 	"DB_PWD"                =>  	"dfe21ddQ",
// 	"DB_USER_R"             =>  	"kang_2read",
// 	"DB_PWD_R"              =>  	"uUh3icC3",
// 	"WEB_PATH"              =>  	$_SERVER['DOCUMENT_ROOT'],
// 	"FILE_PATH"             =>  	substr($_SERVER['DOCUMENT_ROOT'],0,strlen($_SERVER['DOCUMENT_ROOT'])-3),
// 	"LOGIN_CHECK_TIME"      =>  	600,	//單位秒
// 	"WEB_TIME_ZONE"         =>  -4,
// 	"REMOTE_ADDR"		=>	$_SERVER['REMOTE_ADDR'],
// 	"HTTP_USER_AGENT"	=>	$_SERVER['HTTP_USER_AGENT'],
// 	"HTTP_ACCEPT_LANGUAGE"	=>	$_SERVER['HTTP_ACCEPT_LANGUAGE'],
// 	"MEMBER_DNS"            =>	"192.168.201.119",
// 	"MEMLOGIN_PORT"        	=>	"20325",
// 	"BA_REPORT_IP"      	=>      "192.168.201.119",                // BaReportServer IP
// 	"BA_REPORT_PORT"    	=>      "20011",                          // BaReportServer Port
// 	"BILLBOARD_IP"		=>	"192.168.201.119",					// SOCK_IP
// 	"BILLBOARD_PORT"	=>	"10150",					// SOCK_PORT
// 	"RANK_IP"          =>      "192.168.201.119",                                       // SOCK_IP
//         "RANK_PORT"        =>      "12321",
//         "UNDER_BIG_IP"          =>      "N",
// 	"DOMAIN_NAME"           =>      ".cvssp2017.com"
// );
//  while (list($key, $value) = each($global_vars)) {
//   define($key, $value);
//  }

//結束------定義程式所需常數------

//開始------加入共用含括檔------
	include substr($_SERVER['DOCUMENT_ROOT'],0,strlen($_SERVER['DOCUMENT_ROOT'])-3)."/config/pub_config_admin.php";
  /*
  foreach ($_REQUEST as $key => $value) {
		if (!is_array($value)) $$key = defend_SQL_injection($value);
  }
  */
  foreach ($_REQUEST as $key => $value) {
    if(is_array($value))   {
      foreach($value as $mkey => $mval){
        $value[$mkey] = defend_SQL_injection($mval);
      }
      try{
        $$key = $value;
      }catch(Exception $e){
        $$key = "";
      }
    }else{
      try{
        $$key = defend_SQL_injection($value);
      }catch(Exception $e){
        $$key = "";
      }
    }
  }
	include WEB_PATH."/lib/pub_library.php";
	include WEB_PATH."/lib/mysqllib.php";
//結束------加入共用含括檔------

//開始------會員登入與語系處理------
 //產生獨立uid
 if ($uid=='') $uid=get_userid($uid);
 $tmp_path=end(explode("/",dirname($PHP_SELF)));
 //判斷目前是否為靜態網頁,不是需進行登入動作
 if ($tmp_path != "index_data")
 {
  switch (basename($PHP_SELF)) {
	case "login.php":
		//echo "登入不踢出";
		$MEM_DATA = check_login("super_admin",$uid,$langx);
		if ($MEM_DATA == NULL) exit;
		break;
	case "index.php":
		//echo "登入不踢出";
		$MEM_DATA = check_login("super_admin",$uid,$langx);
		if ($MEM_DATA == NULL) exit;
		break;
	default:
		//echo "登入踢出";
		$MEM_DATA = check_login("super_admin",$uid,$langx);
		if ($MEM_DATA == NULL) exit;
		break;

  }
//判斷登入是否發生錯誤
  if ($MEM_DATA[0] == "ERROR")
  {	echo $MEM_DATA[1];  exit;	}
  //指定操盤者語系
  if (!empty($MEM_DATA))
   $langx = $MEM_DATA['langx'];
  $web_type = 'D';
 }
 //靜態網頁不做登入動作
 else
  $web_type = 'S';
//開始------拆解語系設定------
 if (!empty($langx))	$tmp_lang=explode("-",$langx);
 else			$tmp_lang=explode("-",$_SERVER["HTTP_ACCEPT_LANGUAGE"]);
 //--判斷en開頭的語系皆為英文顯示
 if ($tmp_lang[0]=="en")
  $langx='en-us';
//結束------拆解語系設定------
 switch($langx)
 {
  case "zh-tw":
   $LS="c";
   include(WEB_PATH."/conf/zh-tw_ctl.php");
   break;
  case "zh-cn":
   $LS="g";
   include(WEB_PATH."/conf/zh-cn_ctl.php");
   break;
  case "en-us":
   $LS="e";
   include(WEB_PATH."/conf/en-us_ctl.php");
   break;
  default:
   $LS="c";
   $langx = "zh-tw";
   include(WEB_PATH."/conf/zh-tw_ctl.php");
 }
 define("WEB_PATH_TPL",WEB_PATH."/tpl/control/$langx/");
//結束------會員登入與語系處理------
//開始------加入含括檔------
 include WEB_PATH."/lib/library.ctl.php";
 include WEB_PATH."/lib/class.FastTemplate.php";
 include WEB_PATH."/conf/gameAry.php";
 include WEB_PATH."/conf/config_switchFT.php";
//結束------加入含括檔------

//開始------建立產生程式所需物件------
 $db = new proc_DB(DB_HOST,DB_USER,DB_PWD,DB_NAME);
 $dbr = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);
 $dbFT = new proc_DB(DB_HOST_FT,DB_USER,DB_PWD,DB_NAME_FT);
 $tpl= new FastTemplate(WEB_PATH_TPL);
 register_shutdown_function("Close_All_db");
//結束------建立產生程式所需物件------

 $USER_IP=$_SERVER['REMOTE_ADDR'];
 $PHP_AUTH_USER=$MEM_DATA['username'];

//--------------------------------------------------------------------------------
function defend_SQL_injection($word) {
      $word = trim($word);
      $word = preg_replace('/\"/','',$word);
      $word = preg_replace('/\'/','',$word);
      $word = preg_replace('/#/','',$word);
      $word = preg_replace('/[\\\\]/','',$word);
      $word = preg_replace('/=/','',$word);
      $word = preg_replace('/--/','',$word);
      $word = preg_replace('/\(/','',$word);
      $word = preg_replace('/\)/','',$word);
      $word = preg_replace('/%/','',$word);
      $word = preg_replace('/\*/','',$word);
      $word = preg_replace('/\|\|/i','',$word);
      $word = preg_replace('/\bor\b/i','',$word);
      $word = preg_replace('/\band\b/i','',$word);
      $word = preg_replace('/\bunion\b/i','',$word);
      $word = preg_replace('/\bupdate\b/i','',$word);
      $word = preg_replace('/\bdelete\b/i','',$word);
      $word = preg_replace('/\bselect\b/i','',$word);
      $word = preg_replace('/\bascii\b/i','',$word);
      $word = preg_replace('/_schema/i','',$word);
      $word = preg_replace('/\s+/','&nbsp;',$word); //在PHP  把它顯示出來html_entity_decode($$key)
      return $word;
}
?>