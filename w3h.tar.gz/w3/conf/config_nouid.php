<?php
//開始------定義程式所需常數------
// $global_vars = array(
// 	"WEB_HOST"              =>  	$_SERVER['SERVER_NAME'],
// 	"BROWSER_IP"            =>  	"http://".$_SERVER['SERVER_NAME'],
//         "DB_HOST"               =>      "192.168.201.120",
//         "DB_HOST_R"             =>	"192.168.201.121",
//         "DB_HOST_FT"            =>      "192.168.201.120",
// 	"DB_HOST_FT_R"          =>      "192.168.201.121",
//         "DB_WAGERS_HOST_R"      =>      "192.168.201.121",
//         "DB_WAGERS_HOST"        =>      "192.168.201.120",
//         "DB_TICKET_HOST_R"      =>      "192.168.201.121",
//         "DB_TICKET_HOST"        =>      "192.168.201.120",
//         "DB_RECORD_HOST"        =>      "192.168.201.120",
// 	//"JAVA_SERVER_IP"        =>  	"192.168.1.138",
// 	//"JAVA_SERVER_PORT"      =>  	"12050",
// 	//"OPERATION_PORT"        =>  	"12060",
// 	"DB_WAGERS_NAME"        =>  	"iitiReport",
// 	"DB_TICKET_NAME"	=>	"iitiTicket",
// 	"DB_RECORD_NAME"	=>	"iitiMain",
// 	"DB_NAME"               =>  	"iitiMain",
// 	"DB_NAME_FT_TMP"        =>  	"iitiMain_tmp",
// 	"DB_NAME_FT"            =>	"iitibaGame",
// 	"DB_NAME_FT_BO"         =>	"iitiboGame",
//         "DB_NAME_FT_RO"         =>      "iitiroGame",
//         "DB_NAME_FT_DT"         =>      "iitidtGame",
// 	"DB_USER"               =>  	"kang_2php",
// 	"DB_PWD"                =>  	"dfe21ddQ",
// 	"DB_USER_R"             =>  	"kang_2read",
// 	"DB_PWD_R"              =>  	"uUh3icC3",	
// 	"WEB_PATH"              =>  	$_SERVER['DOCUMENT_ROOT'],
// 	"FILE_PATH"             =>  	substr($_SERVER['DOCUMENT_ROOT'],0,strlen($_SERVER['DOCUMENT_ROOT'])-3),
// 	"LOGIN_CHECK_TIME"      =>  	600,	//單位秒
// 	"WEB_TIME_ZONE"         =>  -4,
// 	"REMOTE_ADDR"		=>	$_SERVER['REMOTE_ADDR'],
// 	"HTTP_USER_AGENT"	=>	$_SERVER['HTTP_USER_AGENT'],
// 	"HTTP_ACCEPT_LANGUAGE"	=>	$_SERVER['HTTP_ACCEPT_LANGUAGE'],
// 	"MEMBER_DNS"            =>	"192.168.201.119",
// 	"MEMLOGIN_PORT"        	=>	"21325",
// 	"BA_REPORT_IP"      	=>      "192.168.201.119",                // BaReportServer IP
// 	"BA_REPORT_PORT"    	=>      "21011",                          // BaReportServer Port
// 	"BILLBOARD_IP"		=>	"192.168.201.119",					// SOCK_IP
// 	"BILLBOARD_PORT"	=>	"10150",					// SOCK_PORT
//         "UNDER_BIG_IP"          =>      "N",
// 	"DOMAIN_NAME"           =>      "iiba566-ctl.cvssp.com"
// );

include substr($_SERVER['DOCUMENT_ROOT'],0,strlen($_SERVER['DOCUMENT_ROOT'])-3)."/config/pub_config_ctl.php";
//  while (list($key, $value) = each($global_vars)) {
//   define($key, $value);
//  }
 /*
foreach ($_REQUEST as $key => $value) {
	if(!is_array($value)) $$key = defend_SQL_injection($value);
}
*/
foreach ($_REQUEST as $key => $value) {
    if(is_array($value))   {
      foreach($value as $mkey => $mval){
        $value[$mkey] = defend_SQL_injection($mval);
      }
      try{
        $$key = $value;
      }catch(Exception $e){
        $$key = "";
      }
    }else{
      try{
        $$key = defend_SQL_injection($value);
      }catch(Exception $e){
        $$key = "";
      }
    }
  }
//結束------定義程式所需常數------

//開始------加入共用含括檔------
 include WEB_PATH."/lib/mysqllib.php";
 include WEB_PATH."/lib/pub_library.php";
 //include WEB_PATH."/lib/class.FastTemplate.php";
 $db = new proc_DB(DB_HOST,DB_USER,DB_PWD,DB_NAME);
 $dbr = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);
 $dbFT = new proc_DB(DB_HOST_FT,DB_USER,DB_PWD,DB_NAME_FT);
 $dbFTR = new proc_DB(DB_HOST_FT_R,DB_USER_R,DB_PWD_R,DB_NAME_FT);
 $dbBOFT = new proc_DB(DB_HOST_FT,BO_DB_USER,BO_DB_PWD,BO_DB_NAME_FT);
 $dbBOFTR = new proc_DB(DB_HOST_FT_R,BO_DB_USER_R,BO_DB_PWD_R,BO_DB_NAME_FT);
 $dbROFT = new proc_DB(DB_HOST_FT,DB_USER,DB_PWD,DB_NAME_FT_RO);
 $dbROFTR = new proc_DB(DB_HOST_FT_R,DB_USER_R,DB_PWD_R,DB_NAME_FT_RO);
 $dbDTFT = new proc_DB(DB_HOST_FT,DB_USER,DB_PWD,DB_NAME_FT_DT);
 $dbDTFTR = new proc_DB(DB_HOST_FT_R,DB_USER_R,DB_PWD_R,DB_NAME_FT_DT);
 //$tpl= new FastTemplate(WEB_PATH_TPL);
 register_shutdown_function("Close_All_db");
//結束------加入共用含括檔------

 $USER_IP=$_SERVER['REMOTE_ADDR'];
 $PHP_AUTH_USER=$MEM_DATA['username'];

//--------------------------------------------------------------------------------
function defend_SQL_injection($word){
	$word = trim($word);
	$word = preg_replace('/\"/','',$word);
	$word = preg_replace('/\'/','',$word);
	$word = preg_replace('/#/','',$word);
	$word = preg_replace('/[\\\\]/','',$word);
	$word = preg_replace('/=/','',$word);
	$word = preg_replace('/--/','',$word);
	$word = preg_replace('/\(/','',$word);
	$word = preg_replace('/\)/','',$word);
	$word = preg_replace('/%/','',$word);
	$word = preg_replace('/\*/','',$word);
	$word = preg_replace('/\|\|/i','',$word);
	$word = preg_replace('/\bor\b/i','',$word);
	$word = preg_replace('/\band\b/i','',$word);
	$word = preg_replace('/\bunion\b/i','',$word);
	$word = preg_replace('/\bupdate\b/i','',$word);
	$word = preg_replace('/\bdelete\b/i','',$word);
	$word = preg_replace('/\bselect\b/i','',$word);
	$word = preg_replace('/\bascii\b/i','',$word);
	$word = preg_replace('/_schema/i','',$word);
	$word = preg_replace('/\s+/','&nbsp;',$word); //在PHP  把它顯示出來html_entity_decode($$key)
	return $word;

}
?>