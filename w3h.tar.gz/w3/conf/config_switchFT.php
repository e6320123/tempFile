<?php

function getSwitchFT($gtype){
		$ret = DB_NAME_FT;
		switch (strtoUpper($gtype)){
				case "BA":
					$ret = DB_NAME_FT;
					break;
				case "BO":
					$ret = DB_NAME_FT_BO;
					break;
				case "RO":
					$ret = DB_NAME_FT_RO;
					break;				
				default:
					$ret = DB_NAME_FT;
					break;
		}
		return $ret;
}



?>
