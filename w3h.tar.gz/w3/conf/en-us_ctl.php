<?php
# @Author: roland
# @Date:   2016-03-16T15:19:12+08:00
# @Last modified by:   roland
# @Last modified time: 2017-05-24T11:51:43+08:00



$LVar = Array();
$LVar["h_meta"]='utf-8';		//網頁語系

$LVar["live_report"]="Live Report";  //0605,Leslie
$LVar["action_record"]="Action Record";   //0612,Leslie
$LVar["real"]="Wagers";
$LVar["LIVE"]="Wagers";
$LVar["C2P"]="C2P";
$LVar["P2P"]="P2P";
$LVar["BA"]="Baccarat";
$LVar["BO"]="Sic Bo";
$LVar["RO"]="Roulette";
$LVar["DT"]="D.T.";
$LVar["GM"]="Jackpot";
$LVar["BS1"]="BS1";
$LVar["FR1"]="FR1";
$LVar["MJ"]="MJ";
$LVar["dealer"]="Dealer";
$LVar["report"]="Report";
$LVar["enquiry"]="Enquiry";
$LVar["profile"]="Profile";
$LVar["other"]="Other";
$LVar["road"]="Road";
$LVar["checkcard"]="Check Card";
$LVar["all_ctl"]="Shuffle Table";
$LVar["v_live"] = "资讯页";
$LVar["v_live_2"] = "新-资讯页";
$LVar["check_pic"]="Check Picture";
$LVar["dealer_us"]="Dealer";
$LVar["cartogram"]="Cartogram";
$LVar["p"]="Yesterday";
$LVar["report_live"]="Bet Monitor";
$LVar["game_report"]="Race report";
$LVar["func_list"]="func list";

$LVar["term_all"]= "Please wait...Report making";
$LVar["date_err"]= "Date range error!!";
/*--------------- 設定/其他 ---------------*/
$LVar['SameCur']='Thie currency code currently used.'; 		//幣值代碼重複
$LVar['chg_currency']='You can only amend the currency once per day.';//一天只可更正幣值一次
$LVar['chg_pass']='Change password access, kindly relogin.';//密碼已更新請重新登入
$LVar['Err_pass']='Password illegal'; 						//密碼不合法
$LVar['Err_pass_api_same_ag']='API代理商密碼 需與 本站密碼不同，請重新輸入！';
$LVar['Err_oldpassword']='Wrong old password'; 				//舊密碼錯誤
$LVar['SameIP']='This IP is in list , USERNAME : ';   		//此 IP 已在排外名單中 , 使用者為
$LVar['NoSearch']='No data for search.'; 					//未搜尋到指定的相關資料
$str_on_line="Onlines"; 									//線上人數
$str_connect_fail="Connect Fail"; 							//連線失敗
$str_ante_err="Connect Fail"; 								//連接失敗
$str_transmit_fail="Transmission Fail."; 					//傳輸失敗
$str_run_time="Running time"; 								//執行時間
$str_millisecond=" millisecond "; 							//毫秒
$CHKLOGIN_IP = array('-------','Management','Make account','Ad interim','Other');
$LVar['FirstCurrency']="First currency will be default to local currency.";	//第一筆資料會預設為本地貨幣
$str_Count_Run="Accounting... /n/nPlease try later.";
$str_err_chg_c_enable="Director is expired or Pause or Suspended,can not change Corporator's state";
$str_err_chg_s_enable="Corporator is expired or Pause or Suspended,can not change Super Agent's state";
$str_err_chg_a_enable="Super Agent is expired or Pause or Suspended,can not change Agent's state";
$str_err_chg_lv_a_enable="Up Agents is expired or Pause or Suspended,can not change Agents's state";
$str_err_chg_m_enable="Agents is expired or Pause or Suspended,can not change Member's state";
$str_acc_ext="This parent username not existed.";
$str_chk_mem_line_er="Can't transfer! member play line not match corprator's setup";
$str_currency_cancel="The Currency Can't cancel!lower level have be used! ";
$str_err_tranacc="Transfer is close";
$str_creditamendment=" credit amendment cannot be lower than agents used credit + amount settled  "; //當代理商信用額度小於所有會員的信用額度的錯誤訊息
$LVar["out_of_range"]="out of range";
/*--------------- 帳號管理 ---------------*/
$str_err_cant_term="If you have done manual term today, you cannot reduce the credit amount.";//本日做過手動結帳，不能調低信用額度
$str_su_corp='Director'; 						//總監
$str_corprator='Corporator'; 					//股東
$str_su_agents='Super Agent'; 					//總代理
$str_agents='Agents'; 							//代理商
$str_level_agents='Agents';                     //代理
$str_level_agents_more='级代理';                 //級代理
$str_members='Member'; 							//會員
$str_mem_count='limitary'; 						//限制人數
$str_credit='Credit Limit'; 					//信用額度
$LVAR["SET"]='Detail'; 							//詳細設定
$str_aforehand="Pre-Setup"; 					//預設
$str_select=" Select "; 						//請選擇 (超帳新增人員)
$str_composite="Percentage";					//成
$str_small=' less than '; 						//小於
$str_small2=' less than '; 						//小於


$str_agency='Agency'; 									//總代理
$str_agent='Agent'; 							//代理商
$str_new_cash=' available point ';						//可用點數
$str_bigger_than=" bigger than ";			//大於
$str_upline='upline';									//上層
$str_over_than=" over than ";					//超過
$str_over=' more than '; 						//大於
$str_must=' must ';								 //必需
$str_input_cash=' Number of insert ';    //輸入點數
$str_lowerline='lowerline';		//下層
$mem_has_no_result="This member has no result wagers.";		//會員有未結算注單
$str_equals=' equals ';		//為
$str_zero='0';
$str_lowerline.$str_new_cash.$str_must.$str_equals.$str_zero;  //下層可用點數需為0


$LVar['START']='Active'; 						//啟用
$LVar['STOP']='Expired'; 						//停用
$str_disuse="Expired"; 							//已停用
$LVar['EDIT']='Edit'; 							//修改
$LVar['DEL']='Delete'; 							//刪除
$LVar["PAUSE"]='Pause'; 						//暫停
$str_pause="Pause"; 							//已暫停
$LVar['CurUsed']='Active'; 						//會員啟用
$LVar['CurNoUse']='Expired'; 					//會員停用
$LVar['Err_account']='The user name iqarcurrently used.'; 			//此帳號以有人使用!!
$str_mem_ext="This username existed."; 								//會員已存在
$str_no_edit="Can not edit status."; 								//無法修改狀態
$mem_wg_msg='This member has wagging record can not change currency.'; 	//會員已有下注不可更改幣值
$mem_wg_err_msg='Credit less than wagers-accumulated today.';  		//信用額度小於今日下注金額
$str_no_del="This member has wagging record can not delete."; 		//該帳號會員已有下注記錄無法刪法
$str_err_c="No account for search!";
$LVar["del"]="Delete";
$LVar["chk_ip"]="Control IP";							//查無類似帳號資料!!!
$LVar['Err_chk_fix8']='total percentage of agency + agent must be full fill , not allow to modify when the percentage are smaller than total percentage of agency + agent';
$LVar['Err_chk_sa_fix8_s']="If Agency & Agent possessed percentage is not equal to ";
$LVar['Err_chk_sa_fix8_e']="%, please re- confirm percentage possession with agent.";
$LVar['Err_chk_a_fix8']="Agency percentage + Agent percentage must be ";
$LVar['Err_chk_co_winloss1'] = "If Corporator + Agency & Agent possessed percentage is not equal to ";
$LVar['Err_chk_co_winloss2'] = "%, please re- confirm percentage possession with agent.";
$LVar['Err_chk_co_winloss_back'] = "Feasible additional of Corporator additional possess can't be smaller than Agency possess + Agent possess leftover possession";
$LVar['Err_chk_co_winloss3'] = "Corporator + Agency percentage + Agent percentage must be ";
/*--------------- 盤面 ---------------*/
$LVar['gmt']='E.S.T';
$LVar['enableY']='CloseTable';
$LVar['enableN']='<font color="#FF0000">OpenTable</font>';
$LVar['insenableY']='CloseInsurance';
$LVar['insenableN']='<font color="#FF0000">OpenInsurance</font>';
$LVar['waterenableY']='CloseNon-Insurance';
$LVar['waterenableN']='<font color="#FF0000">OpenNon-Insurance</font>';
$LVar['newgame']='FirstShoe';
$LVar['chgBoot']='ChangeShoe';
$LVar['open']='Open';
$LVar['result']='Result';
$LVar['gameset']='Set';
$LVar['push']='<font color="#FF0000">Cancel</font>';
$LVar['SafePush']='<font color="#FF0000">Insurance Cancel</font>';
$LVar['SafePushErr']='<font color="#FF0000">Insurance Cancel Error</font>';
$LVar['OpenSafeErr']='<font color="#FF0000">Take Insurance Error</font>';
$LVar['wrongDelear_1']='選取錯誤!!此荷官為 ';
$LVar['wrongDelear_2']=' 桌荷官';
$LVar['ctlResultErr']='Calculate result error';
$LVar['ctlSetFirst']='First shoe';
$LVar['ctlFirstErr']='Set first shoe error';
$LVar['haveDealer']='There is another dealer login at this table ';
$LVar['addRoad']='補路';
$LVar['check']='確定';
/*--------------- report ---------------*/
$LVar["r_all"]="ALL";
//百家樂
$LVar["BA_M"]='<font color="#0000FF">NO</font>';
$LVar["BA_MH"]='<font color="#0000FF">BANKER</font>';
$LVar["BA_MC"]='<font color="#0000FF">PLAYER</font>';
$LVar["BA_MN"]='<font color="#0000FF">TIE</font>';
$LVar["BA_HP"]='<font color="#000000">B.PAIR</font>';
$LVar["BA_CP"]='<font color="#000000">P.PAIR</font>';
$LVar["BA_UN"]='<font color="#000000">SMALL</font>';
$LVar["BA_OV"]='<font color="#000000">BIG</font>';
$LVar["BA_SH"]='<font color="#000000">INS Banker</font>';
$LVar["BA_SC"]='<font color="#000000">INS Player</font>';
$LVar["BA_PH"]='<font color="#000000">GRATUITY</font>';

$LVar["BA_0"]="";
$LVar["BA_1"]="no reason";
$LVar["BA_2"]="Dealer replacement in progress.";
$LVar["BA_3"]="Video streaming has failed. Game will be cancelled. ";
$LVar["BA_4"]="Commencement error. Shoe will be replaced.";
$LVar["BA_5"]="Card(s) exposed. Shoe will be replaced.";
$LVar["BA_6"]="System error. Amendments will be made.";
$LVar["BA_7"]="Fallen unregistered card. Game will be cancelled.";
$LVar["BA_8"]="Card error. Amendment will be made.";
$LVar["BA_9"]="Multiple errors. Game will be cancelled.";
$LVar["BA_10"]="Pause Game For Video Delay.";
$LVar["BA_11"]="Video streaming has problem, current shoe will be change to a new shoe.";
$LVar["BA_12"]="Fallen unregistered card(s). Shoe is replaced.";
$LVar["BA_13"]="Fallen unregistered card(s). Shoe is replaced,aside from \"game will be cancelled\"";
$LVar["BA_14"]="Technical error,amendments will be made";

$str_BA_SH="INS Banker";
$str_BA_SC="INS Player";
$str_BA_NC="NC";
$str_BA_T="T";
//骰寶
$LVar["BO_OUO"]='<font color="#0000FF">BIG</font>';
$LVar["BO_OUU"]='<font color="#0000FF">SMALL</font>';
$LVar["BO_EOO"]='<font color="#0000FF">ODD</font>';
$LVar["BO_EOE"]='<font color="#0000FF">EVEN</font>';
$LVar["BO_OU"]="Big/Small";
$LVar["BO_EO"]="Odd/Even";
$LVar["BO_CT"]="3 Dice total";
$LVar["BO_TP"]="Specific Double";
$LVar["BO_RP"]="Specific Triple";
$LVar["BO_RP16"]="Any Triple";
$LVar["BO_OP"]="Single Die";
$LVar["BO_CN"]="2 Dice Combinations";

$LVar["BO_0"]="This game is paused";
$LVar["BO_1"]="Dealer replacement in progress";
$LVar["BO_2"]="Video streaming has failed. Game will be cancelled";
$LVar["BO_3"]="System error. Amendments will be made";
$LVar["BO_4"]="Dice will be re-tumbled";
$LVar["BO_5"]="Dome malfunctions. Game will be cancelled";
$LVar["BO_6"]="Attn: After 3 games,this table will be closed for maintenance.";
$LVar["BO_7"]="Technical error,amendments will be made";
$LVar["BO_8"]="Technical error, Dice will be  re-tumbled";
$LVar["BO_9"]="Technical error,game will be cancelled";
$LVar["BO_10"]="Lean/Cocked Dice dice will be re-tumbled";
$LVar["BO_11"]="Video streaming failed,dices will be tumble";
//輪盤
$LVar["RO_OUO"]='<font color="#0000FF">BIG</font>';
$LVar["RO_OUU"]='<font color="#0000FF">SMALL</font>';
$LVar["RO_EOO"]='<font color="#0000FF">ODD</font>';
$LVar["RO_EOE"]='<font color="#0000FF">EVEN</font>';
$LVar["RO_RBR"]='<font color="#DD0000">RED</font>';
$LVar["RO_RBB"]="BLACK";
$LVar["RO_OU"]="Big/Small";
$LVar["RO_EO"]="Odd/Even";
$LVar["RO_N"]="Straight";
$LVar["RO_I"]="Split";
$LVar["RO_E13"]="Street (0,1,2)(0,2,3)";
$LVar["RO_E"]="Street";
$LVar["RO_J"]="Corner";
$LVar["RO_J0"]="Corner(0,1,2,3)";
$LVar["RO_X"]="Section Betting";
$LVar["RO_T"]="Line";
$LVar["RO_H"]="Columns";
$LVar["RO_V"]="Dozens";
$LVar["RO_RB"]="Red/Black";

$LVar["RO_0"]="This game is paused";
$LVar["RO_1"]="Dealer replacement in progress";
$LVar["RO_2"]="Video streaming has failed. Game will be cancelled";
$LVar["RO_3"]="System error. Amendments will be made";
$LVar["RO_4"]="Invalid spin. Ball will be re-spinned";
$LVar["RO_5"]="Roulette wheel malfunctions. Game will be cancelled";
$LVar["RO_6"]="Attn: This table will be closed after 3 games for maintenance.";
$LVar["RO_7"]="Technical error,amendments will be made";
$LVar["RO_8"]="Technical error,game will be cancelled";
$LVar["RO_9"]="Technical error, ball will be red-spinned";
//龍虎
$LVar["DT_MC"]='<font color="#0000FF">Dragon</font>';
$LVar["DT_MH"]='<font color="#0000FF">Tiger</font>';
$LVar["DT_MN"]='<font color="#0000FF">Tie</font>';


//老虎機
$LVar["GM_1"]= "Chinese Chess";
$LVar["GM_2"]= "Chinese Chess 3D";
$LVar["GM_3"]= "Oh! My Gods";
$LVar["GM_4"]= "Fruit Planet";
$LVar["GM_7"]= "Ocean Paradise";
$LVar["GM_5"]= "Kung-Fu Combat";
$LVar["GM_8"]= "Panda & Dragoness";
$LVar["GM_9"]= "Chinese Zodiac";
$LVar["GM_10"]= "The Doggy Job";
$LVar["GM_13"]= "I am Tuhao";
$LVar["GM_12"]= "Pretty Sun";
$LVar["GM_14"]= "Mahjong King";
$LVar["GM_6"]= "Gangster Cat";
$LVar["GM_11"]= "Shanghai Legend";
$LVar["GM_15"]= "Naughty Landlord";
$LVar["GM_16"]= "Journey to the West";

$LVar["gMH"]='<font color="#0000FF">BANKER</font>';
$LVar["gMC"]='<font color="#0000FF">PLAYER</font>';
$LVar["gMN"]='<font color="#0000FF">TIE</font>';
$LVar["gHP"]='<font color="#000000">B.PAIR</font>';
$LVar["gCP"]='<font color="#000000">P.PAIR</font>';
$LVar["gUN"]='<font color="#000000">SMALL</font>';
$LVar["gOV"]='<font color="#000000">BIG</font>';
$LVar["gOUO"]='<font color="#0000FF">BIG</font>';
$LVar["gOUU"]='<font color="#0000FF">SMALL</font>';
$LVar["gEOO"]='<font color="#0000FF">ODD</font>';
$LVar["gEOE"]='<font color="#0000FF">EVEN</font>';
$LVar["gRBR"]='<font color="#DD0000">RED</font>';
$LVar["gDMH"]='<font color="#0000FF">Dragon</font>';
$LVar["gDMC"]='<font color="#0000FF">Tiger</font>';
$LVar["gDMN"]='<font color="#0000FF">Tie</font>';
$LVar["gRBB"]="BLACK";
$LVar["gOU"]="Big/Small";
$LVar["gEO"]="Odd/Even";
$LVar["gCT"]="3 Dice total";
$LVar["gTP"]="Specific Double";
$LVar["gRP"]="Specific Triple";
$LVar["gRP16"]="Any Triple";
$LVar["gOP"]="Single Die";
$LVar["gCN"]="2 Dice Combinations";
$LVar["gN"]="Straight";
$LVar["gI"]="Split";
$LVar["gE13"]="Street (0,1,2)(0,2,3)";
$LVar["gE"]="Street";
$LVar["gJ"]="Corner";
$LVar["gJ0"]="Corner(0,1,2,3)";
$LVar["gX"]="Section Betting";
$LVar["gT"]="Line";
$LVar["gH"]="Columns";
$LVar["gV"]="Dozens";
$LVar["gRB"]="Red/Black";


$LVar["class"]="Type";
$LVar["statistics"]="Total";
$str_score_finish="All results are entered";
$str_score_unfinished="result(s) not yet entered";
$str_ordertype_HK="HK";
$str_ordertype_MY="MY";
$str_grp_FT=Array("","Main Leagues","Secondary Leagues","Normal Leagues","Cups","Group1","Group2","Group3","Group4","Group5","Group6");
$str_grp_BK=Array("","NBA","NCAA","WNBA","International","Group1","Group2","Group3","Group4","Group5","Group6");
$str_grp_BS=Array("","MLB","NPB","International","Intercontinental","Group1","Group2","Group3","Group4","Group5","Group6");
$str_grp_TN=Array("","Main Leagues","Secondary Leagues","Normal Leagues","Cups","Group1","Group2","Group3","Group4","Group5","Group6");
$str_grp_VB=Array("","Main Leagues","Secondary Leagues","Normal Leagues","Cups","Group1","Group2","Group3","Group4","Group5","Group6");
$str_setxt=array('Q1','Q2`','Q3`','Q4');
$str_chk_ip="this account is unable to use this function";
$str_able_data="able data";
$str_no_data="No data";
$str_up_pd="Other";
$str_deposit="Deposit";
$str_withdraw="WithDraw";
$str_paytype_H="Manual";
$str_paytype_C="Credit";
$str_paytype_A="Auto";

$str_pay_H_O=" Term-Credit ";
$str_pay_H=" Term ";
$str_pay_L=$str_pay_H;
$str_pay_E="Expired ";
$str_pay_D="Delete ";

$str_multiple="Agent's Multiplier";
$str_wgold="Dis.";
$str_xratio="Rolling Discount";
$str_cash_limit="Cash Limit Less than 0";
$str_term_success="Term Success !!";
$str_insurance="Insurance ";
$str_linmitbs="Big/Small suspended :";
$str_limit_pair="B/P Pair suspended :";
/*--------------- ohterset ---------------*/
$LVar["live_set1"] = "Wagers";
$LVar["live_set2"] = "Wagers member";
$LVar["user_bet"] = "User Bet Search";
$LVar["game"] = "Race";
$LVar["lock_game_ag"] = "Table Set";
$LVar["LobbyType1"] = "Normal";
$LVar["LobbyType9"] = "Race";
$LVar["set_game_mem"] = "Race member";
$str_GameGroupFull = "this group is full";
$str_more_gold="Maxcredit can't less than today's wager";
$LVar["report_percent"] = "Report%";
$LVar["report_ledger"] = "General Report";
$LVar["str_df_winloss"] = "Preset possess%";
$LVar["str_edit_winloss"] = "Edit %";
$LVar["initiative"] = "Free-Will Sign up";    //主動報名
$LVar["billboard"] = "list" ;    //排行榜
$LVar["set_game_table"] = "Table Set";
$LVar["set_rank"] = "Time Set";
$LVar["load_rank"] = "Leaderboard";

$str_OUO="Big";
$str_OUU="Small";
$str_EOO="Odd";
$str_EOE="Even";
$LVar["str_report_switch"] = "Report Switch";
$LVar["str_longerr"]="Login ";
$LVar["ch_OK"]="Modify Success !!";
$LVar["str_limit_people"]="人数限制";
$LVar["str_set_game"]="游戏设定";
$LVar["str_enquiry"]="单号分析期数";
$LVar["str_show_online"]="online人数";
$LVar["str_show_emergency"]="紧急停止下注";
$LVar["str_show_now_people_count"]="目前人数";
$str_mobile="mobile";


//0926,Leslie
$str_max_winloss="Percentage takings can not be more than maximum setting."; //超過總成數最大值
$str_min_winloss="Percentage taking less than minimum setting"; 				//小於總成數最小值
$str_afresh_sel="Please select again."; 							//請重新選擇
$str_than_winloss="Percentage can not greater than";	//成數設定不可大於
$str_max_win="maximum";//超過總成數最大值
$str_small_winloss="Percentage can not smaller than "; //"成數不可小於";


$str_winloss_canused="winloss that can used";  //可使用成數
$str_equal="must  equals ";  //必需等於
$str_prasent ="%";  //成
$str_cor_winloss="Must be equals Winloss";  //必需等於成數

$str_do = ",";
$str_go_agent_chk = "Please confirm percentage of agents";
$str_winloss_max = "Maximum percentage";
$str_winloss_min = "Minimum percentage";
$str_co_min_more_max = "Minimum percentage of corporator can't bigger than maximum percentage of corporator";
$str_max_min_back = "Feasible addtional of corporator can't smaller than minimun percentage of corporator";

//1231,Tom
$str_edit_winloss_str_err = "StartDate Error!";
$str_edit_winloss_end_err = "EndDate Error!";
$str_edit_winloss_st_en_err = "StartDate < EndData Error!";
$str_edit_winloss_sta_and_Equal = "StartDate = EndDate Error!";
$str_edit_winloss_OK = "O.K.";
$str_edit_winloss_str = "Date Error Please (YYYY-MM-DD mm:ss)";
$str_user_bet = "Date Error Please Again";


//--------------- flash dealer ---------------
$LVar["BA_MSG_STOP0"]=" Select reason";
$LVar["BA_MSG_STOP1"]="no reason";
$LVar["BA_MSG_STOP2"]="Dealer replacement in progress.";
$LVar["BA_MSG_STOP3"]="Video streaming failed.Game will be canceled,shoe will be replaced.";
$LVar["BA_MSG_STOP4"]="Commencement error. Shoe will be replaced.";
$LVar["BA_MSG_STOP5"]="Card(s) exposed. Shoe will be replaced.";
$LVar["BA_MSG_STOP6"]="System error. Amendments will be made.";
$LVar["BA_MSG_STOP7"]="Fallen unregistered card. Game will be canceled. Shoe will be replaced.";
$LVar["BA_MSG_STOP8"]="Card error. Amendment will be made.";
$LVar["BA_MSG_STOP9"]="Multiple errors. Game will be canceled.";
$LVar["BA_MSG_STOP10"]="Pause Game For Video Delay.";
$LVar["BA_MSG_STOP11"]="Video streaming has problem, current shoe will be change to a new shoe.";


$LVar["BO_MSG_STOP0"]="This game is paused";
$LVar["BO_MSG_STOP1"]="Dealer replacement in progress";
$LVar["BO_MSG_STOP2"]="Video streaming has failed. Game will be canceled";
$LVar["BO_MSG_STOP3"]="System error. Amendments will be made";
$LVar["BO_MSG_STOP4"]="Dice will be re-tumbled";
$LVar["BO_MSG_STOP5"]="Dome malfunctions. Game will be canceled";
$LVar["BO_MSG_STOP6"]="Attn: After 3 games,this table will be closed for maintenance.";
$LVar["BO_MSG_STOP7"]="Technical error,amendments will be made";
$LVar["BO_MSG_STOP8"]="Technical error, Dice will be  re-tumbled";
$LVar["BO_MSG_STOP9"]="Technical error,game will be canceled";
$LVar["BO_MSG_STOP10"]="Lean/Cocked Dice dice will be re-tumbled";
$LVar["BO_MSG_STOP11"]="Video streaming failed,dices will be tumble";

$LVar["RO_MSG_STOP0"]="This game is paused";
$LVar["RO_MSG_STOP1"]="Dealer replacement in progress";
$LVar["RO_MSG_STOP2"]="Video streaming has failed. Game will be canceled";
$LVar["RO_MSG_STOP3"]="System error. Amendments will be made";
$LVar["RO_MSG_STOP4"]="Invalid spin. Ball will be re-spinned";
$LVar["RO_MSG_STOP5"]="Roulette wheel malfunctions. Game will be canceled";
$LVar["RO_MSG_STOP6"]="Attn: After 3 games,this table will be closed for maintenance.";
$LVar["RO_MSG_STOP7"]="Technical error,amendments will be made";
$LVar["RO_MSG_STOP8"]="Technical error,game will be canceled";
$LVar["RO_MSG_STOP9"]="Technical error, ball will be red-spinned";
$LVar["RO_MSG_STOP10"]="VIDEO STREAMING FAILED, BALL WILL BE SPIN";
//--------------- flash dealer ---------------

//總控端live
$str_vip_y="确定要设为VIP桌?";
$str_vip_n="确定取消VIP桌?";
$str_cancel="是否取消";
$str_cancel2="所有未结算注单?";
$str_table="T";
$str_boots="B";
$str_game="G";


//內部設定列表
$LVar["maintainlist_ctl_SW"]="控端白名單開關";
$LVar["rejectlist_ctl_SW"]="控端阻擋地區開關";
$LVar["maintainlist_ag_SW"]="管理端白名單開關";
$LVar["rejectlist_ag_SW"]="管理端阻擋地區開關";
$LVar["maintainlist_mem_SW"]="會員端白名單開關";
$LVar["rejectlist_mem_SW"]="會員端阻擋地區開關";
?>