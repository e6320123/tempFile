<?php
# @Author: roland
# @Date:   2013-11-20T11:03:04+08:00
# @Last modified by:   roland
# @Last modified time: 2017-05-24T10:54:31+08:00




//$gameAry = Array("BA","BO","RO","GM");
// $gameAry = Array("BA","BO","RO");
$gameAry = Array("BA");
?>