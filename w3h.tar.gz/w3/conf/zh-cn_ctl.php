<?php
# @Author: roland
# @Date:   2016-03-16T15:19:02+08:00
# @Last modified by:   roland
# @Last modified time: 2017-05-24T11:51:22+08:00



$LVar = Array();
$LVar["h_meta"]='utf-8';		//网页语系
$companySI='皇家线上娱乐城';

$LVar["live_report"]="即时报表";  //0605,Leslie
$LVar["action_record"]="行为记录";   //0612,Leslie
$LVar["real"]="游戏项目";
$LVar["LIVE"]="真人游戏";
$LVar["C2P"]="C2P游戏";
$LVar["P2P"]="P2P游戏";
$LVar["BA"]="百家乐";
$LVar["BO"]="骰宝";
$LVar["RO"]="轮盘";
$LVar["DT"]="龙虎";
$LVar["GM"]="老虎机";
$LVar["BS1"]="斗牛";
$LVar["FR1"]="水果盘";
$LVar["MJ"]="麻将";
$LVar["FLH"]="斗地主";
$LVar["dealer"]="荷官";
$LVar["report"]="报表";
$LVar["enquiry"]="单号分析";
$LVar["profile"]="下注参数";
$LVar["BOprofile"]="骰宝下注参数";
$LVar["other"]="其他参数";
$LVar["road"]="路纸";
$LVar["checkcard"]="验牌介面";
$LVar["all_ctl"]="总控端";
$LVar["v_live"] = "资讯页";
$LVar["v_live_2"] = "新-资讯页";
$LVar["check_pic"]="检查图片";
$LVar["dealer_us"]="荷官帐号";
$LVar["cartogram"]="即时统计";
$LVar["p"]="已开赛";
$LVar["report_live"]="下注监控";
$LVar["game_report"]="比赛报表";
$LVar["func_list"]="内部设定列表";

$LVar['SameCur']='币值代码重复';
$LVar['chg_currency']='一天只可更正币值一次';
$LVar['chg_pass']='密码已更新请重新登入';
$LVar['Err_pass']='密码不合法';
$LVar['Err_pass_api_same_ag']='API代理商密码 需与 本站密码不同，请重新输入！';
$LVar['Err_oldpassword']='旧密码错误';
$LVar['SameIP']='此 IP 已在会员名单中 , 使用者为 ';
$LVar['NoSearch']='未搜寻到指定的相关资料';
$str_on_line="线上人数";
$str_connect_fail="连线失败";
$str_ante_err="连接失败";
$str_transmit_fail="传输失败";
$str_run_time="执行时间";
$str_millisecond="毫秒";
$CHKLOGIN_IP = array('-------','操盘','作帐','临时','其它');
$LVar['FirstCurrency']="第一笔资料会预设为本地货币";
$str_Count_Run="结果计算中, 请稍后输入!";
$LVar["out_of_range"]="超出查询范围";
$LVar["term_all"]= "此功能暂停服务,请稍候...";
$LVar["date_err"]= "日期区间错误!!";
/*--------------- 帐号管理 ---------------*/
$str_err_chg_c_enable="总监为停用/暂停/禁止登入状态，无法变更股东的状态";
$str_err_chg_s_enable="股东为停用/暂停/禁止登入状态，无法变更总代理的状态";
$str_err_chg_a_enable="总代理为停用/暂停/禁止登入状态，无法变更代理商的状态";
$str_err_chg_lv_a_enable="上层代理商为停用/暂停/禁止登入状态，无法变更代理商的状态";
$str_err_chg_m_enable="代理商为停用/暂停/禁止登入状态，无法变更会员的状态";
$str_creditamendment="调降额度不可以小于代理商已用额度+当日已结帐额度";
$str_acc_ext="此母帐号不存在";
$str_chk_mem_line_er="不可转移！会员Line别不符合此股东的Line别设定";
$str_err_tranacc="移转帐号未开放";
$str_currency_cancel="所取消之币别，下层已使用！！！";
$str_su_corp='总监';
$str_corprator='股东';
$str_su_agents='总代理';
$str_agents='代理商';
$str_level_agents='代理';
$str_level_agents_more='级代理';
$str_members='会员';
$str_mem_count='限制人数';
$str_cash='结帐额度';
$str_credit='信用额度';
$str_aforehand="预设";
$str_select='请选择'; 	//超帐新增人员
$str_composite="成";
$str_small='小于';
$str_small2='小于';
//$str_over='超过';


$str_agency=$str_su_agents;
$str_agent=$str_agents;
$str_new_cash='可用点数';
$str_upline='上层';
$str_bigger_than="大于";
$str_over_than="超过";
$str_over='大于';
$str_must='必需';
$str_input_cash='输入点数';
$str_lowerline='下层';
$mem_has_no_result="会员有未结算注单";
$str_equals='为';
$str_zero='0';
$str_lowerline.$str_new_cash.$str_must.$str_equals.$str_zero;  //下层可用点数需为0


$LVar['START']='启用';
$LVar['STOP']='停用';
$str_disuse="已停用";
$LVar['EDIT']='修改';
$LVar['DEL']='删除';
$LVar["PAUSE"]='暂停';
$str_pause="已暂停";
$LVar['CurUsed']='会员启用';
$LVar['CurNoUse']='会员停用';
$LVar['Err_account']='此帐号已有人使用!!';
$str_mem_ext="会员已存在";
$str_no_edit="无法修改状态";
$mem_wg_msg='会员已有下注不可更改币值';
$mem_wg_err_msg='信用额度小于今日下注金额';
$str_no_del="该帐号会员已有下注记录无法删除";
$str_err_c="查无类似帐号资料!";
$LVar["del"]="删除";
$LVar["chk_ip"]="控端IP";
$LVar['Err_chk_fix8']='总代+代理 未占满成数，不能修改小于未占满的成数';
$LVar['Err_chk_sa_fix8_s']="总代成数+代理成数不等于";
$LVar['Err_chk_sa_fix8_e']="%，请至代理商确认成数";
$LVar['Err_chk_a_fix8']="总代成数+代理成数必须等于";
$LVar['Err_chk_co_winloss1'] = "股东+总代成数+代理成数不等于";
$LVar['Err_chk_co_winloss2'] = "成，请至代理商确认成数";
$LVar['Err_chk_co_winloss_back']="股东回归成数，不得小于总代+代理未占满成数";
$LVar['Err_chk_co_winloss3'] = "股东+总代成数+代理成数必须等于";
/*--------------- 盘面 ---------------*/
$LVar['gmt']='美东时间';
$LVar['enableY']='关闭牌桌';
$LVar['enableN']='<font color="#FF0000">开启牌桌</font>';
$LVar['insenableY']='关闭保险';
$LVar['insenableN']='<font color="#FF0000">开启保险</font>';
$LVar['waterenableY']='关闭免佣';
$LVar['waterenableN']='<font color="#FF0000">开启免佣</font>';
$LVar['newgame']='首靴';
$LVar['chgBoot']='换靴';
$LVar['open']='开放';
$LVar['result']='结果';
$LVar['gameset']='参数设定';
$LVar['refer_record']='记录查询';
$LVar['push']='<font color="#FF0000">流局取消</font>';
$LVar['SafePush']='<font color="#FF0000">保险流局取消</font>';
$LVar['SafePushErr']='<font color="#FF0000">保险流局取消错误</font>';
$LVar['OpenSafeErr']='<font color="#FF0000">保险开放错误</font>';
$LVar['wrongDelear_1']='选取错误!!此荷官为 ';
$LVar['wrongDelear_2']=' 桌荷官';
$LVar['haveDealer']='此桌已有荷官';
$LVar["SET"]='设定';
$LVar['addRoad']='補路';
$LVar['check']='確定';
/*--------------- report ---------------*/
$LVar["r_all"]="全部";
//百家乐
$LVar["BA_M"]='<font color="#0000FF">不</font>';
$LVar["BA_MH"]='<font color="#0000FF">庄</font>';
$LVar["BA_MC"]='<font color="#0000FF">闲</font>';
$LVar["BA_MN"]='<font color="#0000FF">和</font>';
$LVar["BA_HP"]='<font color="#000000">庄对</font>';
$LVar["BA_CP"]='<font color="#000000">闲对</font>';
$LVar["BA_UN"]='<font color="#000000">小</font>';
$LVar["BA_OV"]='<font color="#000000">大</font>';
$LVar["BA_SH"]='<font color="#000000">保险庄</font>';
$LVar["BA_SC"]='<font color="#000000">保险闲</font>';
$LVar["BA_PH"]='<font color="#0000FF">小費</font>';

$LVar["BA_0"]="";
$LVar["BA_1"]="原因无";
$LVar["BA_2"]="交换荷官";
$LVar["BA_3"]="影像输送出现故障,此局将流局。";
$LVar["BA_4"]="开牌程序错误,更换新靴!";
$LVar["BA_5"]="不正常亮牌,更换新靴!";
$LVar["BA_6"]="系统错误,进行修正!";
$LVar["BA_7"]="未经扫描的牌掉落,此局作废,更换新靴!";
$LVar["BA_8"]="发牌程序错误,进行修正!";
$LVar["BA_9"]="多种错误,此局作废!";
$LVar["BA_10"]="因视讯延迟,暂停游戏!";
$LVar["BA_11"]="影像输送出现故障,此靴将更换新靴!";
$LVar["BA_12"]="未扫描而掉落的牌,此靴将更换新靴";
$LVar["BA_13"]="未扫描而掉落的牌,此靴将更换新靴,此局流局";
$LVar["BA_14"]="技术性错误,将修正";

$str_BA_SH="保险庄";
$str_BA_SC="保险闲";
$str_BA_NC="免佣";
$str_BA_T="传统";
//骰宝
$LVar["BO_OUO"]='<font color="#0000FF">大</font>';
$LVar["BO_OUU"]='<font color="#0000FF">小</font>';
$LVar["BO_EOO"]='<font color="#0000FF">单</font>';
$LVar["BO_EOE"]='<font color="#0000FF">双</font>';
$LVar["BO_OU"]="大小";
$LVar["BO_EO"]="单双";
$LVar["BO_CT"]="点数";
$LVar["BO_TP"]="长牌";
$LVar["BO_RP"]="围骰";
$LVar["BO_RP16"]="全骰";
$LVar["BO_OP"]="三军";
$LVar["BO_CN"]="短牌";

$LVar["BO_0"]="游戏暂停";
$LVar["BO_1"]="交换荷官";
$LVar["BO_2"]="影像输送出现故障,此局将流局";
$LVar["BO_3"]="系统错误,进行修正!";
$LVar["BO_4"]="点数将重新骰过!";
$LVar["BO_5"]="因骰盅无法正常操作，此局将流局!";
$LVar["BO_6"]="敬请注意：本桌将在3局之后进行关桌维修!";
$LVar["BO_7"]="技术性错误,将修正";
$LVar["BO_8"]="技术性错误,此局将重骰";
$LVar["BO_9"]="技术性错误,此局流局";
$LVar["BO_10"]="骰子重叠,此局将重骰";
$LVar["BO_11"]="视讯中断，骰子将重骰";
//轮盘
$LVar["RO_OUO"]='<font color="#0000FF">大</font>';
$LVar["RO_OUU"]='<font color="#0000FF">小</font>';
$LVar["RO_EOO"]='<font color="#0000FF">单</font>';
$LVar["RO_EOE"]='<font color="#0000FF">双</font>';
$LVar["RO_RBR"]='<font color="#DD0000">红</font>';
$LVar["RO_RBB"]="黑";
$LVar["RO_OU"]="大小";
$LVar["RO_EO"]="单双";
$LVar["RO_N"]="直注";
$LVar["RO_I"]="分注";
$LVar["RO_E13"]="三数";
$LVar["RO_E"]="街注";
$LVar["RO_J"]="角注";
$LVar["RO_J0"]="四注";
$LVar["RO_X"]="区注";
$LVar["RO_T"]="线注";
$LVar["RO_H"]="列注";
$LVar["RO_V"]="一打注";
$LVar["RO_RB"]="红黑";

$LVar["RO_0"]="游戏暂停";
$LVar["RO_1"]="交换荷官";
$LVar["RO_2"]="影像输送出现故障,此局将流局";
$LVar["RO_3"]="系统错误,进行修正!";
$LVar["RO_4"]="此次发球无效，将重新转盘发球";
$LVar["RO_5"]="转盘无法正常操作，此局作废";
$LVar["RO_6"]="敬请注意：本桌将在3局之后进行关桌维修!";
$LVar["RO_7"]="技术性错误,将修正";
$LVar["RO_8"]="技术性错误,此局流局";
$LVar["RO_9"]="技术性错误,此局将重新发球";

//龙虎
$LVar["DT_MC"]='<font color="#0000FF">龙</font>';
$LVar["DT_MH"]='<font color="#0000FF">虎</font>';
$LVar["DT_MN"]='<font color="#0000FF">和</font>';

//老虎機
$LVar["GM_1"]= "楚汉争霸";
$LVar["GM_2"]= "楚汉争霸 3D";
$LVar["GM_3"]= "仙翁游";
$LVar["GM_4"]= "水果星球";
$LVar["GM_7"]= "海底乐园";
$LVar["GM_5"]= "功夫擂台";
$LVar["GM_8"]= "胖达与龙妹";
$LVar["GM_9"]= "十二生笑";
$LVar["GM_10"]= "狗胆妙算";
$LVar["GM_13"]= "我是土豪";
$LVar["GM_12"]= "Q环传";
$LVar["GM_14"]= "国士无双";
$LVar["GM_6"]= "极道猫";
$LVar["GM_11"]= "上海风云";
$LVar["GM_15"]= "斗地主";
$LVar["GM_16"]= "西游";


$LVar["gMH"]='<font color="#0000FF">庄</font>';
$LVar["gMC"]='<font color="#0000FF">闲</font>';
$LVar["gMN"]='<font color="#0000FF">和</font>';
$LVar["gHP"]='<font color="#000000">庄对</font>';
$LVar["gCP"]='<font color="#000000">闲对</font>';
$LVar["gUN"]='<font color="#000000">小</font>';
$LVar["gOV"]='<font color="#000000">大</font>';
$LVar["gOUO"]='<font color="#0000FF">大</font>';
$LVar["gOUU"]='<font color="#0000FF">小</font>';
$LVar["gEOO"]='<font color="#0000FF">单</font>';
$LVar["gEOE"]='<font color="#0000FF">双</font>';
$LVar["gRBR"]='<font color="#DD0000">红</font>';
$LVar["gRBB"]="黑";
$LVar["gOU"]="大小";
$LVar["gEO"]="单双";
$LVar["gCT"]="点数";
$LVar["gTP"]="长牌";
$LVar["gRP"]="围骰";
$LVar["gRP16"]="全骰";
$LVar["gOP"]="三军";
$LVar["gCN"]="短牌";
$LVar["gN"]="直注";
$LVar["gI"]="分注";
$LVar["gE13"]="三数";
$LVar["gE"]="街注";
$LVar["gJ"]="角注";
$LVar["gJ0"]="四注";
$LVar["gX"]="区注";
$LVar["gT"]="线注";
$LVar["gH"]="列注";
$LVar["gV"]="一打注";
$LVar["gRB"]="红黑";


$LVar["class"]="类别";
$LVar["statistics"]="统计";
$str_free_spin_start="免费游戏触发红利";
$str_free_spin="免费游戏";
$str_gamble="比倍";
$str_lose="输";
$str_win='赢';

$LVar["gBS"]="一般下注";
$LVar["gDR"]="平局下注";
$LVar["gWR"]="挑战";
$LVar["gSD"]="投降";

$str_chk_ip="帐号无法使用此功能";
$str_able_data="有记录";
$str_no_data="无记录";
$str_up_pd="其他比分";
$str_deposit="存入";
$str_withdraw="提出";
$str_paytype_H="手动结";
$str_paytype_C="信用结";
$str_paytype_A="自动结";

$str_pay_H_O="結帳-初始";
$str_pay_H="结帐";
$str_pay_L=$str_pay_H;
$str_pay_E="停用";
$str_pay_D="删除";

$str_multiple="代理商倍数";
$str_wgold="退水";
$str_xratio="洗码退水";
$str_cash_limit="可用余额小于0!!!";
$str_term_success="结帐完成 !!";
$str_insurance="保险";
$str_linmitbs="大小局数:";
$str_limit_pair="庄闲对局数:";
/*--------------- ohterset ---------------*/
$LVar["live_set1"] = "即时金额";
$LVar["live_set2"] = "警示会员";
$LVar["user_bet"] = "会员下注查询";
$LVar["game"] = "比赛";
$LVar["lock_game_ag"] = "桌设定";
$LVar["LobbyType1"] = "一般";
$LVar["LobbyType9"] = "比赛";
$LVar["set_game_mem"] = "参赛会员";
$LVar["initiative"] = "主动报名";
$LVar["billboard"] = "排行榜";

$LVar["set_game_table"] = "设定比赛桌";
$LVar["set_rank"] = "比赛时间设定";
$LVar["load_rank"] = "排行榜";

$str_GameGroupFull = "此群组已满";
$str_more_gold="信用额度不得少于今日交易金额";
$LVar["report_percent"] = "总帐百分比";
$LVar["report_ledger"] = "总表";
$LVar["str_df_winloss"] = "预设成数";
$LVar["str_edit_winloss"] = "成数修改";
$LVar["str_report_switch"] = "Report Switch";
$LVar["str_longerr"]="登入控管";
$LVar["ch_OK"]="修改成功 !!";
$LVar["str_limit_people"]="人数限制";
$LVar["str_set_game"]="游戏设定";
$LVar["str_enquiry"]="单号分析期数";
$LVar["str_show_online"]="online人数";
$LVar["str_show_emergency"]="紧急停止下注";
$LVar["str_show_now_people_count"]="目前人数";
$str_mobile="手机";


//0926,Leslie
$str_max_winloss="超过总成数最大值";
$str_min_winloss="小于总成数最小值";
$str_afresh_sel="请重新选择";
$str_than_winloss="成数设定不可大于";
$str_max_winloss="超过总成数最大值";
$str_small_winloss="成数不可小于";


$str_winloss_canused="可使用成数";
$str_equal="必需等于";
$str_prasent ="成";
$str_cor_winloss="必需等于成数";

$str_do = ",";
$str_go_agent_chk = "请至代理商确认成数";
$str_winloss_max = "占成上限";
$str_winloss_min = "最低占成";
$str_co_min_more_max = "股东最低占成不得高于股东占成上限";
$str_max_min_back = "股东回归成数，不得小于股东最低成数";

//1231,Tom
$str_edit_winloss_str_err = "开始时间不可为过去时间，或日期错误";
$str_edit_winloss_end_err = "结束时间不可为过去时间，或日期错误";
$str_edit_winloss_st_en_err = "结束时间不可小于开始时间";
$str_edit_winloss_sta_and_Equal = "开始时间与结束时间不可相同";
$str_edit_winloss_OK = "输入完成";
$str_edit_winloss_str = "日期格式错误，请依照(YYYY-MM-DD mm:ss)格式输入";
$str_user_bet = "格式错误，请重新输入！";

//--------------- flash dealer ---------------
$LVar["BA_MSG_STOP0"]="选择原因";
$LVar["BA_MSG_STOP1"]="原因无";
$LVar["BA_MSG_STOP2"]="交换荷官";
$LVar["BA_MSG_STOP3"]="影像输送出现故障,此局将流局,将更换新靴。";
$LVar["BA_MSG_STOP4"]="开牌程序错误,更换新靴!";
$LVar["BA_MSG_STOP5"]="不正常亮牌,更换新靴!";
$LVar["BA_MSG_STOP6"]="系统错误,进行修正!";
$LVar["BA_MSG_STOP7"]="未经扫描的牌掉落,此局作废,更换新靴!";
$LVar["BA_MSG_STOP8"]="发牌程序错误,进行修正!";
$LVar["BA_MSG_STOP9"]="多种错误,此局作废!";
$LVar["BA_MSG_STOP10"]="因视讯延迟,暂停游戏!";
$LVar["BA_MSG_STOP11"]="影像输送出现故障,此靴将更换新靴!";


$LVar["BO_MSG_STOP0"]="游戏暂停";
$LVar["BO_MSG_STOP1"]="交换荷官";
$LVar["BO_MSG_STOP2"]="影像输送出现故障,此局将流局";
$LVar["BO_MSG_STOP3"]="系统错误,进行修正!";
$LVar["BO_MSG_STOP4"]="点数将重新骰过!";
$LVar["BO_MSG_STOP5"]="因骰盅无法正常操作，此局将流局!";
$LVar["BO_MSG_STOP6"]="敬请注意：本桌将在3局之后进行关桌维修!";
$LVar["BO_MSG_STOP7"]="技术性错误,将修正";
$LVar["BO_MSG_STOP8"]="技术性错误,此局将重骰";
$LVar["BO_MSG_STOP9"]="技术性错误,此局流局";
$LVar["BO_MSG_STOP10"]="骰子重叠,此局将重骰";
$LVar["BO_MSG_STOP11"]="视讯中断，骰子将重骰";

$LVar["RO_MSG_STOP0"]="游戏暂停";
$LVar["RO_MSG_STOP1"]="交换荷官";
$LVar["RO_MSG_STOP2"]="影像输送出现故障,此局将流局";
$LVar["RO_MSG_STOP3"]="系统错误,进行修正!";
$LVar["RO_MSG_STOP4"]="此次发球无效，将重新转盘发球";
$LVar["RO_MSG_STOP5"]="转盘无法正常操作，此局作废";
$LVar["RO_MSG_STOP6"]="敬请注意：本桌将在3局之后进行关桌维修!";
$LVar["RO_MSG_STOP7"]="技术性错误,将修正";
$LVar["RO_MSG_STOP8"]="技术性错误,此局流局";
$LVar["RO_MSG_STOP9"]="技术性错误,此局将重新发球";
$LVar["RO_MSG_STOP10"]="视讯中断，将继续打球";
//--------------- flash dealer ---------------

//總控端live
$str_vip_y="确定要设为VIP桌?";
$str_vip_n="确定取消VIP桌?";
$str_cancel="是否取消";
$str_cancel2="所有未结算注单?";
$str_table="桌";
$str_boots="靴";
$str_game="局";

//內部設定列表
$LVar["maintainlist_ctl_SW"]="控端白名單開關";
$LVar["rejectlist_ctl_SW"]="控端阻擋地區開關";
$LVar["maintainlist_ag_SW"]="管理端白名單開關";
$LVar["rejectlist_ag_SW"]="管理端阻擋地區開關";
$LVar["maintainlist_mem_SW"]="會員端白名單開關";
$LVar["rejectlist_mem_SW"]="會員端阻擋地區開關";
?>
