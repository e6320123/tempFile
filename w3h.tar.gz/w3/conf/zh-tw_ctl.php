<?php
# @Author: roland
# @Date:   2016-03-16T15:18:27+08:00
# @Last modified by:   roland
# @Last modified time: 2017-05-25T14:59:37+08:00



$LVar = Array();
$LVar["h_meta"]='utf-8';		//網頁語系
$companySI='皇家線上娛樂城';

$LVar["live_report"]="即時報表";  //0605,Leslie
$LVar["action_record"]="行為記錄";   //0612,Leslie
$LVar["real"]="遊戲項目";
$LVar["LIVE"]="真人遊戲";
$LVar["C2P"]="C2P遊戲";
$LVar["P2P"]="P2P遊戲";
$LVar["BA"]="百家樂";
$LVar["BO"]="骰寶";
$LVar["RO"]="輪盤";
$LVar["DT"]="龍虎";
$LVar["GM"]="老虎機";
$LVar["BS1"]="鬥牛";
$LVar["FR1"]="水果盤";
$LVar["MJ"]="麻將";
$LVar["FLH"]="鬥地主";
$LVar["dealer"]="荷官";
$LVar["report"]="報表";
$LVar["enquiry"]="單號分析";
$LVar["profile"]="下注參數";
$LVar["BOprofile"]="骰寶下注參數";
$LVar["other"]="其他參數";
$LVar["road"]="路紙";
$LVar["checkcard"]="驗牌介面";
$LVar["all_ctl"]="總控端";
$LVar["v_live"] = "資訊頁";
$LVar["v_live_2"] = "新-資訊頁";
$LVar["check_pic"]="檢查圖片";
$LVar["dealer_us"]="荷官帳號";
$LVar["cartogram"]="即時統計";
$LVar["p"]="已開賽";
$LVar["report_live"]="下注監控";
$LVar["game_report"]="比賽報表";
$LVar["func_list"]="內部設定列表";

$LVar['SameCur']='幣值代碼重複';
$LVar['chg_currency']='一天只可更正幣值一次';
$LVar['chg_pass']='密碼已更新請重新登入';
$LVar['Err_pass']='密碼不合法';
$LVar['Err_pass_api_same_ag']='API代理商密碼 需與 本站密碼不同，請重新輸入！';
$LVar['Err_oldpassword']='舊密碼錯誤';
$LVar['SameIP']='此 IP 已在會員名單中 , 使用者為 ';
$LVar['NoSearch']='未搜尋到指定的相關資料';
$str_on_line="線上人數";
$str_connect_fail="連線失敗";
$str_ante_err="連接失敗";
$str_transmit_fail="傳輸失敗";
$str_run_time="執行時間";
$str_millisecond="毫秒";
$CHKLOGIN_IP = array('-------','操盤','作帳','臨時','其它');
$LVar['FirstCurrency']="第一筆資料會預設為本地貨幣";
$str_Count_Run="結果計算中, 請稍後輸入!";
$LVar["out_of_range"]="超出查詢範圍";
$LVar["term_all"]= "此功能暫停服務,請稍候...";
$LVar["date_err"]= "日期區間錯誤!!";
/*--------------- 帳號管理 ---------------*/
$str_err_cant_term="本日做過手動結帳，不能調低信用額度";
$str_err_chg_c_enable="總監為停用/暫停/禁止登入狀態，無法變更股東的狀態";
$str_err_chg_s_enable="股東為停用/暫停/禁止登入狀態，無法變更總代理的狀態";
$str_err_chg_a_enable="總代理為停用/暫停/禁止登入狀態，無法變更代理商的狀態";
$str_err_chg_lv_a_enable="上層代理商為停用/暫停/禁止登入狀態，無法變更代理商的狀態";
$str_err_chg_m_enable="代理商為停用/暫停/禁止登入狀態，無法變更會員的狀態";
$str_creditamendment="調降額度不可以小於代理商已用額度+當日已結帳額度";
$str_acc_ext="此母帳號不存在";
$str_chk_mem_line_er="不可轉移！會員Line別不符合此股東的Line別設定";
$str_err_tranacc="移轉帳號未開放";
$str_currency_cancel="所取消之幣別，下層已使用！！！";
$str_su_corp='總監';
$str_corprator='股東';
$str_su_agents='總代理';
$str_agents='代理商';
$str_level_agents='代理';
$str_level_agents_more='級代理';
$str_members='會員';
$str_mem_count='限制人數';
$str_cash='結帳額度';
$str_credit='信用額度';
$str_aforehand="預設";
$str_select='請選擇'; 	//超帳新增人員
$str_composite="成";
$str_small='小於';
$str_smal2='小於';
//$str_over='超過';


$str_agency=$str_su_agents;
$str_agent=$str_agents;
$str_new_cash='可用點數';
$str_upline='上層';
$str_bigger_than="大於";
$str_over_than="超過";
$str_over='大於';
$str_must='必需';
$str_input_cash='輸入點數';
$str_lowerline='下層';
$mem_has_no_result="會員有未結算注單";
$str_equals='為';
$str_zero='0';
$str_lowerline.$str_new_cash.$str_must.$str_equals.$str_zero;  //下層可用點數需為0


$LVar['START']='啟用';
$LVar['STOP']='停用';
$str_disuse="已停用";
$LVar['EDIT']='修改';
$LVar['DEL']='刪除';
$LVar["PAUSE"]='暫停';
$str_pause="已暫停";
$LVar['CurUsed']='會員啟用';
$LVar['CurNoUse']='會員停用';
$LVar['Err_account']='此帳號已有人使用!!';
$str_mem_ext="會員已存在";
$str_no_edit="無法修改狀態";
$mem_wg_msg='會員已有下注不可更改幣值';
$mem_wg_err_msg='信用額度小於今日下注金額';
$str_no_del="該帳號會員已有下注記錄無法刪除";
$str_err_c="查無類似帳號資料!";
$LVar["del"]="刪除";
$LVar["chk_ip"]="控端IP";
$LVar['Err_chk_fix8']='總代+代理 未佔滿成數，不能修改小於未佔滿的成數';
$LVar['Err_chk_sa_fix8_s']="總代成數+代理成數不等於";
$LVar['Err_chk_sa_fix8_e']="%，請至代理商確認成數";
$LVar['Err_chk_a_fix8']="總代成數+代理成數必須等於";
$LVar['Err_chk_co_winloss1'] = "股東+總代成數+代理成數不等於";
$LVar['Err_chk_co_winloss2'] = "成，請至代理商確認成數";
$LVar['Err_chk_co_winloss_back'] = "股東回歸成數，不得小於總代+代理 未佔滿成數";
$LVar['Err_chk_co_winloss3'] = "股東+總代成數+代理成數必須等於";
/*--------------- 盤面 ---------------*/
$LVar['gmt']='美東時間';
$LVar['enableY']='關閉牌桌';
$LVar['enableN']='<font color="#FF0000">開啟牌桌</font>';
$LVar['insenableY']='關閉保險';
$LVar['insenableN']='<font color="#FF0000">開啟保險</font>';
$LVar['waterenableY']='關閉免佣';
$LVar['waterenableN']='<font color="#FF0000">開啟免佣</font>';
$LVar['newgame']='首靴';
$LVar['chgBoot']='換靴';
$LVar['open']='開放';
$LVar['result']='結果';
$LVar['gameset']='參數設定';
$LVar['refer_record']='記錄查詢';
$LVar['push']='<font color="#FF0000">流局取消</font>';
$LVar['SafePush']='<font color="#FF0000">保險流局取消</font>';
$LVar['SafePushErr']='<font color="#FF0000">保險流局取消錯誤</font>';
$LVar['OpenSafeErr']='<font color="#FF0000">保險開放錯誤</font>';
$LVar['wrongDelear_1']='選取錯誤!!此荷官為 ';
$LVar['wrongDelear_2']=' 桌荷官';
$LVar['haveDealer']='此桌已有荷官';
$LVar["SET"]='設定';
$LVar['addRoad']='補路';
$LVar['check']='確定';
/*--------------- report ---------------*/
$LVar["r_all"]="全部";
//百家樂
$LVar["BA_M"]='<font color="#0000FF">不</font>';
$LVar["BA_MH"]='<font color="#0000FF">莊</font>';
$LVar["BA_MC"]='<font color="#0000FF">閒</font>';
$LVar["BA_MN"]='<font color="#0000FF">和</font>';
$LVar["BA_HP"]='<font color="#000000">莊對</font>';
$LVar["BA_CP"]='<font color="#000000">閒對</font>';
$LVar["BA_UN"]='<font color="#000000">小</font>';
$LVar["BA_OV"]='<font color="#000000">大</font>';
$LVar["BA_SH"]='<font color="#000000">保險莊</font>';
$LVar["BA_SC"]='<font color="#000000">保險閒</font>';
$LVar["BA_PH"]='<font color="#0000FF">小費</font>';



$LVar["BA_0"]="";
$LVar["BA_1"]="原因無";
$LVar["BA_2"]="交換荷官";
$LVar["BA_3"]="影像輸送出現故障,此局將流局。";
$LVar["BA_4"]="開牌程序錯誤,更換新靴!";
$LVar["BA_5"]="不正常亮牌,更換新靴!";
$LVar["BA_6"]="系統錯誤,進行修正!";
$LVar["BA_7"]="未經掃描的牌掉落,此局作廢,更換新靴!";
$LVar["BA_8"]="發牌程序錯誤,進行修正!";
$LVar["BA_9"]="多種錯誤,此局作廢!";
$LVar["BA_10"]="因視訊延遲,暫停遊戲!";
$LVar["BA_11"]="影像輸送出現故障,此靴將更換新靴!";
$LVar["BA_12"]="未掃描而掉落的牌,此靴將更換新靴";
$LVar["BA_13"]="未掃描而掉落的牌,此靴將更換新靴,此局流局";
$LVar["BA_14"]="技術性錯誤,將修正";



$str_BA_SH="保險莊";
$str_BA_SC="保險閒";
$str_BA_NC="免佣";
$str_BA_T="傳統";
//骰寶
$LVar["BO_OUO"]='<font color="#0000FF">大</font>';
$LVar["BO_OUU"]='<font color="#0000FF">小</font>';
$LVar["BO_EOO"]='<font color="#0000FF">單</font>';
$LVar["BO_EOE"]='<font color="#0000FF">雙</font>';
$LVar["BO_OU"]="大小";
$LVar["BO_EO"]="單雙";
$LVar["BO_CT"]="點數";
$LVar["BO_TP"]="長牌";
$LVar["BO_RP"]="圍骰";
$LVar["BO_RP16"]="全骰";
$LVar["BO_OP"]="三軍";
$LVar["BO_CN"]="短牌";



$LVar["BO_0"]="遊戲暫停";
$LVar["BO_1"]="交換荷官";
$LVar["BO_2"]="影像輸送出現故障,此局將流局";
$LVar["BO_3"]="系統錯誤,進行修正!";
$LVar["BO_4"]="點數將重新骰過!";
$LVar["BO_5"]="因骰盅無法正常操作，此局將流局!";
$LVar["BO_6"]="敬請注意：本桌將在3局之後進行關桌維修!";
$LVar["BO_7"]="技術性錯誤,將修正";
$LVar["BO_8"]="技術性錯誤,此局將重骰";
$LVar["BO_9"]="技術性錯誤,此局流局";
$LVar["BO_10"]="骰子重疊,此局將重骰";
$LVar["BO_11"]="視訊中斷，骰子將重骰";

//輪盤
$LVar["RO_OUO"]='<font color="#0000FF">大</font>';
$LVar["RO_OUU"]='<font color="#0000FF">小</font>';
$LVar["RO_EOO"]='<font color="#0000FF">單</font>';
$LVar["RO_EOE"]='<font color="#0000FF">雙</font>';
$LVar["RO_RBR"]='<font color="#DD0000">紅</font>';
$LVar["RO_RBB"]="黑";
$LVar["RO_OU"]="大小";
$LVar["RO_EO"]="單雙";
$LVar["RO_N"]="直注";
$LVar["RO_I"]="分注";
$LVar["RO_E13"]="三數";
$LVar["RO_E"]="街注";
$LVar["RO_J"]="角注";
$LVar["RO_J0"]="四注";
$LVar["RO_X"]="區注";
$LVar["RO_T"]="線注";
$LVar["RO_H"]="列注";
$LVar["RO_V"]="一打注";
$LVar["RO_RB"]="紅黑";


$LVar["RO_0"]="遊戲暫停";
$LVar["RO_1"]="交換荷官";
$LVar["RO_2"]="影像輸送出現故障,此局將流局";
$LVar["RO_3"]="系統錯誤,進行修正!";
$LVar["RO_4"]="此次發球無效，將重新轉盤發球";
$LVar["RO_5"]="轉盤無法正常操作，此局作廢";
$LVar["RO_6"]="敬請注意：本桌將在3局之後進行關桌維修!";
$LVar["RO_7"]="技術性錯誤,將修正";
$LVar["RO_8"]="技術性錯誤,此局流局";
$LVar["RO_9"]="技術性錯誤,此局將重新發球";

//龍虎
$LVar["DT_MC"]='<font color="#0000FF">龍</font>';
$LVar["DT_MH"]='<font color="#0000FF">虎</font>';
$LVar["DT_MN"]='<font color="#0000FF">和</font>';

//老虎機
$LVar["GM_1"]= "楚漢爭霸";
$LVar["GM_2"]= "楚漢爭霸 3D";
$LVar["GM_3"]= "仙翁遊";
$LVar["GM_4"]= "水果星球";
$LVar["GM_7"]= "海底樂園";
$LVar["GM_5"]= "功夫擂台";
$LVar["GM_8"]= "胖達與龍妹";
$LVar["GM_9"]= "十二生笑";
$LVar["GM_10"]= "狗膽妙算";
$LVar["GM_13"]= "我是土豪";
$LVar["GM_12"]= "Q環傳";
$LVar["GM_14"]= "國士無雙";
$LVar["GM_6"]= "極道貓";
$LVar["GM_11"]= "上海風雲";
$LVar["GM_15"]= "鬥地主";
$LVar["GM_16"]= "西遊";

$LVar["gMH"]='<font color="#0000FF">莊</font>';
$LVar["gMC"]='<font color="#0000FF">閒</font>';
$LVar["gMN"]='<font color="#0000FF">和</font>';
$LVar["gHP"]='<font color="#000000">莊對</font>';
$LVar["gCP"]='<font color="#000000">閒對</font>';
$LVar["gUN"]='<font color="#000000">小</font>';
$LVar["gOV"]='<font color="#000000">大</font>';
$LVar["gOUO"]='<font color="#0000FF">大</font>';
$LVar["gOUU"]='<font color="#0000FF">小</font>';
$LVar["gEOO"]='<font color="#0000FF">單</font>';
$LVar["gEOE"]='<font color="#0000FF">雙</font>';
$LVar["gRBR"]='<font color="#DD0000">紅</font>';
$LVar["gRBB"]="黑";
$LVar["gOU"]="大小";
$LVar["gEO"]="單雙";
$LVar["gCT"]="點數";
$LVar["gTP"]="長牌";
$LVar["gRP"]="圍骰";
$LVar["gRP16"]="全骰";
$LVar["gOP"]="三軍";
$LVar["gCN"]="短牌";
$LVar["gN"]="直注";
$LVar["gI"]="分注";
$LVar["gE13"]="三數";
$LVar["gE"]="街注";
$LVar["gJ"]="角注";
$LVar["gJ0"]="四注";
$LVar["gX"]="區注";
$LVar["gT"]="線注";
$LVar["gH"]="列注";
$LVar["gV"]="一打注";
$LVar["gRB"]="紅黑";


$LVar["class"]="類別";
$LVar["statistics"]="統計";
$str_free_spin_start="免費遊戲觸發紅利";
$str_free_spin="免費遊戲";
$str_gamble="比倍";
$str_lose="輸";
$str_win='贏';

$LVar["gBS"]="一般下注";
$LVar["gDR"]="平局下注";
$LVar["gWR"]="挑戰";
$LVar["gSD"]="投降";

$str_chk_ip="帳號無法使用此功能";
$str_able_data="有記錄";
$str_no_data="無記錄";
$str_up_pd="其他比分";
$str_deposit="存入";
$str_withdraw="提出";
$str_paytype_H="手動結";
$str_paytype_C="信用結";
$str_paytype_A="自動結";

$str_pay_H_O="結帳-初始";
$str_pay_H="結帳";
$str_pay_L=$str_pay_H;
$str_pay_E="停用";
$str_pay_D="刪除";

$str_multiple="代理商倍數";
$str_wgold="退水";
$str_xratio="洗碼退水";
$str_cash_limit="可用餘額小於0!!!";
$str_term_success="結帳完成 !!";
$str_insurance="保險";
$str_linmitbs="大小局數:";
$str_limit_pair="莊閒對局數:";
/*--------------- ohterset ---------------*/
$LVar["live_set1"] = "即時金額";
$LVar["live_set2"] = "警示會員";
$LVar["user_bet"] = "會員下注查詢";
$LVar["game"] = "比賽";
$LVar["lock_game_ag"] = "桌設定";
$LVar["LobbyType1"] = "一般";
$LVar["LobbyType9"] = "比賽";
$LVar["set_game_mem"] = "參賽會員";
$LVar["initiative"] = "主動報名";
$LVar["billboard"] = "排行榜";

$LVar["set_game_table"] = "設定比賽桌";
$LVar["set_rank"] = "比賽時間設定";
$LVar["load_rank"] = "排行榜";

$str_GameGroupFull = "此群組已滿";
$str_more_gold="信用額度不得少於今日交易金額";
$LVar["report_percent"] = "總帳百分比";
$LVar["report_ledger"] = "總表";
$LVar["str_df_winloss"] = "預設成數";
$LVar["str_edit_winloss"] = "成數修改";
$LVar["str_report_switch"] = "Report Switch";
$LVar["str_longerr"]="登入控管";
$LVar["str_limit_people"]="人數限制";
$LVar["str_set_game"]="遊戲設定";
$LVar["ch_OK"]="修改成功 !!";
$LVar["str_enquiry"]="單號分析期數";
$LVar["str_show_online"]="online人數";
$LVar["str_show_emergency"]="緊急停止下注";
$LVar["str_show_now_people_count"]="目前人數";
$str_mobile="手機";


//0926,Leslie
$str_max_winloss="超過總成數最大值";
$str_min_winloss="小於總成數最小值";
$str_afresh_sel="請重新選擇";
$str_than_winloss="成數設定不可大於";
$str_max_win="最大成數";
$str_small_winloss="成數不可小於";


$str_winloss_canused="可使用成數";
$str_equal="必需等於";
$str_prasent ="成";
$str_cor_winloss="必需等於成數";

$str_do = ",";
$str_go_agent_chk = "請至代理商確認成數";
$str_winloss_max = "佔成上限";
$str_winloss_min = "最低佔成";
$str_co_min_more_max = "股東最低佔成不得高於股東佔成上限";
$str_max_min_back = "股東回歸成數，不得小於股東最低成數";



//1231,Tom
$str_edit_winloss_str_err = "開始時間不可為過去時間，或日期錯誤";
$str_edit_winloss_end_err = "結束時間不可為過去時間，或日期錯誤";
$str_edit_winloss_st_en_err = "結束時間不可小於開始時間";
$str_edit_winloss_sta_and_Equal = "開始時間與結束時間不可相同";
$str_edit_winloss_OK = "輸入完成";
$str_edit_winloss_str = "日期格式錯誤，請依照(YYYY-MM-DD mm:ss)格式輸入";

$str_user_bet = "格式錯誤，請重新輸入！";

//--------------- flash dealer ---------------
$LVar["BA_MSG_STOP0"]="選擇原因";
$LVar["BA_MSG_STOP1"]="原因無";
$LVar["BA_MSG_STOP2"]="交換荷官";
$LVar["BA_MSG_STOP3"]="影像輸送出現故障,此局將流局,將更換新靴。";
$LVar["BA_MSG_STOP4"]="開牌程序錯誤,更換新靴!";
$LVar["BA_MSG_STOP5"]="不正常亮牌,更換新靴!";
$LVar["BA_MSG_STOP6"]="系統錯誤,進行修正!";
$LVar["BA_MSG_STOP7"]="未經掃描的牌掉落,此局作廢,更換新靴!";
$LVar["BA_MSG_STOP8"]="發牌程序錯誤,進行修正!";
$LVar["BA_MSG_STOP9"]="多種錯誤,此局作廢!";
$LVar["BA_MSG_STOP10"]="因視訊延遲,暫停遊戲!";
$LVar["BA_MSG_STOP11"]="影像輸送出現故障,此靴將更換新靴!";
$LVar["BA_MSG_STOP12"]="BA test";


$LVar["BO_MSG_STOP0"]="遊戲暫停";
$LVar["BO_MSG_STOP1"]="交換荷官";
$LVar["BO_MSG_STOP2"]="影像輸送出現故障,此局將流局";
$LVar["BO_MSG_STOP3"]="系統錯誤,進行修正!";
$LVar["BO_MSG_STOP4"]="點數將重新骰過!";
$LVar["BO_MSG_STOP5"]="因骰盅無法正常操作，此局將流局!";
$LVar["BO_MSG_STOP6"]="敬請注意：本桌將在3局之後進行關桌維修!";
$LVar["BO_MSG_STOP7"]="技術性錯誤,將修正";
$LVar["BO_MSG_STOP8"]="技術性錯誤,此局將重骰";
$LVar["BO_MSG_STOP9"]="技術性錯誤,此局流局";
$LVar["BO_MSG_STOP10"]="骰子重疊,此局將重骰";
$LVar["BO_MSG_STOP11"]="視訊中斷，骰子將重骰";
$LVar["BO_MSG_STOP12"]="BO test";


$LVar["RO_MSG_STOP0"]="遊戲暫停";
$LVar["RO_MSG_STOP1"]="交換荷官";
$LVar["RO_MSG_STOP2"]="影像輸送出現故障,此局將流局";
$LVar["RO_MSG_STOP3"]="系統錯誤,進行修正!";
$LVar["RO_MSG_STOP4"]="此次發球無效，將重新轉盤發球";
$LVar["RO_MSG_STOP5"]="轉盤無法正常操作，此局作廢";
$LVar["RO_MSG_STOP6"]="敬請注意：本桌將在3局之後進行關桌維修!";
$LVar["RO_MSG_STOP7"]="技術性錯誤,將修正";
$LVar["RO_MSG_STOP8"]="技術性錯誤,此局流局";
$LVar["RO_MSG_STOP9"]="技術性錯誤,此局將重新發球";
$LVar["RO_MSG_STOP10"]="視訊中斷，將繼續打球";
$LVar["RO_MSG_STOP11"]="RO test";

//--------------- flash dealer ---------------
$LVar["CLEAR_OK"]="排行榜已清除 請至排行榜歷史資料查詢";
$LVar["DATA_OK"]="比賽時間設定完成";
$LVar["NOTEND"]="比賽時間未結束，請稍候操作";



//總控端live
$str_vip_y="確定要設為VIP桌?";
$str_vip_n="確定取消VIP桌?";
$str_cancel="是否取消";
$str_cancel2="所有未結算注單?";
$str_table="桌";
$str_boots="靴";
$str_game="局";

//內部設定列表
$LVar["maintainlist_ctl_SW"]="控端白名單開關";
$LVar["rejectlist_ctl_SW"]="控端阻擋地區開關";
$LVar["maintainlist_ag_SW"]="管理端白名單開關";
$LVar["rejectlist_ag_SW"]="管理端阻擋地區開關";
$LVar["maintainlist_mem_SW"]="會員端白名單開關";
$LVar["rejectlist_mem_SW"]="會員端阻擋地區開關";


?>