<?php
// include($_SERVER['DOCUMENT_ROOT']."/app/control/dealer_index.php");
$first="Y";
if ($username=="-1" && $password =="-1") {
  $first="N";
}
if ($isapp!="") {
  if ($autoLogin=="") $autoLogin = "Y";
}
include("dealer_index.html");
echo "<script>\n";
echo "var isapp='".$isapp."';\n";
echo "var appusername='".$username."';\n";
echo "var apppassword='".$password."';\n";
echo "var appfirst='".$first."';\n";
echo "var autoLogin='".$autoLogin."';\n";
echo "</script>\n";
?>
