
var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;

var casino = "COD";
var videoSettingCopy = "";
var domainSettingCopy = "";
var casinoAry = Object();
var domainAry = Object();
var domainNameAry = ["Ph", "CDN", "Internet"];

var retrySocketTimeout = 0;
function init() {
	
	listenEvt.addOnClick("submit", util.getSpan(document, "submit"), this, null);
	listenEvt.addOnClick("submit_domain", util.getSpan(document, "submit_domain"), this, null);
	listenEvt.addOnClick("COD_button", util.getSpan(document, "COD_button"), this, null);
	listenEvt.addOnClick("OKADA_button", util.getSpan(document, "OKADA_button"), this, null);
	listenEvt.addOnClick("RWM_button", util.getSpan(document, "RWM_button"), this, null);
	listenEvt.addOnClick("CH_1_P", util.getSpan(document, "CH1_P"), this, null);
	listenEvt.addOnClick("CH_1_S", util.getSpan(document, "CH1_S"), this, null);
	listenEvt.addOnClick("CH_1_C", util.getSpan(document, "CH1_C"), this, null);
	listenEvt.addOnClick("CH_2_P", util.getSpan(document, "CH2_P"), this, null);
	listenEvt.addOnClick("CH_2_S", util.getSpan(document, "CH2_S"), this, null);
	listenEvt.addOnClick("CH_2_C", util.getSpan(document, "CH2_C"), this, null);
	listenEvt.addOnClick("CH_3_P", util.getSpan(document, "CH3_P"), this, null);
	listenEvt.addOnClick("CH_3_S", util.getSpan(document, "CH3_S"), this, null);
	listenEvt.addOnClick("CH_3_C", util.getSpan(document, "CH3_C"), this, null);
	listenEvt.addOnClick("Domain_1_P", util.getSpan(document, "Domain1_P"), this, null);
	listenEvt.addOnClick("Domain_1_S", util.getSpan(document, "Domain1_S"), this, null);
	listenEvt.addOnClick("Domain_1_C", util.getSpan(document, "Domain1_C"), this, null);
	listenEvt.addOnClick("Domain_2_P", util.getSpan(document, "Domain2_P"), this, null);
	listenEvt.addOnClick("Domain_2_S", util.getSpan(document, "Domain2_S"), this, null);
	listenEvt.addOnClick("Domain_2_C", util.getSpan(document, "Domain2_C"), this, null);
	listenEvt.addOnClick("Domain_3_P", util.getSpan(document, "Domain3_P"), this, null);
	listenEvt.addOnClick("Domain_3_S", util.getSpan(document, "Domain3_S"), this, null);
	listenEvt.addOnClick("Domain_3_C", util.getSpan(document, "Domain3_C"), this, null);
	var Path = "./adjustVideo/adjustVideo.php";
	var code = "uid=" + uid;
	code += "&action=query";
	util.addPostPHP("showTable", Path, code, this);
}

function listenCenter(eventName, listenData) {
	if(eventName.indexOf("CH")!=-1){
		var info = eventName.split("_");
		var videoCh = info[1];
		var videoFrom = info[2];
		casinoAry[casino]["CH"+videoCh] = videoFrom;
		showChannels();
	}
	else if(eventName.indexOf("Domain")!=-1){
		var info = eventName.split("_");
		var videoCh = info[1];
		videoCh = videoCh -1;
		var videoFrom = info[2];
		domainAry["Domain"][domainNameAry[videoCh]] = videoFrom;
		showChannels();
	}
	else if (eventName == "COD_button") {
		casino = "COD";
		refreshChannels();
	}
	else if (eventName == "OKADA_button") {
		casino = "OKADA";
		refreshChannels();
	}
	else if (eventName == "RWM_button") {
		casino = "RWM";
		refreshChannels();
	}
	else if (eventName == "submit") {
		if (confirm("確定送出?")) {
			var Path = "./adjustVideo/adjustVideo.php";
			var code = "uid=" + uid;
			code += "&action=submit";
			code += "&newVideoSetting=" + encode(JSON.stringify(casinoAry));
			util.addPostPHP("showTable", Path, code, this);
		}else{
			return;
		}
	}
	else if (eventName == "submit_domain") {
		if (confirm("確定送出?")) {
			var Path = "./adjustVideo/adjustVideo.php";
			var code = "uid=" + uid;
			code += "&action=submitDomain";
			code += "&newVideoSetting=" + encode(JSON.stringify(domainAry));
			util.addPostPHP("showTable", Path, code, this);
		}else{
			return;
		}
	}
}

function setToDefault(){
	var Path = "./adjustVideo/adjustVideo.php";
	var code = "uid=" + uid;
	code += "&action=default";
	util.addPostPHP("", Path, code, this);
}

function handleChannelData(videoChannelInfo){
	if(!videoChannelInfo){
		var eachCasino = Object();
		eachCasino["CH1"] = "P";
		eachCasino["CH2"] = "S";
		eachCasino["CH3"] = "C";
		casinoAry["COD"] = eachCasino;
		var eachCasino = Object();
		eachCasino["CH1"] = "P";
		eachCasino["CH2"] = "S";
		eachCasino["CH3"] = "C";
		casinoAry["OKADA"] = eachCasino;
		var eachCasino = Object();
		eachCasino["CH1"] = "P";
		eachCasino["CH2"] = "S";
		eachCasino["CH3"] = "C";
		casinoAry["RWM"] = eachCasino;
		var eachCasino = Object();
		eachCasino[domainNameAry[0]] = "P";
		eachCasino[domainNameAry[1]] = "C";
		eachCasino[domainNameAry[2]] = "S";
		domainAry["Domain"] = eachCasino;
		showChannels();
	}else if(!videoChannelInfo["text_video"] || !videoChannelInfo["text_domain"]){
		if(!videoChannelInfo["text_video"] ){
			var eachCasino = Object();
			eachCasino["CH1"] = "P";
			eachCasino["CH2"] = "S";
			eachCasino["CH3"] = "C";
			casinoAry["COD"] = eachCasino;
			var eachCasino = Object();
			eachCasino["CH1"] = "P";
			eachCasino["CH2"] = "S";
			eachCasino["CH3"] = "C";
			casinoAry["OKADA"] = eachCasino;
			var eachCasino = Object();
			eachCasino["CH1"] = "P";
			eachCasino["CH2"] = "S";
			eachCasino["CH3"] = "C";
			casinoAry["RWM"] = eachCasino;
		}else{
			videoSettingCopy = decode(videoChannelInfo["text_video"]);
			casinoAry = getJsonObj(videoSettingCopy);
		}
		if(!videoChannelInfo["text_domain"]){
			var eachCasino = Object();
			eachCasino[domainNameAry[0]] = "P";
			eachCasino[domainNameAry[1]] = "C";
			eachCasino[domainNameAry[2]] = "S";
			domainAry["Domain"] = eachCasino;
		}else{
			domainSettingCopy = decode(videoChannelInfo["text_domain"]);
			domainAry = getJsonObj(domainSettingCopy);
		}
		showChannels();
	}
	else{
		videoSettingCopy = decode(videoChannelInfo["text_video"]);
		domainSettingCopy = decode(videoChannelInfo["text_domain"]);
		refreshChannels();
	}
}

function getJsonObj(text){
	try{
		var obj = JSON.parse(text);
	}catch(e){
		return null;
	}
	return obj;
}

function refreshChannels(){
	var obj = getJsonObj(videoSettingCopy);
	if(obj == null){
		var eachCasino = Object();
		eachCasino["CH1"] = "P";
		eachCasino["CH2"] = "S";
		eachCasino["CH3"] = "C";
		casinoAry["COD"] = eachCasino;
		var eachCasino = Object();
		eachCasino["CH1"] = "P";
		eachCasino["CH2"] = "S";
		eachCasino["CH3"] = "C";
		casinoAry["OKADA"] = eachCasino;
		var eachCasino = Object();
		eachCasino["CH1"] = "P";
		eachCasino["CH2"] = "S";
		eachCasino["CH3"] = "C";
		casinoAry["RWM"] = eachCasino;
	}else{
		casinoAry = obj;
	}

	var obj = getJsonObj(domainSettingCopy);
	if(obj == null){
		var eachCasino = Object();
		eachCasino[domainNameAry[0]] = "P";
		eachCasino[domainNameAry[1]] = "C";
		eachCasino[domainNameAry[2]] = "S";
		domainAry["Domain"] = eachCasino;
	}else{
		domainAry = obj;
	}
	showChannels();
}

function showChannels(){
	var subDatas = casinoAry[casino];
	if(casino == "COD"){
		util.getSpan(document, "COD_button").className = "btn-primary";
		util.getSpan(document, "OKADA_button").className = "btn-info";
		util.getSpan(document, "RWM_button").className = "btn-info";
	}else if(casino == "OKADA"){
		util.getSpan(document, "OKADA_button").className = "btn-primary";
		util.getSpan(document, "COD_button").className = "btn-info";
		util.getSpan(document, "RWM_button").className = "btn-info";
	}else if(casino == "RWM"){
		util.getSpan(document, "RWM_button").className = "btn-primary";
		util.getSpan(document, "COD_button").className = "btn-info";
		util.getSpan(document, "OKADA_button").className = "btn-info";
	}
	for(var ch = 1; ch < 4; ch++){
		util.getSpan(document, "CH"+ch+"_P").className = "btn-info";
		util.getSpan(document, "CH"+ch+"_S").className = "btn-info";
		util.getSpan(document, "CH"+ch+"_C").className = "btn-info";
		if(subDatas["CH"+ch] == "P"){
			util.getSpan(document, "CH"+ch+"_P").className = "btn-warning";
		}else if(subDatas["CH"+ch] == "S"){
			util.getSpan(document, "CH"+ch+"_S").className = "btn-warning";
		}else if(subDatas["CH"+ch] == "C"){
			util.getSpan(document, "CH"+ch+"_C").className = "btn-warning";
		}
	}

	subDatas = domainAry["Domain"];
	for(var ch = 1; ch < 4; ch++){
		util.getSpan(document, "Domain"+ch+"_P").className = "btn-info";
		util.getSpan(document, "Domain"+ch+"_S").className = "btn-info";
		util.getSpan(document, "Domain"+ch+"_C").className = "btn-info";
		if(subDatas[domainNameAry[ch-1]] == "P"){
			util.getSpan(document, "Domain"+ch+"_P").className = "btn-warning";
		}else if(subDatas[domainNameAry[ch-1]] == "S"){
			util.getSpan(document, "Domain"+ch+"_S").className = "btn-warning";
		}else if(subDatas[domainNameAry[ch-1]] == "C"){
			util.getSpan(document, "Domain"+ch+"_C").className = "btn-warning";
		}
	}

}

function phpDataCenter(eventName, phpData) {
	//console.log(phpData);
	handleChannelData(phpData.videoChannelInfo);
}


	//編碼
	function encode(Str) {
			var trans = "";
			var rev = "";
			var getcode = "";
	
			for (var i = 0; i < Str.length; i++) trans += (255 - Str.charCodeAt(i)).toString(16).toUpperCase();
			for (var i = 0; i < trans.length; i++) rev = trans.substr(i, 1) + rev;
	
			getcode = rev.substr(5, rev.length - 5) + rev.substr(0, 5);
	
			return getcode;
		}
	
		//解碼
		function decode(getstr) {
			//若 Server 回傳訊息無編碼，則不解碼
			if (getstr.indexOf(",") > -1) return getstr;
	
			var gettrans = "";
			var destr = "";
			var getrev = "";
			getrev = getstr.substr(getstr.length - 5, 5) + getstr.substr(0, getstr.length - 5);
	
			for (var i = 0; i < getrev.length; i++) gettrans = getrev.substr(i, 1) + gettrans;
			for (var i = 0; i < gettrans.length; i+=2) destr += String.fromCharCode(255 - Number("0x" + gettrans.substr(i, 2)));
		
			return destr;
		}