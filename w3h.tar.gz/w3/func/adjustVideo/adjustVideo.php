<?php
include ("../../conf/config_admin.php");


if($action=="submit" || $action=="submitDomain" || $action == "default"){
	$DB = $db;

}else{
	$DB = $dbr;
}
//====== 執行動作區 ======
if($action == "submit"){
	$DB->query("select id from other_set where name='adjustVideoChannel';");
    if ($DB->num_rows()==0) {//insert
        $sql="insert into other_set set name='adjustVideoChannel',text='.$newVideoSetting.';";
    } else {//update
        $sql="update other_set set text='".$newVideoSetting."' where  name='adjustVideoChannel';";
	}
    $DB->query($sql);
}
if($action == "submitDomain"){
	$DB->query("select id from other_set where name='adjustDomainChannel';");
    if ($DB->num_rows()==0) {//insert
        $sql="insert into other_set set name='adjustDomainChannel',text='.$newVideoSetting.';";
    } else {//update
        $sql="update other_set set text='".$newVideoSetting."' where  name='adjustDomainChannel';";
	}
    $DB->query($sql);
}
if($action == "default"){
	$sql="delete from other_set where name='adjustVideoChannel';";
    $DB->query($sql);
}
//====== 執行動作區 ======

//====== 主要資料區 ======

$videoChannelInfo = Array();
$DB->query("select id, name, text from other_set where  name='adjustVideoChannel';");
if($DB->num_rows()> 0){
	while($DB->next_record()){
		$videoChannelInfo["text_video"] = $DB->f("text");
	}
}
$DB->query("select id, name, text from other_set where  name='adjustDomainChannel';");
if($DB->num_rows()> 0){
	while($DB->next_record()){
		$videoChannelInfo["text_domain"] = $DB->f("text");
	}
}


$out=Array();
$out["videoChannelInfo"] = $videoChannelInfo;
$out["msg"] = " ".$sql."  ";
$DB -> close();
echo json_encode($out);
exit;


?>