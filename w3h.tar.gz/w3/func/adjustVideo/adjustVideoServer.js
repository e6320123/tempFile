
var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;

var videoSettingCopy = "";
var videoSettingObj = Object();
var siteType = "TI";
var retrySocketTimeout = 0;
function init() {
	listenEvt.addOnClick("testURL_button", util.getSpan(document, "testURL_button"), this, null);
	listenEvt.addOnClick("setURL_button", util.getSpan(document, "setURL_button"), this, null);
	listenEvt.addOnClick("modifyModal_submit", util.getSpan(document, "modifyModal_submit"), this, null);
	listenEvt.addOnClick("modifyModal_cancle", util.getSpan(document, "modifyModal_cancle"), this, null);
	
	var Path = "./adjustVideo/adjustVideoServer.php";
	var code = "uid=" + uid;
	code += "&action=queryServerList";
	util.addPostPHP("showTable", Path, code, this);
}

function createEachTable(tableNo, casino, table, port, serverIp, Line5, Line4, Line3, Line2, Line1, LineSequence){
	var eachTable = Object();
	eachTable["tableNo"] =  tableNo;
	eachTable["casino"] =  casino;
	eachTable["table"] =  table;
	eachTable["port"] =  port;
	eachTable["serverIp"] =  serverIp;
	eachTable["Line5"] =  Line5;
	eachTable["Line4"] =  Line4;
	eachTable["Line3"] =  Line3;
	eachTable["Line2"] =  Line2;
	eachTable["Line1"] =  Line1;
	eachTable["LineSequence"] =  LineSequence;
	
	return eachTable;
}

function setDefaultURL(){
	if(siteType == "CO"){
		setDefaultURL_CO();
	}else if(siteType == "TI"){
		setDefaultURL_TI();
	}
}

function setDefaultURL_CO(){
	var tableAry = Array();
	tableAry.push(createEachTable("1", "COD", "2001", "14001", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("2", "COD", "2002", "14002", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("3", "COD", "2003", "14001", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("4", "COD", "2004", "14002", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("5", "COD", "2101", "14001", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("6", "COD", "2102", "14002", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("7", "COD", "2103", "14001", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("8", "COD", "2104", "14002", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("9", "COD", "2105", "14001", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("10", "COD", "2106", "14002", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("11", "COD", "2107", "14001", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("12", "COD", "2108", "14002", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("13", "COD", "2109", "14001", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("14", "COD", "2110", "14002", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("15", "COD", "3001", "14001", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("16", "COD", "3002", "14002", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("17", "COD", "3003", "14001", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("18", "COD", "3004", "14002", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("19", "COD", "3005", "14001", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("20", "COD", "3007", "14002", "192.168.10.75", "", "", "","", "", ""));
	tableAry.push(createEachTable("50", "RWM", "MBJ80", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("51", "RWM", "MBJ81", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("52", "RWM", "MBJ85", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("53", "RWM", "MBJ86", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("54", "RWM", "MBJ87", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("55", "RWM", "MBJ88", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("56", "RWM", "MBJ90", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("57", "RWM", "MBJ91", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("58", "RWM", "MBJ92", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("59", "RWM", "MBJ93", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("60", "RWM", "MBJ95", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("61", "RWM", "MBJ96", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("62", "RWM", "MBJ97", "14001", "192.168.10.76", "", "", "", "", "", ""));
	tableAry.push(createEachTable("63", "RWM", "MBJ98", "14001", "192.168.10.76", "", "", "", "", "", ""));
	videoSettingObj["tables"] =tableAry;
}

function setDefaultURL_TI(){
	var tableAry = Array();
	tableAry.push(createEachTable("21", "OKADA", "6601", "14001", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("22", "OKADA", "6602", "14001", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("23", "OKADA", "6603", "14001", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("24", "OKADA", "6604", "14001", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("25", "OKADA", "6605", "14001", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("26", "OKADA", "6606", "14001", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("27", "OKADA", "6607", "14001", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("28", "OKADA", "6608", "14001", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("29", "OKADA", "6701", "14001", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("30", "OKADA", "6801", "14001", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("31", "OKADA", "6901", "14001", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("32", "OKADA", "5001", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("33", "OKADA", "5002", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("34", "OKADA", "5003", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("35", "OKADA", "5004", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("36", "OKADA", "5005", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("37", "OKADA", "5006", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("38", "OKADA", "5007", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("39", "OKADA", "5008", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("40", "OKADA", "5301", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("41", "OKADA", "7001", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("42", "OKADA", "7002", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("43", "OKADA", "7003", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("44", "OKADA", "7004", "14002", "192.168.130.141", "", "", "","", "", ""));
	tableAry.push(createEachTable("45", "OKADA", "7301", "14002", "192.168.130.141", "", "", "","", "", ""));
	videoSettingObj["tables"] =tableAry;
}

function refreshTestPage(){
	cleanPingResult();
	cleanActive();
	startGetPingAndConf();
	if(siteType == "TI"){
		document.getElementById("netFlowChartId").style.display = "";
		getFlowChart();
	}
}

function listenCenter(eventName, listenData) {
	if (eventName == "testURL_button") {
		refreshTestPage();
		util.getSpan(document, "table_setURL_div").style.display="none";
	}
	else if (eventName == "setURL_button") {
		util.getSpan(document, "table_testURL_div_COD").style.display="none";
		util.getSpan(document, "table_testURL_div_OKADA").style.display="none";
		util.getSpan(document, "table_testURL_div_RWM").style.display="none";
		util.getSpan(document, "table_setURL_div").style.display="";
	}
	else if(eventName.indexOf("modify_btn")!=-1){
		var tmpTable = getTableByTableNo(eventName.split("_")[2]);
		if(tmpTable != null){
			util.getSpan(document, "modifyModalCasinoName").innerHTML = tmpTable.casino+"_"+tmpTable.table;
			util.getSpan(document, "modifyModalPort").value = tmpTable.port;
			util.getSpan(document, "modifyModalServerIp").value = tmpTable.serverIp;
			util.getSpan(document, "modifyModalSequence").value = tmpTable.LineSequence;
			openModal();
		}
	}
	else if(eventName.indexOf("config_all_btn")!=-1){
		// var tmpCasino = eventName.split("_")[3];
		// for(var i = 0; i <videoSettingObj["tables"].length; i++){
		// 	if(videoSettingObj["tables"][i].casino == tmpCasino){
		// 		var tmpTable =videoSettingObj["tables"][i]
		// 		var serverId = i;
		// 		var line_0_btn = util.getSpan(document, "line_1_btn_" + serverId);
		// 		var line_1_btn = util.getSpan(document, "line_2_btn_" + serverId);
		// 		var line_2_btn = util.getSpan(document, "line_3_btn_" + serverId);
		// 		var off_btn = util.getSpan(document, "off_btn_" + serverId);
		// 		if(line_0_btn.classList.contains("bg-info")){
		// 			setServerConf(tmpTable, 0);
		// 		}else if(line_1_btn.classList.contains("bg-info")){
		// 			setServerConf(tmpTable, 1);
		// 		}else if(line_2_btn.classList.contains("bg-info")){
		// 			setServerConf(tmpTable, 2);
		// 		}else if(off_btn.classList.contains("bg-info")){
		// 			closeServer(tmpTable);
		// 		}
		// 	}
		// }
	}
	else if(eventName.indexOf("config_btn")!=-1){
		var tmpTable = getTableByTableNo(eventName.split("_")[2]);
		if(tmpTable != null){
			var serverId = eventName.split("_")[2];
			var line_1_btn = util.getSpan(document, "line_1_btn_" + serverId);
			var line_2_btn = util.getSpan(document, "line_2_btn_" + serverId);
			var line_3_btn = util.getSpan(document, "line_3_btn_" + serverId);
			var line_4_btn = util.getSpan(document, "line_4_btn_" + serverId);
			var line_5_btn = util.getSpan(document, "line_5_btn_" + serverId);
			var off_btn = util.getSpan(document, "off_btn_" + serverId);
			openProcessingModal();
			if(line_1_btn.classList.contains("bg-info")){
				setServerConf(tmpTable, 0);
			}else if(line_2_btn.classList.contains("bg-info")){
				setServerConf(tmpTable, 1);
			}else if(line_3_btn.classList.contains("bg-info")){
				setServerConf(tmpTable, 2);
			}else if(line_4_btn.classList.contains("bg-info")){
				setServerConf(tmpTable, 3);
			}else if(line_5_btn.classList.contains("bg-info")){
				setServerConf(tmpTable, 4);
			}else if(off_btn.classList.contains("bg-info")){
				closeServer(tmpTable);
			}
		}
	}
	else if(eventName.indexOf("off_btn")!=-1){
		var tmpTable = getTableByTableNo(eventName.split("_")[2]);
		if(tmpTable != null){
			var serverId = eventName.split("_")[2];
			util.getSpan(document, "off_btn_" + serverId).className = "t_list_caption text-center bg-info";
			util.getSpan(document, "line_1_btn_" + serverId).className = "t_list_caption text-center";
			util.getSpan(document, "line_2_btn_" + serverId).className = "t_list_caption text-center";
			util.getSpan(document, "line_3_btn_" + serverId).className = "t_list_caption text-center";
			util.getSpan(document, "line_4_btn_" + serverId).className = "t_list_caption text-center";
			util.getSpan(document, "line_5_btn_" + serverId).className = "t_list_caption text-center";
		}
	}
	else if(eventName.indexOf("line_")!=-1){
		var lineNum = eventName.split("_")[1];
		var serverId = eventName.split("_")[3];
		var tmpTable = getTableByTableNo(serverId);
		if(tmpTable != null){
			util.getSpan(document, "off_btn_" + serverId).className = "t_list_caption text-center";
			for(var ii = 1; ii <= 5; ii++){
				if( ii == lineNum*1){
					util.getSpan(document, "line_"+ii+"_btn_" + serverId).className = "t_list_caption text-center bg-info";
				}else{
					util.getSpan(document, "line_"+ii+"_btn_" + serverId).className = "t_list_caption text-center";
				}
			}
		}
	}
	else if (eventName == "modifyModal_submit") {
		var tableName = util.getSpan(document, "modifyModalCasinoName").innerHTML.split("_")[1];
		var port = util.getSpan(document, "modifyModalPort").value;
		var serverIP = util.getSpan(document, "modifyModalServerIp").value;
		// setNewData(tableName, port, serverIP);
		// var Path = "./adjustVideo/adjustVideoServer.php";
		// var code = "uid=" + uid;
		// code += "&action=changeServerList";
		// code += "&newVideoSetting=" + encode(JSON.stringify(videoSettingObj));
		// util.addPostPHP("submitResponse", Path, code, this);
		// closeModal();

		var seq = util.getSpan(document, "modifyModalSequence").value;
		var seqAry = seq.split("|");
		var isValid = true;
		var regExp = /^[\d]$/;
		for(var i = 0; i < seqAry.length; i++){
			if(!regExp.test(seqAry[i])){
				alert("參數錯誤");
				isValid = false;
				break;
			}
		}
		if(isValid){
			setSequence(serverIP, port, util.getSpan(document, "modifyModalSequence").value);
		}
	}
	else if (eventName == "modifyModal_cancle") {
		util.getSpan(document, "modifyModalCasinoName").innerHTML = "";
		closeModal();
	}
}

function setSequence(serverIp, serverPort, sequence){
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		if(videoSettingObj["tables"][i].serverIp == serverIp && videoSettingObj["tables"][i].port == serverPort){
			var Path = "./adjustVideo/adjustVideoServer.php";
			var code = "uid=" + uid;
			code += "&action=setConnectionSequence";
			code += "&tableName="+videoSettingObj["tables"][i].table ;
			code += "&testServerIp="+videoSettingObj["tables"][i].serverIp;
			code += "&testServerPort="+videoSettingObj["tables"][i].port;
			code += "&tableSequence=" + sequence;
			util.addPostPHP("none", Path, code, this);
		}
	}
	closeModal();
	init();
}

function openModal(){
	util.getSpan(document, "modifyURLModal").className="modal show";
}
function closeModal(){
	util.getSpan(document, "modifyURLModal").className="modal";
}
function openProcessingModal(){
	util.getSpan(document, "processingModal").className="modal show";
}
function closeProcessingModal(){
	util.getSpan(document, "processingModal").className="modal";
}

function setNewData(tableName, port, serverIP){
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		if(videoSettingObj["tables"][i].table == tableName){
			videoSettingObj["tables"][i].port = port;
			videoSettingObj["tables"][i].serverIP = serverIP;
		}
	}
}

function getTableByTableNo(tableNo){
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		if(videoSettingObj["tables"][i].tableNo == tableNo){
			return videoSettingObj["tables"][i];
		}
	}
	return null;
}

function getTableByTableName(tableName){
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		if(videoSettingObj["tables"][i].table == tableName){
			return videoSettingObj["tables"][i];
		}
	}
	return null;
}

function cleanPingResult(){
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		videoSettingObj["tables"][i].pingLine1 = 0; 
		videoSettingObj["tables"][i].pingLine2 = 0; 
		videoSettingObj["tables"][i].pingLine3 = 0; 
		videoSettingObj["tables"][i].pingLine4 = 0; 
		videoSettingObj["tables"][i].pingLine5 = 0; 
		videoSettingObj["tables"][i].pingLine1_Count = 0; 
		videoSettingObj["tables"][i].pingLine2_Count = 0;
		videoSettingObj["tables"][i].pingLine3_Count = 0; 
		videoSettingObj["tables"][i].pingLine4_Count = 0; 
		videoSettingObj["tables"][i].pingLine5_Count = 0; 
	}
}

function cleanQueryServerSource(){
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		videoSettingObj["tables"][i].Line1 = ""; 
		videoSettingObj["tables"][i].Line2 = ""; 
		videoSettingObj["tables"][i].Line3 = ""; 
		videoSettingObj["tables"][i].Line4 = ""; 
		videoSettingObj["tables"][i].Line5 = ""; 
		videoSettingObj["tables"][i].serverSource_Count = 0;
		videoSettingObj["tables"][i].serverSequence_Count = 0;
	}
}

function cleanActive(){
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		videoSettingObj["tables"][i].activeIndex = -1;
		videoSettingObj["tables"][i].activeIndex_Count = 0;
	}
}

function getFlowChart(){
	var Path = "./adjustVideo/adjustVideoServer.php";
	var code = "uid=" + uid;
	code += "&action=getFlowChart";
	util.addPostPHP("getFlowChart", Path, code, this);
}

function startGetPingAndConf(){
	getPing_Line(1);
}

function getPing_Line(LineIndex){
	var isDone = true;
    var lineName = "Line"+LineIndex;
    var pingName = "pingLine"+LineIndex;
    var pingCount = "pingLine"+LineIndex+"_Count";
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		if(videoSettingObj["tables"][i][pingName] == 0 &&videoSettingObj["tables"][i][pingCount] < 2){
			isDone = false;
			videoSettingObj["tables"][i][pingCount] ++;
			var Path = "./adjustVideo/adjustVideoServer.php";
			var code = "uid=" + uid;
			code += "&action=pingServer";
			code += "&testServerIp="+videoSettingObj["tables"][i].serverIp;
			code += "&testServerPort="+videoSettingObj["tables"][i].port;
			code += "&pingFileName="+videoSettingObj["tables"][i][lineName];
			util.addPostPHP("getPing_Line_"+LineIndex+"_"+videoSettingObj["tables"][i]["casino"], Path, code, this);
			break;
		}
	}
	if(isDone){
		if(LineIndex >= 5){
			getServerConf();
		}else{
			getPing_Line(LineIndex+1);
		}
	}
}

function getServerConf(){
	var isDone = true;
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		if(videoSettingObj["tables"][i].activeIndex == -1 &&videoSettingObj["tables"][i].activeIndex_Count < 2){
			isDone = false;
			videoSettingObj["tables"][i].activeIndex_Count ++;
			var Path = "./adjustVideo/adjustVideoServer.php";
			var code = "uid=" + uid;
			code += "&action=getServerConnectionInfo";
			code += "&testServerIp="+videoSettingObj["tables"][i].serverIp;
			code += "&testServerPort="+videoSettingObj["tables"][i].port;
			util.addPostPHP("getServerConf"+videoSettingObj["tables"][i]["casino"], Path, code, this);
			break;
		}
	}
	if(isDone){
		showTestTable();
	}
}

function setServerConf(tableObj, index){
	var Path = "./adjustVideo/adjustVideoServer.php";
	var code = "uid=" + uid;
	code += "&action=reconnectServer";
	code += "&testServerIp="+tableObj.serverIp;
	code += "&testServerPort="+tableObj.port;
	code += "&connectIndex="+index;
	code += "&tableName="+tableObj.table;
	util.addPostPHP("setConfResponse", Path, code, this);
}

function closeServer(tableObj){
	var Path = "./adjustVideo/adjustVideoServer.php";
	var code = "uid=" + uid;
	code += "&action=closeServer";
	code += "&testServerIp="+tableObj.serverIp;
	code += "&testServerPort="+tableObj.port;
	code += "&tableName="+tableObj.table;
	util.addPostPHP("setConfResponse", Path, code, this);
}

function handleVideoServerData(videoServerInfo){
	if(videoServerInfo.length == 0){
		setDefaultURL();
		cleanQueryServerSource();
		queryServerSourceNames();
	}else{
		videoSettingCopy = decode(videoServerInfo["text"]);
		refreshTables();
	}
}

function handleFlowChart(flowChartData){
	document.getElementById("PLTD_text").innerHTML = "PLTD_"+ flowChartData["7294"]["adddate"];
	document.getElementById("GLOBE_text").innerHTML = "GLOBE_"+ flowChartData["9795"]["adddate"];

	document.getElementById("PLTD_img").src = "data:image/png;base64,"+ flowChartData["7294"]["content"];
	document.getElementById("GLOBE_img").src = "data:image/png;base64,"+ flowChartData["9795"]["content"];
}

function refreshTables(){
	var obj = getJsonObj(videoSettingCopy);
	if(obj == null){
		setDefaultURL();
	}else{
		videoSettingObj = obj;
	}
	cleanQueryServerSource();
	queryServerSourceNames();
}

function afterGetAllServerConf(){
	showSettingTables();
	util.getSpan(document, "testURL_button").click();
}

function queryServerSourceNames(){
	var isDone = true;
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		if((videoSettingObj["tables"][i]["Line1"] == "" || videoSettingObj["tables"][i]["Line2"] == "" || videoSettingObj["tables"][i]["Line3"] == "" || videoSettingObj["tables"][i]["Line4"] == "" || videoSettingObj["tables"][i]["Line5"] == "")&& videoSettingObj["tables"][i]["serverSource_Count"] < 2){
			isDone = false;
			videoSettingObj["tables"][i]["serverSource_Count"] ++;
			var Path = "./adjustVideo/adjustVideoServer.php";
			var code = "uid=" + uid;
			code += "&action=queryServerSource";
			code += "&testServerIp="+videoSettingObj["tables"][i].serverIp;
			code += "&testServerPort="+videoSettingObj["tables"][i].port;
			util.addPostPHP("queryServerSource_"+videoSettingObj["tables"][i].serverIp+"_"+videoSettingObj["tables"][i].port, Path, code, this);
			break;
		}
	}
	if(isDone){
		querySequenceConf();
	}
}

function querySequenceConf(){
	var isDone = true;
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		if((videoSettingObj["tables"][i]["LineSequence"] == "")&& videoSettingObj["tables"][i]["serverSequence_Count"] < 2){
			isDone = false;
			videoSettingObj["tables"][i]["serverSequence_Count"] ++;
			var Path = "./adjustVideo/adjustVideoServer.php";
			var code = "uid=" + uid;
			code += "&action=queryConnectionSequence";
			code += "&testServerIp="+videoSettingObj["tables"][i].serverIp;
			code += "&testServerPort="+videoSettingObj["tables"][i].port;
			code += "&tableName="+videoSettingObj["tables"][i].table;
			util.addPostPHP("queryConnectionSequence_"+videoSettingObj["tables"][i].serverIp+"_"+videoSettingObj["tables"][i].port, Path, code, this);
			break;
		}
	}
	if(isDone){
		afterGetAllServerConf();
	}
}

function setSourceSequence(server, port, sequence){
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		if(videoSettingObj["tables"][i].serverIp == server && videoSettingObj["tables"][i].port == port ){
			videoSettingObj["tables"][i]["LineSequence"] = sequence;
		}
	}
}

function handleServerSequence(serverSource, server, port){
	//118,nowVideoSequence,0|1|2↵
		var conf = serverSource.split(",");
		if(conf.length == 3){
			var sequence = conf[2];
			setSourceSequence(server, port, sequence);
		}
	querySequenceConf();
}


function setSourceIndex(server, port, sourceIndex, sourceFrom){
	for(var i = 0; i <videoSettingObj["tables"].length; i++){
		if(videoSettingObj["tables"][i].serverIp == server && videoSettingObj["tables"][i].port == port ){
			videoSettingObj["tables"][i]["Line"+(sourceIndex*1+1)] = sourceFrom;
		}
	}
}

function handleServerSourceName(serverSource, server, port){
	//112,VideoConnectionIndex,1@INTERNET1,0@GLOBE_IPLC,2@INTERNET
	var confAry = serverSource.split(",");
	for(var i = 0; i< confAry.length; i++){
		var conf = confAry[i].split("@");
		if(conf.length == 2){
			var sourceIndex = conf[0];
			var sourceFrom  =conf[1];
			sourceFrom = sourceFrom.replace(/\r\n|\n/g,"");
			sourceFrom = sourceFrom.toUpperCase();
			setSourceIndex(server, port, sourceIndex, sourceFrom);
		}
	}
	queryServerSourceNames();
}

function getJsonObj(text){
	try{
		var obj = JSON.parse(text);
	}catch(e){
		return null;
	}
	return obj;
}

function showTestTable(){
	var table_div_COD = util.getSpan(document, "table_testURL_div_COD");
	var table_div_OKADA = util.getSpan(document, "table_testURL_div_OKADA");
	var table_div_RWM = util.getSpan(document, "table_testURL_div_RWM");
	table_div_COD.style.display = "none";
	table_div_OKADA.style.display = "none";
	table_div_RWM.style.display = "none";
	var xmpheader = util.getSpan(document, "testURL_xmpheader").innerHTML;

	var table_div_COD_head = xmpheader;
	var table_div_OKADA_head = xmpheader;
	var table_div_RWM_head = xmpheader;

	var xmpEnd = util.getSpan(document, "testURL_xmpEnd").innerHTML;
	var dataStr_COD = "";
	var dataStr_OKADA = "";
	var dataStr_RWM = "";
	var isFirst_COD = true;
	var isFirst_OKADA = true;
	var isFirst_RWM = true;
	for (var i = 0; i < videoSettingObj["tables"].length; i++) {
		if(videoSettingObj["tables"][i]["casino"] == "COD"){
			if(isFirst_COD){
				isFirst_COD = false;
				for(var ii = 1; ii <= 5; ii++){
					var reStrName = "\\*NAME_"+ii+"\\*";
					var reName = new RegExp(reStrName,"gi");
					var reStrDisplay = "\\*DISPLAY_LINE_"+ii+"\\*";
					var reDisplay = new RegExp(reStrDisplay,"gi");
					if(videoSettingObj["tables"][i]["Line"+ii] !=""){
						table_div_COD_head = table_div_COD_head.replace(reName, videoSettingObj["tables"][i]["Line"+ii]);
						table_div_COD_head = table_div_COD_head.replace(reDisplay, "");
					}else{
						table_div_COD_head = table_div_COD_head.replace(reDisplay, "none");
					}
				}
				table_div_COD_head = table_div_COD_head.replace(/\*SERVER_TYPE\*/gi, videoSettingObj["tables"][i]["casino"]);
			}
			dataStr_COD += createTestUrlTableTr(videoSettingObj["tables"][i]);
			table_div_COD.style.display = "";
		}else if(videoSettingObj["tables"][i]["casino"] == "OKADA"){
			if(isFirst_OKADA){
				isFirst_OKADA = false;
				for(var ii = 1; ii <= 5; ii++){
					var reStrName = "\\*NAME_"+ii+"\\*";
					var reName = new RegExp(reStrName,"gi");
					var reStrDisplay = "\\*DISPLAY_LINE_"+ii+"\\*";
					var reDisplay = new RegExp(reStrDisplay,"gi");
					if(videoSettingObj["tables"][i]["Line"+ii] != ""){
						table_div_OKADA_head = table_div_OKADA_head.replace(reName, videoSettingObj["tables"][i]["Line"+ii]);
						table_div_OKADA_head = table_div_OKADA_head.replace(reDisplay, "");
					}else{
						table_div_OKADA_head = table_div_OKADA_head.replace(reDisplay, "none");
					}
				}
				table_div_OKADA_head = table_div_OKADA_head.replace(/\*SERVER_TYPE\*/gi, videoSettingObj["tables"][i]["casino"]);
			}
			dataStr_OKADA += createTestUrlTableTr(videoSettingObj["tables"][i]);
			table_div_OKADA.style.display = "";
		}else if(videoSettingObj["tables"][i]["casino"] == "RWM"){
			if(isFirst_RWM){
				isFirst_RWM = false;

				for(var ii = 1; ii <= 5; ii++){
					var reStrName = "\\*NAME_"+ii+"\\*";
					var reName = new RegExp(reStrName,"gi");
					var reStrDisplay = "\\*DISPLAY_LINE_"+ii+"\\*";
					var reDisplay = new RegExp(reStrDisplay,"gi");
					if(videoSettingObj["tables"][i]["Line"+ii] != ""){
						table_div_RWM_head = table_div_RWM_head.replace(reName, videoSettingObj["tables"][i]["Line"+ii]);
						table_div_RWM_head = table_div_RWM_head.replace(reDisplay, "");
					}else{
						table_div_RWM_head = table_div_RWM_head.replace(reDisplay, "none");
					}
				}
				table_div_RWM_head = table_div_RWM_head.replace(/\*SERVER_TYPE\*/gi, videoSettingObj["tables"][i]["casino"]);
			}
			dataStr_RWM += createTestUrlTableTr(videoSettingObj["tables"][i]);
			table_div_RWM.style.display = "";
		}
	}
	table_div_COD.innerHTML = table_div_COD_head + dataStr_COD + xmpEnd;
	table_div_OKADA.innerHTML = table_div_OKADA_head + dataStr_OKADA + xmpEnd;
	table_div_RWM.innerHTML = table_div_RWM_head + dataStr_RWM + xmpEnd;

	for (var i = 0; i < videoSettingObj["tables"].length; i++) {
		var serverId = videoSettingObj["tables"][i]["tableNo"];
		var activeIndex = videoSettingObj["tables"][i]["activeIndex"];
		var config_btn = util.getSpan(document, "config_btn_" + serverId);
		listenEvt.addOnClick("config_btn_" + serverId, config_btn, this, serverId);

		var td_line1 = util.getSpan(document, "line_1_btn_" + serverId);
		listenEvt.addOnClick("line_1_btn_" + serverId, td_line1, this, serverId);

		var td_line2 = util.getSpan(document, "line_2_btn_" + serverId);
		listenEvt.addOnClick("line_2_btn_" + serverId, td_line2, this, serverId);

		var td_line3 = util.getSpan(document, "line_3_btn_" + serverId);
		listenEvt.addOnClick("line_3_btn_" + serverId, td_line3, this, serverId);

		var td_line4 = util.getSpan(document, "line_4_btn_" + serverId);
		listenEvt.addOnClick("line_4_btn_" + serverId, td_line4, this, serverId);

		var td_line5 = util.getSpan(document, "line_5_btn_" + serverId);
		listenEvt.addOnClick("line_5_btn_" + serverId, td_line5, this, serverId);

		var td_Off = util.getSpan(document, "off_btn_" + serverId);
		listenEvt.addOnClick("off_btn_" + serverId, td_Off, this, serverId);

		if(activeIndex == 0){
			td_line1.classList.add("bg-info");
		}else if(activeIndex == 1){
			td_line2.classList.add("bg-info");
		}else if(activeIndex == 2){
			td_line3.classList.add("bg-info");
		}else if(activeIndex == 3){
			td_line4.classList.add("bg-info");
		}else if(activeIndex == 4){
			td_line5.classList.add("bg-info");
		}else{
			td_Off.classList.add("bg-info");
		}
	}
}

function createTestUrlTableTr(eachTable){
	var xmpData = util.getSpan(document, "testURL_xmpData").innerHTML;
	var td = xmpData;
	td = td.replace(/\*TABLE\*/gi, eachTable.table);
	for(var ii = 1; ii <= 5; ii++){
		var reStrName = "\\*LINE_"+ii+"_DELAY_CLASS\\*";
		var reName = new RegExp(reStrName,"gi");
		if(eachTable["pingLine"+ii] > 200){
			td = td.replace(reName, "text-danger");
		}else{
			td = td.replace(reName, "");
		}
	}

	for(var ii = 1; ii <= 5; ii++){
		var reStrName = "\\*LINE_"+ii+"_DELAY\\*";
		var reName = new RegExp(reStrName,"gi");
		var reStrDisplay = "\\*DISPLAY_LINE_"+ii+"\\*";
		var reDisplay = new RegExp(reStrDisplay,"gi");
		if(eachTable["Line"+ii] !=""){
			if(eachTable["pingLine"+ii]*1 > 0){
				td = td.replace(reName, eachTable["pingLine"+ii]+"ms");
			}else{
				td = td.replace(reName, "LOST");
			}
			td = td.replace(reDisplay, "");
		}else{
			td = td.replace(reDisplay, "none");
		}
	}
	td = td.replace(/\*SERVER_ID\*/gi, eachTable.tableNo);
	return td;
}

function showSettingTables(){
	var table_div = util.getSpan(document, "table_setURL_div");
	table_div.style.display = "";
	var xmpheader = util.getSpan(document, "setURL_xmpheader").innerHTML;
	var xmpEnd = util.getSpan(document, "setURL_xmpEnd").innerHTML;
	var dataStr = "";
	var showTitleAry = {};
	for (var i = 0; i < videoSettingObj["tables"].length; i++) {
		dataStr += createSetUrlTableTr(videoSettingObj["tables"][i]);
		for(var ii = 1; ii <= 5; ii++){
			if(videoSettingObj["tables"][i]["Line"+ii] != ""){
				showTitleAry[ii] = "Y";
			}
		}
	}

	for(var ii = 1; ii<= 5; ii++){
		var reStrDisplay = "\\*DISPLAY_LINE_"+ii+"\\*";
		var reDisplay = new RegExp(reStrDisplay,"gi");
		if(showTitleAry[ii] == "Y"){
			xmpheader = xmpheader.replace(reDisplay, "");
		}else{
			xmpheader = xmpheader.replace(reDisplay, "none");
		}
	}
	table_div.innerHTML = xmpheader + dataStr + xmpEnd;
	for (var i = 0; i < videoSettingObj["tables"].length; i++) {
		var serverId = videoSettingObj["tables"][i]["tableNo"];
		var modify_btn = util.getSpan(document, "modify_btn_" + serverId);
		listenEvt.addOnClick("modify_btn_" + serverId, modify_btn, this, serverId);
	}
}

function createSetUrlTableTr(eachTable){
	var xmpData = util.getSpan(document, "setURL_xmpData").innerHTML;
	var td = xmpData;
	td = td.replace(/\*CASINO\*/gi, eachTable.casino);
	td = td.replace(/\*TABLE\*/gi, eachTable.table);
	td = td.replace(/\*PORT\*/gi, eachTable.port);
	td = td.replace(/\*SERVER_IP\*/gi, eachTable.serverIp);

	for(var ii = 1; ii <= 5; ii++){
		var reStrName = "\\*LINE_"+ii+"\\*";
		var reName = new RegExp(reStrName,"gi");
		var reStrDisplay = "\\*DISPLAY_LINE_"+ii+"\\*";
		var reDisplay = new RegExp(reStrDisplay,"gi");
		if(eachTable["Line"+ii] != ""){
			td = td.replace(reName, eachTable["Line"+ii]);
			td = td.replace(reDisplay, "");
		}else{
			td = td.replace(reDisplay, "none");
		}
	}

	td = td.replace(/\*SEQUENCE\*/gi, eachTable.LineSequence);
	td = td.replace(/\*SERVER_ID\*/gi, eachTable.tableNo);
	return td;
}
//"546,pong,10 packets transmitted, 10 received, 0% packet loss, time 9119ms rtt min/avg/max/mdev = 106.632/106.740/106.822/0.363 ms↵"

function handlePing(pingResponse,pingServer,casino){
	var delay = pingResponse.split("/")[5];
	for(var i = 0; i < videoSettingObj["tables"].length; i++){
		if(videoSettingObj["tables"][i]["casino"]==casino){
			videoSettingObj["tables"][i]["pingLine"+pingServer] = delay;
		}
	}
}

function handleServerConf(serverConf){
	var confAry = serverConf.split(",");
	for(var i = 0; i< confAry.length; i++){
		var conf = confAry[i].split("@");
		if(conf.length == 2){
			var tableName = conf[0];					//3005
			var sourceFrom  =conf[1].split(":")[0];		//PLTD_IPLC
			sourceFrom = sourceFrom.toUpperCase();
			for(var j = 0; j < videoSettingObj["tables"].length; j++){
				if(videoSettingObj["tables"][j]["table"] == tableName){
					if(videoSettingObj["tables"][j].Line1 == sourceFrom){
						videoSettingObj["tables"][j].activeIndex = 0;
					}else if(videoSettingObj["tables"][j].Line2 == sourceFrom){
						videoSettingObj["tables"][j].activeIndex = 1;
					}else if(videoSettingObj["tables"][j].Line3 == sourceFrom){
						videoSettingObj["tables"][j].activeIndex = 2;
					}else if(videoSettingObj["tables"][j].Line4 == sourceFrom){
						videoSettingObj["tables"][j].activeIndex = 3;
					}else if(videoSettingObj["tables"][j].Line5 == sourceFrom){
						videoSettingObj["tables"][j].activeIndex = 4;
					}else{
						videoSettingObj["tables"][j].activeIndex = -1;
					}
					break;
				}
			}
		}
	}
}

function phpDataCenter(eventName, phpData) {
	if(eventName.indexOf("getPing_Line")!=-1){
		var lineNum = eventName.split("_")[2];
		var casinoName = eventName.split("_")[3];
		handlePing(phpData.ping, ""+lineNum,casinoName);
		getPing_Line(lineNum*1);
	}
	else if (eventName == "getServerConfCOD" || eventName == "getServerConfOKADA" || eventName == "getServerConfRWM") {
		console.log(eventName);
		console.log(phpData);
		handleServerConf(phpData.msg);
		getServerConf();
	}
	else if (eventName == "setConfResponse") {
		console.log(phpData);
		closeProcessingModal();
		if(phpData.msg == "OK"){
			refreshTestPage();
		}
	}
	else if (eventName == "submitResponse") {
		console.log(phpData);
		var Path = "./adjustVideo/adjustVideoServer.php";
		var code = "uid=" + uid;
		code += "&action=queryServerList";
		util.addPostPHP("showTable", Path, code, this);
	}
	else if (eventName == "showTable") {
		handleVideoServerData(phpData.VideoServer);
	}
	else if (eventName.match("queryServerSource")) {
		var eventAry = eventName.split("_");
		var queryServer = eventAry[1];
		var queryPort = eventAry[2];
		handleServerSourceName(phpData.serverSource, queryServer, queryPort);
	}
	else if (eventName.match("queryConnectionSequence")) {
		var eventAry = eventName.split("_");
		var queryServer = eventAry[1];
		var queryPort = eventAry[2];
		handleServerSequence(phpData.serverSource, queryServer, queryPort);
	}
	else if (eventName.match("getFlowChart")) {
		handleFlowChart(phpData.flowChart);
	}
}

//編碼
function encode(Str) {
	var trans = "";
	var rev = "";
	var getcode = "";

	for (var i = 0; i < Str.length; i++) trans += (255 - Str.charCodeAt(i)).toString(16).toUpperCase();
	for (var i = 0; i < trans.length; i++) rev = trans.substr(i, 1) + rev;

	getcode = rev.substr(5, rev.length - 5) + rev.substr(0, 5);

	return getcode;
}

//解碼
function decode(getstr) {
	//若 Server 回傳訊息無編碼，則不解碼
	if (getstr.indexOf(",") > -1) return getstr;

	var gettrans = "";
	var destr = "";
	var getrev = "";
	getrev = getstr.substr(getstr.length - 5, 5) + getstr.substr(0, getstr.length - 5);

	for (var i = 0; i < getrev.length; i++) gettrans = getrev.substr(i, 1) + gettrans;
	for (var i = 0; i < gettrans.length; i+=2) destr += String.fromCharCode(255 - Number("0x" + gettrans.substr(i, 2)));

	return destr;
}