<?php
include ("../../conf/config_admin.php");

$casino = "TI";
if($action=="changeServerList"){
	$DB = $db;
}else{
	$DB = $dbr;
}
//====== 執行動作區 ======
if($action == "changeServerList"){
	$DB->query("select id from other_set where name='".$casino."VideoServer';");
    if ($DB->num_rows()==0) {//insert
        $sql="insert into other_set set name='".$casino."VideoServer',text='.$newVideoSetting.';";
    } else {//update
        $sql="update other_set set text='".$newVideoSetting."' where  name='".$casino."VideoServer';";
	}
    $DB->query($sql);
}else if($action == "queryServerList"){
	$VideoServer = Array();
	$DB->query("select id, name, text from other_set where  name='".$casino."VideoServer';");
	if($DB->num_rows()> 0){
		while($DB->next_record()){
			$VideoServer["ipList"] = Array();
			$VideoServer["id"] = $DB->f("id");
			$VideoServer["name"] = $DB->f("name");
			$VideoServer["text"] = $DB->f("text");
		}
	}
	
	$out=Array();
	$out["VideoServer"] = $VideoServer;
	$out["msg"] = "success";
}else if($action == "pingServer"){
	$startTime = time();
	$cmd = "541,ping,".$startTime;
	$Respone = javaConnnection($cmd , $testServerIp , $testServerPort , true );
	$receiveTime = time();
	$cmdTime = preg_split("/,/",$Respone);
	$diff = $receiveTime - $cmdTime[2]*1;
	$out["ping"] = $diff;
	$out["msg"] = $Respone;
}else if($action == "getServerConnectionInfo"){
	$cmd = "107,VideoConnectionInfo,";
	$Respone = javaConnnection($cmd , $testServerIp , $testServerPort , true );
	$out["msg"] = $Respone;
}else if($action == "reconnectServer"){
	$cmd = "103,reconnect,".$connectIndex.",".$tableName;
	$Respone = javaConnnection($cmd , $testServerIp , $testServerPort , true );
	$out["msg"] = $Respone;
}
//====== 執行動作區 ======

//====== 主要資料區 ======
$DB -> close();
echo json_encode($out);
exit;


//連向Server的連線
function javaConnnection($command,$ip,$port,$back=false){
    $get="";
    $fp = fsockopen($ip, $port, $errno, $errstr, 5);
    if (!$fp) {
        return "Server error";
        //echo "<script>alert('$errno:$errstr');</script>";
    } else {
        fwrite($fp, $command."\n");
        if($back){
            while (!feof($fp)) {
                $get.= fgets($fp, 256);
                if(strpos($get , "\n") > -1) break;
                //echo $get;
            }
        }
        fclose($fp);
    }
    return $get;
}

?>