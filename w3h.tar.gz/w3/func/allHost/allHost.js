var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;

var allData;                        //HostData
var allData2;                       //調整過的HostData
var companyData = new Object();     //data(用廠商分類)
var companyObj = {
    "COD":"1_20",
    "OKADA":"21_49",
    "RWM":"50_63"
};
var channelAry = ["廠商","CH1","CH2","CH3"]; //線路分類
var channelBtnAry = ["P","S","C"];          //按鈕分類
var corpsAry = ["COD","OKADA","RWM"];       //廠商分類
var TableNameAry = ["domain","video"];      //table分類
var selectedOptionAry;
var flag = false;

//初始化
function init() {
    phpEvent = new phpEvent();	//PHP事件
    listenEvent = new listenEvent();	//監聽事件
    showChannelsTable = new showChannelsTables();
    //DTF = new DateTimeFormat();	//取得時間格式
    showChannelsTable.generatetTitle();
    showChannelsTable.generateTable();
    showChannelsTable.generateOption();
    doSet();
}

function doSet() {
    selectedOptionAry = new Array();
    selectedOptionAry.push("tableNum", "All", "All", "All", "All", "All");

    phpEvent.allHost();
}

//PHP事件
function phpEvent() {
    var self = this;
    var aPath = "/func/allHost/allHost.php";

    //allHostData
    self.allHost = function () {
        var parame = "&action=allHost";
        parame += "&uid=" + uid;
        util.addPostPHP("allHost", aPath, parame, this);
    }

    self.updateEnable = function (id, enable) {
        var parame = "&action=updateEnable";
        parame += "&uid=" + uid;
        parame += "&id=" + id;
        parame += "&enable=" + enable;
        util.addPostPHP("updateEnable", aPath, parame, this);
    }

    self.updateWorkChannel = function (minTable, maxTable, type, ch, wch) {
        var parame = "&action=updateWorkChannel";
        parame += "&uid=" + uid;
        parame += "&minTable=" + minTable;
        parame += "&maxTable=" + maxTable;
        parame += "&type=" + type;
        parame += "&channel=" + ch;
        parame += "&workChannel=" + wch;
        util.addPostPHP("updateWorkChannel", aPath, parame, this);
    }

    self.insertHostData = function (gtype, type, table_num, channel, work_channel, host, port, port_ssl, isIP, enable) {
        var parame = "&action=insertHostData";
        parame += "&uid=" + uid;
        parame += "&gtype=" + gtype;
        parame += "&type=" + type;
        parame += "&tableNum=" + table_num;
        parame += "&channel=" + channel;
        parame += "&workChannel=" + work_channel;
        parame += "&host=" + host;
        parame += "&port=" + port;
        parame += "&portSSL=" + port_ssl;
        parame += "&isIP=" + isIP;
        parame += "&enable=" + enable;
        util.addPostPHP("insertHostData", aPath, parame, this);
    }

    self.deleteHostData = function (id) {
        var parame = "&action=deleteHostData";
        parame += "&uid=" + uid;
        parame += "&id=" + id;
        util.addPostPHP("deleteHostData", aPath, parame, this);
    }

    //PHP事件回應
    self.phpDataCenter = function (eventName, phpData) {

        //get data
        if (eventName == "allHost") {

            allData = phpData["allHost"];
            console.log(allData);

            //用廠商分的 data
            for (var co = 0; co < Object.keys(companyObj).length; co++) {

                var tmpAry = Object.keys(companyObj);
                var company = tmpAry[co];
                var startTb = parseInt(companyObj[company].split("_")[0]);
                var endTb = parseInt(companyObj[company].split("_")[1]);

                var count = 0;

                var tmpObj = new Object();
                for (var i = 0; i < Object.keys(allData).length; i++) {
                    var tmp = allData[i];
                    var tmpTbNum = parseInt(allData[i]["table_num"]);

                    if (startTb <= tmpTbNum && tmpTbNum <= endTb) {
                        tmpObj[count] = tmp;
                        count++;
                    }
                }
                companyData[company] = tmpObj
            }
            console.log(companyData);

            //第一次載入頁面才執行
            if (flag == false) {
                showHostList(allData);
                showTypeOption(allData);
                showTableNumOption(allData);
                showChannelOption(allData);

                showChannels(allData);

                flag = true;
            } else {
                var cp_HostData = allData;
                var filterData = filterHostData(cp_HostData, selectedOptionAry);
                showHostList(filterData);
            }

            listenEvent.setStaticListen();
        }

        if (eventName == "updateEnable") {
            setTimeout(function () {
                phpEvent.allHost();
            }, 300);
        }

        if (eventName == "updateWorkChannel") {
            setTimeout(function () {
                phpEvent.allHost();
            }, 300);
        }

        if (eventName == "insertHostData") {
            setTimeout(function () {
                phpEvent.allHost();

                alert("新增成功");
            }, 300);
        }

        if (eventName == "deleteHostData") {
            setTimeout(function () {
                phpEvent.allHost();

                alert("刪除成功");
            }, 300);


        }
    }
}

function listenEvent() {
    var self = this;

    //建立監聽事件
    self.setStaticListen = function () {

        listenEvt.addSelectOnChange("selectTable", util.getSpan(document, "selectTable"), this, "");

        listenEvt.addSelectOnChange("selectFilter_type", util.getSpan(document, "selectType"), this, "");
        listenEvt.addSelectOnChange("selectFilter_company", util.getSpan(document, "selectCompany"), this, "");
        listenEvt.addSelectOnChange("selectFilter_tablenum", util.getSpan(document, "selectTableNum"), this, "");
        listenEvt.addSelectOnChange("selectFilter_channel", util.getSpan(document, "selectChannel"), this, "");
        listenEvt.addSelectOnChange("selectFilter_enable", util.getSpan(document, "selectEnable"), this, "");


        var buttonArr = document.getElementsByName("button");
        var domainArr = document.getElementsByName("domain");
        var videoArr = document.getElementsByName("video");

        for (var i = 0; i < buttonArr.length; i++) {
            listenEvt.addOnClick(buttonArr[i]["id"], buttonArr[i], this, "");
        }

        for (var i = 0; i < domainArr.length; i++) {
            listenEvt.addOnClick(domainArr[i]["id"], domainArr[i], this, "");
        }

        for (var i = 0; i < videoArr.length; i++) {
            listenEvt.addOnClick(videoArr[i]["id"], videoArr[i], this, "");
        }

        listenEvt.addOnClick("insertSubmit", util.getSpan(document, "insert_submit"), this, "");
    }

    self.listenCenter = function (eventName, obj) {

        if (eventName.indexOf("selectFilter_") > -1) {

            selectedOptionAry = new Array();

            var optionType = util.getSpan(document, "selectTable").value;

            var company = util.getSpan(document, "selectCompany").value;

            var type = util.getSpan(document, "selectType").value;
            var table_num = util.getSpan(document, "selectTableNum").value;
            var channel = util.getSpan(document, "selectChannel").value;
            var enable = util.getSpan(document, "selectEnable").value;

            selectedOptionAry.push(optionType, company, type, table_num, channel, enable);

            var cp_HostData = allData;
            var filterData = filterHostData(cp_HostData, selectedOptionAry);
            showHostList(filterData);

            listenEvent.setStaticListen();

            return;
        }

        if (eventName == "selectTable") {

            var choose = util.getSpan(document, "selectTable").value;
            if (choose == "company") {
                selectMethod = "company";
                util.getSpan(document, "selectCompany").style.display = "";
                util.getSpan(document, "showTableNumOption").style.display = "none";
            } else {
                selectMethod = "table";
                util.getSpan(document, "selectCompany").style.display = "none";
                util.getSpan(document, "showTableNumOption").style.display = "";
            }
        }

        if (eventName.indexOf("btn_") > -1) {

            var id = (eventName.split("_"))[1];
            var enable = util.getSpan(document, "enable_" + id).innerHTML;

            if (enable == "Y") {
                enable = "N";
            } else {
                enable = "Y";
            }

            var r = confirm("確定要更新 id : " + id + " 的enable ?");
            if (r == true) {
                phpEvent.updateEnable(id, enable);
            } else {

            }

            return;
        }

        if (eventName.indexOf("domain") > -1) {

            var idAry = eventName.split("_");
            chgChannels(idAry);

            return;
        }

        if (eventName.indexOf("video") > -1) {

            var idAry = eventName.split("_");
            chgChannels(idAry);

            return;
        }

        if (eventName == "insertSubmit") {

            insertData();

            return;
        }

        if (eventName.indexOf("delBtn_") > -1) {

            var id = (eventName.split("_"))[1];

            var delData = new Object();
            var tmpAry = Object.keys(allData);
            var count = 0;

            for (var i = 0; i < tmpAry.length; i++) {
                var tmp = tmpAry[i];
                var delObj = allData[tmp];

                if (delObj["id"] === id) {
                    delData[count] = delObj;
                    count++;
                }
            }
            console.log(delData);

            var cp_HostData = allData;
            selectedOptionAry = new Array();
            selectedOptionAry.push("tableNum", "All", delData["type"], delData["table_num"], delData["channel"], "All");

            var tmpFilterHostData = filterHostData(cp_HostData, selectedOptionAry);

            var len = Object.keys(tmpFilterHostData).length;

            if (len == "1") {
                var r1 = confirm("確定要刪除 id : " + id + " 這條線路 ?");
                if (r1 == true) {
                    var r2 = confirm("id : " + id + " 這個channel只剩下一條，確定要刪除 ?");
                    if (r2 == true) {
                        phpEvent.deleteHostData(id);
                    } else {

                    }
                } else {

                }
            } else {
                var r3 = confirm("確定要刪除 id : " + id + " 這條線路 ?");
                if (r3 == true) {
                    phpEvent.deleteHostData(id);
                } else {

                }
            }

            return;
        }
    }
}

function showChannelsTables(){
    var self = this ;

    //動態產生線路
    self.generatetTitle = function (){
        for(var i in TableNameAry){
            var ChannelTitle = "";
            for(var tmp = 0 ; tmp < channelAry.length ; tmp++){
                var XMP_Channels_title = util.getSpan(document, "XMP_Channels").innerHTML;
                var view_Channels_Domain_title = util.getSpan(document, "showAllview_Domain_Channels");
                var view_Channels_Video_title = util.getSpan(document, "showAllview_Video_Channels");
                XMP_Channels_title  = XMP_Channels_title.replace("*CHANNELS*",channelAry[tmp]);
                ChannelTitle += XMP_Channels_title;
            }

            if(TableNameAry[i] == "domain"){
                view_Channels_Domain_title.innerHTML = ChannelTitle;
            }else if(TableNameAry[i] == "video"){
                view_Channels_Video_title.innerHTML = ChannelTitle;
            }
        }
    }

    //動態產生廠商及畫面秀出
    self.generateTable = function () {
        var XMP_channel_corps = util.getSpan(document, "XMP_Corps").innerHTML;
        var view_Channels_Domain_table = util.getSpan(document, "showAllview_Domain");
        var view_Channels_Video_table = util.getSpan(document, "showAllview_Video");

        for(var tmp in TableNameAry){
            var allBtnStr = "";
            for(var corps in corpsAry){
                var XMP_Allbutton_show = util.getSpan(document, "XMP_Allbutton_show").innerHTML;
                var alltmpStr = "";
                var info = corpsAry[corps];
                var allChannelStr = showChannelsTable.XMP_AllStr(TableNameAry[tmp],info);
                var tmpStr = XMP_channel_corps + allChannelStr;

                tmpStr = tmpStr.replace("*CORPS*",info);
                alltmpStr += tmpStr;

                XMP_Allbutton_show = XMP_Allbutton_show.replace("*CORPS*",info);
                XMP_Allbutton_show = XMP_Allbutton_show.replace("*COPRSLISTCONTENT*",alltmpStr);
                allBtnStr += XMP_Allbutton_show;


                if(TableNameAry[tmp] == "domain"){
                    view_Channels_Domain_table.innerHTML = allBtnStr;
                }else if(TableNameAry[tmp] == "video"){
                    view_Channels_Video_table.innerHTML = allBtnStr;
                }

            }
        }
    }

    //動態產生按鈕
    self.XMP_AllStr = function (tableName,corpsName) {
        var allChannelStr = "";

        for(var tmp = 1 ; tmp < channelAry.length ; tmp++){
            var XMP_channel_button =  util.getSpan(document, "XMP_button").innerHTML;
            var XMP_channel_table  =  util.getSpan(document, "XMP_button_show").innerHTML;
            var ChannelStr = "";
            for(var i = 1; i <= channelBtnAry.length ; i++){
                var tmpChannelStr = XMP_channel_button ;
                tmpChannelStr = tmpChannelStr.replace(/\*FNUM\*/g, tmp);
                tmpChannelStr = tmpChannelStr.replace(/\*SNUM\*/g, i);
                tmpChannelStr = tmpChannelStr.replace("*BTN*",channelBtnAry[i-1]);

                for(var j in TableNameAry){
                    if(tableName == TableNameAry[j]){
                        tmpChannelStr = tmpChannelStr.replace("*TABLENAME*",tableName);
                        tmpChannelStr = tmpChannelStr.replace("*TABLENAME*",tableName);
                        break;
                    }
                }

                for(var corps in corpsAry){
                    if(corpsName == corpsAry[corps]){
                        tmpChannelStr = tmpChannelStr.replace("*CORPS*",corpsName);
                        break;
                    }
                }

                ChannelStr += tmpChannelStr;
            }

            ChannelStr = XMP_channel_table.replace("*LISTCONTENT*", ChannelStr);
            allChannelStr += ChannelStr;
        }
        return  allChannelStr;
    }

    //動態產生Option廠商
    self.generateOption = function (){
        var view_selectEnable = util.getSpan(document, "selectCompany");
        var XMP_corps_option  = util.getSpan(document, "option_corps").innerHTML;
        var allOptionStr = "";
        var OptionStr = "";

        XMP_corps_option = XMP_corps_option.replace("*CORPS*","All");
        XMP_corps_option = XMP_corps_option.replace("*CORPS*","All");
        OptionStr = XMP_corps_option;
        for(var corps in corpsAry){
            var XMP_corps_option  = util.getSpan(document, "option_corps").innerHTML;
            XMP_corps_option = XMP_corps_option.replace("*CORPS*",corpsAry[corps]);
            XMP_corps_option = XMP_corps_option.replace("*CORPS*",corpsAry[corps]);

            allOptionStr += XMP_corps_option;

        }
        view_selectEnable.innerHTML = OptionStr + allOptionStr;
    }

}

//show type SelectOption
function showTypeOption(data) {

    //data
    var tmpTypeAry = new Array();   //存每一筆的type

    for (var n = 0; n < Object.keys(data).length; n++) {
        var tmpType = data[n]["type"];
        tmpTypeAry.push(tmpType);
    }

    var typeObj = new Object();     //存不重複的type類型
    var count = 0;

    tmpTypeAry.forEach(function (item) {
        var tmpAry = Object.values(typeObj);

        if (tmpAry.indexOf(item) == -1) {
            typeObj[count] = item;
            count++;
        }
    });

    //show type Option
    var showTypeOption = util.getSpan(document, "showTypeOption");

    var xmpTypeHeader = util.getSpan(document, "xmpTypeHeader").innerHTML;
    var xmpTypeData = util.getSpan(document, "xmpTypeData").innerHTML;
    var xmpTypeFooter = util.getSpan(document, "xmpTypeFooter").innerHTML;

    var typeOptionStr = "";

    for (var i = 0; i < Object.keys(typeObj).length; i++) {

        var typeOptionData = xmpTypeData;
        var typeOption = typeObj[i];

        typeOptionData = typeOptionData.replace("*TYPEVAlUE*", typeOption);
        typeOptionData = typeOptionData.replace("*TYPE*", typeOption);

        typeOptionStr += typeOptionData;

    }

    xmpTypeData = typeOptionStr;

    showTypeOption.innerHTML = xmpTypeHeader + xmpTypeData + xmpTypeFooter;
}

//show table_num SelectOption
function showTableNumOption(data) {

    //data
    var tmpTbNumAry = new Array();   //存每一筆的table_num

    for (var n = 0; n < Object.keys(data).length; n++) {
        var tmpTbNum = data[n]["table_num"];
        tmpTbNumAry.push(tmpTbNum);
    }

    var tbNumObj = new Object();     //存不重複的table_num類型
    var count = 0;

    tmpTbNumAry.forEach(function (item) {
        var tmpAry = Object.values(tbNumObj);

        if (tmpAry.indexOf(item) == -1) {
            tbNumObj[count] = item;
            count++;
        }
    });

    //show table_num Option
    var showTbNumOption = util.getSpan(document, "showTableNumOption");

    var xmpTbNumHeader = util.getSpan(document, "xmpTableNumHeader").innerHTML;
    var xmpTbNumData = util.getSpan(document, "xmpTableNumData").innerHTML;
    var xmpTbNumFooter = util.getSpan(document, "xmpTableNumFooter").innerHTML;

    var tbNumOptionStr = "";

    for (var i = 0; i < Object.keys(tbNumObj).length; i++) {

        var tbNumOptionData = xmpTbNumData;
        var tbNumOption = tbNumObj[i];

        tbNumOptionData = tbNumOptionData.replace("*TABLENUMVAlUE*", tbNumOption);
        tbNumOptionData = tbNumOptionData.replace("*TABLENUM*", tbNumOption);

        tbNumOptionStr += tbNumOptionData;
    }

    xmpTbNumData = tbNumOptionStr;

    showTbNumOption.innerHTML = xmpTbNumHeader + xmpTbNumData + xmpTbNumFooter;
}

//show channel SelectOption
function showChannelOption(data) {

    //data
    var tmpChannelAry = new Array();   //存每一筆的channel

    for (var n = 0; n < Object.keys(data).length; n++) {
        var tmpChannel = data[n]["channel"];
        tmpChannelAry.push(tmpChannel);
    }

    var channelObj = new Object();     //存不重複的channel類型
    var count = 0;

    tmpChannelAry.forEach(function (item) {
        var tmpAry = Object.values(channelObj);

        if (tmpAry.indexOf(item) == -1) {
            channelObj[count] = item;
            count++;
        }
    });

    //show channel Option
    var showChannelOption = util.getSpan(document, "showChannelOption");

    var xmpChannelHeader = util.getSpan(document, "xmpChannelHeader").innerHTML;
    var xmpChannelData = util.getSpan(document, "xmpChannelData").innerHTML;
    var xmpChannelFooter = util.getSpan(document, "xmpChannelFooter").innerHTML;

    var channelOptionStr = "";

    for (var i = 0; i < Object.keys(channelObj).length; i++) {

        var channelOptionData = xmpChannelData;
        var channelOption = channelObj[i];

        channelOptionData = channelOptionData.replace("*CHANNELVAlUE*", channelOption);
        channelOptionData = channelOptionData.replace("*CHANNEL*", channelOption);

        channelOptionStr += channelOptionData;
    }

    xmpChannelData = channelOptionStr;

    showChannelOption.innerHTML = xmpChannelHeader + xmpChannelData + xmpChannelFooter;
}

//filter hostData
function filterHostData(data, optionAry) {

    var hostData = new Object();

    var method = optionAry[0];
    var company = optionAry[1]
    var type = optionAry[2];
    var table_Num = optionAry[3];
    var channel = optionAry[4];
    var enable = optionAry[5];

    if (method == "company") {

        if (type == "All" && company == "All" && channel == "All" && enable == "All") {
            hostData = data;
        } else {
            var companyAry = Object.keys(companyObj);

            if (company == "All") {
                var tmpAry = Object.keys(data);
                var count = 0;

                for (var i = 0; i < tmpAry.length; i++) {
                    var tmp = tmpAry[i];
                    if ((type == "All") || (data[tmp]["type"] == type && type != "All")) {
                        if ((table_Num == "All") || (data[tmp]["table_num"] == table_Num && table_Num != "All")) {
                            if ((channel == "All") || (data[tmp]["channel"] == channel && channel != "All")) {
                                if ((enable == "All") || (data[tmp]["enable"] == enable && enable != "All")) {
                                    hostData[count] = data[tmp];
                                    count++;
                                }
                            }
                        }
                    }
                }
            } else if (companyAry.indexOf(company) > -1){
                var tmpData = companyData[company];
                var tmpAry = Object.keys(tmpData);
                var count = 0;

                for(var i = 0; i < tmpAry.length; i++){
                    var tmp = tmpAry[i];
                    if ((type == "All") || (tmpData[tmp]["type"] == type && type != "All")) {
                        if ((channel == "All") || (tmpData[tmp]["channel"] == channel && channel != "All")) {
                            if ((enable == "All") || (tmpData[tmp]["enable"] == enable && enable != "All")) {
                                hostData[count] = tmpData[tmp];
                                count++;
                            }
                        }
                    }
                }
            }
        }
    } else if (method == "tableNum") {

        var tmpAry = Object.keys(data);
        var count = 0;

        if (type == "All" && table_Num == "All" && channel == "All" && enable == "All") {
            hostData = data;
        } else {

            for (var i = 0; i < tmpAry.length; i++) {
                var tmp = tmpAry[i];
                if ((type == "All") || (data[tmp]["type"] == type && type != "All")) {
                    if ((table_Num == "All") || (data[tmp]["table_num"] == table_Num && table_Num != "All")) {
                        if ((channel == "All") || (data[tmp]["channel"] == channel && channel != "All")) {
                            if ((enable == "All") || (data[tmp]["enable"] == enable && enable != "All")) {
                                hostData[count] = data[tmp];
                                count++;
                            }
                        }
                    }
                }
            }

        }

    }
    return hostData;
}

//show HostList
function showHostList(data) {

    var showSelectedTypeHostList = util.getSpan(document, "showHostList");

    var xmpHostHeader = util.getSpan(document, "xmpHostHeader").innerHTML;
    var xmpHostData = util.getSpan(document, "xmpHostData").innerHTML;
    var xmpHostFooter = util.getSpan(document, "xmpHostFooter").innerHTML;

    var hostStr = "";
    var tmpAry = Object.keys(data);

    for (var i = 0; i < Object.keys(data).length; i++) {

        var tmp = tmpAry[i]
        var hostData = data[tmp];

        var xmp_hostData = xmpHostData;
        var tmpEnable = hostData["enable"];

        xmp_hostData = xmp_hostData.replace("*ID*", hostData["id"]);
        xmp_hostData = xmp_hostData.replace("*GTYPE*", hostData["gtype"]);
        xmp_hostData = xmp_hostData.replace("*TYPE*", hostData["type"]);
        xmp_hostData = xmp_hostData.replace("*TABLENUM*", hostData["table_num"]);
        xmp_hostData = xmp_hostData.replace("*CHANNEL*", hostData["channel"]);
        xmp_hostData = xmp_hostData.replace("*WORK_CHANNEL*", hostData["work_channel"]);
        xmp_hostData = xmp_hostData.replace("*HOST*", hostData["host"]);
        xmp_hostData = xmp_hostData.replace("*PORT*", hostData["port"]);
        xmp_hostData = xmp_hostData.replace("*PORT_SSL*", hostData["port_ssl"]);
        xmp_hostData = xmp_hostData.replace("*ISIP*", hostData["isIP"]);
        xmp_hostData = xmp_hostData.replace("*ENABLE*", hostData["enable"]);
        xmp_hostData = xmp_hostData.replace("*ENABLEID*", hostData["id"]);
        xmp_hostData = xmp_hostData.replace("*BTNID*", hostData["id"]);
        xmp_hostData = xmp_hostData.replace("*DELETEBTNID*", hostData["id"]);

        if (tmpEnable == "Y") {
            xmp_hostData = xmp_hostData.replace("*BTNCLASS*", "btn btn-danger btn-sm");
            xmp_hostData = xmp_hostData.replace("*BTNINNERHTML*", "關閉");
        } else {
            xmp_hostData = xmp_hostData.replace("*BTNCLASS*", "btn btn-success btn-sm");
            xmp_hostData = xmp_hostData.replace("*BTNINNERHTML*", "啟動");
        }

        hostStr += xmp_hostData;
    }
    showSelectedTypeHostList.innerHTML = xmpHostHeader + hostStr + xmpHostFooter;
}

function showChannels(data) {

    for(var co = 0; co < Object.keys(companyObj).length; co++){
        var tmpAry = Object.keys(companyObj);


        //channel data
        var lineObj = new Object();
        var firstTb = companyObj[tmpAry[co]].split("_")[0];
        var count = 0;

        for(var i = 0; i < Object.keys(data).length; i++){
            var tmpData = data[i];
            if( tmpData["table_num"] == firstTb){
                lineObj[count] = tmpData;
                count++;
            }
        }

        //show channel & work_channel
        for(var j = 0; j < Object.keys(lineObj).length; j++){

            var type = lineObj[j]["type"];
            var ch = lineObj[j]["channel"];
            var wch = lineObj[j]["work_channel"];

            if(type == "Game"){
                type = "domain";
            }else if (type == "Video"){
                type = "video";
            }
            if(util.getSpan(document, type + "_" + tmpAry[co] + "_" + ch + "_" + wch)){
                util.getSpan(document, type + "_" + tmpAry[co] + "_" + ch + "_" + wch).className = "btn btn-success";
            }
        }
    }
}

function chgChannels(idAry) {

    var type = idAry[0];
    var company = idAry[1];
    var ch = idAry[2];
    var wch = idAry[3];

    var tableRange = companyObj[company];
    var minTb =  tableRange.split("_")[0];
    var maxTb =  tableRange.split("_")[1];

    var check = confirm("確定要修改 " + type + " " + company + " CH" + ch + " 的 " + "work_channel嗎?");
    if (check == true) {
        util.getSpan(document, type + "_" + company + "_" + ch + "_1").className = "btn btn-default";
        util.getSpan(document, type + "_" + company + "_" + ch + "_2").className = "btn btn-default";
        util.getSpan(document, type + "_" + company + "_" + ch + "_3").className = "btn btn-default";

        util.getSpan(document, type + "_" + company + "_" + ch + "_" + wch).className = "btn btn-success";

        phpEvent.updateWorkChannel(minTb, maxTb, type, ch, wch);
    } else {

    }
}

//insert HostData
function insertData() {

    var gtype = "BA";
    var type = util.getSpan(document, "insert_type").value;
    var table_num = util.getSpan(document, "insert_tableNum").value;
    var channel = util.getSpan(document, "insert_channel").value;
    var work_channel = util.getSpan(document, "insert_workChannel").value;
    var host = util.getSpan(document, "insert_host").value;
    var port = util.getSpan(document, "insert_port").value;
    var port_ssl = util.getSpan(document, "insert_portSSL").value;
    var isIP = util.getSpan(document, "insert_isIP").value;
    var enable = util.getSpan(document, "insert_enable").value;

    var mathPattern = /^-?[\d]+$/; //只能數字
    var typePattern = /^[A-Z]{1}[a-z]+$/;
    var hostPattern = /^[a-z0-9]+-?[a-z0-9]+$/;

    if (type.match(typePattern)) {
        if (table_num.match(mathPattern)) {
            if (channel.match(mathPattern)) {
                if (work_channel.match(mathPattern)) {
                    if (host.match(hostPattern)) {
                        if (port.match(mathPattern)) {
                            if (port_ssl.match(mathPattern)) {
                                if (isIP != "選擇 isIP") {
                                    if (enable != "選擇 enable") {
                                        phpEvent.insertHostData(gtype, type, table_num, channel, work_channel, host, port, port_ssl, isIP, enable);
                                    } else {
                                        alert("enable 沒有選!");
                                    }
                                } else {
                                    alert("isIP 沒有選!");
                                }
                            } else {
                                alert("port_ssl 格式錯誤!");
                            }
                        } else {
                            alert("port 格式錯誤!");
                        }
                    } else {
                        alert("host 格式錯誤!");
                    }
                } else {
                    alert("work_channel 格式錯誤!");
                }
            } else {
                alert("channel 格式錯誤!");
            }
        } else {
            alert("table_num 格式錯誤!");
        }
    } else {
        alert("type 格式錯誤!");
    }
}