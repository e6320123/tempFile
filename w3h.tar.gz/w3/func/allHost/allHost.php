<?php
include("../../conf/config_admin.php");

$uid = $uid;
$dbr= new proc_DB(DB_HOST_R, DB_USER_R, DB_PWD_R, DB_NAME);
$dbw = new proc_DB(DB_HOST,DB_USER,DB_PWD,DB_NAME);

if( $action == "allHost"){
        $host_data = array();
    
        $sql = "SELECT * FROM  conf_hostport_list ;";
        $dbr->query($sql);
        $count = 0;
        while($dbr->next_record()){
            $hostData = array();
            $hostData["id"] = $dbr->f("id");
            $hostData["gtype"] = $dbr->f("gtype");
            $hostData["type"] = $dbr->f("type");
            $hostData["table_num"] = $dbr->f("table_num");
            $hostData["channel"] = $dbr->f("channel");
            $hostData["work_channel"] = $dbr->f("work_channel");
            $hostData["host"] = $dbr->f("host");
            $hostData["port"] = $dbr->f("port");
            $hostData["port_ssl"] = $dbr->f("port_ssl");
            $hostData["isIP"] = $dbr->f("isIP");
            $hostData["enable"] = $dbr->f("enable");

            $host_data[$count] = $hostData;
            $count++;
        }

    $out["allHost"] = $host_data;
    
}else if ($action == "updateEnable") {

    $upsql = "UPDATE conf_hostport_list SET enable = '".$enable."' WHERE id = '".$id."' ;";
    $dbw->query($upsql);

    $out["msg"] = "update enable success";

}else if ($action == "updateWorkChannel"){
    
    if($type == "domain"){

        $updsql = "UPDATE conf_hostport_list SET work_channel = '".$workChannel."' WHERE (table_num BETWEEN ".$minTable." AND ".$maxTable.") and channel = '".$channel."' and (type = 'Lobby' or type = 'Game') ;";
        
    }else if($type == "video"){

        $updsql = "UPDATE conf_hostport_list SET work_channel = '".$workChannel."' WHERE (table_num BETWEEN ".$minTable." AND ".$maxTable.") and channel = '".$channel."' and type = 'Video' ;";
        
    }
    
    $dbw->query($updsql);

    $out["msg"] = "update work_channel success";
    
}else if ($action == "insertHostData"){

    $insertsql = "INSERT INTO conf_hostport_list(gtype,type,table_num,channel,work_channel,host,port,port_ssl,isIP,enable) ";
    $insertsql .="VALUES('".$gtype."','".$type."','".$tableNum."','".$channel."','".$workChannel."','".$host."','".$port."','".$portSSL."','".$isIP."','".$enable."');";

    $dbw->query($insertsql);

    $out["msg"] = "insert success";
}else if ($action == "deleteHostData"){
    
    $delsql = "DELETE FROM conf_hostport_list WHERE id = '".$id."';";

    $dbw->query($delsql);

    $out["msg"] = "delete success";
}else {
    $out["msg"] = "error";
}
$dbr->close();
$dbw->close();
echo json_encode($out);
?>