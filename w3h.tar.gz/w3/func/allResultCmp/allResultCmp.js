var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;
var aryNum = null;//當前靴號
var cmpdate = "0000-00-00";//初始化日期
var fulldata = new Object();
var alldata = null;
var comparedbobj = null;//站別
var tableinfoObj = null;//桌次
var error_All_Str = ""; //比對後所有桌的字串
var dateAgo = 20;//預設20天以前
var count = null;//記住每桌資料的次數
var tabledata = new Array();//以外層資料長度最長排序
var giddata = new Array();//以內層資料長度最長排序
var errorAry = new Array();//比對結果有異的桌次
var casinocnt = "";//上一次站別的站數
function init(){
    listenEvent = new listenEvent();
    phpEvent = new phpEvents();
    showTable = new showTables();
    compare = new compares();
    toolbag = new toolbags();
    listenEvent.staticListener();
    //取得站別
    phpEvent.getcomparedb();
    //取得桌次
    phpEvent.gettableNo();
   
}

function listenEvent(){
	var self = this;
	//靜態監聽
	self.staticListener = function (){
        listenEvt.addOnClick("newCompareBoot", util.getSpan(document, "newCompareBoot"), this, null);
        listenEvt.addOnClick("newCompareText", util.getSpan(document, "newCompareText"), this, null);
        listenEvt.addSelectOnChange("showTable_select", util.getSpan(document, "showTable_select"), this, null);
        listenEvt.addSelectOnChange("tableName_show", util.getSpan(document, "tableName_show"), this, null);
        listenEvt.addSelectOnChange("shoeBox_show", util.getSpan(document, "shoebox_show"), this, null);
        listenEvt.addOnClick("differentShow", util.getSpan(document, "differentShow"), this, null);
    }
    self.animateListener = function (){
        if(alldata != null){
            for(var j in tabledata){
                for(var tabledbname in tabledata[j]){
                    var dbname = tabledbname.split("@")[0];
                    listenEvt.addOnClick(dbname + "_shoebox_" + j, util.getSpan(document,dbname + "_btn_" + j), this,{ "aryNum": j});
                }
            }
        }
    }
    self.errorListener =function (){
        for(var j in errorAry){
            var tableNo =  errorAry[j];
            listenEvt.addOnClick("error_" + tableNo, util.getSpan(document,"error_" + tableNo), this,tableNo);
        }
    }
    self.listenCenter = function(eventName, listenData) {
        //單桌比對
        if(eventName == "newCompareBoot"){
            errorAry = new Array();//初始化
            var dbnameStr = "";
            var date = util.getSpan(document, "date_show").value;
            var tableno = util.getSpan(document,"tableName_show").value;
            //流局開關
            var drawSw = util.getSpan(document,"comparedb_draw").value;
            var search_str = util.getSpan(document,"search_str");
            toolbag.compareBootSw();
            //如果日期一樣,就直接跟fulldata拿資料
            var casinolen = toolbag.comparecasino(casinocnt);
            if(fulldata!=null  && cmpdate==date && casinolen){
                phpEvent.phpDataCenter("getdata",fulldata[tableno]);
            }else{
                fulldata = null;
                for(var dbname in comparedbobj){
                    if(util.getSpan(document,"checkbox_" + dbname).checked){
                        if(dbnameStr) dbnameStr += "," + dbname;
                        else dbnameStr = dbname;
                    }
                }
                if(dbnameStr != "")phpEvent.getdata("getdata",date,tableno,drawSw,dbnameStr);
                else search_str.innerHTML = "請選擇站別。";
            }
            return;
        }
        //一鍵比對
        if(eventName == "newCompareText"){
            fulldata = new Object();
            errorAry = new Array();
            var date = util.getSpan(document, "date_show").value;
            var drawSw = util.getSpan(document,"comparedb_draw").value;
            var search_str = util.getSpan(document,"search_str");
            var rwm_pitboss = util.getSpan(document,"checkbox_RWM_PITBOSS").checked
            var okada_pitboss = util.getSpan(document,"checkbox_OKADA_PITBOSS").checked
            cmpdate = date;
            count = 1;
            var dbnameStr = "";
            var dbnamecnt = 0;
            for(var dbname in comparedbobj){
                if(util.getSpan(document,"checkbox_" + dbname).checked){
                    if(dbnameStr) dbnameStr += "," + dbname;
                    else dbnameStr = dbname;
                    dbnamecnt++;
                }
            }
            if(dbnamecnt < 2){
                //畫面控制
                toolbag.compareTextSw();
                search_str.innerHTML = "請選擇兩種以上站別。";
                toolbag.showtextSw();
                fulldata = null;
                return;
            }
            casinocnt = dbnamecnt;
            toolbag.compareTextSw();
            search_str.innerHTML="查詢中...請稍等。";
            var tableNoStr = "";
            var max = "";
            var min = "";
            if(rwm_pitboss && !okada_pitboss){
                max = 63;
                min = 50;
                tableNoStr = toolbag.checktableNo(max,min,date,drawSw,dbnameStr);
            }else if(!rwm_pitboss && okada_pitboss){
                max = 46;
                min = 21;
                tableNoStr = toolbag.checktableNo(max,min,date,drawSw,dbnameStr);
            }else{
                tableNoStr = toolbag.checktableNo(max,min,date,drawSw,dbnameStr);
            }
            if(tableNoStr!="")phpEvent.getdata("getdatas",date,tableNoStr,drawSw,dbnameStr);
            return;
        }
        //詳細
        if(eventName.indexOf("shoebox") != -1){
            var showView = util.getSpan(document,"btnTable_showView");
            aryNum = listenData.object["aryNum"];
            showView.innerHTML = "";//初始化table
            showTable.showBtnTable(aryNum,false);
            showTable.showAllroad(aryNum);
            util.getSpan(document,"allshowtable").selected = true;
            util.getSpan(document,"showTable_select").style.display = "";
            return;
        }
        //全部顯示,僅顯示比對不同
        if(eventName == "showTable_select"){
            var select = util.getSpan(document,"showTable_select").value;
            var showView = util.getSpan(document,"btnTable_showView");
            showView.innerHTML = "";//初始化table
            (select == "1") ? select = true : select = false;
            showTable.showBtnTable(aryNum,select);
            return;
        }
        //一鍵比對桌號按鈕
        if(eventName.indexOf("error") != -1){
            var tableno = listenData.object;
            toolbag.errorbtnSw(tableno);
            phpEvent.phpDataCenter("getdata",fulldata[tableno]);
            return;
        }
        //控制桌次select
        if(eventName == "tableName_show"){
            toolbag.casinoControl(false);
            return; 
        }
        //控制站別select
        if(eventName == "shoeBox_show"){
            toolbag.casinoControl(true);
            return; 
        }
    }
}

//動態產生table
function showTables(){
    var self = this;
    //動態產生桌號及日期
    self.showTableSelect = function(){
        var nowTable = util.getSpan(document,"tableName_show");
        var date_show = util.getSpan(document,"date_show");
        var xmp_select = util.getSpan(document,"xmp_tableNo_select").innerHTML;
        var xmpStr = "";
        var xmpdate="";
        for(var tableNo in tableinfoObj["tableinfo"]){
            var tablename = tableinfoObj["tableinfo"][tableNo];
            var xmp_option = util.getSpan(document,"xmp_tableNo_option").innerHTML;
            xmp_option = xmp_option.replace(/\*TABLENAME\*/gi,tablename);
            xmp_option = xmp_option.replace(/\*TABLENO\*/gi,tableNo);
            xmpStr += xmp_option;
        }
        xmp_select = xmp_select.replace("*OPTION*",xmpStr);
        for(var i = 0; i< dateAgo ;i++){
            var xmp_date_select = util.getSpan(document,"xmp_date_select").innerHTML;
            xmp_date_select = xmp_date_select.replace(/\*DATE\*/gi,toolbag.getDate(i));
            xmpdate += xmp_date_select;
        }
        nowTable.innerHTML = xmp_select;
        date_show.innerHTML = xmpdate;
        date_show.value = toolbag.getDate(1);
    }
    //動態產生站別及薛盒選項
    self.showCheckbox = function(){
        var okada_shoebox = util.getSpan(document,"OKADA_shoebox");
        var rwm_shoebox = util.getSpan(document,"RWM_shoebox");
        var local_shoebox = util.getSpan(document,"LOCAL_shoebox");
    
        for(var shoebox in comparedbobj){
            var xmp_checkbox = util.getSpan(document,"xmp_checkbox").innerHTML;
            var local = comparedbobj[shoebox]["local"];
            xmp_checkbox = xmp_checkbox.replace(/\*SHOEBOX\*/gi,shoebox);
            if(local == "Y"){
                local_shoebox.innerHTML += xmp_checkbox;
            }else if(local == "N" && shoebox.indexOf("RWM") == -1){
                okada_shoebox.innerHTML += xmp_checkbox;
            }else if(shoebox.indexOf("RWM") != -1){
                rwm_shoebox.innerHTML += xmp_checkbox;
            }
        }
    }
    //動態產生上方table
    self.showView = function (){
        var showView = util.getSpan(document,"table_showView");
        var search_str = util.getSpan(document,"search_str");
        var nowdate_show = util.getSpan(document,"nowdate_show");
        var date_show = util.getSpan(document,"date_show");
          
        if(tabledata.length == 0) {
            search_str.innerHTML = "此桌號當日無資料。"
            return;
        }
        var xmp_title_str = "";
        var xmp_th_str = "";
        var xmp_th_Str = "";
        var xmp_title_Str = "";
        var xmplist = "";
        var xmp_table = util.getSpan(document,"xmp_table").innerHTML;
        showView.innerHTML = xmp_table;
        //title
        for(var comaredb in alldata){
            var tablesum = 0;
            var xmp_title = util.getSpan(document,"xmp_title").innerHTML;
            var xmp_th = util.getSpan(document,"xmp_th").innerHTML;
            xmp_title = xmp_title.replace(/\*DBNAME\*/gi,comaredb);
            for(var idx in alldata[comaredb]){
                for(var gmid in alldata[comaredb][idx]){ 
                    var allgmid = Object.keys(alldata[comaredb][idx]).length;
                    tablesum = tablesum *1 + allgmid * 1;
                    break;
                }
            }
            xmp_th = xmp_th.replace("*ALLTABLESUM*",tablesum);
            xmp_th_str += xmp_th;
            xmp_title_str += xmp_title;
        }

        for(var j in tabledata){     
            var color = "";
            var needcolor = compare.resultCompareAll(j);
            //顯示比對文字
            for(var i = 0;i<needcolor.length;i++){
                if(needcolor[i]["needcolor"]) color = "color:red;";      
            }
            var xmpStr = "";
            //body
            for(var comaredb in alldata){
                var doit = false;
                for(var tabledb in tabledata[j]){
                    if(tabledb.indexOf(comaredb)>-1){
                        //填資料
                        var idx = tabledb.split("@")[1];
                        for(var gmid in alldata[comaredb][idx]){
                            var numdata = alldata[comaredb][idx][gmid];
                            var allgmid = Object.keys(alldata[comaredb][idx]).length;
                            var dipyStr = "";
                            xmpStr += showTable.getTbxmp(numdata,allgmid,comaredb,color,j,dipyStr);
                            break;
                        }
                        doit = true;
                        break;
                    }
                }
                //填空格
                if(!doit){
                    var dipyStr = "none;";
                    xmpStr += showTable.getTbxmp(numdata,allgmid,comaredb,color,j,dipyStr);
                }
            }
            xmplist += "<tr>"+xmpStr+"<tr>";
        }

        var th_title = util.getSpan(document,"th_title");
        var thShow = util.getSpan(document,"th_show");
        var tableShow = util.getSpan(document,"showbody");
        if(errorAry == "")error_str.innerHTML = compare.errorStr(true);
        tableShow.innerHTML = xmplist; 
        th_title.innerHTML = xmp_title_str + xmp_title_Str;
        thShow.innerHTML = xmp_th_str + xmp_th_Str;
        nowdate_show.innerHTML = date_show.value;
        search_str.innerHTML="";
        showView.style.display = "";
    }

    //動態產生下方比對table
    self.showBtnTable = function (myidx,only){
        //取得內層資料以長度最長的排序
        compare.comparedata2(myidx);
        var xmp_title_str = "";
        var xmp_th_str = "";
        var xmplist = "";
        var showView = util.getSpan(document,"btnTable_showView");  
        var xmp_table = util.getSpan(document,"xmp_btn_table").innerHTML;
        showView.innerHTML = xmp_table;
        //title
        for(var tabledb in giddata[0]){
            var xmp_title = util.getSpan(document,"xmp_btn_title").innerHTML;
            var xmp_th = util.getSpan(document,"xmp_btn_th").innerHTML;
            xmp_title = xmp_title.replace(/\*DBNAME\*/gi,tabledb);
            xmp_title_str += xmp_title;
            xmp_th_str += xmp_th;
        }
        //body
        for(var j in giddata){     
            var xmpStr="";
            var xmp_btn_font = util.getSpan(document,"xmp_btn_font").innerHTML;
            for(var tabledb in giddata[j]){
                var numdata = giddata[j][tabledb];
                var needcolor = compare.resultCompare(tabledb,j);
                if(only){
                
                    if(needcolor){
                        xmp_btn_font = showTable.getXMP(numdata,needcolor);
                        xmplist += xmp_btn_font;
                    }   
                }else{
                    xmp_btn_font =  showTable.getXMP(numdata,needcolor);
                    xmpStr += xmp_btn_font;
                }                  
            }
            xmplist += xmpStr;
            xmplist = "<tr>"+xmplist+"<tr>";
        }
        var th_title = util.getSpan(document,"btn_th_title");
        var thShow = util.getSpan(document,"btn_th_show");
        var tableShow = util.getSpan(document,"btn_showbody"); 
        th_title.innerHTML = xmp_title_str;
        thShow.innerHTML = xmp_th_str;
        tableShow.innerHTML = xmplist;   
        showView.style.display = "";
    }
    //動態產生文字
    self.showText = function(i){
        var error_str = util.getSpan(document,"error_str");
        var search_str = util.getSpan(document,"search_str");
        var nowdate_show = util.getSpan(document,"nowdate_show");
        var date_show = util.getSpan(document,"date_show");
        var rwm_pitboss = util.getSpan(document,"checkbox_RWM_PITBOSS").checked
        var okada_pitboss = util.getSpan(document,"checkbox_OKADA_PITBOSS").checked
        error_str.innerHTML = "";
        error_All_Str += compare.errorStr(false);
        var tablelength = Object.keys(tableinfoObj["tableinfo"]).length;
        if(!rwm_pitboss && okada_pitboss)tablelength = 26;
        if(rwm_pitboss && !okada_pitboss)tablelength = 14;
        if(i == tablelength){
            if(error_All_Str != ""){
                error_str.innerHTML = error_All_Str;
                nowdate_show.innerHTML = date_show.value;
                if(error_str.innerHTML != "")listenEvent.errorListener();
                search_str.innerHTML="";
                toolbag.showtextSw();
            }else{
                search_str.innerHTML = "當日比對無資料。"
                nowdate_show.innerHTML = "";
                toolbag.showtextSw();
            }    
            error_All_Str = "";
        }
    }
    //動態產生珠路
    self.showAllroad = function(idx){
        var date = util.getSpan(document, "date_show").value;
        var allroadview = util.getSpan(document, "allroadview");
        var xmp_str = "";
        compare.comparedata2(idx);
        //動態產生table
        for(var giddb in giddata[0]){
            for(var tabledb in tabledata[idx]){
                var tabledbname = tabledb.split("@")[0];
                var tableidx = tabledb.split("@")[1];
                if(giddb == tabledbname){
                    var xmpheader = util.getSpan(document,"xmpheader").innerHTML;
                    for(var gmid in alldata[giddb][tableidx]){
                        var allgmid = Object.keys(alldata[giddb][tableidx]).length;
                        var numdata = alldata[giddb][tableidx][gmid][0];
                        var tbid = numdata["tbid"];
                        var btid = numdata["btid"];
                        var tableName = tableinfoObj["tableinfo"][tbid];
                        var tdstr = showTable.showtabletd();
                        xmpheader = xmpheader.replace("*TBNAME*",tableName);
                        xmpheader = xmpheader.replace("*TBID*",tbid);
                        xmpheader = xmpheader.replace("*BOOT*",btid);
                        xmpheader = xmpheader.replace("*ROUND*",allgmid);
                        xmpheader = xmpheader.replace("*DATE*",date);
                        xmpheader = xmpheader.replace("*LIST*",tdstr);
                        xmpheader = xmpheader.replace(/\*DBNAME\*/gi,giddb);
                        xmp_str += xmpheader ;
                        break;
                    }
                }
            }
        }
        allroadview.innerHTML = xmp_str;
        //顯示table珠路圖
        for(var giddb in giddata[0]){
            for(var tabledb in tabledata[idx]){
                var tabledbname = tabledb.split("@")[0];
                var tableidx = tabledb.split("@")[1];
                if(giddb == tabledbname){
                    var tdcnt = 0;
                    var trcnt = 0;
                    var giddb = tabledb.split("@")[0];
                    var tableidx = tabledb.split("@")[1];
                    for(var gmid in alldata[giddb][tableidx]){
                        if(tdcnt > 5){
                            tdcnt = 0;
                            trcnt++;
                        }
                        var roadtd = util.getSpan(document,giddb + "_"+ tdcnt + "_" + trcnt);
                        var onedata = alldata[giddb][tableidx][gmid][0];
                        var result = toolbag.resultTextImg(onedata,true);
                        roadtd.innerHTML = result;
                        tdcnt ++;
                    }
                }
            } 
        }
        util.setHidden(allroadview,false);
    }

    //上方table資料
    self.getTbxmp = function(numdata,allgmid,comaredb,color,j,dipyStr){
        var xmp_font = util.getSpan(document,"xmp_font").innerHTML;
        var tbid = (dipyStr=="") ? numdata[0]["tbid"]:"";
        var btid = (dipyStr=="") ? numdata[0]["btid"]:"";
        var usatime = (dipyStr=="") ?  numdata[0]["usatime"]:"";
        if(dipyStr!="")allgmid = "";
        xmp_font = xmp_font.replace("*TABLE*",tbid);
        xmp_font = xmp_font.replace("*BOOT*",btid);
        xmp_font = xmp_font.replace("*ALLTABLENUM*",allgmid);
        xmp_font = xmp_font.replace("*DBNAME*",comaredb);
        xmp_font = xmp_font.replace("*TIME*",usatime);
        xmp_font = xmp_font.replace(/\*COLOR\*/gi,color);
        xmp_font = xmp_font.replace("*NUM*",j);
        xmp_font = xmp_font.replace("*DISPLAY*",dipyStr);
        return xmp_font;
    }

    //下方table資料
    self.getXMP = function(gmidary,needcolor){
        var xmp_btn_font = util.getSpan(document,"xmp_btn_font").innerHTML;
        var numdata = null;
        var allresult = "";
        var allusatime = "";
        var compareResult= "";
        if(gmidary!=null && gmidary!=""){
            for(var i=0;i<gmidary.length;i++){
                numdata = gmidary[i];
                var tbid = numdata["tbid"];
                var btid =  numdata["btid"];
                var gmid = numdata["gmid"];
                if(allresult!="")allresult+="<br>";
                allresult+=toolbag.resultTextImg(numdata,false);
                if(allusatime!="")allusatime+="<br>";
                allusatime+=numdata["usatime"];
            }
            if(needcolor)compareResult= "color:red;";
          
        }else{
            var tbid = "";
            var btid = "";
            var gmid = "";
        }
        xmp_btn_font = xmp_btn_font.replace("*TABLE*",tbid);
        xmp_btn_font = xmp_btn_font.replace("*BOOT*",btid);
        xmp_btn_font = xmp_btn_font.replace("*TABLENUM*",gmid);
        xmp_btn_font = xmp_btn_font.replace("*RESULT*",allresult);
        xmp_btn_font = xmp_btn_font.replace(/\*COLOR\*/gi,compareResult);//顯示顏色
        xmp_btn_font = xmp_btn_font.replace("*TIME*",allusatime);
        
        return xmp_btn_font;
    }

    //動態產生td
    self.showtabletd = function(){
        var xmptrstr = "";
        for(var j=0;j<6;j++){
            var xmptdstr = "";
            for(var i=0;i<28;i++){
                var xmptd = util.getSpan(document, "xmp_td").innerHTML;
                xmptd = xmptd.replace("*TD*",i);
                xmptdstr += xmptd;
            }
            xmptdstr = xmptdstr.replace(/\*TR\*/gi,j);
            xmptrstr += "<tr>" + xmptdstr + "</tr>"
        }
        return xmptrstr;
    }

}

//比對工具
function compares(){
    var self = this;

    //取得最大總局數dbname及單靴長度
    self.compareAllgmidDB =function(onetable){
        var tmpcomaredb = "";
        var tmptablesum = 0;
        var tmpallgmid = 0;
        for(var comaredb in comparedbobj){
            var tablesum = 0;
            for(var idx in alldata[comaredb]){
                var allgmid = Object.keys(alldata[comaredb][idx]).length;
                tablesum = tablesum *1 + allgmid * 1;
            }
            if(tablesum  != "") {
                tmptablesum = tablesum;
                tmpcomaredb = comaredb;
            }else{
                if(tablesum > tmptablesum) {
                    tmptablesum = tablesum;
                    tmpcomaredb = comaredb;
                }
            }
        }

        for(var tabledbname in onetable){
            var tmpdbname = tabledbname.split("@")[0];//cobaGame phokada_baGame tibaGame
            var tmpidx = tabledbname.split("@")[1];
            if(tmpdbname == tmpcomaredb){
            var tmpallgmid = Object.keys(alldata[tmpdbname][tmpidx]).length;
            break;
            }
        }
        
        var ret = {"dbname":tmpcomaredb,"lendb":tmpallgmid};
        return ret;
    }

    //判斷dbname外層長度,使用外層長度較長的dbname
    self.comparedata = function(){
        var max_dbname =  compare.outerDB();
        for(var max_idx in alldata[max_dbname]){
            for(var max_gmid in alldata[max_dbname][max_idx]){
                var max_myobj = alldata[max_dbname][max_idx][max_gmid][0];
                tabledata[max_idx] = new Array();
                tabledata[max_idx][max_dbname +"@" + max_idx]=max_myobj;
                break;
            }
        }

        for(var dbname in alldata){
            if(dbname==max_dbname)continue;

            for(var idx in alldata[dbname]){
                for(var gmid in alldata[dbname][idx]){
                    var myobj = alldata[dbname][idx][gmid][0];
                    var max_idx = compare.timeCompare(max_dbname,myobj);
                    tabledata[max_idx][dbname +"@" + idx]=myobj;
                    break;
                }
            }
        }
    }

    //判斷dbname內層長度,使用內層長度較長的dbname
    self.comparedata2 = function(myidx){
        giddata = new Array();
        
        var tabledataobj = tabledata[myidx];
        var maxtable = compare.innerDB(tabledataobj);
        var max_dbname = maxtable["dbname"];
        var max_idx =  maxtable["idx"];
        //console.log(myidx,max_dbname,max_idx);
        var j = 0;
        for(var max_gmid in alldata[max_dbname][max_idx]){
            var max_myobj = alldata[max_dbname][max_idx][max_gmid];
            giddata[j] = new Array();
            var ary;
            for(var gidx in max_myobj){
                if(giddata[j][max_dbname]!=null){
                    ary = giddata[j][max_dbname];
                }else{
                    ary = new Array();
                }
                ary[ary.length] = max_myobj[gidx];
                giddata[j][max_dbname]= ary;
            }
            j++;
        }
        //對齊時間資料
        for(var i in giddata){
            for(var tmpdb in tabledata[myidx]){
                var tmpdbname = tmpdb.split("@")[0];
                var tmpidx = tmpdb.split("@")[1];
                if(tmpdbname==max_dbname)continue;
                var gidobj = giddata[i][max_dbname];
                var gmid = "";
                var local = comparedbobj[tmpdbname]["local"];
                if(local == "Y"){
                    gmid = gidobj[0]["gmid"];
                }else{
                    gmid = compare.timeCompare3(gidobj,alldata[tmpdbname][tmpidx],-1);
                }
                var myobj = alldata[tmpdbname][tmpidx][gmid];
                var ary;
                for(var gidx in myobj){
                    //console.log(tmpdb,tmpdbname,tmpidx,gmid,gidx);
                    if(giddata[i][tmpdbname]!=null){
                        ary = giddata[i][tmpdbname];
                    }else{
                        ary = new Array();
                    }
                    ary[ary.length] = myobj[gidx];
                    giddata[i][tmpdbname]= ary;
                }

            }
        }
    
        //過濾重複
        for(var i in giddata){
            for(var tmpdb in giddata[i]){
                var local = comparedbobj[tmpdb]["local"];
                if(tmpdb==max_dbname || local == "Y")continue; 
                if(giddata[i-1]==null)continue;

                var k = 0;
                var upobj = null;
                while (upobj==null) {
                    k++;
                    upobj = giddata[i-k][tmpdb]; 
                }
                var gidobj = giddata[i][tmpdb];
                if(upobj==null || gidobj==null)continue;
                if(upobj[0]["id"]==gidobj[0]["id"]){
                    //console.log(tmpdb,i,i-k,upobj[0]["id"],gidobj[0]["id"]);
                    var t1 = compare.timeCompare2(upobj,giddata[i-k][max_dbname]);
                    var t2 = compare.timeCompare2(gidobj,giddata[i][max_dbname]);
                    if(t1>=t2){
                        giddata[i-k][tmpdb] = null;
                    }else{
                        giddata[i][tmpdb] = null;
                    }
                }
            }

        }

        //補漏的
        for(var i in giddata){
            for(var tmpdb in tabledata[myidx]){
                var tmpdbname = tmpdb.split("@")[0];
                var tmpidx = tmpdb.split("@")[1];
                var local = comparedbobj[tmpdbname]["local"];
                if(tmpdbname==max_dbname || local == "Y")continue;
                var gidobj = giddata[i][max_dbname];
                if(giddata[i][tmpdbname]==null){
                    //當沒資料時拿次小的時間去塞
                    var gmid = compare.timeCompare3(gidobj,alldata[tmpdbname][tmpidx],-1);
                    gmid = compare.timeCompare3(gidobj,alldata[tmpdbname][tmpidx],gmid);
                    for(var j in giddata){
                        //但是要過濾沒其他局用過的gmid才行
                        if(giddata[j][tmpdbname]==null)continue;
                        if(giddata[j][tmpdbname][0]["gmid"]==gmid)return;
                    }
                    myobj = alldata[tmpdbname][tmpidx][gmid];

                    var ary;
                    for(var gidx in myobj){
                        //console.log(tmpdb,tmpdbname,tmpidx,gmid,gidx);
                        if(giddata[i][tmpdbname]!=null){
                            ary = giddata[i][tmpdbname];
                        }else{
                            ary = new Array();
                        }
                        ary[ary.length] = myobj[gidx];
                        giddata[i][tmpdbname]= ary;
                    }

                    //排除相近時間 gmid 順序錯誤的
                    if( giddata[i*1+1]!=null && giddata[i*1+1][tmpdbname]!=null){
                        var next = giddata[i*1+1][tmpdbname];
                        if(ary[0]["gmid"]>next[0]["gmid"]){
                            giddata[i][tmpdbname] = next;
                            giddata[i*1+1][tmpdbname] = ary;
                        }
                    }
                }
            }
        }

        //補local="Y"的薛盒的空格
        for(var i in giddata){
            for(var tmpdb in alldata){
                if(giddata[i][tmpdb] == null){
                    giddata[i][tmpdb] = new Array();
                }
            }
        }
        
    }

    //取得最小時間的idx
    self.timeCompare = function(dbname,myobj){
        var mint = Number.MAX_VALUE;
        var mingmid= null;
        var mytime = Date.parse(myobj["usatime"]);
        for(var idx in alldata[dbname]){
            for(var gmid in alldata[dbname][idx]){
                var time = Date.parse(alldata[dbname][idx][gmid][0]["usatime"]);
                var t = Math.abs(mytime - time);
                if(t<mint){
                    mint = t;
                    mingmid = idx;
                }
                break;
            }

            // if(t<=5000)return idx;
        }
        return mingmid;
    }

    //取得時間差
    self.timeCompare2 = function(gidobj,myobj){
        var mytime = Date.parse(myobj[0]["usatime"]);
        var time = Date.parse(gidobj[0]["usatime"]);
        var t = Math.abs(mytime - time);
        return t;
    }

    //取得時間最小的gmid
    self.timeCompare3 = function(gidobj,myary,fi){
        var mint = Number.MAX_VALUE;
        var mingmid= null;
        for(var gmid in myary){
            if(gmid!=-1 && gmid==fi)continue;
            var myobj = myary[gmid];
            var mytime = Date.parse(myobj[0]["usatime"]);
            var time = Date.parse(gidobj[0]["usatime"]);
            var t = Math.abs(mytime - time);
            if(t<mint){
                mint = t;
                mingmid = gmid;
            } 
        }
        return mingmid;
    }

    //比對上方table
    self.resultCompareAll = function(tableidx){
        var onetable = tabledata[tableidx];
        var ret = new Array();
        //判斷靴盒數量
        if(Object.keys(onetable).length < Object.keys(alldata).length){
            var i = 0;
            for(var tabledbname in onetable){
                var tmpdbname = tabledbname.split("@")[0];
                var tmpidx = tabledbname.split("@")[1];
                for(var gmid in alldata[tmpdbname][tmpidx]){ 
                    var allgmid = Object.keys(alldata[tmpdbname][tmpidx]).length;
                    var tbid = alldata[tmpdbname][tmpidx][gmid][0]["tbid"];
                    var btid = alldata[tmpdbname][tmpidx][gmid][0]["btid"];
                    break;
                }
                
                ret[i] =  {"needcolor":true,"shoeBoxname":tmpdbname,"error":"0","allgmid":allgmid,"tbid":tbid,"btid":btid};
                i++;
            }   
        } 
        if(ret != "") return ret;
        //判斷總局數是否相等
        var tablesum = "";
        var i = 0;
        var ret = new Array();
        //回傳最大總局數的dbname
        var allgmidDB = compare.compareAllgmidDB(onetable);
        var alldbname = allgmidDB["dbname"];
        var lengdb = allgmidDB["lendb"];
        var tmpallgmid = "";
        for(var tabledbname in onetable){
            var tmpdbname = tabledbname.split("@")[0];//cobaGame phokada_baGame tibaGame
            var tmpidx = tabledbname.split("@")[1];
            if(tmpdbname == alldbname)continue;
            for(var gmid in alldata[tmpdbname][tmpidx]){ 
                var allgmid = Object.keys(alldata[tmpdbname][tmpidx]).length;
                var tbid = alldata[tmpdbname][tmpidx][gmid][0]["tbid"];
                var btid = alldata[tmpdbname][tmpidx][gmid][0]["btid"];
                tablesum =  allgmid ;
                break;
            }
            if(lengdb != tablesum){
                tmpallgmid = tablesum;
                ret[i] = {"needcolor":true,"shoeBoxname":tmpdbname,"error":"0","tbid":tbid,"btid":btid,"allgmid":tmpallgmid};
                i++;
            }
        }
        
        if(ret != "") return ret;
        //判斷gmid結果及數量是否相等
        var needcolor =false;
        var dbname = "";
        var idx = "";
        var ret = new Array();
        for(var tabledbname in onetable){
            var cnt = 0;
            var tmpdbname = tabledbname.split("@")[0];//cobaGame phokada_baGame tibaGame
            var tmpidx = tabledbname.split("@")[1];
            if(dbname !=""){
                for(var gmid in alldata[dbname][idx]){
                    needcolor = compare.compareObj(alldata[dbname][idx][gmid],alldata[tmpdbname][tmpidx][gmid]);
                    var tbid = alldata[dbname][idx][gmid][0]["tbid"];
                    var btid = alldata[dbname][idx][gmid][0]["btid"];
                    if(needcolor){
                        cnt++;
                        ret[0] = {"needcolor":needcolor,"error":"1","shoeBoxname":dbname,"count":cnt,"tbid":tbid,"btid":btid,"gmid":gmid};
                    }
                }
            }
            dbname = tmpdbname;
            idx = tmpidx;
        }       
        if(ret != "") return ret;
        //比對無誤
        ret[0] = {"needcolor":needcolor};
        return ret;
    }
    
    //比對下方table
    self.resultCompare = function(dbname,idx){
        var needcolor =false;
        for(var giddbname in giddata[idx]){
            if(Object.keys(giddata[idx]).length < Object.keys(alldata).length) return true;
            if(dbname == giddbname)continue;
            if(dbname !=""){
                needcolor = compare.compareObj(giddata[idx][dbname],giddata[idx][giddbname]);
                if(needcolor)return needcolor;  
            }
        } 
        
        
    }

    //比對結果
    self.compareObj = function(my,other){

        if(my == null || other == null || my.length != other.length){ //比對結果出現次數不同
            return true;
        }else{
            for(var i=0;i<my.length;i++){
                var myobj = my[i];
                var otherobj = other[i];
                var myresult = myobj["result"].substr(myobj["result"].indexOf(","));
                var otherresult = otherobj["result"].substr(otherobj["result"].indexOf(","));
                if(myresult != otherresult){  //比對結果不同
                    return true;
                }
            }
        } 
    }

    //比對結果字串
    self.errorStr = function(only){
        var tmplist = "";
        var tmpAllstr = "";
        var xmp_errorBtn = util.getSpan(document,"xmp_error_btn").innerHTML;
        var tmperror = "";
        var tbid = "";
        for(var j in tabledata){
            var error_Str = "";
            var needcolor = "";
            needcolor = compare.resultCompareAll(j);
            var nodatadb = new Array();
            var errorNum = "";
            for(var i = 0;i<needcolor.length;i++){
                if(needcolor[i]["needcolor"]){
                    if(needcolor[i]["tbid"] != null){
                        tbid = needcolor[i]["tbid"];
                        var btid = needcolor[i]["btid"];
                        var tableName = tableinfoObj["tableinfo"][tbid];
                        var shoeBoxname = needcolor[i]["shoeBoxname"];
                        errorNum = needcolor[i]["error"];
                        var tmpStr = tableName + "(" + tbid + ")" + "桌" + btid + "靴" +"("+ shoeBoxname +")";
                        xmp_errorBtn = xmp_errorBtn.replace(/\*TABLENO\*/gi,tbid);
                        xmp_errorBtn = xmp_errorBtn.replace(/\*TABLENAME\*/gi,tableName);
                        if(errorNum == "0"){
                            var allgmid = needcolor[i]["allgmid"];
                            if(error_Str != "")error_Str += shoeBoxname + ":" + allgmid + " ";
                            else error_Str = tmpStr + " " +  "局數(Ｘ)  " + shoeBoxname + ":" + allgmid + " ";
                            if(needcolor.length == Object.keys(alldata).length) error_Str += "<br>";
                        }else if(errorNum == "1"){
                            var sumgmid = needcolor[i]["count"];
                            error_Str += tmpStr;
                            error_Str += " 局數(Ｏ) 結果(Ｘ) " + "錯" + sumgmid + "局" + "<br>";
                        }
                        nodatadb[shoeBoxname] = shoeBoxname;
                    }
                }
            }

            if(errorNum == "0"){
                for(var comaredb in alldata){
                    var tmpallgmid = 0;
                    //過濾已出現過的薛盒
                    if(comaredb == nodatadb[comaredb])continue;
                    for(var tabledb in tabledata[j]){
                        var tabledbname = tabledb.split("@")[0];
                        var tableidx = tabledb.split("@")[1];
                        if(comaredb == tabledbname){
                            tmpallgmid =  Object.keys(alldata[comaredb][tableidx]).length;
                            break;
                        }
                    }
                    error_Str += comaredb + ":" + tmpallgmid + " ";   
                }
                error_Str += "<br>";
            }
            tmpAllstr += error_Str;
        }

        if(only){
            if(tmpAllstr != "") tmplist += tmpAllstr +"<br>";
        }else{
            tmperror = xmp_errorBtn;
            if(tbid != "")errorAry.push(tbid);
            if(tmpAllstr != "") tmplist += tmperror + "<br>" + tmpAllstr + "<br>";
        }
        
        return tmplist;
    }

    //取得外層資料長度最長的DBNAME
    self.outerDB = function(){
        var lendb = "";
        var dbname = "";
        for(var lendbname in alldata){
            if(lendb != ""){
                if(lendb < alldata[lendbname].length){
                    lendb = alldata[lendbname].length;
                    dbname = lendbname;
                } 
            }else{
                lendb =  alldata[lendbname].length;
                dbname = lendbname;
            }
        }
        return dbname;
    }

    //取得內層資料(gmid)長度最長的DBNAME及idx
    self.innerDB = function(tabledataobj){
        var lendb = "";
        var dbname = "";
        var idx = "";
        for(var tabledb in tabledataobj){
            var tabledbname = tabledb.split("@")[0];
            var tableidx = tabledb.split("@")[1];
            var local = comparedbobj[tabledbname]["local"];
            var shoeboxlen = Object.keys(tabledataobj).length
            var length = Object.keys(alldata[tabledbname][tableidx]).length;
            if(local == "Y" && shoeboxlen == 1){
                var ret = {"dbname":tabledbname,"idx":tableidx,"lendb":length};
                return ret;
            }
            if(local == "N"){
                if(lendb != ""){
                    if(lendb < length){
                        lendb = length;
                        dbname = tabledbname;
                        idx = tableidx;
                    } 
                }else{
                    lendb =  length;
                    dbname = tabledbname;
                    idx = tableidx;
                }
            }
        }
        var ret = {"dbname":dbname,"idx":idx,"lendb":lendb};

    return ret;
    }
}

//工具包
function toolbags(){
    var self = this;
    
    //圖片文字結果
    self.resultTextImg = function(onedata,istrue){
        var tdImgWinnerType = "";
        var tdTextWinnerType = "";
        if (onedata["result"].indexOf("MH") != -1) {
            tdImgWinnerType = "b_";
            tdTextWinnerType = "莊";
        } else if (onedata["result"].indexOf("MC") != -1) {
            tdImgWinnerType = "d_";
            tdTextWinnerType = "閑";
        } else if (onedata["result"].indexOf("MN") != -1) {
            tdImgWinnerType = "p_";
            tdTextWinnerType = "和";
        } else if (onedata["result"].indexOf("-1") != -1) {
            tdTextWinnerType = "流";
        } 

        if (tdTextWinnerType != "" || tdImgWinnerType !="") {
            var isHP = false;
            var isCP = false;
            if (onedata["result"].indexOf("HP") != -1) {
                isHP = true;
            }
            if (onedata["result"].indexOf("CP") != -1) {
                isCP = true;
            }
            if (isHP && isCP) {
                tdImgWinnerType += "04";
                tdTextWinnerType += ",莊對閑對";
            } else if (isHP) {
                tdImgWinnerType += "03";
                tdTextWinnerType += ",莊對";
            } else if (isCP) {
                tdImgWinnerType += "02";
                tdTextWinnerType += ",閑對";
            }else{
                tdImgWinnerType += "01";
            }
        }
        if(istrue){
            return tdText = "<img src='../../../images/control/" + tdImgWinnerType + ".svg' style='width:18px;height:18px;'>"; 
        }else{
            return tdTextWinnerType;  
        } 
    }

    //過濾勾選站別送出的桌次
    self.checktableNo = function(max,min,date,drawSw,dbnameStr){
        var tableNoStr = "";
        var cnt = 0;
        var len = Object.keys(tableinfoObj["tableinfo"]).length;
        var limit = Math.ceil(len/6);
        for(var tableNo in tableinfoObj["tableinfo"]){
            if(min <= tableNo && max>=tableNo){
                if(tableNoStr){
                    tableNoStr += "," + tableNo;
                } else{
                    tableNoStr = tableNo;   
                } 
                cnt++;
                if(cnt>=limit){
                    phpEvent.getdata("getdatas",date,tableNoStr,drawSw,dbnameStr);
                    tableNoStr = "";
                    cnt=0;
                };
            }else if(max == "" && min == ""){
                if(tableNoStr){
                    tableNoStr += "," + tableNo;
                } else{
                    tableNoStr = tableNo;   
                } 
                cnt++;
                if(cnt>=limit){
                    phpEvent.getdata("getdatas",date,tableNoStr,drawSw,dbnameStr);
                    tableNoStr = "";
                    cnt=0;
                };
            }
            
        }
        return tableNoStr;
    }

    //判斷站別個數,是否重新送出請求
    self.comparecasino = function(count){
        var cnt = 0;
        var ret = false;
        for(var shoebox in comparedbobj){
            var shoebox_check = util.getSpan(document,"checkbox_" + shoebox).checked;
            if(shoebox_check){
                cnt++;
            }
        }

        if(count == cnt) ret = true;
        return ret;
    }

    //判斷站別及按鈕開關
    self.casinoControl = function(selectSw){
        var nowshoe = util.getSpan(document,"shoebox_show");
        var nowTable = util.getSpan(document,"tableName_show");
        var newCompareBoot = util.getSpan(document,"newCompareBoot");
        var option = (selectSw) ? nowshoe:nowTable;
        if(option.value == -1){
            if(option == nowTable)newCompareBoot.disabled = true;
        }else{
            if(option == nowTable)newCompareBoot.disabled = false;
            if(option == nowshoe){
                if(nowshoe.value != -1)nowTable.value = -1;
                newCompareBoot.disabled = true;
            }
        }

        for(var dbname in comparedbobj){
            var shoebox = util.getSpan(document,"checkbox_" + dbname);
            //預設全勾
            shoebox.checked = true;
            shoebox.disabled = false;
            if(option.value < 47 && option.value > 20 || option.value == 0 || nowshoe.value == 0  && option.value == -1){
                if(dbname =="RWM_PITBOSS"){
                    shoebox.checked = false;
                    shoebox.disabled = true;  
                    nowshoe.value = 0;  
                }
                
            }else if(option.value > 49 || option.value == 1 || nowshoe.value == 1  && option.value == -1){
                if(dbname !="RWM_PITBOSS" && dbname.indexOf("BA") == -1){
                    shoebox.checked = false;
                    shoebox.disabled = true;
                    nowshoe.value = 1;  
                }
            }
        }
    }

    //取得日期
    self.getDate = function(i){
        var d = new Date();
        d.setDate(d.getDate() -i);
        var dd = d.getDate();
        var mm = (d.getMonth()+1);
        if(dd < 10) dd = "0" + dd;
        if(mm < 10)  mm = "0" + mm;
        var ret  = d.getFullYear() + '-' + mm + '-' + dd;
        return ret;
    }

    //單桌比對畫面控制
    self.compareBootSw = function(){
        var btnshowView = util.getSpan(document,"btnTable_showView");
        var showView = util.getSpan(document,"table_showView");
        var showTable_select =  util.getSpan(document,"showTable_select");
        var nowdate_show = util.getSpan(document,"nowdate_show");
        var allroadview = util.getSpan(document, "allroadview");
        var search_str = util.getSpan(document,"search_str");
        var error_str = util.getSpan(document,"error_str");
        util.setHidden(btnshowView,true);
        util.setHidden(showTable_select,true);
        util.setHidden(showView,true);
        util.setHidden(allroadview,true);
        search_str.innerHTML="查詢中...請稍等。";
        error_str.innerHTML = "";
        nowdate_show.innerHTML = "";
        showView.innerHTML = "";
        btnshowView.innerHTML = "";//初始化table
        allroadview.innerHTML = "";
    }

    //一鍵比對畫面控制
    self.compareTextSw = function(){
        var btnshowView = util.getSpan(document,"btnTable_showView");
        var showView = util.getSpan(document,"table_showView");
        var showTable_select =  util.getSpan(document,"showTable_select");
        var nowdate_show = util.getSpan(document,"nowdate_show");
        var allroadview = util.getSpan(document, "allroadview");
        var date_show = util.getSpan(document,"date_show");
        var newCompareBoot = util.getSpan(document, "newCompareBoot");
        var nowTable = util.getSpan(document,"tableName_show");
        var error_str = util.getSpan(document,"error_str");
        var search_str = util.getSpan(document,"search_str");
        var comparedb_draw = util.getSpan(document,"comparedb_draw");
        var shoebox_show = util.getSpan(document,"shoebox_show");
        newCompareBoot.disabled = true;
        date_show.disabled = true;
        nowTable.disabled = true;
        shoebox_show.disabled = true;
        comparedb_draw.disabled = true;
        util.setHidden(btnshowView,true);
        util.setHidden(showTable_select,true);
        util.setHidden(showView,true);
        util.setHidden(allroadview,true);
        error_str.innerHTML = "";
        search_str.innerHTML = "";
        nowdate_show.innerHTML = "";
        showView.innerHTML = "";
        btnshowView.innerHTML = "";//初始化table
        allroadview.innerHTML = "";
    }

    //table 產生後的畫面控制
    self.showtextSw = function(){
        var date_show = util.getSpan(document,"date_show");
        var newCompareBoot = util.getSpan(document, "newCompareBoot");
        var nowTable = util.getSpan(document,"tableName_show");
        var comparedb_draw = util.getSpan(document,"comparedb_draw");
        var shoebox_show = util.getSpan(document,"shoebox_show");
        comparedb_draw.disabled = false;
        if(nowTable.value != -1)newCompareBoot.disabled = false;
        shoebox_show.disabled = false;
        date_show.disabled = false;
        nowTable.disabled = false;
    }
    //一鍵比對的文字按鈕畫面控制
    self.errorbtnSw = function(tableno){
        var btnshowView = util.getSpan(document,"btnTable_showView");
        var showView = util.getSpan(document,"table_showView");
        var dateopt = util.getSpan(document, "date_show");
        var nowTable = util.getSpan(document,"tableName_show");
        var showTable_select = util.getSpan(document,"showTable_select");
        var newCompareBoot = util.getSpan(document,"newCompareBoot");
        var allroadview = util.getSpan(document, "allroadview");
        showView.innerHTML = "";
        allroadview.innerHTML="";
        btnshowView.innerHTML = "";//初始化table
        nowTable.value = tableno;
        dateopt.value = cmpdate;
        newCompareBoot.disabled = false;
        util.setHidden(allroadview,true);
        util.setHidden(showTable_select,true);
    }
}

function phpEvents(){
    var self = this;
    self.getdata = function(action,data,table,drawSw,dbnameStr){
        var Path = "./allResultCmp/allResultCmp.php";
        var code = "uid=" + uid;
        code += "&action="+action;
        code += "&schdate=" + data;
        code += "&tableno=" + table;
        code += "&drawSw=" + drawSw;
        code += "&dbnameStr=" + dbnameStr;
        util.addPostPHP(action, Path, code, this);
    }

    //取得站別
    self.getcomparedb = function(){
        var Path = "./allResultCmp/allResultCmp.php";
        var code = "uid=" + uid;
        code += "&action=getcomparedb";
        util.addPostPHP("getcomparedb", Path, code, this);

    }

    //取得桌號
    self.gettableNo = function(){
        var Path = "./allResultCmp/allResultCmp.php";
        var code = "uid=" + uid;
        code += "&action=gettableNo";
        util.addPostPHP("gettableNo", Path, code, this);

    }

    self.phpDataCenter = function (eventName, phpData){
        if (!phpData) return;
		if(eventName == "getdata") {
            console.log(phpData);
            alldata = phpData;
            tabledata = new Array();
            compare.comparedata();
            showTable.showView();
            listenEvent.animateListener();
            return;  
        }
        
        if(eventName == "getdatas") {
            // console.log(phpData);
            fulldata = Object.assign(fulldata, phpData);
            var tablelength = "";
            var rwm_pitboss = util.getSpan(document,"checkbox_RWM_PITBOSS").checked;
            var okada_pitboss = util.getSpan(document,"checkbox_OKADA_PITBOSS").checked;
            tablelength = Object.keys(tableinfoObj["tableinfo"]).length;
            if(!rwm_pitboss && okada_pitboss)tablelength = 26;
            if(rwm_pitboss && !okada_pitboss)tablelength = 14;
            if(Object.keys(fulldata).length== tablelength){
                for(var tno in fulldata){
                    alldata = fulldata[tno];
                    tabledata = new Array();
                    compare.comparedata();
                    showTable.showText(count);
                    count++;
                }
            }
            return; 
        }
        if(eventName == "getcomparedb"){
            comparedbobj = phpData;
            showTable.showCheckbox();
            var shoebox_show = util.getSpan(document, "shoebox_show");
            var checkbox_rwm_pitboss = util.getSpan(document,"checkbox_RWM_PITBOSS");
            if(shoebox_show.value == 0){
                checkbox_rwm_pitboss.checked = false;
                checkbox_rwm_pitboss.disabled = true;
            }
            return;
        }
        if(eventName == "gettableNo"){
            var newCompareBoot = util.getSpan(document, "newCompareBoot");
            tableinfoObj = phpData;
            showTable.showTableSelect();
            newCompareBoot.disabled = true;
            return;
        }
    }
}














