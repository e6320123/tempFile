<?php
include("../../conf/config_admin.php");

$uid = $uid;
$schdate = $schdate;
$tableno = $tableno;
$dbnameStr = $dbnameStr;
$drawSw = $drawSw;
$out = array();


//========================================================================

$cs = array();
//21~46
$cs["BOX"] = array();
$cs["BOX"]["time"] = "-04:00";
$cs["BOX"]["ip"] = "192.168.130.219";
$cs["BOX"]["name"] = "BOX";
$cs["BOX"]["DBUSER"] = DB_USER_R;
$cs["BOX"]["DBPSWD"] = DB_PWD_R;
$cs["BOX"]["DBNAME"] = "tibaGame";
$cs["BOX"]["local"] = "N";
$cs["BSB"] = array();
$cs["BSB"]["time"] = "-04:00";
$cs["BSB"]["ip"] = "192.168.130.219";
$cs["BSB"]["name"] = "BSB";
$cs["BSB"]["DBUSER"] = DB_USER_R;
$cs["BSB"]["DBPSWD"] = DB_PWD_R;
$cs["BSB"]["DBNAME"] = "cobaGame";
$cs["BSB"]["local"] = "N";
$cs["OKADA_PITBOSS"] = array();
$cs["OKADA_PITBOSS"]["time"] = "+08:00";
$cs["OKADA_PITBOSS"]["ip"] = "192.168.130.219";
$cs["OKADA_PITBOSS"]["name"] = "OKADA_PITBOSS";
$cs["OKADA_PITBOSS"]["DBUSER"] = DB_USER_R;
$cs["OKADA_PITBOSS"]["DBPSWD"] = DB_PWD_R;
$cs["OKADA_PITBOSS"]["DBNAME"] = "phokada_baGame";
$cs["OKADA_PITBOSS"]["local"] = "N";
//50~63
$cs["RWM_PITBOSS"] = array();
$cs["RWM_PITBOSS"]["time"] = "+08:00";
$cs["RWM_PITBOSS"]["ip"] = "192.168.130.70";
$cs["RWM_PITBOSS"]["name"] = "RWM_PITBOSS";
$cs["RWM_PITBOSS"]["DBUSER"] = "baPHP";
$cs["RWM_PITBOSS"]["DBPSWD"] = "baPHP_PassCode";
$cs["RWM_PITBOSS"]["DBNAME"] = "phctbaGame";
$cs["RWM_PITBOSS"]["local"] = "N";
if(CASINO_CSS == "TI"){
    $cs["BA2"] = array();
    $cs["BA2"]["time"] = "-04:00";
    $cs["BA2"]["ip"] = "192.168.130.74";
    $cs["BA2"]["name"] = "BA2_TI";
    $cs["BA2"]["DBUSER"] = "baPHP";
    $cs["BA2"]["DBPSWD"] = "baPHP_PassCode";
    $cs["BA2"]["DBNAME"] = "baabaGame";
    $cs["BA2"]["local"] = "Y";
}else if(CASINO_CSS == "CO"){
    $cs["BA3"] = array();
    $cs["BA3"]["time"] = "-04:00";
    $cs["BA3"]["ip"] = "192.168.10.220";
    $cs["BA3"]["name"] = "BA3_CO";
    $cs["BA3"]["DBUSER"] = "baPHP";
    $cs["BA3"]["DBPSWD"] = "baPHP_PassCode";
    $cs["BA3"]["DBNAME"] = "cobaGame";
    $cs["BA3"]["local"] = "Y";
}else if(CASINO_CSS == "CT"){
    $cs["BA5"] = array();
    $cs["BA5"]["time"] = "-04:00";
    $cs["BA5"]["ip"] = "192.168.10.220";
    $cs["BA5"]["name"] = "BA5_CT";
    $cs["BA5"]["DBUSER"] = "baPHP";
    $cs["BA5"]["DBPSWD"] = "baPHP_PassCode";
    $cs["BA5"]["DBNAME"] = "ctbaGame";
    $cs["BA5"]["local"] = "Y";
}

if($action == "gettableNo"){
    $ary = array();
    $ary["tableinfo"] = getNo();
    echo json_encode($ary);
    exit;
}

if($action == "getcomparedb"){


    $comparedata = $cs;

    echo json_encode($comparedata);
    exit;
}

if($action == "getdata"){
    if($dbnameStr == "") exit;
    $dbnameAry = Array();
    $dbnameAry = explode(",",$dbnameStr);
    for($i=0;$i<count($dbnameAry);$i++){
        $key = $dbnameAry[$i];
        $dbhost = $cs[$key]["ip"];
        $timezone = $cs[$key]["time"];
        $dbname = $cs[$key]["DBNAME"];
        $dbuser = $cs[$key]["DBUSER"];
        $dbpswd = $cs[$key]["DBPSWD"];
        $dbr= new proc_DB($dbhost, $dbuser, $dbpswd, $dbname);
        if($out[$key] == null)$out[$key]=array();//第一層
        $out[$key] = getData($dbr,$timezone,$schdate,$tableno,$drawSw);
    }
    echo json_encode($out);
    exit;
}

if($action == "getdatas"){
    if($dbnameStr == ""|| $tableno == "") exit;
    $dbnameAry = explode(",",$dbnameStr);
    $tablenoAry = explode(",",$tableno);
    for($i=0;$i<count($dbnameAry);$i++){
        $key = $dbnameAry[$i];
        $dbhost = $cs[$key]["ip"];
        $dbnameTime = $cs[$key]["time"];
        $dbname = $cs[$key]["DBNAME"];
        $dbuser = $cs[$key]["DBUSER"];
        $dbpswd = $cs[$key]["DBPSWD"];
        $dbr= new proc_DB($dbhost, $dbuser, $dbpswd, $dbname);
        for($j=0;$j<count($tablenoAry);$j++){
            $tno= $tablenoAry[$j];
            if($out[$tno] == null)$out[$tno]=array();//第一層
            if($out[$tno][$key] == null)$out[$tno][$key]=array();//第一層
            $out[$tno][$key] = getData($dbr,$dbnameTime,$schdate,$tno,$drawSw);
        }
    }
    echo json_encode($out);
    exit;
}



function getData($dbr,$timezone,$schdate,$tableno,$drawSw){
    $ret = array();
    $count = 0;
    $gmidcount = 0;
    if($timezone == "-04:00"){
        $sql = "SELECT * , CONCAT( DATE,  ' ', stime ) AS usatime ";
    }else{
        $sql = "SELECT * , CONVERT_TZ( CONCAT( DATE,  ' ', stime ),  '".$timezone."',  '-04:00' ) AS usatime ";
    }
    if($drawSw == "N") $draw = "AND `result` != '-1,-1,-1,-1'";
    else $draw ="";
    $sql .= "FROM BA ";
    $sql .= "WHERE  `tbid` =  '".$tableno."' ".$draw." AND `result` IS NOT NULL ";
    $sql .= "HAVING usatime >=  '".$schdate." 00:00:00'";
    $sql .= "AND usatime <=  '".$schdate." 23:59:59' ORDER BY id;";
    $dbr->query($sql);
    $upbtid = "-1";
    $upgmid = "-1";
    while($dbr->next_record()){
        $id = $dbr->f("id");//流水號
        $tbid = $dbr->f("tbid");//桌
        $btid = $dbr->f("btid");//靴
        $gmid = $dbr->f("gmid");//局
        
        $obj = array();
        $obj["id"] = $id;
        $obj["tbid"] = $tbid;
        $obj["btid"] = $btid;
        $obj["gmid"] = $gmid;
        $obj["result"] = $dbr->f("result");//結果
        $obj["usatime"] = $dbr->f("usatime");//此局的美東時間

        if($upbtid == "-1")$upbtid = $btid;
        if($btid!=$upbtid){
            $count++;
            $upbtid = $btid;
        }

        if($ret[$count][$gmid]!=null){
            $ary = $ret[$count][$gmid];
        }else{
            $ary = array();
        }
        if($ret[$count] == null)$ret[$count] = array();//第二層
        $ary[count($ary)] = $obj;//第三層
        $ret[$count][$gmid] = $ary;
    }
    return $ret;
}

function getNo(){

    $tt = array();
    $tt["21"]="6601";
    $tt["22"]="6602";
    $tt["23"]="6603";
    $tt["24"]="6604";
    $tt["25"]="6605";
    $tt["26"]="6606";
    $tt["27"]="6607";
    $tt["28"]="6608";
    $tt["29"]="6701";
    $tt["30"]="6801";
    $tt["31"]="6901";
    $tt["32"]="5001";
    $tt["33"]="5002";
    $tt["34"]="5003";
    $tt["35"]="5004";
    $tt["36"]="5005";
    $tt["37"]="5006";
    $tt["38"]="5007";
    $tt["39"]="5008";
    $tt["40"]="5301";
    $tt["41"]="7001";
    $tt["42"]="7002";
    $tt["43"]="7003";
    $tt["44"]="7004";
    $tt["45"]="7301";
    $tt["46"]="5201";
    $tt["50"] ="MBJ80" ;
    $tt["51"] ="MBJ81" ;
    $tt["52"] ="MBJ85" ;
    $tt["53"] ="MBJ86" ;
    $tt["54"] ="MBJ87" ;
    $tt["55"] ="MBJ88" ;
    $tt["56"] ="MBJ90" ;
    $tt["57"] ="MBJ91" ;
    $tt["58"] ="MBJ92" ;
    $tt["59"] ="MBJ93" ;
    $tt["60"] ="MBJ95" ;
    $tt["61"] ="MBJ96" ;
    $tt["62"] ="MBJ97" ;
    $tt["63"] ="MBJ98" ;

    return $tt;

}
?>