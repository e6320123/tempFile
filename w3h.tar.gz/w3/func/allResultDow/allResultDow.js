var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;
var dateAgo = 30;//預設30天以前
var datedata = [];
function init(){
    listenEvent = new listenEvent();
    showdate();
    listenEvent.staticListener();
    listenEvent.selectListener();
}
function listenEvent(){
    var self = this;
	//靜態監聽
	self.staticListener = function (){
        listenEvt.addOnClick("getExcel", util.getSpan(document, "getExcel"), this, null);
    }
    self.selectListener = function (){
        listenEvt.addSelectOnChange("date_show_start", util.getSpan(document, "date_show_start"), this, null);
        listenEvt.addSelectOnChange("date_show_end", util.getSpan(document, "date_show_end"), this, null);
    }
    self.listenCenter = function(eventName, listenData) {
        if(eventName == "getExcel"){
            var date_show_start = util.getSpan(document,"date_show_start");
            var date_show_end = util.getSpan(document,"date_show_end");
            var sdate = date_show_start.value;
            var edate = date_show_end.value;
            var sobj = datedata[sdate];
            var eobj = datedata[edate];
            if(eobj["ms"] - sobj["ms"] > 0 || eobj["ms"] - sobj["ms"] == 0){
                for(i = eobj["ago"] ; i <= sobj["ago"] ;i++){
                    var date = getDate(i,false);
                    var Path = "./allResultDow/allResultDow.php?uid=" + uid + "&date=" + date;
                   // console.log(date,i,Path);
                    downloadFile(Path);
                }
            }
            return;
        }
        if(eventName == "date_show_start"){
            datecompare(false);
            return;
        }
        if(eventName == "date_show_end"){
            datecompare(true);
            return;
        }
    }
}
//新增iframe多次下載
function downloadFile(Path){
    var iframe = document.createElement("iframe");
    iframe.style.display = "none"; // 防止影響頁面
    iframe.style.height = 0; // 防止影響頁面
    iframe.src = Path; 
    document.body.appendChild(iframe);
    setTimeout(function (){// 5分鐘之後刪除
        iframe.remove();
    },5 * 60 * 1000);
}
//日期比對
function datecompare(sw){
    var date_show_start = util.getSpan(document,"date_show_start");
    var date_show_end = util.getSpan(document,"date_show_end");
    var sdate = date_show_start.value;
    var edate = date_show_end.value;
    if(datedata[edate]["ms"] - datedata[sdate]["ms"] < 0){
        if(sw)date_show_start.value = edate;
        else date_show_end.value = sdate;
    }
}
//動態產生日期
function showdate(){
    var date_show_start = util.getSpan(document,"date_show_start");
    var date_show_end = util.getSpan(document,"date_show_end");
    var xmpdate = "";
    for(var i = 1; i<= dateAgo ;i++){
        var xmp_date_select = util.getSpan(document,"xmp_date_select").innerHTML;
        xmp_date_select = xmp_date_select.replace(/\*DATE\*/gi,getDate(i,true));
        xmpdate += xmp_date_select;
    }
    date_show_start.innerHTML = xmpdate;
    date_show_end.innerHTML = xmpdate;
    date_show_start.value = getDate(1,false);//取前一天日期
    date_show_end.value = getDate(1,false);
}
//取得前i天日期,sw 儲存30天以前毫秒數
function getDate(i,sw){
    var d = new Date();
    var ss = d.setDate(d.getDate() -i);
    var dd = d.getDate();
    var mm = (d.getMonth()+1);
    if(dd < 10) dd = "0" + dd;
    if(mm < 10)  mm = "0" + mm;
    var ret  = d.getFullYear() + '-' + mm + '-' + dd;
    if(sw) datedata[ret] = {"ms":ss,"ago":i};
    return ret;
}
