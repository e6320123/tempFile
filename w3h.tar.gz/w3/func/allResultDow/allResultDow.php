<?php
include("../../conf/config_admin.php");
$uid = $uid;
$date = $date;
$filename = $date . ".csv";
//百三測試機
// $dbhost = "192.168.201.121";
// $dbuser = DB_USER_R;
// $dbpswd = DB_PWD_R;
// $dbname = DB_NAME_FT;
//線上百二
$dbhost = "192.168.130.74";
$dbuser = "baPHP";
$dbpswd = "baPHP_PassCode";
$dbname = "baabaGame";  
$dbr= new proc_DB($dbhost, $dbuser, $dbpswd, $dbname);
$dataBA = "BA";
$datarecord = "BA_record";
$min = 0;
$max = 5000;
$uNum = 1;
if($date == "" || $date == null) exit;
while($uNum != 0){
    $limit = $max;
    $sql = "SELECT * FROM  ".$dataBA." WHERE `date` = '".$date."' AND  `result` != '-1,-1,-1,-1' ORDER BY `date`,`id` LIMIT ".$min.",".$max.";";
    $dbr->query($sql);
    $uNum = $dbr->num_rows();
    $idstr = "";
    $cardAry = array();
    $i = 0 ;
    while($dbr->next_record()){
        $id = $dbr->f("id");
        $cardAry[$i]["id"] = $dbr->f("id");//流水號
        $cardAry[$i]["tbid"] = $dbr->f("tbid");//桌
        $cardAry[$i]["btid"] = $dbr->f("btid");//靴
        $cardAry[$i]["gmid"] = $dbr->f("gmid");//局
        $cardAry[$i]["orderdate"] = $dbr->f("date");//日期
        $cardAry[$i]["stime"] = $dbr->f("stime");//開始時間
        $cardAry[$i]["etime"] = $dbr->f("etime");//結束時間
        $cardAry[$i]["result"] = $dbr->f("result");//結果
        if($idstr != "")$idstr .= ",".$id;
        else $idstr = $id;
        $i++;
    }
    if($idstr != "")$sql = "SELECT * FROM  ".$datarecord." WHERE `baid` in(".$idstr.");";
//=============================================================================
    //拿BA的id去對BA_record的baid
    $dbr->query($sql);
    $i=0;
    $cardstr = "";
    $allstr = "";
    $tmpAry = "";
    $calcAry = "";
    while($dbr->next_record()){
        $card1 = $dbr->f("card1");
        $card2 = $dbr->f("card2");
        $card3  = $dbr->f("card3");
        $card4  = $dbr->f("card4");
        $card5 = $dbr->f("card5");
        $card6 = $dbr->f("card6");
        $cardAry[$i]["card1"] = $card1;
        $cardAry[$i]["card2"] = $card2;
        $cardAry[$i]["card3"] = $card3;
        $cardAry[$i]["card4"] = $card4;
        $cardAry[$i]["card5"] = $card5;
        $cardAry[$i]["card6"] = $card6; 
        $cardstr = $card1.",".$card2.",".$card3.",".$card4.",".$card5.",".$card6;
        $allstr = calcNum($cardstr,$i);
        $tmpAry = explode("@",$allstr);
        for($j=0;$j<count($tmpAry);$j++){
            $calcAry = explode(",",$tmpAry[$j]);
            for($k=0;$k<count($calcAry);$k++){
                if($j == 0){
                    $cardAry[$i]["cardColor".($k+1)]=$calcAry[$k];
                }else{
                    $cardAry[$i]["cardNum".($k+1)]=$calcAry[$k];
                }
            }
        }
        $i++;
    }
    getcsv($cardAry,$filename,$min);
    $min = $min + $limit;
}
if($dbr) $dbr->close();
exit;
//=============================================================================
function calcNum($cardstr,$i){
    $cardstrAry = array();
    $colorstr = "";
    $numstr = "";
    $allstr = "";
    $cardstrAry = explode(",",$cardstr);
    for($j=0;$j<count($cardstrAry);$j++){
        $card = $cardstrAry[$j];
        if($card == 0){
            $color =  floor((fmod(abs($card-1),100)/13)*100);
        }else{
            $color =  floor((fmod($card-1,100)/13));
        }
        $num = fmod(fmod($card,100),13);
        if($colorstr != "" || $numstr != ""){
            $colorstr .= ','.$color;
            $numstr .= ','.$num;
        }else{
            $colorstr = $color;
            $numstr = $num;
        }
    }
    $allstr = $colorstr.'@'.$numstr;
    return $allstr;
}
//輸出excel
function getcsv($cardAry,$filename,$min){
    header('Pragma: no-cache');
    header('Expires: 0');
    header('Content-Disposition: attachment;filename="' . $filename . '";');
    header('Content-Type: application/csv; charset=UTF-8');
    //csv標題
    if($min == 0){
        $csv_arr[] = array(
        '流水號','桌','靴','局','日期','開始時間','結束時間','結果',
        'card1','card2','card3','card4','card5','card6',
        'card1花色','card1數字','card2花色','card2數字','card3花色','card3數字',
        'card4花色','card4數字','card5花色','card5數字','card6花色','card6數字'
        );
    }
    //帶入資料陣列
    for($i = 0; $i <count($cardAry); $i++){
        $ca = $cardAry[$i];
        $csv_arr[] = array(
            $c1= $ca['id'],
            $c2= $ca['tbid'],
            $c3= $ca['btid'],
            $c4= $ca['gmid'],
            $c5= $ca['orderdate'],
            $c6= $ca['stime'],
            $c7= $ca['etime'],
            $c8= str_replace(',', '，' , $ca['result']),
            $c9=  $ca['card1'],
            $c10=  $ca['card2'],
            $c11=  $ca['card3'],
            $c12=  $ca['card4'],
            $c13= $ca['card5'],
            $c14= $ca['card6'],
            $c15= $ca['cardColor1'],
            $c16= $ca['cardNum1'],
            $c17= $ca['cardColor2'],
            $c18= $ca['cardNum2'],
            $c19= $ca['cardColor3'],
            $c20= $ca['cardNum3'],
            $c21= $ca['cardColor4'],
            $c22= $ca['cardNum4'],
            $c23= $ca['cardColor5'],
            $c24= $ca['cardNum5'],
            $c25= $ca['cardColor6'],
            $c26= $ca['cardNum6'],
        );
    }
    
    for ($j = 0; $j < count($csv_arr); $j++) {
        if ($j == 0) {
            //輸出 BOM 避免 Excel 讀取時會亂碼
            echo "\xEF\xBB\xBF";
        }
        echo join(',', $csv_arr[$j]) . PHP_EOL;
    }
    $csv_arr = array();
}
?>