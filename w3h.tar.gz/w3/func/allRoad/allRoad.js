var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;

var choiceDB = "IPLC";
var lenOfRow = 6;
var tableNum = "";              //單桌號碼
var allData;                    //每桌全部Data
var allReadData;                    //外點每桌全部Data
var videoHostData;              //視訊Data
var reloadsec = 60;//刷新倒數
var nowshowVideo = "";//目前視訊是哪桌
var videoLimit = 0;//目前視訊數量
var roads = new Array();

var videoCenter;                //上一次點擊開啟視訊
var videoAry = new Array();     //CH1,CH2,CH3
var videoDomain = "ibd3000.com";//ba2:iabc365.com/iabc3000.com ba3:ibd080.com/ibd3000.com ba5:88lucky3000

var nowGRP = 2; //預設分頁 okada

var isShowOrgRoad = "N"; //預設不show 流局
var elementSelected;
var mouseX, mouseY;
var moveX = 0;
var moveY = 0;
var nowNo;//目前視訊是哪一桌
var ishttps = ('https:' == document.location.protocol) ? true : false;

//初始化
function init() {
    if (CASINO == "CO") {
        videoDomain = "ibd3000.com";
    } else if (CASINO == "CT") {
        videoDomain = "88lucky3000.com";
    } else {
        videoDomain = "iabc3000.com";
    }
    phpEvent = new phpEvent();	        //PHP事件
    listenEvent = new listenEvent();	//監聽事件
    //DTF = new DateTimeFormat();	    //取得時間格式
    threadEvent = new threadEvent();

    phpEvent.getVideoData();
    phpEvent.allRoad();
    phpEvent.allReadRoad();
    threadEvent.startReloadThread();


    //視訊畫面
    document.querySelectorAll(".move").forEach(function (element, index) {
        // element.style.left = 400;
        element.addEventListener('mousedown', function (event) {
            elementSelected = element;
            elementSelectStart = true;
            mouseX = event.clientX - parseInt(getComputedStyle(elementSelected).left);
            mouseY = event.clientY - parseInt(getComputedStyle(elementSelected).top);
        })
        element.addEventListener('mouseup', function (event) {
            //啟動五個視訊
            if (moveX != 0 || moveY != 0) {//有移動才刷新
                console.log(moveX + "|" + moveY);
                for (var i = 1; i <= videoLimit; i++) {
                    showVideo(nowNo, i);
                }
                newHLSplayer(nowNo);
            }
            moveX = 0;//重置移動計數器
            moveY = 0;
            elementSelected = undefined;

        })
    });
    document.addEventListener('mousemove', function (event) {
        var videoDiv = util.getSpan(document, "videoTB");
        if (videoDiv.style.display == "") {
            if (elementSelected !== undefined) {
                moveX += event.clientX - mouseX;
                moveY += event.clientY - mouseY;
                clearVideo();//關閉 視訊
                elementSelected.style.left = event.clientX - mouseX + 'px';
                elementSelected.style.top = event.clientY - mouseY + 'px';
            }
        }
    });

}

//PHP事件
function phpEvent() {
    var self = this;
    var aPath = "/func/allRoad/allRoad.php";
    //桌次Data
    self.allRoad = function () {
        var parame = "&action=allRoad";
        parame += "&uid=" + uid;
        parame += "&grp=" + nowGRP;
        parame += "&choiceDB=" + choiceDB;
        parame += "&isShowOrgRoad=" + isShowOrgRoad;
        util.addPostPHP("allRoad", aPath, parame, this);
    }
    // 外點桌次Data
    self.allReadRoad = function () {
        var parame = "&action=allReadRoad";
        parame += "&uid=" + uid;
        parame += "&grp=" + nowGRP;
        parame += "&choiceDB=" + choiceDB;
        parame += "&isShowOrgRoad=" + isShowOrgRoad;
        util.addPostPHP("allReadRoad", aPath, parame, this);
    }
    //重新取珠路Data
    self.reGetAllRoad = function () {
        var parame = "&action=reGetAllRoad";
        parame += "&uid=" + uid;
        parame += "&grp=" + nowGRP;
        parame += "&choiceDB=" + choiceDB;
        parame += "&isShowOrgRoad=" + isShowOrgRoad;
        util.addPostPHP("reGetAllRoad", aPath, parame, this);
    }
    //重新取外點珠路Data
    self.reGetAllReadRoad = function () {
        var parame = "&action=reGetAllReadRoad";
        parame += "&uid=" + uid;
        parame += "&grp=" + nowGRP;
        parame += "&choiceDB=" + choiceDB;
        parame += "&isShowOrgRoad=" + isShowOrgRoad;
        util.addPostPHP("reGetAllReadRoad", aPath, parame, this);
    }
    //重新取單桌珠路Data
    self.reGetOnlyRoad = function () {
        var parame = "&action=reGetOnlyRoad";
        parame += "&uid=" + uid;
        parame += "&grp=" + nowGRP;
        parame += "&choiceDB=" + choiceDB;
        parame += "&tableNum=" + tableNum;
        parame += "&isShowOrgRoad=" + isShowOrgRoad;
        util.addPostPHP("reGetOnlyRoad", aPath, parame, this);
    }
    //重新取外點單桌珠路Data
    self.reGetOnlyReadRoad = function () {
        var parame = "&action=reGetOnlyReadRoad";
        parame += "&uid=" + uid;
        parame += "&grp=" + nowGRP;
        parame += "&choiceDB=" + choiceDB;
        parame += "&tableNum=" + tableNum;
        parame += "&isShowOrgRoad=" + isShowOrgRoad;
        util.addPostPHP("reGetOnlyReadRoad", aPath, parame, this);
    }

    //視訊Data
    self.getVideoData = function () {
        var parame = "&action=getVideoData";
        parame += "&grp=" + nowGRP;
        parame += "&uid=" + uid;
        util.addPostPHP("getVideoData", aPath, parame, this);
    }

    //PHP事件回應
    self.phpDataCenter = function (eventName, phpData) {

        //get 全部桌Data
        if (eventName == "allRoad") {
            // console.log(phpData);
            allData = phpData;
            // phpEvent.getVideoData();
            console.time("Time this");
            showAllRoadTable(allData["allRoadData"]);
            showAllRoad(allData["allRoadData"], "road");
            console.timeEnd("Time this");
            listenEvent.setStaticListen();
            var showallRoad = document.getElementById("showallRoad");
            util.setHidden(showallRoad, false);
        }
        //get 全部外點桌Data
        if (eventName == "allReadRoad") {
            // console.log(phpData);
            allReadData = phpData;
            // phpEvent.getVideoData();
            console.time("Time this 2");
            showAllRoadTable2(allReadData["allReadRoadData"]);
            showAllRoad(allReadData["allReadRoadData"], "readroad");
            console.timeEnd("Time this 2");
            var showallRoad2 = util.getSpan(document, "showallRoad2");
            util.setHidden(showallRoad2, false);
        }
        //重新取珠路Data
        if (eventName == "reGetAllRoad" || eventName == "reGetOnlyRoad") {
            if (eventName == "reGetAllRoad") {
                allData = phpData;
                showAllRoad(allData["allRoadData"], "road");
            } else {
                showAllRoad(phpData["allRoadData"], "road");
            }
            //刷新檢查
            var objtmp = new Object()
            objtmp["div"] = util.getSpan(document, "showfilter");
            listenEvent.listenCenter("showfilter", objtmp);
        }
        //重新取外點珠路Data
        if (eventName == "reGetAllReadRoad" || eventName == "reGetOnlyReadRoad") {
            if (eventName == "reGetAllReadRoad") {
                allReadData = phpData;
                showAllRoad(allReadData["allReadRoadData"], "readroad");
            } else {
                showAllRoad(phpData["allReadRoadData"], "readroad");
            }
            //刷新檢查
            var objtmp = new Object()
            objtmp["div"] = util.getSpan(document, "showfilter");
            listenEvent.listenCenter("showfilter", objtmp);
        }
        //get 視訊Data
        if (eventName == "getVideoData") {
            console.log("getVideoData");
            videoHostData = phpData["host_data"];
            videoLimit = phpData["channelcount"];
        }
    }
}
//監聽事件
function listenEvent() {
    var self = this;
    //建立監聽事件
    self.setStaticListen = function () {

        for (var i = 0; i < Object.keys(allData["allRoadData"]).length; i++) {
            var no = Object.keys(allData["allRoadData"])[i];
            listenEvt.addOnClick("videobtn" + no, util.getSpan(document, "videobtn_" + no), this, no);
            listenEvt.addOnClick("onlyreload" + no, util.getSpan(document, "onlyreload_" + no), this, "");
        }
        listenEvt.addOnClick("title_1", util.getSpan(document, "title_1"), this, "1");
        listenEvt.addOnClick("title_2", util.getSpan(document, "title_2"), this, "2");
        listenEvt.addOnClick("title_3", util.getSpan(document, "title_3"), this, "3");
        listenEvt.addOnClick("title_4", util.getSpan(document, "title_4"), this, "4");

        listenEvt.addOnClick("reload", util.getSpan(document, "reload"), this, "");
        listenEvt.addOnClick("showorgroad", util.getSpan(document, "showorgroad"), this, "");
        listenEvt.addSelectOnChange("showfilter", util.getSpan(document, "showfilter"), this, "");

    }

    self.listenCenter = function (eventName, obj) {
        console.log(eventName);
        if (eventName.indexOf("videobtn") != -1) {
            nowNo = obj.object;
            var btndiv = obj.div;
            var videoShowDiv = util.getSpan(document, "videoTB");
            var fixheighdiv = util.getSpan(document, "fixheighdiv");
            // console.log("nowshowVideo=" + nowshowVideo + " | no= " + no);
            if (nowshowVideo != "" && nowshowVideo != nowNo) {//不同桌
                var oldbtn = util.getSpan(document, "videobtn_" + nowshowVideo);//前一個按鈕
                var newbtn = util.getSpan(document, "videobtn_" + nowNo);//前一個按鈕
                util.setClassName(oldbtn, "btn btn-secondary");//還原按鈕
                util.setClassName(newbtn, "btn btn-danger");//目前點的要換色
                util.setHidden(videoShowDiv, false);
                // fixheighdiv.style.height = "300px";
                //目前有五個視訊
                for (var i = 1; i <= videoLimit; i++) {
                    showVideo(nowNo, i);
                }
                newHLSplayer(nowNo);
            } else {//同桌
                if (btndiv.className.indexOf("secondary") != -1) {//開啟
                    util.setClassName(btndiv, "btn btn-danger");
                    util.setHidden(videoShowDiv, false);
                    // fixheighdiv.style.height = "300px";
                    //目前有五個視訊
                    for (var i = 1; i <= videoLimit; i++) {
                        showVideo(nowNo, i);
                    }
                    newHLSplayer(nowNo);
                } else {
                    util.setClassName(btndiv, "btn btn-secondary");
                    util.setHidden(videoShowDiv, true);
                    //關閉視訊 重置header 位置
                    var headerDiv = util.getSpan(document, "headerDIV");
                    headerDiv.style.left = 0;
                    headerDiv.style.top = 0;
                    clearVideo();//關閉 清空
                    // fixheighdiv.style.height = "90px";

                }
            }
            nowshowVideo = nowNo;

            return;
        }

        if (eventName == "reload") {
            threadEvent.reload();
        }
        if (eventName.indexOf("onlyreload") != -1) {
            tableNum = eventName.match(/\d+/g)[0];
            threadEvent.onlyreload();
        }
        //切換頂部filter
        if (eventName.indexOf("title_") != -1) {
            clearVideo();//關閉 清空
            var olddiv = util.getSpan(document, "title_" + nowGRP);
            util.setClassName(olddiv, "nav-link"); //
            var newdiv = util.getSpan(document, "title_" + obj.object);
            util.setClassName(newdiv, "nav-link active");
            var filterdiv = util.getSpan(document, "showfilter");
            filterdiv.value = "all";//預設全部顯示
            //關閉視訊
            var videoShowDiv = util.getSpan(document, "videoTB");
            var fixheighdiv = util.getSpan(document, "fixheighdiv");
            util.setHidden(videoShowDiv, true);
            nowshowVideo = "";//目前視訊是哪桌
            // fixheighdiv.style.height = "90px";

            nowGRP = obj.object;
            phpEvent.getVideoData();
            phpEvent.allRoad();
            phpEvent.allReadRoad();
        }
        //是否顯示流局
        if (eventName == "showorgroad") {
            console.log(obj.div.className);
            var classname = obj.div.className;
            if (classname.indexOf("secondary") != -1) {
                util.setClassName(obj.div, "btn btn-primary");
                isShowOrgRoad = "Y";
            } else if (classname.indexOf("primary") != -1) {
                util.setClassName(obj.div, "btn btn-secondary");
                isShowOrgRoad = "N";
            }
            //重新繞路
            phpEvent.reGetAllRoad();
            phpEvent.reGetAllReadRoad();

        }
        //是否 僅顯示 珠路不同桌次
        if (eventName.indexOf("showfilter") != -1) {
            console.log(obj.div.value);
            var filter = obj.div.value;
            if (filter == "showDif") {            //只顯示不同
                for (var key in allData["allRoadData"]) {
                    var roadAry = allData["allRoadData"][key]["rounddata"];
                    var readRoadAry = allReadData["allReadRoadData"][key]["rounddata"];
                    //長度一樣 且內容一樣 需要隱藏
                    if (roadAry.length == readRoadAry.length) {
                        for (var i = 0; i < roadAry.length; i++) {
                            //比較內容
                            if (roadAry[i]["result"].substring(3) != readRoadAry[i]["result"].substring(3)) {
                                //跳過之前要打開
                                util.setHidden(util.getSpan(document, "table_" + key + "_div"), false);
                                util.setHidden(util.getSpan(document, "table_" + key + "_readdiv"), false);
                                continue;//有一個結果不一樣就跳過
                            }
                            //結果都一樣就要隱藏那桌
                            util.setHidden(util.getSpan(document, "table_" + key + "_div"), true);
                            util.setHidden(util.getSpan(document, "table_" + key + "_readdiv"), true);
                        }
                        if (roadAry.length == "0") {
                            //結果都一樣就要隱藏那桌
                            util.setHidden(util.getSpan(document, "table_" + key + "_div"), true);
                            util.setHidden(util.getSpan(document, "table_" + key + "_readdiv"), true);
                        }
                    } else {
                        //如果長度不一樣 預設要顯示
                        util.setHidden(util.getSpan(document, "table_" + key + "_div"), false);
                        util.setHidden(util.getSpan(document, "table_" + key + "_readdiv"), false);
                    }
                }

            } else if (filter == "all") {            //全部顯示
                // console.log(allData["allRoadData"]);
                for (var key in allData["allRoadData"]) {
                    util.setHidden(util.getSpan(document, "table_" + key + "_div"), false);
                    util.setHidden(util.getSpan(document, "table_" + key + "_readdiv"), false);
                }
            }

        }
    }

}

//show每桌的珠路格子
function showAllRoadTable(allRoadData) {
    var showallRoad = document.getElementById("showallRoad");
    var allRoadDataAry = Object.keys(allRoadData);
    //console.log(allRoadData);

    var xmpheader = util.getSpan(document, "xmpheader").innerHTML;
    var xmpData = util.getSpan(document, "xmpData").innerHTML;
    var c = document.createDocumentFragment();
    var e = document.createElement("div");
    var dataStr = "";
    showallRoad.innerHTML = "";
    util.setHidden(showallRoad, true);
    //show每桌資訊
    for (var i = 0; i < allRoadDataAry.length; i++) {

        var tbheader = xmpheader;
        var tbdata = xmpData;

        var tableNO = allRoadDataAry[i];
        var allRoundDataAry = Object.keys(allRoadData[tableNO]["rounddata"]);
        var tbRoadData = allRoadData[tableNO];
        var cloneDiv = e.cloneNode(true);
        cloneDiv.id = "table_" + tableNO + "_div";
        tbheader = tbheader.replace("*TBID*", tableNO);
        tbheader = tbheader.replace("*TBNAME*", tbRoadData.tbname);
        tbheader = tbheader.replace("*DATE*", tbRoadData.date);
        tbheader = tbheader.replace("*BOOT*", tbRoadData.btid);
        tbheader = tbheader.replace("*ROUND*", allRoundDataAry.length);
        tbheader = tbheader.replace("*VIDEOBTN*", tableNO);
        tbheader = tbheader.replace(/\*TABLENO\*/g, tableNO);
        tbdata = tbdata.replace(/\*TABLENO\*/g, tableNO);
        tbdata = tbdata.replace("*VIDEOTABLE*", tableNO);
        tbdata = tbdata.replace("*VIDEONO1*", tableNO);
        tbdata = tbdata.replace("*VIDEONO2*", tableNO);
        tbdata = tbdata.replace("*VIDEONO3*", tableNO);
        tbdata = tbdata.replace("*VIDEONO4*", tableNO);
        tbdata = tbdata.replace("*VIDEONO5*", tableNO);
        dataStr = tbheader + tbdata;
        cloneDiv.innerHTML = tbheader + tbdata;
        // showallRoad.appendChild(e);
        c.appendChild(cloneDiv);
        // tmpDiv.innerHTML = dataStr;
        // fragment.appendChild(tmpDiv);

    }

    // showallRoad.insertAdjacentHTML("afterend", dataStr);
    // showallRoad = showallRoad.replace("*DATA*", dataStr);
    // showallRoad.innerHTML = dataStr;
    // showallRoad.textContent = dataStr;
    showallRoad.appendChild(c);

}
//show每桌的外點珠路格子
function showAllRoadTable2(allRoadData) {
    var showallRoad = document.getElementById("showallRoad2");
    var allRoadDataAry = Object.keys(allRoadData);
    //console.log(allRoadData);

    var xmpheader = util.getSpan(document, "xmpheader2").innerHTML;
    var xmpData = util.getSpan(document, "xmpData").innerHTML;
    var c = document.createDocumentFragment();
    var e = document.createElement("div");
    var dataStr = "";
    showallRoad.innerHTML = "";
    util.setHidden(showallRoad, true);
    //show每桌資訊
    for (var i = 0; i < allRoadDataAry.length; i++) {

        var tbheader = xmpheader;
        var tbdata = xmpData;

        var tableNO = allRoadDataAry[i];
        var allRoundDataAry = Object.keys(allRoadData[tableNO]["rounddata"]);
        var tbRoadData = allRoadData[tableNO];
        var cloneDiv = e.cloneNode(true);
        cloneDiv.id = "table_" + tableNO + "_readdiv";
        //console.log(tbRoadData);

        tbheader = tbheader.replace("*TBID*", tableNO);
        tbheader = tbheader.replace("*TBNAME*", tbRoadData.tbname);
        tbheader = tbheader.replace("*DATE*", tbRoadData.date);
        tbheader = tbheader.replace("*BOOT*", tbRoadData.btid);
        tbheader = tbheader.replace("*ROUND*", allRoundDataAry.length);
        tbheader = tbheader.replace(/\*TABLENO\*/g, "read_" + tableNO);
        tbdata = tbdata.replace(/\*TABLENO\*/g, "read_" + tableNO);
        dataStr = tbheader + tbdata;
        cloneDiv.innerHTML = tbheader + tbdata;
        // showallRoad.appendChild(e);
        c.appendChild(cloneDiv);
        // tmpDiv.innerHTML = dataStr;
        // fragment.appendChild(tmpDiv);

    }
    showallRoad.appendChild(c);

}
//show單桌及每桌最後一靴的珠路
function showAllRoad(allRoadData, type) {

    var allRoadDataAry = Object.keys(allRoadData);
    var tableNO;
    var idType = (type != "readroad") ? "" : "read_";


    //show每桌珠路圖
    for (var j = 0; j < allRoadDataAry.length; j++) {
        var showroadTB = document.getElementById("roadTB" + '_' + idType + allRoadDataAry[j]);
        allRoadDataAry.length == 1 ? tableNO = tableNum : tableNO = allRoadDataAry[j];
        var tbRoadData = allRoadData[tableNO];
        var roads = tbRoadData.rounddata;
        var showRoads;

        document.getElementById("tbid_" + idType + tableNO).innerHTML = tableNO;
        document.getElementById("tbname_" + idType + tableNO).innerHTML = allRoadData[tableNO]["tbname"];
        document.getElementById("boot_" + idType + tableNO).innerHTML = allRoadData[tableNO]["btid"];
        document.getElementById("round_" + idType + tableNO).innerHTML = roads.length;
        document.getElementById("date_" + idType + tableNO).innerHTML = allRoadData[tableNO]["date"];


        showRoads = roads;
        // console.log(showroadTB.getElementsByTagName("td"));
        //先清空每一桌 裡面的每一個td
        var alltdAry = showroadTB.getElementsByTagName("td");
        for (var k = 0; k < alltdAry.length; k++) {
            alltdAry[k].innerHTML = "";
        }

        for (var i = 0; i < showRoads.length; i++) {
            //var roadData = showRoads[roadcount];
            var roadData = showRoads[i];
            var idxOfTr = parseInt(i % lenOfRow);
            var idxOfTd = parseInt(i / lenOfRow);
            var directTd = showroadTB.rows[idxOfTr].cells[idxOfTd];

            if (roadData["result"] == "NULL") {
                if (i == showRoads.length - 1) {
                    directTd.innerHTML = "+";
                } else {
                    directTd.innerHTML = "";
                }
            } else if (roadData["result"] == "-1,-1,-1,-1") {
                directTd.innerHTML = "流";
            } else {
                var tdTextWinnerType = "";
                if (roadData["result"].indexOf("MH") != -1) {
                    tdTextWinnerType = "b_";
                } else if (roadData["result"].indexOf("MC") != -1) {
                    tdTextWinnerType = "d_";
                } else if (roadData["result"].indexOf("MN") != -1) {
                    tdTextWinnerType = "p_";
                } else {
                    alert("NO WINNER ERROR");
                }
                if (tdTextWinnerType != "") {
                    var isHP = false;
                    var isCP = false;
                    if (roadData["result"].indexOf("HP") != -1) {
                        isHP = true;
                    }
                    if (roadData["result"].indexOf("CP") != -1) {
                        isCP = true;
                    }
                    if (isHP && isCP) {
                        tdTextWinnerType += "04";
                    } else if (isHP) {
                        tdTextWinnerType += "03";
                    } else if (isCP) {
                        tdTextWinnerType += "02";
                    } else {
                        tdTextWinnerType += "01";
                    }
                }
                var tdText = "<img src='../../../images/control/" + tdTextWinnerType + ".svg'>";
                // console.log(tableNO + "|" + idxOfTr + "|" + idxOfTd + "|" + i);
                directTd.innerHTML = tdText;
            }
        }
    }
}
function clearVideo() {
    for (var i = 1; i <= videoLimit; i++) {
        var vdiv = util.getSpan(document, "iVideo_" + i);
        // vdiv.contentWindow.player.stop();
        if (vdiv.contentWindow.player) {
            try {
                vdiv.contentWindow.player.destroy();
            } catch (e) {
            }
        }
    }
    var vdivHls = util.getSpan(document, "iVideo_HLS");
    vdivHls.src = "";
    // if (vdivHls.contentWindow.player) {
    //     try {
    //         vdivHls.contentWindow.player.destroy();
    //     } catch (e) {
    //     }
    // }
}
//show視訊畫面
function showVideo(tbno, videoSet) {
    video = new allRoad_videoView();
    //video.init();
    video.setTableNo(tbno);
    video.setVideoSet(videoSet);
    video.init_video();
    videoAry["CH" + videoSet] = video;

}
function newHLSplayer(tbno) {
    console.log("newHLSplayer");

    if (nowGRP == "4") return;//tbno = tbno*1-63;//ba1桌次需要轉換
    var ivideo = util.getSpan(document, "iVideo_HLS");
    var ismobile = "N";
    var tableName = allReadData["allReadRoadData"][tbno]["tbname"];
    self.tableName = tbno;
    ivideo.src = "./lib/videoHLS.html?ismobile=" + ismobile + "&tablename=" + tableName + "&ishttps=" + ishttps;
    ivideo.contentWindow.onunload = function (e) { /* console.log(e); */ try { ivideo.contentWindow.player.destroy(); } catch (e) { } }
}

//視訊
function allRoad_videoView() {
    var self = this;
    // var video_player;
    // var COD_Channel;
    // var OKADA_Channel;
    // var RWM_Channel;
    var ivideo;
    var isSecure = ('https:' == document.location.protocol);
    var tableNO;
    var video_set;

    self.init = function () {

    }

    self.setVideoChannel = function (cod, okada, rwm) {
        COD_Channel = cod;
        OKADA_Channel = okada;
        RWM_Channel = rwm;
    }

    self.setTableNo = function (no) {
        tableNO = no;
    }

    self.setVideoSet = function (no) {
        video_set = no;
    }

    self.init_video = function () {

        ivideo = util.getSpan(document, "iVideo_" + video_set);


        var videodata = videoHostData["Video_Host_" + tableNO][video_set];
        var ip = videodata["host"];
        var port = videodata["port"];
        var isIP = videodata["isIP"];
        if (isIP != "Y") {
            if (util.checkIsIPV4(util.getMainDomain())) {
                ip += "." + videoDomain;
            } else {
                ip += "." + util.getMainDomain();
            }
        }
        if (isSecure) port = videodata["port_ssl"];
        //setTimeout(self.newplayer,3000,ip,port);
        self.newplayer(ip, port);
        //util.setRepeatButton(document, "video_open", "video_off", "", "", listenEvt, this, null);

        //return;
    }
    self.newplayer = function (ip, port) {
        try {
            ishttps = ('https:' == document.location.protocol) ? true : false;
            var canvas = util.getSpan(document, 'video_canvas');
            var url = (ishttps) ? 'wss://' : 'ws://';
            //url +=ip+':'+port+'/';

            url += "" + ip + ":" + port;
            if (url.match(/cvssp2017\.com/) != null) url = url.replace(/cvssp2017\.com/, videoDomain);
            // console.log(allReadData["allReadRoadData"]);
            //ivideo.contentWindow.video.connect(url);
            //if (ivideo.src.match(/videoMpeg\.html/) == null) ivideo.src = "../../js/lib/videoMpeg.html?url=" + url + "&tableno=" + player.tableNO;
            ivideo.contentWindow.location.replace("/js/lib/videoMpeg.html?url=" + url + "&tableno=" + tableNO + "&tablename=" + allData["allRoadData"][tableNO]["tbname"]);
            ivideo.contentWindow.onunload = function (e) { /*console.log(e);*/ try { ivideo.contentWindow.player.destroy(); } catch (e) { } }
        } catch (e) {

        }
    }

    self.close = function () {
        ivideo.contentWindow.location.replace("about:blank");
    }

    //主domain
    self.getMainDomain = function (obj) {

        var domain = "";
        var host = "";
        if (obj != null) {
            if (typeof obj == "string") {
                obj = obj.replace("https://", "");
                obj = obj.replace("http://", "");
                obj = obj.split("?")[0];
                obj = obj.split("/")[0];
                host = obj;
            }
            if (obj === window) {
                host = obj.location.host;
            }
        }
        if (host == "") {
            host = window.location.host;
        }
        if (self.checkIsIPV4(host)) {
            return host;
        }
        var ary = host.split(".");
        var len = ary.length;
        domain = ary[len - 2] + "." + ary[len - 1];
        return domain
    }
    self.checkIsIPV4 = function (str) {
        var blocks = str.split(".");
        if (blocks.length === 4) {
            return blocks.every(function (block) {
                return parseInt(block, 10) >= 0 && parseInt(block, 10) <= 255;
            });
        }
        return false;
    }
}

//倒數更新每桌珠路
function threadEvent() {
    var self = this;

    var reload_interval = reloadsec;
    var reload_time = reload_interval;
    var reload_thread = null;

    //定時刷新珠路Data
    self.startReloadThread = function () {
        reload_thread = setInterval(() => {
            util.getSpan(document, "countdown").innerText = (reload_time < 10) ? "0" + reload_time : reload_time;

            if (reload_time == 0) {
                reload_time = reload_interval;
                phpEvent.reGetAllRoad();
                phpEvent.reGetAllReadRoad();
            }

            reload_time--;
        }, 1000);
    }

    //手動刷新珠路Data
    self.reload = function () {
        reload_time = reload_interval;
        phpEvent.reGetAllRoad();
        phpEvent.reGetAllReadRoad();
    }
    //單桌刷新珠路Data
    self.onlyreload = function () {
        phpEvent.reGetOnlyRoad();
        phpEvent.reGetOnlyReadRoad();
    }
}