<?php
include("../../conf/config_admin.php");

$uid = $uid;
$tbid = $tbid;
$tbname = $tbname;
$gid = $gid;
$btid = $btid;
$gmid = $gmid;
$tableNum = $tableNum;
$choiceDB = $choiceDB;
$grp = $grp;//目前選擇的廠商

$game_type = "BA";

$tableAry = array();
$roadData = array();

//目前選擇的廠商 對應桌號
$companyObj = array(
    "1" => "1_20",
    "2" => "21_49",
	"3" => "50_63",
	"4" => "64_77"
);


if( $action == "allRoad" || $action == "reGetAllRoad" || $action == "reGetOnlyRoad") {
	$tableLimite = explode("_", $companyObj[$grp]);
	//取得全部桌最後一靴的珠路值
	$table =  array();
	$shoe = array();
	$round = array();
	$data  =  array();
	$tableid = $tableNum;
	$isShowOrgRoad = $isShowOrgRoad;
	$LS = "c";
	if($action == "reGetOnlyRoad")$tablesql = "SELECT tbid,name_".$LS." FROM ".$game_type."_lobby WHERE tbid= '".$tableid."' AND tbid >='".$tableLimite[0]."' AND  tbid <='".$tableLimite[1]."'  order by tbid";
	else $tablesql = "SELECT tbid,name_".$LS." FROM ".$game_type."_lobby WHERE tbid > 0  AND tbid >='".$tableLimite[0]."' AND  tbid <='".$tableLimite[1]."'  order by tbid";
	$dbr->query($tablesql);
	while($dbr->next_record()){

		$tableid = $dbr->f("tbid");
		$tbname = $dbr->f("name_".$LS);
		$shoe["tbname"] = $tbname;

		$firstbtsql = "SELECT gid, btid, date FROM ".$game_type."_boot WHERE tbid='".$tableid."' order by id DESC limit 1";

		$dbFT->query($firstbtsql,1);

		$firstGid = $dbFT->f("gid");
		$btid = $dbFT->f("btid");
		$date = $dbFT->f("date");
		$shoe["btid"] = $btid;
		$shoe["date"] = $date;

		if($isShowOrgRoad == "N")$sqltemp = "AND `result` != '-1,-1,-1,-1'";
		else $sqltemp = "";
		$roundsql = "SELECT * ";
		$roundsql.= "FROM ".$game_type." WHERE id>='".$firstGid."' and tbid='".$tableid."' and btid='".$btid."' ".$sqltemp." AND `result` IS NOT NULL";
		$roundsql.= " ORDER BY id ASC ";

		$dbFT->query($roundsql);

		$round = array();
		$gmidcount = 0;
		while($dbFT->next_record()){
			$round[$gmidcount]["date"] = $dbFT->f("date");
			$round[$gmidcount]["gmid"] = $dbFT->f("gmid");

			if ($dbFT->f("result") == null){
				$round[$gmidcount]["result"] = "NULL";
			}else{
				$round[$gmidcount]["result"] = $dbFT->f("result");
			}
			$gmidcount++;
		}

		$shoe["rounddata"] = $round;
		$table[$tableid] = $shoe;
	}

	$out["allRoadData"] = $table;

}if( $action == "allReadRoad" || $action == "reGetAllReadRoad" || $action == "reGetOnlyReadRoad") {
	$tableLimite = explode("_", $companyObj[$grp]);
	//取得全部桌最後一靴的珠路值
	$table =  array();
	$shoe = array();
	$round = array();
	$data  =  array();
	$tableid = $tableLimite[0];
	$isShowOrgRoad = $isShowOrgRoad;
	$LS = "c";

	if($tableid*1 <= 20){
		if($choiceDB == "IPLC"){
			$usedDatabase = DB_NAME_RELOAD_ROAD;
		}else{
			$usedDatabase = DB_NAME_RELOAD_ROAD_2;
		}
		$dbReadRoad = new proc_DB(DB_RELOAD_ROAD_HOST,DB_USER_R,DB_PWD_R,$usedDatabase);
	}else if($tableid*1 <= 49){
		if($choiceDB == "IPLC"){
			$usedDatabase = DB_NAME_RELOAD_ROAD;
		}else{
			$usedDatabase = DB_NAME_RELOAD_ROAD_2;
		}
		$dbReadRoad = new proc_DB(DB_RELOAD_ROAD_HOST_2,DB_USER_R,DB_PWD_R,$usedDatabase);
	}else if($tableid*1 <= 63){
		if($choiceDB == "IPLC"){
		$usedDatabase = DB_NAME_RELOAD_ROAD_3;
	}else{
		$usedDatabase = DB_NAME_RELOAD_ROAD_4;
	}
		$dbReadRoad = new proc_DB(DB_RELOAD_ROAD_HOST_3,DB_USER_R,DB_PWD_R,$usedDatabase);
	}else if($tableid*1 <= 77){
		$usedDatabase = DB_NAME_RELOAD_ROAD_BA1;
		$dbReadRoad = new proc_DB(DB_RELOAD_ROAD_HOST_BA1,DB_USER_R,DB_PWD_R,$usedDatabase);
	}
	//如果是ba1的桌次 需要轉換桌號 63->1, 77->14
	if($grp == "4"){
		$tableNum = $tableNum*1-63;
		$tableLimite[0] = $tableLimite[0]*1-63;
		$tableLimite[1] = $tableLimite[1]*1-63;
	}
	if($action == "reGetOnlyReadRoad")$tablesql = "SELECT tbid,name_".$LS." FROM ".$game_type."_lobby WHERE tbid= '".$tableNum."' AND tbid >='".$tableLimite[0]."' AND  tbid <='".$tableLimite[1]."'  order by tbid";
	else $tablesql = "SELECT tbid,name_".$LS." FROM ".$game_type."_lobby WHERE tbid > 0  AND tbid >='".$tableLimite[0]."' AND  tbid <='".$tableLimite[1]."'  order by tbid";
	$dbr->query($tablesql);
	while($dbr->next_record()){

		$tableid = $dbr->f("tbid");
		$tbname = $dbr->f("name_".$LS);
		$shoe["tbname"] = $tbname;

		$firstbtsql = "SELECT gid, btid, date FROM ".$game_type."_boot WHERE tbid='".$tableid."' order by id DESC limit 1";

		$dbReadRoad->query($firstbtsql,1);

		$firstGid = $dbReadRoad->f("gid");
		$btid = $dbReadRoad->f("btid");
		$date = $dbReadRoad->f("date");
		$shoe["btid"] = $btid;
		$shoe["date"] = $date;

		if($isShowOrgRoad == "N")$sqltemp = "AND `result` != '-1,-1,-1,-1'";
		else $sqltemp = "";

		$round = array();

		if($firstGid != 0){
			$roundsql = "SELECT * ";
			$roundsql.= "FROM ".$game_type." WHERE id>='".$firstGid."' and tbid='".$tableid."' and btid='".$btid."' ".$sqltemp." AND `result` IS NOT NULL";
			$roundsql.= " ORDER BY id ASC ";

			$dbReadRoad->query($roundsql);
			$gmidcount = 0;
			while($dbReadRoad->next_record()){
				$round[$gmidcount]["date"] = $dbReadRoad->f("date");
				$round[$gmidcount]["gmid"] = $dbReadRoad->f("gmid");

				if ($dbReadRoad->f("result") == null){
					$round[$gmidcount]["result"] = "NULL";
				}else{
					$round[$gmidcount]["result"] = $dbReadRoad->f("result");
				}
				$gmidcount++;
			}
		}
		$shoe["rounddata"] = $round;
		$table[$tableid] = $shoe;
		$out["sql"][$tableid] = $roundsql;
	}
	$out["allReadRoadData"] = $table;

}else if ( $action == "getVideoData" ) {
	//視訊資料
	$tableLimite = explode("_", $companyObj[$grp]);
	$host_data = array();
	$dbr_video = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);
	$dbr_video2 = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);

	$videosql = "SELECT * FROM ".$game_type."_lobby WHERE tbid > 0  AND tbid >='".$tableLimite[0]."' AND  tbid <='".$tableLimite[1]."' order by tbid";
	$dbr_video->query($videosql);
		while($dbr_video->next_record()){

			$tableid = $dbr_video->f("tbid");

			//各桌Game的連線資料
			// $hostData = array();
			// $sql = "SELECT * FROM conf_hostport_list WHERE type = 'Game'  and table_num='".$tableid."' order by channel ASC";//
			// $dbr_video2->query($sql);
			// while($dbr_video2->next_record()){
			// 	$channelData = array();
			//  	$channelData["channel"] = $dbr_video2->f("channel");
			//  	$channelData["host"] = $dbr_video2->f("host");
			//  	$channelData["port"] = $dbr_video2->f("port");
			//  	$channelData["port_ssl"] = $dbr_video2->f("port_ssl");
			//  	$channelData["isIP"] = $dbr_video2->f("isIP");
			//  	$channelData["enable"] = $dbr_video2->f("enable");
			//  	$hostData[$dbr_video2->f("channel")] = $channelData;
			// }
			//$host_data["Game_Host_".$tableid] = $hostData;

			//各桌Video的連線資料
			$hostData = array();
			$sql = "SELECT * FROM conf_hostport_list WHERE type = 'Video'  and table_num='".$tableid."' order by channel ASC";//
			$dbr_video2->query($sql);
			while($dbr_video2->next_record()){
				$channelData = array();
				$channelData["channel"] = $dbr_video2->f("channel");
				$channelData["host"] = $dbr_video2->f("host");
				$channelData["port"] = $dbr_video2->f("port");
				$channelData["port_ssl"] = $dbr_video2->f("port_ssl");
				$channelData["isIP"] = $dbr_video2->f("isIP");
				$channelData["enable"] = $dbr_video2->f("enable");
				$hostData[$dbr_video2->f("channel")] = $channelData;
				$out["channelcount"] = $dbr_video2->f("channel");
			}

			$host_data["Video_Host_".$tableid] = $hostData;
		}
	$out["host_data"] = $host_data;
} else {
	$out["msg"] = $fail;
}
echo json_encode($out);
?>