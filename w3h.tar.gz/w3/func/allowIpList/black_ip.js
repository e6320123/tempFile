var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;

var table_div;
var div_model;

function init(){

	div_model = util.getSpan(document,"div_model");
  table_div = util.getSpan(document,"table_div");

	var open_button = util.getSpan(document,"open_button");
	listenEvt.addOnClick("open_button",open_button,this,null);


	var Path = "./allowIpList/getBlack_ip.php";
	var code="uid=" + uid ;
	util.addPostPHP("showTable", Path, code,this);
}
function listenCenter(eventName,listenData){

	var Path = "./allowIpList/getBlack_ip.php";
	var code="uid=" + uid ;



	if(eventName=="open_button"){//
		div_model.style.display="";
		table_div.style.display="none";
		addIPObj();
	}else if(eventName=="goBack"){// 
		div_model.style.display="none";
		table_div.style.display="";
	}else if(eventName=="submit_btn"){//
		var inputAry = listenData.object;

		code+="&type=insert";
		for(var key in inputAry){
			var val = inputAry[key].value;
			if(val==""){
				alert(langStr["text_noinput"]);
				return ;
			}

			code+="&"+key+"="+val;
		}

		util.addPostPHP("showTable", Path, code,this);
	} else if (eventName.indexOf("del_btn_") != -1){
		if (confirm("確認刪除?")) {//langStr["del_realy"]
			code += "&type=del";
			code += "&delid=" + listenData.object;
			util.addPostPHP("showTable", Path, code, this);
		}
	}

}
function phpDataCenter(eventName , phpData){
	showTable(phpData);
}

function showTable(phpData){

	div_model.style.display="none";
	table_div.style.display=""

	var IpAry=phpData.blackIpAry;

	var xmpheader = util.getSpan(document,"xmpheader").innerHTML;
	var xmpEnd = util.getSpan(document,"xmpEnd").innerHTML;
	var	xmpData = util.getSpan(document,"xmpData").innerHTML;

	var dataStr="";

	for(var i=0;i<IpAry.length;i++){
		var td=xmpData;
		var black=IpAry[i];

		td=td.replace(/\*ID\*/gi,black.id);
		td=td.replace("*IP*",black.ip);
		td=td.replace("*text*",black.text);
		td=td.replace("*user*",black.username);
		td=td.replace("*date*",black.adddate);

		dataStr+=td;
	}

	table_div.innerHTML=xmpheader+dataStr+xmpEnd;
	setListener(phpData.blackIpAry);
}
function addIPObj(){//

	var ip_text    =  util.getSpan(document,"ip_text");
	var user_text  =  util.getSpan(document,"user_text");
	var text_text  =  util.getSpan(document,"text_text");
	var submit_btn =  util.getSpan(document,"submit_btn");
	var cancel_btn =  util.getSpan(document,"cancel_btn");

	//
	var inputAry = Array();
	inputAry["ip"] = ip_text;
	inputAry["username"] = user_text;
	inputAry["text"] = text_text;

	ip_text.value="";
	user_text.value="";

	listenEvt.addOnClick("submit_btn",submit_btn,this,inputAry);
	listenEvt.addOnClick("goBack",cancel_btn,this,inputAry);
}
function setListener(data){
	for (var i = 0; i < data.length; i++) {
		listenEvt.addOnClick("del_btn_" + data[i].id, util.getSpan(document, "del_btn_" + data[i].id), this, data[i].id);
	}
}
