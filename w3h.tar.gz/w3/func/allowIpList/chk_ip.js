// var username = top.username;
// var usertype = top.usertype;
// var mid = top.mid;
var uid = parent.uid;
// var ltype = top.ltype;
// var langx = top.langx;
// var langStr = top.langStr;
var util = parent.util;
var listenEvt = parent.listenEvt;

var div_model;//新增div
var table_div;//顯示div
//var purview = top.purview;

function init() {


	div_model = util.getSpan(document, "div_model");
	table_div = util.getSpan(document, "table_div");

	var open_button = util.getSpan(document, "open_button");
	listenEvt.addOnClick("open_button", open_button, this, null);


	var Path = "./allowIpList/getChk_ip.php";
	var code = "uid=" + uid;
	util.addPostPHP("showTable", Path, code, this);

}
function listenCenter(eventName, listenData) {

	var Path = "./allowIpList/getChk_ip.php";
	var code = "uid=" + uid;


	if (eventName == "open_button") {//新增按鈕
		div_model.style.display = "";
		table_div.style.display = "";
		addIPObj();
	} else if (eventName == "goBack") {//取消新增 回到顯示畫面
		div_model.style.display = "none";
		table_div.style.display = "";
	} else if (eventName == "submit_btn") {//確定新增
		var inputAry = listenData.object;

		code += "&type=newip";
		for (var key in inputAry) {
			if (key.indexOf("allow_") != -1) {
				var val = (inputAry[key].checked) ? "Y" : "N";
			} else {
				var val = inputAry[key].value;
			}
			if (val == "") {
				alert("請確實填寫內容");//langStr["text_noinput"]
				return;
			}

			code += "&" + key + "=" + val;
		}

		util.addPostPHP("showTable", Path, code, this);

	} else if (eventName.match("del_btn")) {//刪除扭事件
		if (confirm("確定刪除?")) {
			var del_ID = listenData.object;
			code += "&type=del";
			code += "&delid=" + del_ID;

			util.addPostPHP("showTable", Path, code, this);
		} else {
			return;
		}
	}

}
function phpDataCenter(eventName, phpData) {
	showTable(phpData);
}
function showTable(phpData) {//showTable

	div_model.style.display = "none";
	table_div.style.display = ""

	var ctlIpAry = phpData.ctlIp;

	var xmpheader = util.getSpan(document, "xmpheader").innerHTML;
	var xmpEnd = util.getSpan(document, "xmpEnd").innerHTML;
	var xmpData = util.getSpan(document, "xmpData").innerHTML;

	var dataStr = "";

	for (var i = 0; i < ctlIpAry.length; i++) {
		var td = xmpData;
		var ctl = ctlIpAry[i];

		td = td.replace(/\*ID\*/gi, ctl.id);
		td = td.replace("*IP*", ctl.IP);
		td = td.replace("*adduser*", ctl.addname);
		td = td.replace("*user*", ctl.username);
		td = td.replace("*date*", ctl.adddate);
		(ctl.allow_ctl == "Y") ? td = td.replace("*CHECKED_ctl*", "checked") : td = td.replace("*CHECKED_ctl*", "");
		(ctl.allow_ag == "Y") ? td = td.replace("*CHECKED_ag*", "checked") : td = td.replace("*CHECKED_ag*", "");
		(ctl.allow_mem == "Y") ? td = td.replace("*CHECKED_mem*", "checked") : td = td.replace("*CHECKED_mem*", "");
		(ctl.allow_mobile == "Y") ? td = td.replace("*CHECKED_mobile*", "checked") : td = td.replace("*CHECKED_mobile*", "");

		dataStr += td;
	}

	table_div.innerHTML = xmpheader + dataStr + xmpEnd;

	for (var i = 0; i < ctlIpAry.length; i++) {

		var delId = ctlIpAry[i].id;
		var del_btn = util.getSpan(document, "del_btn_" + delId);
		listenEvt.addOnClick("del_btn_" + delId, del_btn, this, delId);

	}

}
function addIPObj() {//新增畫面宣告

	var ip_text = util.getSpan(document, "ip_text");
	var user_text = util.getSpan(document, "user_text");
	var ctl_check = util.getSpan(document, "ip_ctl_check");
	var ag_check = util.getSpan(document, "ip_ag_check");
	var mem_check = util.getSpan(document, "ip_mem_check");
	var mobile_check = util.getSpan(document, "ip_mobile_check"); //手機預設給Ｙ
	var submit_btn = util.getSpan(document, "submit_btn");
	var cancel_btn = util.getSpan(document, "cancel_btn");

	//所有輸入物件的陣列
	var inputAry = Array();
	inputAry["ip"] = ip_text;
	inputAry["username"] = user_text;
	inputAry["allow_ctl"] = ctl_check;
	inputAry["allow_ag"] = ag_check;
	inputAry["allow_mem"] = mem_check;
	inputAry["allow_mobile"] = mobile_check;//手機預設給Ｙ // mobile_check
	ip_text.value = "";
	user_text.value = "";
	ctl_check.checked = true;
	ag_check.checked = true;
	mem_check.checked = true;
	mobile_check.checked = true;
	listenEvt.addOnClick("submit_btn", submit_btn, this, inputAry);
	listenEvt.addOnClick("goBack", cancel_btn, this, inputAry);
}