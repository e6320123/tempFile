// var langx = top.langx;
// var langStr = top.langStr;
var util = parent.util;
var listenEvt = parent.listenEvt;
// var usertype = top.usertype;
// var mid = top.mid;
var uid = parent.uid;
var SWobj = null;//存放other_set 資料

function init() {
	phpEvent = new phpEvent();
	listenEvent = new listenEvent();
	showView = new showView();

	phpEvent.getData();
}

function phpEvent() {
	var self = this;

	//取得預設資料
	self.getData = function () {
		var aPath = "../func/allowIpList/getchkipSW.php";
		var parame = "uid=" + uid + "&action=reload";
		util.addPostPHP("reload_data", aPath, parame, this);
	}

	//修改資料
	self.setData = function () {
		var aPath = "../func/allowIpList/getchkipSW.php";
		var parame = "uid=" + uid + "&action=modify";

		var parameObj = SWobj;
		for (var key in parameObj) {
			parameObj[key]["text"] = util.getSpan(document, parameObj[key]["o_name"]).value;
		}
		var tempStr = JSON.stringify(parameObj).replace(/"/gi, "@");
		parame += "&updateJson=" + tempStr;
		util.addPostPHP("update_data", aPath, parame, this);
	}

	//預設資料顯示
	self.phpDataCenter = function (eventName, phpData) {
		var obj = phpData;

		//顯示預設資料
		if (eventName == "reload_data") {
			SWobj = obj
			showView.showTable(SWobj);
		}

		//重新載入資料
		if (eventName == "update_data") {
			showMsg(obj["motion"]);
			self.getData();
		}
	}
}

function listenEvent() {
	var self = this;

	self.addHyperLink = function () {
		listenEvt.addOnClick("setData", util.getSpan(document, "editeBTN"), this, null);
	}

	self.listenCenter = function (eventName, listenData) {
		if (eventName == "setData") {
			if (confirm("確定修改？")) {
				phpEvent.setData();
			}
		}
	}
}

function showView() {
	var self = this;

	self.showTable = function (data) {
		var show_main = util.getSpan(document, "show_main");
		var xmp_header = util.getSpan(document, "xmp_header").innerHTML;
		var xmp_footer = util.getSpan(document, "xmp_footer").innerHTML;
		var xmp_content = util.getSpan(document, "xmp_content").innerHTML;
		var dataStr = "";

		for (var key in data) {
			var td = xmp_content;
			td = td.replace(/\*NAME\*/gi, data[key]["name"]);
			td = td.replace(/\*ONAME\*/gi, data[key]["o_name"]);
			// td = td.replace("*NOTE*", data[key]["t_note"]);
			td = td.replace("*SELECTED" + data[key]["text"] + "*", "selected");

			dataStr += td;
		}
		show_main.innerHTML = xmp_header + dataStr + xmp_footer;
		listenEvent.addHyperLink();
	}
}

function showMsg(code) {
	if (code == "UPDATE_SUCCESS") {
		alert("修改成功!");
	}
}