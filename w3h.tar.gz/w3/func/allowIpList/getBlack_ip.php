<?php
include ("../../conf/config_admin.php");

if($type=="del"||$type=="insert"){
	$DB = $db;

}else{
	$DB = $dbr;
}


//====== 執行動作區 ======
if($type=="del"){
	$sql = "SELECT * FROM `ip_list_maintain` WHERE `id` ='".$delid."' ;";
	$DB->query($sql);
	$originData = "";
	while($DB->next_record()){
		$originData = "id=".$DB->f("id").",IP=".$DB->f("IP").",addname=".$DB->f("addname").",username=".$DB->f("username").",adddate=".$DB->f("adddate").",allow_ctl=".$DB->f("allow_ctl").",allow_ag=".$DB->f("allow_ag").",allow_mem=".$DB->f("allow_mem").",allow_mobile=".$DB->f("allow_mobile");
	}

	$sql = "DELETE FROM `logblack_members` WHERE `id` = '".$delid."'";
	$DB->query($sql);
	// $out = "<account>201</account>";
	//寫紀錄
	Write_Ctl_Record($MEM_DATA["username"],"ip_list_maintain","func/allowIpList/","M","刪除黑名單IP : ".preg_replace("/'/","",$sql)."|初始資料:".$originData,$DB,$_SERVER['REMOTE_ADDR']);

}else if($type=="insert"){
	$sql = "INSERT INTO logblack_members set IP='".$ip."',username='".$username."',text='".$text."',adddate=NOW();";
	$DB->query($sql);
	//寫紀錄
	Write_Ctl_Record($MEM_DATA["username"],"logblack_members","func/allowIpList/","M","新增黑名單IP : ".preg_replace("/'/","",$sql),$DB,$_SERVER['REMOTE_ADDR']);

}


//====== 執行動作區 ======


//====== 主要資料區 ======

$blackIpAry = Array();

$sql = "SELECT * FROM `logblack_members` ORDER BY `adddate` DESC ;";
$DB->query($sql);

if($DB->num_rows()> 0){
	while($DB->next_record()){

		$black = Array();

  	$black["id"]=$DB->f("id");
  	$black["ip"]=$DB->f("IP");
  	$black["text"]=$DB->f("text");
  	$black["username"]=$DB->f("username");
  	$black["adddate"]=$DB->f("adddate");


		$blackIpAry[]=$black;
	}

}


$out=Array();
$out["blackIpAry"] = $blackIpAry;
echo json_encode($out);
exit;



?>