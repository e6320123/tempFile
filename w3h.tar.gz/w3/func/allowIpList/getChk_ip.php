<?php
include ("../../conf/config_admin.php");


if($type=="del"||$type=="newip"){
	$DB = $db;

}else{
	$DB = $dbr;
}

//====== 執行動作區 ======

if($type=="del"){
	$sql = "SELECT * FROM `ip_list_maintain` WHERE `id` ='".$delid."' ;";
	$DB->query($sql);
	$originData = "";
	while($DB->next_record()){
		$originData = "id=".$DB->f("id").",IP=".$DB->f("IP").",addname=".$DB->f("addname").",username=".$DB->f("username").",adddate=".$DB->f("adddate").",allow_ctl=".$DB->f("allow_ctl").",allow_ag=".$DB->f("allow_ag").",allow_mem=".$DB->f("allow_mem").",allow_mobile=".$DB->f("allow_mobile");
	}

	$sql = "DELETE FROM `ip_list_maintain` WHERE `id` = '".$delid."' ;";

	$DB->query($sql);
	//寫紀錄
	Write_Ctl_Record($MEM_DATA["username"],"ip_list_maintain","func/allowIpList/","M","刪除允許IP : ".preg_replace("/'/","",$sql)."|初始資料:".$originData,$DB,$_SERVER['REMOTE_ADDR']);


}else if($type=="newip"){
	$sql = "INSERT INTO ip_list_maintain ";
	$sql.=" set id = NULL,IP='".$ip."',";
	$sql.="username='".$username."',";
	$sql.="allow_ctl='".$allow_ctl."',";
	$sql.="allow_ag='".$allow_ag."',";
	$sql.="allow_mem='".$allow_mem."',";
	$sql.="allow_mobile='".$allow_mobile."',";
	$sql.="addname='".$MEM_DATA['username']."',";
	$sql.="root_sw='Y' ,";//func 內部管理新增 root = Y  客人增加的 = N
	$sql.="adddate=NOW();";
	// echo $sql;

	$DB->query($sql);
	//寫紀錄
	Write_Ctl_Record($MEM_DATA["username"],"ip_list_maintain","func/allowIpList/","M","新增允許IP : ".preg_replace("/'/","",$sql),$DB,$_SERVER['REMOTE_ADDR']);

}

//====== 執行動作區 ======

//====== 主要資料區 ======

$ctlIpAry = Array();

$sql = "SELECT * FROM `ip_list_maintain` ORDER BY `adddate` DESC  ;";
$DB->query($sql);

if($DB->num_rows()> 0){
	while($DB->next_record()){
		$ctl = Array();
		$ctl["id"] = $DB->f("id");
		$ctl["IP"] = $DB->f("IP");
		$ctl["addname"] = $DB->f("addname");
		$ctl["username"] = $DB->f("username");
		$ctl["adddate"] = $DB->f("adddate");
		$ctl["allow_ctl"] = $DB->f("allow_ctl");
		$ctl["allow_ag"] = $DB->f("allow_ag");
		$ctl["allow_mem"] = $DB->f("allow_mem");
		$ctl["allow_mobile"] = $DB->f("allow_mobile");
		$ctlIpAry[]=$ctl;
	}

}


$out=Array();
$out["ctlIp"] = $ctlIpAry;
$DB -> close();
echo json_encode($out);
exit;


?>