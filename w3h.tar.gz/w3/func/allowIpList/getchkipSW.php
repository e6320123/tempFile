<?php
include ("../../conf/config_admin.php");

$db = $db;

if ($action == "reload") {
	$sql = "SELECT * FROM other_set  WHERE name in ('maintainlist_ctl_SW','rejectlist_ctl_SW','maintainlist_ag_SW','rejectlist_ag_SW','maintainlist_mem_SW','rejectlist_mem_SW')";
	$db->query($sql);

	while($db->next_record()) {
		$out[$db->f("id")]["name"] = $LVar[$db->f("name")];
		$out[$db->f("id")]["o_name"] = $db->f("name");
		$out[$db->f("id")]["text"] = $db->f("text");
	}
	$db->close();

	echo json_encode($out);
	exit;
} else if ($action == "modify") {
	$tempjson = str_replace("@", '"', $updateJson);
	$jsonData = json_decode($tempjson,true);
	$qstr = "";
	foreach ($jsonData as $key => $value) {
		$qstr .= "UPDATE other_set SET text = '".$jsonData[$key]["text"]."' WHERE name = '".$jsonData[$key]["o_name"]."' AND id=".$key." ;";
	}
	// echo $qstr ;
	$db->muti_query($qstr);

	//寫紀錄
	Write_Ctl_Record($MEM_DATA["username"],"other_set","allowIpList/getchkipSW.php","M","修改IP阻擋開關 : ".preg_replace("/'/","",$qstr),$db,$_SERVER['REMOTE_ADDR']);

	$db->close();

	$out["motion"] = "UPDATE_SUCCESS";
	// $out["sql"] = $qstr;
	echo json_encode($out);
	exit;
}
?>