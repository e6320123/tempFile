var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;
var starttime = "2018-01-01";//月曆的初始日期限制
var nowPage = 1;//預設目前頁數

//初始化
function init() {
    phpEvent = new phpEvent();	//PHP事件
    listenEvent = new listenEvent();	//監聽事件
    showView = new showView();	//畫面控制
    DTF = new DateTimeFormat();	//取得時間格式
    
    doSet();	//預設動作
}

//預設動作
function doSet() {
    //建立監聽事件(靜態)
    listenEvent.addHyperLink();
    // listenEvent.addListenEvent();
    var doc = doc || document;
    //設定自動關閉月曆
    calendar.window.setAutoClose(doc, document);
    //取得資料
    // phpEvent.getData();
}

//PHP事件
function phpEvent() {
    var self = this;
    var aPath = "/func/api_rec/getApi_add.php";
    var parame = "uid=" + top.uid + "&langx=" + top.langx;

    //取得資料
    self.getData = function () {
       var regExp = /^[\d|a-zA-Z]+$/;
       var username =  document.getElementById("txtNumSearch").value;
       var id =  document.getElementById("txtIdSearch").value;
    //    if(!regExp.test(username)){
    //         alert("只能是英數字");
    //         return;
    //     }
        if(username=="" && id==""){
            alert("帳號/id 不能空白");
            return;
        }

        var tmp = parame;
        tmp += "&action=search";
        tmp += "&username="+username;
        tmp += "&user_id="+id;
        tmp += "&method=searchData";
        util.addPostPHP("searchData", aPath, tmp, this);
    }

    //修改資料
    self.editData = function () {
        var username =  document.getElementById("txtNumEdit").value;
        var paswd =  document.getElementById("txtPasEdit").value;
        var paswdRe =  document.getElementById("txtRePasEdit").value;
        var regExp = /^[\d|a-zA-Z]+$/;
        if(paswd!=paswdRe){
            alert("密碼錯誤");
            return;
       }
       if(!regExp.test(username)){
           alert("只能是英數字");
            return;
       }
       if(!regExp.test(paswd)){
           alert("只能是英數字");
           return;
       }
       if(username==""){
           alert("帳號不能空白");
           return;
       }
       if(paswd==""){
           alert("密碼不能空白");
           return;
       }
        var tmp = parame;
        tmp += "&action=edi";
        tmp += "&username="+username;
        tmp += "&paswd="+paswd;
        tmp += "&method=ediData";
        if(confirm("是否修改API代理密碼")){
            util.addPostPHP("ediData", aPath, tmp, this);
        }else{
            return;
        }

    }

    //修改籌碼
    self.editDataKR = function(){
        var username =  document.getElementById("txtNumEditKR").value;
        var krtype =  document.getElementsByName("editkrtype");
        var krchk;
        var regExp = /^[\d|a-zA-Z]+$/;

        if(username==""){
            alert("帳號不能空白");
            return;
        }
        for(var i=0;i<krtype.length;i++){
            if(krtype[i].checked) krchk=krtype[i].value;
        }

        var tmp = parame;
        tmp += "&action=ediKR";
        tmp += "&username="+username;
        tmp += "&krtype="+krchk;
        tmp += "&method=ediKR";
        if(confirm("是否修改API代理使用韓版籌碼")){
            util.addPostPHP("ediKR", aPath, tmp, this);
        }else{
            return;
        }
    }
    //新增資料
    self.addData = function(){
        var username =  document.getElementById("txtNum").value;
        var paswd =  document.getElementById("txtPaswd").value;
        var paswdRe =  document.getElementById("txtRePaswd").value;
        var alias =  document.getElementById("txtAlias").value;
        var status = document.getElementsByName("status");
        var krtype = document.getElementsByName("krtype");
        var chk;
        var krchk;
        var regExp = /^[\d|a-zA-Z]+$/;
        if(paswd!=paswdRe){
             alert("密碼錯誤");
             return;
        }
        if(!regExp.test(username)){
            alert("只能是英數字");
             return;
        }
        if(!regExp.test(paswd)){
            alert("只能是英數字");
            return;
        }
        if(username==""){
            alert("帳號不能空白");
            return;
        }
        if(paswd==""){
            alert("密碼不能空白");
            return;
        }
        if(alias==""){
            alert("名稱不能空白");
            return;
        }
        for(var i=0;i<status.length;i++){
            if(status[i].checked) chk=status[i].value;
        }

        for(var i=0;i<krtype.length;i++){
            if(krtype[i].checked) krchk=krtype[i].value;
        }
        
        var tmp = parame;
        tmp += "&action=add";
        tmp += "&username="+username;
        tmp += "&paswd="+paswd;
        tmp += "&alias="+alias;
        tmp += "&enable="+chk;
        tmp += "&krtype="+krchk;
        tmp += "&method=addData";
        if(confirm("是否新增API代理")){
            util.addPostPHP("addData", aPath, tmp, this);
        }else{
            return;
        }
    }
    //搜尋一般代理名字
    self.searchNameData = function(){
        var input = util.getSpan(document,"clear").previousElementSibling;
        var regExp = /^[\d|a-zA-Z]+$/;
        if(input.value==""){
            // alert("只能是英數字");
             return;
        }
        if(!regExp.test(input.value)){
            alert("只能是英數字");
             return;
        }

        var tmp = parame;
        tmp += "&action=find";
        tmp += "&username="+input.value;
        tmp += "&method=searchName";
        
        util.addPostPHP("searchNameData", aPath, tmp, this);
        
        return;
    }

    //PHP事件回應
    self.phpDataCenter = function (eventName, phpData) {
        var obj = phpData;

        if (eventName == "getData") {
            return;
        }

        if (eventName == "ediData") {
            document.getElementById("txtNumEdit").value="";
            document.getElementById("txtPasEdit").value="";
            document.getElementById("txtRePasEdit").value="";
            showView.pasemainBody(obj,"ediAry");
            return;
        }
        if (eventName == "ediKR") {
            document.getElementById("txtNumEditKR").value="";
            showView.pasemainBody(obj,"ediAry");
            return;
        }
        
        if (eventName == "searchData") {
            document.getElementById("txtNumSearch").value="";
            document.getElementById("txtIdSearch").value="";
            showView.pasemainBody(obj,"searchAry");
            return;
        }
        if (eventName == "addData") {
            document.getElementById("txtNum").value ="";
            document.getElementById("txtPaswd").value ="";
            document.getElementById("txtRePaswd").value = "";
            document.getElementById("txtAlias").value = "";
            showView.pasemainBody(obj,"addAry");
            // console.log(eventName,phpData);
            return;
        }
        if (eventName == "searchNameData") {
            // console.log(obj);
            showView.pasemainSearchName(obj,"serachNameAry");
            return;
        }

    }
}

//監聽事件
function listenEvent() {
    var self = this;

    //建立監聽事件(靜態)
    self.addHyperLink = function () {
        //日期選擇
        var buttonArr = document.getElementsByName("button");
        buttonArr.forEach((button) => { listenEvt.addOnClick(button.id, button, this, button.getAttribute("data-func")); });
        
        
        listenEvt.addOnClick("btnok", util.getSpan(document, "btnok"), this, "btnok");
        listenEvt.addOnClick("btnS", util.getSpan(document, "btnS"), this, "btnS");
        listenEvt.addOnClick("btnE", util.getSpan(document, "btnE"), this, "btnS");
        listenEvt.addOnClick("btnKR", util.getSpan(document, "btnKR"), this, "btnKR");

        listenEvt.addOnClick("add", util.getSpan(document, "add"), this, null);
        listenEvt.addOnClick("search", util.getSpan(document, "search"), this, null);
        listenEvt.addOnClick("edit", util.getSpan(document, "edit"), this, null);
        listenEvt.addOnClick("editKR", util.getSpan(document, "editKR"), this, null);

        listenEvt.addOnClick("searchDiv_O", util.getSpan(document, "txtNum").nextElementSibling, this, null);
        listenEvt.addOnClick("searchDiv_C", util.getSpan(document, "search_close"), this, null);
        listenEvt.addOnClick("clear_serchName", util.getSpan(document, "clear"), this, util.getSpan(document, "clear"));
        listenEvt.addOnClick("searchName", util.getSpan(document, "search_name_send"), this, null);
    
    }

    //建立監聽事件(動態)
    self.addListenEvent = function () {
        var ary = document.getElementsByName("username");
        for(var i = 0;i<ary.length;i++){
            listenEvt.addOnClick("parName_"+i, util.getSpan(document, "span_alert_username_"+i), this, null);
        }
        
    }

    //監聽事件回應
    self.listenCenter = function (eventName, listenData) {
        var obj = listenData;

        //打開月曆
        if (eventName.indexOf("calendar") != -1) {
            var tmp = eventName.split("_");
            eventType = tmp[1];
            if (eventType == "startdate") {
                var startdate = DTF.timeToString(DTF.getTime(null, { "time": starttime }), "day");
                var enddate = util.getSpan(document, "enddate_0").value;
            } else {
                var startdate = util.getSpan(document, "startdate_0").value;
                var enddate = DTF.timeToString(DTF.getTime(), "day");
            }
            DTF.setDateLimit(startdate, "start");
            DTF.setDateLimit(enddate, "end");

            calendar.window.setSpan(obj.div.children[1], "value", 30, 40);
            calendar.window.setDay(obj.div.children[1].value);

            return true;
        }
        //點擊全選
        if (eventName.indexOf("ckeckAll") != -1){
            var checkAry = document.getElementsByName(obj.object);
            for (var i = 0; i < checkAry.length ; i++){
                checkAry[i].checked = obj.div.checked;
            }
        }
        //新增
        if (eventName == "btnok"){
            // phpEvent.getData();
            phpEvent.addData();
        }
        
        //搜尋
        if (eventName == "btnS"){
            phpEvent.getData();
        }

        //修改密碼
        if (eventName == "btnE"){
            
            phpEvent.editData();
        }

        //修改密碼
        if (eventName == "btnKR"){
    
            phpEvent.editDataKR();
        }

        
        
        //檢查輸入的代理帳號
        if (eventName == "txtNum"){
            // obj.div.value = util.moneyCheck(obj.div.value);
            
        }

        if (eventName == "add"){
            // console.log("add");
            var search_table = util.getSpan(document, "search_table");
            var btnS = util.getSpan(document, "btnS");
            var add_table = util.getSpan(document, "add_table");
            var btnok = util.getSpan(document, "btnok");
            var edit_table = util.getSpan(document, "edit_table");
            var btnE = util.getSpan(document, "btnE");
            var btnKR = util.getSpan(document, "btnKR");
            var editkr_table = util.getSpan(document, "editkr_table");
            editkr_table.style.display="none";
            search_table.style.display="none";
            add_table.style.display="";
            btnS.style.display="none";
            btnok.style.display="";
            edit_table.style.display="none";
            btnE.style.display="none";
            btnKR.style.display="none";
            return;
        }

        if (eventName == "search"){
            // console.log("search");
            var search_table = util.getSpan(document, "search_table");
            var btnS = util.getSpan(document, "btnS");
            var add_table = util.getSpan(document, "add_table");
            var btnok = util.getSpan(document, "btnok");
            var edit_table = util.getSpan(document, "edit_table");
            var btnE = util.getSpan(document, "btnE");
            var btnKR = util.getSpan(document, "btnKR");
            var editkr_table = util.getSpan(document, "editkr_table");
            editkr_table.style.display="none";
            search_table.style.display="";
            add_table.style.display="none";
            btnS.style.display="";
            btnok.style.display="none";
            edit_table.style.display="none";
            btnE.style.display="none";
            btnKR.style.display="none";
            return;
        }

        if (eventName == "edit"){
            var search_table = util.getSpan(document, "search_table");
            var btnS = util.getSpan(document, "btnS");
            var add_table = util.getSpan(document, "add_table");
            var btnok = util.getSpan(document, "btnok");
            var edit_table = util.getSpan(document, "edit_table");
            var btnE = util.getSpan(document, "btnE");
            var btnKR = util.getSpan(document, "btnKR");
            var editkr_table = util.getSpan(document, "editkr_table");
            editkr_table.style.display="none";
            search_table.style.display="none";
            add_table.style.display="none";
            btnS.style.display="none";
            btnok.style.display="none";
            btnKR.style.display="none";

            edit_table.style.display="";
            btnE.style.display="";
            return;
        }

        if (eventName == "editKR"){
            var search_table = util.getSpan(document, "search_table");
            var btnS = util.getSpan(document, "btnS");
            var add_table = util.getSpan(document, "add_table");
            var btnok = util.getSpan(document, "btnok");
            var edit_table = util.getSpan(document, "edit_table");
            var btnE = util.getSpan(document, "btnE");
            var btnKR = util.getSpan(document, "btnKR");
            var editkr_table = util.getSpan(document, "editkr_table");
            editkr_table.style.display="";
            search_table.style.display="none";
            add_table.style.display="none";
            btnS.style.display="none";
            btnok.style.display="none";

            edit_table.style.display="none";
            btnE.style.display="none";
            btnKR.style.display="";
            editkr_table.style.display="";
            return;
        }

        if (eventName.indexOf("searchDiv") != -1 ){
            close_searchName();
            return;
        }

        if (eventName.indexOf("clear") != -1 ){
            var input= obj.object.previousElementSibling;
            input.value="";
            return;
        }

        if (eventName == "searchName" ){
            phpEvent.searchNameData();
        }

        if (eventName.indexOf("parName_") != -1 ){
            var username = obj.div.innerHTML;
            var alias = obj.div.parentElement.nextElementSibling.innerHTML;
            var text_username = document.getElementById("txtNum");
            var text_alias = document.getElementById("txtAlias");
            text_username.value = username;
            text_alias.value = alias;
            close_searchName();
            return;
        }
        
    }
}

function close_searchName(){
    var show = util.getSpan(document, "alert_BG");
    if(show.style.display=="none")show.style.display="";
    else show.style.display="none";
}
//畫面控制
function showView() {
    var self = this;

    //建立表格
    self.pasemainBody = function (obj,methodAry) {
        var dataAry = obj[methodAry];
        var divShow = util.getSpan(document, "divShow");
        var xmp_header = util.getSpan(document, "xmp_header").innerHTML;
        var xmp_content = util.getSpan(document, "xmp_content").innerHTML;
        var xmp_footer = util.getSpan(document, "xmp_footer").innerHTML;
        var pageObj = util.getSpan(document, "pageno");
        if(obj["error"]){
            console.log(obj["error"]);
            divShow.innerHTML = obj["error"];    

        }else{
            outStr = "";
            outStr += xmp_header;
            for (var i = 0; i < dataAry.length ; i++){
                var tmp_content = xmp_content;
                var tmpobj = dataAry[i];
                tmp_content = tmp_content.replace("*ID*", tmpobj["id"]);
                tmp_content = tmp_content.replace("*AID*",tmpobj["aid"]);
                tmp_content = tmp_content.replace("*USERNAME*",tmpobj["username"]);
                tmp_content = tmp_content.replace("*VENDOR*",tmpobj["vendor"]);
                tmp_content = tmp_content.replace("*PASSWORD*",tmpobj["password"]);
                tmp_content = tmp_content.replace("*PASSWORD2*",tmpobj["paswd"]);
                tmp_content = tmp_content.replace("*ENABLE*",tmpobj["enable"]);
                tmp_content = tmp_content.replace("*ALIAS*",tmpobj["alias"]);
                tmp_content = tmp_content.replace("*SECRETKEY*",tmpobj["secretKey"]);
                tmp_content = tmp_content.replace("*TOKEN*",tmpobj["token"]);
                tmp_content = tmp_content.replace("*ADDDATETIME*",tmpobj["adddatetime"]);
                
                outStr += tmp_content;
            }
            outStr += xmp_footer;
            divShow.innerHTML = outStr;
        }

    }
    //建立放大鏡搜尋代理專用
    self.pasemainSearchName = function (obj,methodAry) {
        var dataAry = obj[methodAry];
        var divShow = util.getSpan(document, "div_alert_table");
        var xmp_header = util.getSpan(document, "xmp_header_s").innerHTML;
        var xmp_content = util.getSpan(document, "xmp_content_s").innerHTML;
        var xmp_footer = util.getSpan(document, "xmp_footer_s").innerHTML;
        // var pageObj = util.getSpan(document, "pageno_s");
        if(obj["error"]){
            console.log(obj["error"]);
            divShow.innerHTML = obj["error"];    
        }else{
            outStr = "";
            outStr += xmp_header;
            for (var i = 0; i < dataAry.length ; i++){
                var tmp_content = xmp_content;
                var tmpobj = dataAry[i];
                tmp_content = tmp_content.replace("*NUM*",i);
                tmp_content = tmp_content.replace("*USERNAME*",tmpobj["username"]);
                tmp_content = tmp_content.replace("*ALIAS*",tmpobj["alias"]);
                outStr += tmp_content;
            }
            outStr += xmp_footer;
            divShow.innerHTML = outStr;
        }
        util.getSpan(document, "span_alert_count").innerText=dataAry.length;
        listenEvent.addListenEvent();
    }

    
}

//錯誤訊息
function showMsg(motion, data) {
    var str = "";

    if (motion == null) {
        return;
    } else if (motion == "MODIFY_SUCCESS") {
        str = "修改成功!";
    }

    alert(str);
}