<?php
//這是一隻relay http 至 api server 的php 
$ip="192.168.201.78"; //api server ip
// $port="12001"; //api server port

// $tmp=explode(".",$_SERVER['SERVER_NAME']);
$tmp =  $_SERVER['SERVER_NAME'];




// $ip="192.168.201.119"; //ba2 測試機 api server ip 
$port="40030"; //ba2 info/line api server port
$port="41030"; //ba2 old api server port

//檢查務必使用 Content-Type: application/json

$RequestHader = apache_request_headers();
if(!isSet($RequestHader['Content-Type']) || strpos(strtolower($RequestHader['Content-Type']),"json") === false){
    echo "Content-Type not json";
    exit;
}

header('Content-Type: application/json;charset=utf-8');
$code = file_get_contents('php://input');//取得JSON的內容
$back=javaConnnection($code,$ip,$port,true);;
echo $back;
exit;

function javaConnnection($command,$ip,$port,$back=false){
    $get="";
    $fp = fsockopen($ip, $port, $errno, $errstr, 5);
    if (!$fp) {
        return "Server error";
        //echo "<script>alert('$errno:$errstr');</script>";
    } else {
        fwrite($fp, $command."\n");
        if($back){
            while (!feof($fp)) {
                $get.= fgets($fp, 256);
                if(strpos($get , "\n") > -1) break;
                //echo $get;
            }
        }
        fclose($fp);
    }
    return $get;
}
?>