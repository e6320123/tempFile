var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;
var starttime = "2018-01-01";//月曆的初始日期限制
var nowPage = 1;//預設目前頁數

//初始化
function init() {
    phpEvent = new phpEvent();	//PHP事件
    listenEvent = new listenEvent();	//監聽事件
    showView = new showView();	//畫面控制
    DTF = new DateTimeFormat();	//取得時間格式
    //預設日期時間
    //預設開始時間為臨近整點
    var time = DTF.getTime(null, { "dd": -1, "hh": "0", "mm": "0", "ss": "0" });
    var timeObj = DTF.timeToString(time, "split");
    util.getSpan(document, "startdate_0").value = util.getSpan(document, "startdate_0").value || timeObj[0];
    util.getSpan(document, "startdate_1").value = util.getSpan(document, "startdate_1").value || timeObj[1];
    time = DTF.getTime(time, { "dd": 1, "hh": "23", "mm": "59", "ss": "59" });	//預設結束時間延後一天
    timeObj = DTF.timeToString(time, "split");
    util.getSpan(document, "enddate_0").value = util.getSpan(document, "enddate_0").value || timeObj[0];
    util.getSpan(document, "enddate_1").value = util.getSpan(document, "enddate_1").value || timeObj[1];
    doSet();	//預設動作
}

//預設動作
function doSet() {
    //建立監聽事件(靜態)
    listenEvent.addHyperLink();
    var doc = doc || document;
    //設定自動關閉月曆
    calendar.window.setAutoClose(doc, document);
    //取得資料
    // phpEvent.getData();
}

//PHP事件
function phpEvent() {
    var self = this;
    var aPath = "/func/api_rec/getApi_rec.php";
    var parame = "uid=" + top.uid + "&langx=" + top.langx;

    //取得資料
    self.getData = function () {
        var regExp = /^[\d|a-zA-Z]+$/;
        var checkacAry = document.getElementsByName("action");
        var checkmeAry = document.getElementsByName("method");
        var aidtxt = document.getElementById("txtAid").value;
        var actionStr = "";
        var methodStr = "";
        // if(!regExp.test(aidtxt)){
        //     alert("請輸入aid");
        //     return;
        // }
        for (var i = 0; i < checkacAry.length; i++) {
            if (checkacAry[i].checked){
                if (actionStr != "") actionStr += "@,@";
                actionStr += checkacAry[i].value;
            }
        }
        for (var j = 0; j < checkmeAry.length; j++) {
            if (checkmeAry[j].checked) {
                if (methodStr != "") methodStr += "@,@";
                methodStr += checkmeAry[j].value;
            }
        }
        var midtxt = document.getElementById("txtNum").value;
        var outparam = "&action=@" + actionStr + "@&method=@" + methodStr + "@";
        if (midtxt != "") outparam += "&searchmid=" + midtxt;
        if (aidtxt != "") outparam += "&searchaid=" + aidtxt;
        var tmp = parame + "&pages=" + nowPage + outparam;
        tmp += "&startdate=" + util.getSpan(document, "startdate_0").value + " " + util.getSpan(document, "startdate_1").value;
        tmp += "&enddate=" + util.getSpan(document, "enddate_0").value + " " + util.getSpan(document, "enddate_1").value;
        util.addPostPHP("getData", aPath, tmp, this);
    }

    //修改資料
    self.editData = function () {

    }

    //PHP事件回應
    self.phpDataCenter = function (eventName, phpData) {
        var obj = phpData;

        if (eventName == "getData") {
            showView.pasemainBody(obj);

            // util.getSpan(document, "table").style.display = "";
            return;
        }

        if (eventName == "editData") {
        }
    }
}

//監聽事件
function listenEvent() {
    var self = this;

    //建立監聽事件(靜態)
    self.addHyperLink = function () {
        //日期選擇
        var buttonArr = document.getElementsByName("button");
        buttonArr.forEach((button) => { listenEvt.addOnClick(button.id, button, this, button.getAttribute("data-func")); });
        //全選按鈕兩個
        listenEvt.addOnClick("ckeckAll", util.getSpan(document, "ckeckAll"), this, "action");
        listenEvt.addOnClick("ckeckAll2", util.getSpan(document, "ckeckAll2"), this, "method");
        //查詢
        listenEvt.addOnClick("btnok", util.getSpan(document, "btnok"), this, "btnok");
        //改變頁數
        listenEvt.addSelectOnChange("pageno", util.getSpan(document, "pageno"), this, null);
        //檢查輸入金額
        listenEvt.addOnInput("txtNum", util.getSpan(document, "txtNum"), this, null);
    }

    //建立監聽事件(動態)
    self.addListenEvent = function () {
    }

    //監聽事件回應
    self.listenCenter = function (eventName, listenData) {
        var obj = listenData;

        //打開月曆
        if (eventName.indexOf("calendar") != -1) {
            var tmp = eventName.split("_");
            eventType = tmp[1];
            if (eventType == "startdate") {
                var startdate = DTF.timeToString(DTF.getTime(null, { "time": starttime }), "day");
                var enddate = util.getSpan(document, "enddate_0").value;
            } else {
                var startdate = util.getSpan(document, "startdate_0").value;
                var enddate = DTF.timeToString(DTF.getTime(), "day");
            }
            DTF.setDateLimit(startdate, "start");
            DTF.setDateLimit(enddate, "end");

            calendar.window.setSpan(obj.div.children[1], "value", 30, 40);
            calendar.window.setDay(obj.div.children[1].value);

            return true;
        }
        //點擊全選
        if (eventName.indexOf("ckeckAll") != -1){
            var checkAry = document.getElementsByName(obj.object);
            for (var i = 0; i < checkAry.length ; i++){
                checkAry[i].checked = obj.div.checked;
            }
        }
        //查詢
        if (eventName == "btnok"){
            phpEvent.getData();
        }
        //改變頁數
        if (eventName == "pageno") {
            nowPage = util.getSpan(document, "pageno").value;
            phpEvent.getData();
            return;
        }
        //檢查輸入的會員mid
        if (eventName == "txtNum"){
            obj.div.value = util.moneyCheck(obj.div.value);
        }
    }
}

//畫面控制
function showView() {
    var self = this;

    //建立表格
    self.pasemainBody = function (obj) {
        var recAry = obj["recAry"];
        var divShow = util.getSpan(document, "divShow");
        var xmp_header = util.getSpan(document, "xmp_header").innerHTML;
        var xmp_content = util.getSpan(document, "xmp_content").innerHTML;
        var xmp_footer = util.getSpan(document, "xmp_footer").innerHTML;
        var pageObj = util.getSpan(document, "pageno");

        outStr = "";

        outStr += xmp_header;
        for (var i = 0; i < recAry.length ; i++){
            var tmp_content = xmp_content;
            var tmpobj = recAry[i];
            tmp_content = tmp_content.replace("*ID*", tmpobj["id"]);
            tmp_content = tmp_content.replace("*AID*",tmpobj["aid"]);
            tmp_content = tmp_content.replace("*MID*",tmpobj["mid"]);
            tmp_content = tmp_content.replace("*ACTION*",tmpobj["action"]);
            tmp_content = tmp_content.replace("*METHOD*",tmpobj["method"]);
            tmpobj["content"] = tmpobj["content"].replace(/@/g, "</br>");
            tmp_content = tmp_content.replace("*CONTENT*",tmpobj["content"]);
            tmp_content = tmp_content.replace("*ADDDATE*",tmpobj["adddate"]);
            outStr += tmp_content;
        }

        outStr += xmp_footer;

        divShow.innerHTML = outStr;
        //建立監聽事件
        listenEvent.addListenEvent();
        //產生頁碼
        pageObj.options.length = 0;
        for (var i = 0; i < obj["totalpage"]; i++) {
            var varItem = new Option((i + 1), (i + 1));
            pageObj.options.add(varItem);
        }
        //指定現在頁碼
        pageObj.value = obj["pages"];
        util.getSpan(document, "page_total").innerHTML = obj["totalpage"];

    }

}

//錯誤訊息
function showMsg(motion, data) {
    var str = "";

    if (motion == null) {
        return;
    } else if (motion == "MODIFY_SUCCESS") {
        str = "修改成功!";
    }

    alert(str);
}