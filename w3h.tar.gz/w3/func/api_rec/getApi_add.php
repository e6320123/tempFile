<?php
include ("../../conf/config_admin.php");

if (!preg_match ("/J/", $MEM_DATA['admin_type'])){//沒有內部管理列表權限
	exit;
}

$out=Array();//回傳陣列

$DB = $dbr;


//====== 執行動作區 ======
//====== 執行動作區 ======


//====== 主要資料區 ======

$apiAry = Array();
$action = $action;
$method = $method;
$username = $username;
$paswd = $paswd;
$alias = $alias;
$enable = $enable;
$krtype = $krtype;
$today=getdate();
$adddatetime = gmdate("Y-m-d H:i:s",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds]-15,$today[mon],$today[mday],$today[year])); 
/*
tmp += "&action=add";
tmp += "&username="+username;
tmp += "&paswd="+paswd;
tmp += "&alias="+alias;
tmp += "&enable="+chk;
*/
$error = "格式錯誤";
if(!empty($username) && !preg_match("/^[\d|a-zA-Z]+$/",$username)) error_exit($error);
if(!empty($paswd) && !preg_match("/^[\d|a-zA-Z]+$/",$paswd)) error_exit($error);

if($action=="search"){
    $sql  = "SELECT * from agents where" ;
    if($username!="") $sql .= " username ='".$username."' ";
    if($username!="" && $user_id!="") $sql .= " AND ";
    if($user_id!="") $sql .= " id ='".$user_id."' ";
    $dbr->query($sql,1);
    if($dbr->num_rows()*1<=0){
     $error = "請輸入正確的代理帳號";
     error_exit($error);
    }else{
        $aid = $dbr->f("id");
    }    

    $sql ="SELECT * from outsource_ag where aid ='".$aid."';";
    $dbr->query($sql,1);
    if($dbr->num_rows()*1<=0){
        $error = "尚未成為api代理";
        error_exit($error);
    }
    $tmp = Array();
    $tmp["id"] = $dbr->f("id");
    $tmp["aid"] = $dbr->f("aid");
    $tmp["username"] = $dbr->f("username");
    $tmp["password"] = $dbr->f("password");
    $tmp["paswd"] = $dbr->f("passwd");
    $tmp["enable"] = $dbr->f("enable");
    $tmp["alias"] = $dbr->f("alias");
    $tmp["secretKey"] = $dbr->f("secretKey");
    $tmp["token"] = $dbr->f("token");
    $tmp["adddatetime"] = $dbr->f("adddatetime");
    $tmp["vendor"] = $dbr->f("vendor");
    
    $apiAry[]=$tmp;

    $out["searchAry"] = $apiAry;
    $out["action"] = $action;
    $out["method"] = $method;

    $dbr -> close();
    $db ->  close();
    echo json_encode($out);
    exit;
}
if($action=="find"){
    $tmp = Array();
    $sql ="SELECT username,alias from agents where username like '".$username."%' and level='0' and aid='0' ";
    
    $dbr->query($sql);
    while($dbr->next_record()){
        $tmp["username"]=$dbr->f("username");
        $tmp["alias"]=$dbr->f("alias");
        $apiAry[]=$tmp;
    }
    
    $out["serachNameAry"] = $apiAry;
    $out["action"] = $action;
    $out["method"] = $method;
    $dbr -> close();
    echo json_encode($out);
    exit;
}

// ===== 平層代理 == Begin =====
$REC_level='1';					// 超帳
$REC_status='1';				// NOTE
$REC_action='1';				// 新增
$REC_table='record_ag';			// DB Table
$REC_sub_table='record_ag_sub';	// DB sub_Table
// ===== Variable of Control_Record == End =======

if($action=="edi"){
    $sql ="SELECT * from agents where username ='".$username."' and level='0' and aid='0';";
    $dbr->query($sql,1);
    if($dbr->num_rows()*1<=0){
     $error = "請輸入正確的代理帳號";
     error_exit($error);
    }else{
        $aid = $dbr->f("id");
    }
    $sql ="SELECT aid from outsource_ag where aid ='".$aid."';";
    $dbr->query($sql,1);
    if($dbr->num_rows()*1<0){
        $error = "此帳號尚未成為API代理";
        error_exit($error);
    }else{
    
    }

    $sql_up ="UPDATE outsource_ag set  password=PASSWORD('".$paswd."'),passwd='".$paswd."' where aid = '".$aid."'";
    $db->query($sql_up);
    $record_rid=ctrl_record($db,$REC_table,$uid,$REC_level,$REC_status,$REC_action,"修改 [API代理商ID=".$aid."]  [密碼]");
    $ctrl_sub_str = "修改 [API代理][outsource_ag][aid='$aid'] 的密碼=$paswd";
    ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,$ctrl_sub_str,$sql_up);

    $sql ="SELECT * from outsource_ag where aid ='".$aid."';";
    $dbr->query($sql,1);
    $tmp = Array();
    $tmp["id"] = $dbr->f("id");
    $tmp["aid"] = $dbr->f("aid");
    $tmp["username"] = $dbr->f("username");
    $tmp["password"] = $dbr->f("password");
    $tmp["paswd"] = $paswd;
    $tmp["enable"] = $dbr->f("enable");
    $tmp["alias"] = $dbr->f("alias");
    $tmp["secretKey"] = $dbr->f("secretKey");
    $tmp["token"] = $dbr->f("token");
    $tmp["adddatetime"] = $dbr->f("adddatetime");
    $tmp["vendor"] = $dbr->f("vendor");
    $apiAry[]=$tmp;


    $out["ediAry"] = $apiAry;
    $out["action"] = $action;
    $out["method"] = $method;
    $dbr -> close();
    $db ->  close();
    echo json_encode($out);
    exit;
}
if($action=="ediKR"){
    $sql ="SELECT * from agents where username ='".$username."' and level='0' and aid='0';";
    $dbr->query($sql,1);
    if($dbr->num_rows()*1<=0){
     $error = "請輸入正確的代理帳號";
     error_exit($error);
    }else{
        $aid = $dbr->f("id");
    }
    $sql ="SELECT aid from outsource_ag where aid ='".$aid."';";
    $dbr->query($sql,1);
    if($dbr->num_rows()*1<0){
        $error = "此帳號尚未成為API代理";
        error_exit($error);
    }else{
    
    }

    if($krtype=="Y"){
        $vendor ='KR';
    }else{
        $vendor ='';
    }

    $sql_up ="UPDATE outsource_ag set vendor='".$vendor."'  where aid = '".$aid."'";
    $db->query($sql_up);
    $record_rid=ctrl_record($db,$REC_table,$uid,$REC_level,$REC_status,$REC_action,"修改 [API代理商ID=".$aid."]  [vendor]");
    $ctrl_sub_str = "修改 [API代理][outsource_ag][aid='$aid'] 的vendor=$vendor";
    ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,$ctrl_sub_str,$sql_up);

    $sql ="SELECT * from outsource_ag where aid ='".$aid."';";
    $dbr->query($sql,1);
    $tmp = Array();
    $tmp["id"] = $dbr->f("id");
    $tmp["aid"] = $dbr->f("aid");
    $tmp["username"] = $dbr->f("username");
    $tmp["paswd"] = $dbr->f("passwd");
    $tmp["password"] = $dbr->f("password");
    $tmp["enable"] = $dbr->f("enable");
    $tmp["alias"] = $dbr->f("alias");
    $tmp["secretKey"] = $dbr->f("secretKey");
    $tmp["token"] = $dbr->f("token");
    $tmp["adddatetime"] = $dbr->f("adddatetime");
    $tmp["vendor"] = $dbr->f("vendor");
    $apiAry[]=$tmp;


    $out["ediAry"] = $apiAry;
    $out["action"] = $action;
    $out["method"] = $method;
    $dbr -> close();
    $db ->  close();
    echo json_encode($out);
    exit;
}
if($action=="add"){

    $sql ="SELECT * from agents where username ='".$username."' and level='0' and aid='0';";
    $dbr->query($sql,1);
    if($dbr->num_rows()*1<=0){
    $error = "請輸入正確的代理商帳號";
    error_exit($error);
    }else{
        $aid = $dbr->f("id");
    }

    $sql ="SELECT aid from outsource_ag where aid ='".$aid."';";
    $dbr->query($sql,1);
    if($dbr->num_rows()*1>0){
        $error = "已新增過此API代理";
        error_exit($error);
    }else{
        
    }

    if($krtype=="Y"){
        $vendor ='KR';
    }else{
        $vendor ='';
    }

    $secretKey = random_str(16);
    $sql_in = "INSERT INTO outsource_ag SET ";
    $sql_in .= " aid='".$aid."'";
    $sql_in .= " ,api_agid ='".$aid."'";
    $sql_in .= " ,vendor ='".$vendor."'";
    $sql_in .= " ,username ='".$username."'";
    $sql_in .= " ,password=PASSWORD('".$paswd."')";
    $sql_in .= " ,passwd='".$paswd."'";
    $sql_in .= " ,alias ='".$alias."'";
    $sql_in .= " ,enable ='".$enable."'";
    $sql_in .= " ,secretKey ='".$secretKey."'";
    $sql_in .= " ,adddatetime ='".$adddatetime."'";
    // echo $sql_in;
    $db->query($sql_in);
    // exit;
    $record_rid=ctrl_record($db,$REC_table,$uid,$REC_level,$REC_status,$REC_action,"新增 [API代理商ID=".$aid."]  [基本資料]");
    $ctrl_sub_str = "新增 [API代理][outsource_ag] : aid=$aid,api_agid=$aid, 帳號=$username, 密碼=$paswd, 名稱=$alias ,enable =$enable ,secretKey =$secretKey ,adddatetime =$adddatetime,vendor=$vendor";
    ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,$ctrl_sub_str,$sql_in);

    //api新增六組詳細設定
    $sql = "SELECT * FROM ag_conf WHERE aid='".$aid."' and grp='7'";
    $dbr->query($sql);
    if($dbr->num_rows()*1>0){
        $error = "已新增過七組設定";
        error_exit($error);
    }

    $sql = "SELECT * FROM ag_conf WHERE aid='".$aid."' and grp='1'";
    $dbr->query($sql);
    $conf_data = $dbr->get_total_data();

    for($g=2;$g<=7;$g++){
        for($j=0;$j < count($conf_data);$j++){
            $sql_sc=  "INSERT INTO ag_conf set ";
            $sql_sc.= " aid='".$conf_data[$j]["aid"]."'";
            $sql_sc.= ",gtype='".$conf_data[$j]["gtype"]."'";
            $sql_sc.= ",rtype='".$conf_data[$j]["rtype"]."'";
            $sql_sc.= ",SC='".$conf_data[$j]["SC"]."'";
            $sql_sc.= ",SO='".$conf_data[$j]["SO"]."'";
            // $sql_sc.= ",W_WAR='".$conf_data[$j]["W_WAR"]."'";
            // $sql_sc.= ",L_WAR='".$conf_data[$j]["L_WAR"]."'";
            $sql_sc.= ",W_WAR='0'";
            $sql_sc.= ",L_WAR='0'";
            $sql_sc.= ",grp='".$g."'";
            $db->query($sql_sc);
            // echo $sql_sc."\n";
            ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,"新增 [API代理商AID=".$aid."]"."[".$conf_data[$j]["gtype"]."][".$conf_data[$j]["rtype"]."] 的 [七組詳細設定] [$g]",$sql_sc);
        }
    }

    $sql_wl=  "UPDATE ag_conf set W_WAR='0',L_WAR='0' WHERE   aid='".$aid."' and grp='1' and gtype='BA' ";
    $db->query($sql_wl);
    ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,"新增 [API代理商AID=".$aid."]"."[".$conf_data[$j]["gtype"]."][退水設定]的 [第一組詳細設定] [1]",$sql_wl);
    
    



    $sql ="SELECT * from outsource_ag where aid ='".$aid."';";
    $dbr->query($sql,1);
    $tmp = Array();
    $tmp["id"] = $dbr->f("id");
    $tmp["aid"] = $dbr->f("aid");
    $tmp["username"] = $dbr->f("username");
    $tmp["password"] = $paswd;
    $tmp["enable"] = $dbr->f("enable");
    $tmp["alias"] = $dbr->f("alias");
    $tmp["secretKey"] = $dbr->f("secretKey");
    $tmp["token"] = $dbr->f("token");
    $tmp["adddatetime"] = $dbr->f("adddatetime");
    $tmp["vendor"] = $dbr->f("vendor");
    $apiAry[]=$tmp;


    $out["addAry"] = $apiAry;
    $out["action"] = $action;
    $out["method"] = $method;



    $dbr -> close();
    $db ->  close();

    echo json_encode($out);
    exit;
}


//回傳錯誤訊息
function error_exit($error){
    if($error){
        $out["error"] = $error;
        echo json_encode($out);
        // $dbr -> close();
        // $db ->  close();
        exit;
    }
}

?>