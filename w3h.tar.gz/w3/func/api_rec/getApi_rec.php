<?php
include ("../../conf/config_admin.php");

if (!preg_match ("/J/", $MEM_DATA['admin_type'])){//沒有內部管理列表權限
	exit;
}


$DB = $dbr;
$out=Array();
$dbAction_R = new proc_DB(DB_ACTION_HOST_R,DB_USER_R,DB_PWD_R,DB_ACTION_NAME);

//====== 執行動作區 ======
//====== 執行動作區 ======

//====== 主要資料區 ======

$apiAry = Array();
$action = $action;
$method = $method;
$pages = $pages ;//目前頁數
$max_id = 0;
$min_id = 0;


$startdate = str_replace("&nbsp"," ",$startdate);//傳送空白 會被換成&nbsp
$enddate = str_replace("&nbsp"," ",$enddate);
$sql = "SELECT COUNT(1) AS _count , MAX( id ) AS max_id, MIN( id ) AS min_id FROM `api_record` WHERE adddate > '".$startdate."' AND adddate < '".$enddate."' ";
$action = str_replace("@","'",$action);
$method = str_replace("@","'",$method);
if($action) $sql.=" AND `action` in (".$action.")";
if($method) $sql.=" AND `method` in (".$method.")";
if($searchmid) $sql.=" AND `mid` = ".$searchmid." ";
if($searchaid) $sql.=" AND `aid` = ".$searchaid." ;";

$dbAction_R->query($sql,1);
$totalcount = $dbAction_R->f("_count");
if($dbAction_R->f("max_id"))$max_id = $dbAction_R->f("max_id");
if($dbAction_R->f("min_id"))$min_id = $dbAction_R->f("min_id");
/*---------分頁------------  */
if ($records=="") $records=50;	/*顯示筆數*/
$totalpage = ceil($totalcount/$records);
if ($pages=="" ) $pages=1;
if ($totalpage == 0)$totalpage = 1;
if ($pages > $totalpage)$pages = $totalpage;
if ($records!="-1") $limits=" limit ".(($pages-1)*$records).",".$records;

$sql = "SELECT * FROM `api_record` WHERE id >= ".$min_id." AND id <= ".$max_id." ";
$action = str_replace("@","'",$action);
$method = str_replace("@","'",$method);
if($action) $sql.=" AND `action` in (".$action.")";
if($method) $sql.=" AND `method` in (".$method.")";
if($searchmid) $sql.=" AND `mid` = ".$searchmid."";
if($searchaid) $sql.=" AND `aid` = ".$searchaid."";
$sql .= " order by id DESC ".$limits." ;" ;

$dbAction_R->query($sql);
if($dbAction_R->num_rows()> 0){
	while($dbAction_R->next_record()){
		$tmp = Array();
		$tmp["id"] = $dbAction_R->f("id");
		$tmp["aid"] = $dbAction_R->f("aid");
		$tmp["mid"] = $dbAction_R->f("mid");
		$tmp["action"] = $dbAction_R->f("action");
		$tmp["method"] = $dbAction_R->f("method");
		$tmp["content"] = $dbAction_R->f("content");
		$tmp["adddate"] = $dbAction_R->f("adddate");
		$apiAry[]=$tmp;
	}

}



$out["recAry"] = $apiAry;
$out["totalpage"]=$totalpage;
$out["pages"]=$pages;
$DB -> close();
$dbAction_R -> close();
echo json_encode($out);
exit;


?>