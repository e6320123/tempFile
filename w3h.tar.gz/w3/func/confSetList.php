<?php
include ("../conf/config_admin.php");

if ($file == null || $file == "") {
    $file = "index";
}
if (!preg_match ("/J/", $MEM_DATA['admin_type'])){//沒有內部管理列表權限
	exit;
}

$rand = rand(1, 10000);
include "../func/".$file.".html";

$uid = $uid;

// $str = "<script>var uid='".$uid."';</script>";


// echo $<s>
// echo BROWSER_IP."/func";
// $tpl->clear_all();
// define("WEB_PATH_TPL","../func");
// $tpl->set_root("../func/");
// $tpl->define(array(main=>$file.".html"));
// $tpl->parse(BODY,"main");
// $tpl->FastPrint("BODY");
// echo BROWSER_IP."/func/".$file.".html";


?>