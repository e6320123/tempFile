//lib
var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;;
//class
var phpObj;
var listenObj;
var layerFuncObj;
var DTF;
var starttime = "2018-01-01";//月曆的初始日期限制
var barREChart;



function init(){
    phpObj = new phpEvent();
    listenObj = new listenEvent();
    barREChart = new handleChart();
    listenObj.addHyperLink();
    barREChart.initChart();
    initShow();
    setCalendarInit();
}

function setCalendarInit(){
    var calendar = util.getSpan(document,"calendar");
    // calendar.src="/tpl/control/"+top.langx+"/calendar.html";
    DTF = new DateTimeFormat();	//取得時間格式
    //預設日期時間
    //預設開始時間為臨近整點
    var time = DTF.getTime(null, { "dd": 0, "hh": "0", "mm": "0", "ss": "0" });
    var timeObj = DTF.timeToString(time, "split");
    util.getSpan(document, "startdate_0").value = util.getSpan(document, "startdate_0").value || timeObj[0];
    util.getSpan(document, "startdate_1").value = util.getSpan(document, "startdate_1").value || timeObj[1];
    time = DTF.getTime(time, { "dd": 0, "hh": "23", "mm": "59", "ss": "59" });	//預設結束時間延後一天
    timeObj = DTF.timeToString(time, "split");
    util.getSpan(document, "enddate_0").value = util.getSpan(document, "enddate_0").value || timeObj[0];
    util.getSpan(document, "enddate_1").value = util.getSpan(document, "enddate_1").value || timeObj[1];
    if(calendar.window)calendar.window.setAutoClose(document, document);
}


function initShow(){
    util.getSpan(document,"showDiv").innerHTML="";
    
}


function handleChart(){
    var self = this;
    var chartDiv = null;
    var data_length = 10;

    self.initChart = function(){
        chartDiv = echarts.init(util.getSpan(document, "allContainer"));
        //標題 圖例 座標軸
        chartDiv.setOption({
            title: {
                text: "正期望值的百分比"
            },
            legend: {
                data: [{name:'次數'},{name:'實際'},{name:'天數'}]
            },
            tooltip: {},
            xAxis: {
                // type: 'category',
                // nameGap: 5,
                axisLabel: {
                    interval: 0,      //坐标轴刻度标签的显示间隔(在类目轴中有效) 0:显示所有  1：隔一个显示一个 :3：隔三个显示一个...
                    rotate: -30       //标签倾斜的角度，显示不全时可以通过旋转防止标签重叠（-90到90）
                },
                data: []
            },
            yAxis: {
                max:100
            },
            series: [
                {
                    // 根据名字对应到相应的系列
                    // data: chartData.data
                    type: 'bar',
                    color:'#F75000',
                    data: {}
                },
                {
                    type: 'bar',
                    color: '#546570',
                   data: {}
                },
                {
                    color: '#949449',
                    type: 'bar',
                    data: {}
                }
            ]
        });
        showLoading(true);
    }

    self.setChartData = function(xAxisName,xAxisData,xAxisData2,xAxisData3,xAxisData4){
        var total_rank = 0;
        // set data
        if(xAxisName.length >= data_length)xAxisName.length = data_length;
        if(xAxisData.length >= data_length)xAxisData.length = data_length;
        if(xAxisData2.length >= data_length)xAxisData2.length = data_length;
        if(xAxisData3.length >= data_length)xAxisData3.length = data_length;
        if(xAxisData4.length >= data_length)xAxisData4.length = data_length;

        for(i=0;i<xAxisData4.length;i++){
            total_rank += xAxisData[i];
        }

        for(i=0;i<xAxisData4.length;i++){
            xAxisData[i] = Math.floor(xAxisData[i]*1/total_rank*10000+0.00001)/100;
        }
    
        chartDiv.setOption({
            legend: {
                data: ['期望值強度','正期望值的百分比','正期望值的次數除以天數的百分比','下注次數除以天數']
            },
            xAxis: {
                // data: chartData.categories
                data: xAxisName
            },
            tooltip : {
                trigger: 'axis'
            },
            series: [
                {
                    // 根据名字对应到相应的系列
                    name: "期望值強度",
                    type: 'bar',
                    barWidth:'5',
                    data: xAxisData
                },
                {
                   name: "正期望值的百分比",
                   type: 'bar',
                   barWidth:'5',
                   data: xAxisData2
                },
                {
                    name:"正期望值的次數除以天數的百分比",
                    type: 'bar',
                    barWidth:'5',
                    data: xAxisData3
                },
                {
                    name:"下注次數除以天數",
                    type: 'bar',
                    barWidth:'5',
                    data: xAxisData4
                }
            ]
        });

        showLoading(false);
    }

    function showLoading(bol){
        if(bol)chartDiv.showLoading();
        else chartDiv.hideLoading();
    }

}


function listenEvent(){
    var self = this;

    self.addHyperLink = function(){
        listenEvt.addOnClick("Search", util.getSpan(document,"search"), this, null);
        listenEvt.addOnClick("Change", util.getSpan(document,"change"), this, null);
        listenEvt.addOnClick("Remove", util.getSpan(document,"remove"), this, null);
        
        var buttonArr = document.getElementsByName("button");
        buttonArr.forEach((button) => { listenEvt.addOnClick(button.id, button, this, button.getAttribute("data-func")); });
    }

    self.addDynamicLink = function(){
        var rows = document.getElementsByClassName("show_box");
        var i=0;
        for(var key in rows){
            listenEvt.addOnClick("Display_"+ (i++), rows[key], this, "active"); 
        }
    }

    self.listenCenter = function (eventString, listenData) {
        var tmpData = eventString.split("_");
	    var eventName = tmpData[0];
        var eventData = (tmpData[1]) ? tmpData[1] : "";

        if(eventName == "Search"){
            phpObj.getLayerData();
            return;
        }

        if(eventName == "Change"){
            phpObj.touchData();
            return;    
        }

        if(eventName == "Remove"){
            phpObj.removeData();
            return;    
        }

        if(eventName == "Display"){
            if(util.getClassName(listenData.div).indexOf(listenData.object)*1 != -1){
                util.removeClassName(listenData.div,listenData.object);
            }else{
                util.appendClassName(listenData.div,listenData.object);
            }
            return;    
        }
        //打開月曆
        if (eventName.indexOf("calendar") != -1) {
            if (eventData == "startdate") {
                var startdate = DTF.timeToString(DTF.getTime(null, { "time": starttime }), "day");
                var enddate_select = util.getSpan(document, "enddate_0").value;
                var enddate_today = DTF.timeToString(DTF.getTime(), "day");
                var enddate = (new Date(enddate_select).getTime()*1 <= new Date(enddate_today).getTime()*1)? enddate_select:enddate_today;
            } else {
                var startdate_select = util.getSpan(document, "startdate_0").value;
                var startdate_today = DTF.timeToString(DTF.getTime(null, { "time": starttime }), "day");
                var startdate = (new Date(startdate_select).getTime()*1 >= new Date(startdate_today).getTime()*1)? startdate_select:startdate_today;
                var enddate = DTF.timeToString(DTF.getTime(), "day");
            }
            DTF.setDateLimit(startdate, "start");
            DTF.setDateLimit(enddate, "end");
            calendar.window.setSpan(listenData.div.children[1], "value", 30, 40);
            calendar.window.setDay(listenData.div.children[1].value);
            return;
        }


    }
    

}


//PHP事件
function phpEvent() {
    var self = this;
    var aPath = "/func/expectReward/get_expectReward.php";
    var aPath2 = "/app/control/admin/report_new2/static_data_report_mem_ER.php";
    
    //桌次Data
    self.getLayerData = function () {
        var start_date=document.getElementById("startdate_0").value;
        var end_date=document.getElementById("enddate_0").value;
        var parame = "action=getLayerData";
        parame += "&uid=" + uid;
        parame += "&startdate=" + start_date;
        parame += "&enddate=" + end_date;
        util.addPostPHP("getLayerData", aPath, parame, this);
        
    }

    self.touchData = function(){
        var date_Start =document.getElementById("startdate_0").value;
        var date_End = document.getElementById("enddate_0").value;
        if(date_Start != date_End){
            alert("STARTDATE MUST BE EQUAL TO ENDDATE");
            return;
        }
        var date = date_Start;
        var parame = "action=genReport";
        parame += "&uid=" + uid;
        parame += "&date_start=" + date;
        util.addPostPHP("touchData", aPath2, parame, this);
    }

    self.removeData = function(){
        var date_Start =document.getElementById("startdate_0").value;
        var date_End = document.getElementById("enddate_0").value;
        if(date_Start != date_End){
            alert("STARTDATE MUST BE EQUAL TO ENDDATE");
            return;
        }
        var date = date_Start;
        var parame = "action=delReport";
        parame += "&uid=" + uid;
        parame += "&date_start=" + date;
        util.addPostPHP("removeData", aPath2, parame, this);
    }

    
    //PHP事件回應
    self.phpDataCenter = function (eventName, phpData) {
        //get 全部桌Data
        if (eventName == "getLayerData") {
            
            if(phpData["code"]=="0000"){
                parseData(phpData["data"],phpData["day"]);
            }else{
                alert(phpData["msg"]);
            }
            return;
        }

        if(eventName == "touchData" || eventName == "removeData"){
            alert(phpData);
            return;
        }

    }
}


function parseData(data,diffDay){
    var i=0;
    var countREData = new Object();
    var countREData_Ary =[];
    var countREData_Name = [];
    var countREData_freq = [];
    var countREData_real_freq = [];
    var countREData_day_freq = [];
    var countREData_total_day =[];
    var data_total = data.length;
    var data_rank_total = 0;
    var total_rank = 0;


    if(data){
        data = data.sort(function(a,b){
            return a["report_text"]["ER"] < b["report_text"]["ER"]? 1:-1;
        });
        for(var key in data){
            if(data[key]["report_text"]["ER"]*1>0)data_rank_total+=1;
        }
        for(var key in data){
            var memid = data[key]["uid"];
            var ER = data[key]["report_text"]["ER"];
            if(!countREData[memid]){
                countREData[memid] = new Object();
                countREData[memid]["name"]  ="";
                countREData[memid]["freq"]  = 0;
                countREData[memid]["total"]  = 0;
                countREData[memid]["day"]  = diffDay;
                countREData[memid]["real_plusER_freq"]  = 0;
                countREData[memid]["day_plusER_freq"]  = 0;
                countREData[memid]["rank"]  = 0;
                
                countREData[memid]["origin_data"] = [];
                countREData[memid]["total_gold"] = 0;
                countREData[memid]["total_ER"] = 0;
                countREData[memid]["total_wingold"] = 0;
                countREData[memid]["total_betcount"] = 0;
                countREData[memid]["total_wcount"] = 0;
                countREData[memid]["currency"] = "";
            }

            countREData[memid]["origin_data"].push(data[key]);
            countREData[memid]["total_ER"] += ER;
            countREData[memid]["total_gold"] += data[key]["report_text"]["Gold"];
            countREData[memid]["total_wingold"] += data[key]["report_text"]["Wingold"];
            countREData[memid]["total_betcount"] += data[key]["report_text"]["Total"];
            countREData[memid]["total_wcount"] += data[key]["report_text"]["Wcount"];
            countREData[memid]["currency"] = data[key]["report_text"]["Currency"];

            
            countREData[memid]["name"] = data[key]["report_text"]["Name"];
            countREData[memid]["total"] += 1;

            if(ER*1 > 0 ){
                countREData[memid]["freq"] +=1 ;
                countREData[memid]["rank"] += data_rank_total - i;
            }
            countREData[memid]["real_plusER_freq"] = (Math.floor(countREData[memid]["freq"]*1/countREData[memid]["total"]*10000+0.0000001))/100;
            countREData[memid]["day_plusER_freq"] = (Math.floor(countREData[memid]["freq"]*1/countREData[memid]["day"]*10000+0.0000001))/100;
            total_rank += countREData[memid]["rank"];   
        }


        countREData_Ary = Object.keys(countREData).sort(function(a,b){
            return countREData[a]["rank"] < countREData[b]["rank"]?1:-1;
        })


        

        for(var key_mid in countREData_Ary){
            
            countREData_Name.push(countREData[countREData_Ary[key_mid]]["name"]);
            countREData_freq.push(countREData[countREData_Ary[key_mid]]["rank"]);
            countREData_real_freq.push(countREData[countREData_Ary[key_mid]]["real_plusER_freq"]);
            countREData_day_freq.push(countREData[countREData_Ary[key_mid]]["day_plusER_freq"]);
            countREData_total_day.push( Math.floor(countREData[countREData_Ary[key_mid]]["total"]*1/countREData[countREData_Ary[key_mid]]["day"]*10000+0.000001)/100); 
        }
    }
    
    barREChart.setChartData(countREData_Name,countREData_freq,countREData_real_freq,countREData_day_freq,countREData_total_day);
    parseObjData(countREData,countREData_Ary);
}

function parseObjData(REData,sortREData){
    var xmp_header = util.getSpan(document,"simple_report_header").innerHTML;
    var xmp_contant = util.getSpan(document,"simple_report_contant").innerHTML;
    var xmp_foot = util.getSpan(document,"simple_report_foot").innerHTML;   
    var showDiv = util.getSpan(document,"showDiv");    
    var outStr = "";
    var i =1;
    outStr = xmp_header;
    for( var mapkey in sortREData){
            var key = sortREData[mapkey];
            var tmp_contant = xmp_contant;
            var j=1;
            // var ER = data[key]["report_text"]["ER"];
            tmp_contant = tmp_contant.replace(/\*ID\*/g,i++);
            tmp_contant = tmp_contant.replace(/\*NAME\*/g,REData[key]["name"]);
            tmp_contant = tmp_contant.replace(/\*DATE\*/g,"-");
            tmp_contant = tmp_contant.replace(/\*ER\*/g,Math.floor(REData[key]["total_ER"]*10000+0.0000001)/10000);
            tmp_contant = tmp_contant.replace(/\*TOTAL\*/g,REData[key]["total_betcount"]);
            tmp_contant = tmp_contant.replace(/\*WINCOUNT\*/g,REData[key]["total_wcount"]);
            tmp_contant = tmp_contant.replace(/\*GOLD\*/g,Math.floor(REData[key]["total_gold"]*10000+0.0000001)/10000);
            tmp_contant = tmp_contant.replace(/\*WINGOLD\*/g, Math.floor(REData[key]["total_wingold"]*10000+0.0000001)/10000);
            tmp_contant = tmp_contant.replace(/\*CURRENCY\*/g,REData[key]["currency"]);
            
            var  win_percent = Math.floor((util.accDiv(REData[key]["total_wcount"],REData[key]["total_betcount"]))*10000+0.0000001)/100;
            tmp_contant = tmp_contant.replace(/\*WINPERCENT\*/g,win_percent+"%");
            outStr += tmp_contant;
            
            var tmp_sub_foot = util.getSpan(document,"sub_simple_report_foot").innerHTML;
            for(var rows in REData[key]["origin_data"]){
                var row = REData[key]["origin_data"][rows];
                var tmp_sub_contant = util.getSpan(document,"sub_simple_report_contant").innerHTML;

                tmp_sub_contant = tmp_sub_contant.replace(/\*SUBID\*/g,j++);
                tmp_sub_contant = tmp_sub_contant.replace(/\*SUBNAME\*/g,row["report_text"]["Name"]);
                tmp_sub_contant = tmp_sub_contant.replace(/\*SUBDATE\*/g,row["orderdate"]);
                tmp_sub_contant = tmp_sub_contant.replace(/\*SUBER\*/g,row["report_text"]["ER"]);
                tmp_sub_contant = tmp_sub_contant.replace(/\*SUBTOTAL\*/g,row["report_text"]["Total"]);
                tmp_sub_contant = tmp_sub_contant.replace(/\*SUBWINCOUNT\*/g,row["report_text"]["Wcount"]);
                tmp_sub_contant = tmp_sub_contant.replace(/\*SUBGOLD\*/g,row["report_text"]["Gold"]);
                tmp_sub_contant = tmp_sub_contant.replace(/\*SUBWINGOLD\*/g,row["report_text"]["Wingold"]);
                tmp_sub_contant = tmp_sub_contant.replace(/\*SUBCURRENCY\*/g,row["report_text"]["Currency"]);
                
                var  win_percent = Math.floor((util.accDiv(row["report_text"]["Wcount"],row["report_text"]["Total"]))*10000+0.0000001)/100;
                tmp_sub_contant = tmp_sub_contant.replace(/\*SUBWINPERCENT\*/g,win_percent+"%");
                outStr += tmp_sub_contant;
            }
            outStr += tmp_sub_foot;

    }
    outStr += xmp_foot;
    showDiv.innerHTML = outStr;
    listenObj.addDynamicLink();
    showDiv.style.display="";


}