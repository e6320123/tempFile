<?php
include $_SERVER['DOCUMENT_ROOT']."/conf/config_admin.php";

// if ($action == "") {
//     include "expectReward/expectReward.html";
// }else{
    
// }
include ("expectReward.html");
?>