<?php
include $_SERVER['DOCUMENT_ROOT']."/conf/config_admin.php";

$today=getdate();
$today_date=gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$today_time=gmdate("Y-m-d H:i:s",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));

if(!empty($action))$action = $action;
else $action = "";

if(!empty($startdate))$startdate = $startdate;
else $startdate = "";

if(!empty($enddate))$enddate = $enddate;
else $enddate = "";

/*DB*/
$dbMainR = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);
$dbMainR = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);
$dbWagers_R = new proc_DB(DB_WAGERS_HOST_R,DB_USER,DB_PWD,DB_WAGERS_NAME);
/*DB*/

// $date = "2019-12-31";
$ER_Data = Array();

if(!check_date($startdate,"Y-m-d")){
    echo echoMsg("0001","TIME ERROR startdate FORMAT");
    exit;
}
if(!check_date($enddate,"Y-m-d")){
    echo echoMsg("0001","TIME ERROR enddate FORMAT");
    exit;
}

if($startdate > $today_date){
    echo echoMsg("0001","TIME ERROR DATE ");
    exit;
}

if($startdate > $enddate){
    echo echoMsg("0001","TIME ERROR DATE ");
    exit;
}

if($action == "getLayerData"){
    $sql_RE = "SELECT * FROM  expectReward_Wagerba_mem WHERE orderdate>='".$startdate."' and  orderdate<='".$enddate."' and status='Y' ";
    $dbWagers_R->query($sql_RE);
    while($dbWagers_R->next_record()){
        $tmpAry = Array();

        $memid = $dbWagers_R->f("uid");
        $tmpAry["id"] = $dbWagers_R->f("id");
        $tmpAry["uid"] = $dbWagers_R->f("uid");
        $tmpAry["report_text"] =json_decode($dbWagers_R->f("report_text"));
        $tmpAry["orderdate"] = $dbWagers_R->f("orderdate");
        $ER_Data[] = $tmpAry;
        /*
        if(empty($ER_Data[$memid]))$ER_Data[$memid] = $tmpAry;
        else{
            $ER_Data[$memid]["report_text"]["ER"] +=$tmpAry["report_text"]["ER"];
            $ER_Data[$memid]["report_text"]["Total"] +=$tmpAry["report_text"]["Total"];
            $ER_Data[$memid]["report_text"]["Wcount"] +=$tmpAry["report_text"]["Wcount"];
            $ER_Data[$memid]["report_text"]["Gold"] +=$tmpAry["report_text"]["Gold"];
            $ER_Data[$memid]["report_text"]["Wingold"] +=$tmpAry["report_text"]["Wingold"];
            
        }
        */
    }
}

$diffDay = round((strtotime($enddate)-strtotime($startdate))/3600/24)+1;

echo echoMsg("0000","success",$ER_Data,$diffDay);





exit;

function check_date($date,$format="Y-m-d") {
    $timestamp = strtotime($date);
    if(!$timestamp) return false;
    if(date($format,$timestamp) == $date) return true;
    return false;
}

function echoMsg($code,$msg="",$data=Array(),$day=1){
    $req = Array();
    $req["code"] = $code;
    $req["msg"] = $msg;
    $req["data"] = $data;
    $req["day"] = $day;

    return json_encode($req);
}

?>