
var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;

var div_newModal;//新增的modal
var div_modifyModal;//修改的modal
var div_testModal;//測試的modal
var table_div;//顯示div

var nowDomainData;
var nowServerData;
var nowModifyId;
var resultList;


var useIframe = false;
var maxTryTimes = 2;

var sock;
var cmd;

var retrySocketTimeout = 0;
function init() {
	div_newModal = util.getSpan(document, "newDomainModal");
	btn_newModal_submit = util.getSpan(document, "newModal_submit");
	btn_newModal_cancle = util.getSpan(document, "newModal_cancle");
	btn_newModal_selectLevel = util.getSpan(document, "addModalLevelTypeSelect");
	btn_newModal_selectPID = util.getSpan(document, "addModalPidSelect");
	listenEvt.addOnClick("newModal_submit", btn_newModal_submit, this, null);
	listenEvt.addOnClick("closeNewDomainModal", btn_newModal_cancle, this, null);
	listenEvt.addOnClick("closeNewDomainModal", btn_newModal_cancle, this, null);
	listenEvt.addSelectOnChange("newModal_selectLevel", btn_newModal_selectLevel, this, null);
	listenEvt.addSelectOnChange("newModal_selectPID", btn_newModal_selectPID, this, null);
	div_modifyModal = util.getSpan(document, "modifyDomainModal");
	btn_modifyModal_submit = util.getSpan(document, "modifyModal_submit");
	btn_modifyModal_cancle = util.getSpan(document, "modifyModal_cancle");
	listenEvt.addOnClick("modifyModal_submit", btn_modifyModal_submit, this, null);
	listenEvt.addOnClick("closeModifyDomainModal", btn_modifyModal_cancle, this, null);

	div_testModal = util.getSpan(document, "testModal");
	btn_testModal_submit = util.getSpan(document, "testModal_submit");
	btn_testModal_cancle = util.getSpan(document, "testModal_cancle");
	listenEvt.addOnClick("testModal_submit", btn_testModal_submit, this, null);
	listenEvt.addOnClick("testModal_cancle", btn_testModal_cancle, this, null);

	table_div = util.getSpan(document, "table_div");

	var open_button = util.getSpan(document, "open_button");
	listenEvt.addOnClick("open_button", open_button, this, null);
	var Path = "./flexibleIP/getFlexible_ip.php";
	var code = "uid=" + uid;
	util.addPostPHP("showTable", Path, code, this);
}

function getSelectValue(elem){
	var objS = elem;
	return objS.options[objS.selectedIndex].value;
}

function addModalSelectPid(){
	var value = getSelectValue(util.getSpan(document, "addModalPidSelect"));
	var objSelectType = document.getElementById("addModalTypeSelect");
	if(value != "0"){
		var tmpType = getTypeOfId(nowDomainData ,value);
		selectElemValue(objSelectType,tmpType);
	}
}

function listenCenter(eventName, listenData) {
	var Path = "./flexibleIP/getFlexible_ip.php";
	var code = "uid=" + uid;
	if (eventName == "open_button") {//新增按鈕
		div_newModal.className = "modal show";
		table_div.style.display = "";
	} else if (eventName == "newModal_selectLevel") {//選層級
		var value = getSelectValue(util.getSpan(document, "addModalLevelTypeSelect"));
		var objSelectType = document.getElementById("addModalTypeSelect");
		if(value == "Main"){
			util.getSpan(document, "addModalPidTr").style.display = "none";
			objSelectType.disabled=false;
		}else{
			addModalSelectPid();
			util.getSpan(document, "addModalPidTr").style.display = "";
			objSelectType.disabled=true;
		}
	}else if (eventName == "newModal_selectPID") {//選了某個PID
		addModalSelectPid();
	} else if (eventName == "closeNewDomainModal") {//取消新增 回到顯示畫面
		div_newModal.className = "modal";
		table_div.style.display = "";
	}  else if (eventName == "closeModifyDomainModal") {//取消新增 回到顯示畫面
		div_modifyModal.className = "modal";
		table_div.style.display = "";
	} else if (eventName == "newModal_submit") {//確定新增
		div_modifyModal.className = "modal";
		var add_Pid = util.getSpan(document, "addModalPidSelect").value;
		var add_Domain = util.getSpan(document, "addModalDomain").value;
		var add_Note = util.getSpan(document, "addModalNote").value;
		var add_LevelType = util.getSpan(document, "addModalLevelTypeSelect").value;
		var add_Type = util.getSpan(document, "addModalTypeSelect").value;
		var add_Status = util.getSpan(document, "addModalStatusSelect").value;
		code += "&action=newip";
		code += "&add_Pid=" + add_Pid;
		code += "&add_Domain=" + add_Domain;
		code += "&add_LevelType=" + add_LevelType;
		code += "&add_Type=" + add_Type;
		code += "&remark=" + add_Note;
		code += "&add_Status=" + add_Status;
		util.addPostPHP("showTable", Path, code, this);
	} else if (eventName.match("test_btn")) {//測試事件
		if (confirm("確定測試?")) {
			div_testModal.className = "modal show";
			var test_ID = listenData.object;
			createTestModal(nowDomainData, nowServerData, test_ID);
			btn_testModal_submit.className = "btn-disabled";
		} else {
			return;
		}
	} else if (eventName.match("del_btn")) {//刪除事件
		if (confirm("確定刪除?")) {
			var del_ID = listenData.object;
			code += "&action=del";
			code += "&delid=" + del_ID;
			util.addPostPHP("showTable", Path, code, this);
		} else {
			return;
		}
	} else if (eventName.match("modify_btn")) {//更動事件
		div_modifyModal.className = "modal show";
		var modify_ID = listenData.object;
		nowModifyId = modify_ID;
		createModifyModal(nowDomainData, modify_ID);
	}else if(eventName.match("modifyModal_submit")){
		if (confirm("確定變更?")) {
			var modify_ID = nowModifyId;
			// var modify_Pid = "";
			// var modify_LevelType = "";
			var modifyDomain = util.getSpan(document, "modifyModalDomain").value;
			var modifyStatus = util.getSpan(document, "modifyModalStatusSelect").value;
			var modifyNote = util.getSpan(document, "modifyModalNote").value;
			code += "&action=updateIp";
			code += "&modifyId=" + modify_ID;
			// code += "&modifyPid=" + modify_Pid;
			// code += "&modifyLevelType=" + modify_LevelType;
			code += "&status=" + modifyStatus;
			code += "&domain=" + modifyDomain;
			code += "&remark=" + modifyNote;
			util.addPostPHP("showTable", Path, code, this);
		} else {
			return;
		}
	} else if (eventName == "testModal_submit") {//測試完成 回到顯示畫面
		if(btn_testModal_submit.className == "btn-success"){
			div_testModal.className = "modal";
			table_div.style.display = "";
		}
	} else if (eventName == "testModal_cancle") {//取消測試 回到顯示畫面
		clearTimeout(retrySocketTimeout);
		div_testModal.className = "modal";
		table_div.style.display = "";
	} 
	
}
function phpDataCenter(eventName, phpData) {
	nowDomainData = phpData.domainIps;
	nowServerData = phpData.gameRooms;
	console.log(nowDomainData);
	console.log(nowServerData);

	showTable(nowDomainData);
	createModalPidSelector(nowDomainData);
}

function getTypeOfId(domainIpAry, id){
	for (var i = 0; i < domainIpAry.length; i++) {
		if(domainIpAry[i]["id"] == id){
			return domainIpAry[i]["type"];
		}
	}
	return "game";
}

function getTotalInfoOfId(domainIpAry, id){
	for (var i = 0; i < domainIpAry.length; i++) {
		if(domainIpAry[i]["id"] == id){
			return domainIpAry[i];
		}
		var ipList = domainIpAry[i]["ipList"];
		for (var j = 0; j < ipList.length; j++) {
			if(ipList[j]["id"] == id){
				return ipList[j];
			}
		}
	}
	return null;
}

function selectElemValue(objSelectType, targetValue){
	for(var i=0; i<objSelectType.options.length; i++){  
		if(objSelectType.options[i].value == targetValue){  
			objSelectType.options[i].selected = true;  
			break;  
		}  
	}
}

function createTestModal(domainIpAry, gameRoomList, testId){
	var directedObj = getTotalInfoOfId(domainIpAry, testId);
	resultList = new Array();
	if(directedObj.type.match("lobby")){
		var ip = directedObj.domain;
		var port = "9988";
		if(ip.match("cvssp2017.com")){
			var port = "20301";
		}
		var tmpServer = new Object();
		tmpServer["ip"] = ip;
		tmpServer["port"] = port;
		tmpServer["tbid"] = 0;
		tmpServer["server_no"] =1;
		tmpServer["server_id"] = 1;
		tmpServer["name_c"] = "lobby";
		tmpServer["result"] = "N";
		tmpServer["tryTimes"] = maxTryTimes;
		resultList[0] = tmpServer;
	}else if(directedObj.type.match("game")){
		var ip = directedObj.domain;
		for(var i = 0; i < gameRoomList.length; i++){
			var tmpServer = new Object();
			tmpServer["ip"] = ip;
			tmpServer["port"] = gameRoomList[i].port;
			tmpServer["tbid"] = gameRoomList[i].tbid;
			tmpServer["server_no"] = gameRoomList[i].server_no;
			tmpServer["server_id"] = gameRoomList[i].server_id;
			tmpServer["name_c"] = gameRoomList[i].name_c;
			tmpServer["result"] = "N";
			tmpServer["tryTimes"] = maxTryTimes;
			resultList[i] = tmpServer;
		}
	}
	if(!useIframe){
		cmd = new Socket_cmd();
	}
	calculateTestCount(false);
}

function getTestResult(response){
	var arr = response.split(",");
	console.log(response);
	var responseServerId =arr[0];
	for(var i = 0; i< resultList.length; i++){
		if(resultList[i].server_id == responseServerId){
			resultList[i].result = "Y";
		}
	}
	setTimeout("calculateTestCount(false)", 200);
	return;
}

function calculateTestCount(status){
	var total = resultList.length;
	var doneCount = 0;
	for(var i = 0; i< resultList.length; i++){
		if(resultList[i].result == "Y" || (resultList[i].result == "N" && resultList[i].tryTimes == 0)){
			doneCount ++;
		}
	}
	var percentNum  =0;
	if(doneCount == total){
		percentNum = 100;
	}else{
		percentNum = doneCount/ total * 100;
		percentNum = Math.round(percentNum);
	}
	document.getElementById("testModal_progressBar").style.width = percentNum+"%";
	document.getElementById("testModal_progressBar").innerHTML = percentNum+"%";

	var isDone = true;

	for(var i = 0; i< resultList.length; i++){
		if(resultList[i].result == "N" && resultList[i].tryTimes > 0){
			isDone = false;
			console.log("測試"+resultList[i].tbid +" 嘗試次數 "+ (maxTryTimes - resultList[i].tryTimes));
			if(!status){
				resultList[i].tryTimes --;
			}
			if(useIframe){
				var socketFrame = document.getElementById("iframe_Socket");
				socketFrame.src = socketFrame.src ;
				socketFrame.contentWindow.testSocket(resultList[i]["ip"], resultList[i]["port"],resultList[i]["server_id"]);
				break;
			}else{
				if(sock){
					if(sock.ws_open)sock.closeSocket();
					sock = null;
				}
				sock = new Socket();
				sock.connect(resultList[i]["ip"], resultList[i]["port"]);
				retrySocketTimeout = setTimeout("cancleTimeout()", 5000);
				break;
			}
		}
	}

	var tmpStr = "<p class=\"font-weight-normal\">*TEXT*</p>";
	var innerHTMLText = "";
	var oneLine = "";
	var brCount = 0;
	for(var i = 0; i< resultList.length; i++){
		var str = tmpStr;
		if(resultList[i].result == "N" && resultList[i].tryTimes == 0){
			oneLine += resultList[i].name_c+"桌 第"+resultList[i].server_no+"台 fail \t";
		}else if(resultList[i].result == "Y"){
			oneLine += resultList[i].name_c+"桌 第"+resultList[i].server_no+"台 OK \t";
		}
		brCount ++;
		if(brCount > 4){
			brCount = 0;
			oneLine = oneLine + "<br>";
		}
	}
	str = str.replace(/\*TEXT\*/gi, oneLine);
	innerHTMLText += oneLine;

	if(isDone){
		innerHTMLText = "<p class=\"font-weight-normal\">完成</p>"+innerHTMLText;
		btn_testModal_submit.className = "btn-success";
	}
	document.getElementById("showTestResult").innerHTML=innerHTMLText;
	listenEvt.addOnClick("testModal_submit", btn_testModal_submit, this, null);
	
}

function cancleTimeout(status){
	clearTimeout(retrySocketTimeout);
	calculateTestCount(status);
}

function createModifyModal(domainIpAry, modifyId){
	var directedObj = getTotalInfoOfId(domainIpAry, modifyId);

	var tmpLevel = "Slave";
	if(directedObj.pid == "0"){
		tmpLevel = "Main";
		util.getSpan(document, "modifyModalPidTr").style.display = "none";
	}else{
		util.getSpan(document, "modifyModalPidTr").style.display = "";
		var upLevelObj = getTotalInfoOfId(domainIpAry, directedObj.pid);
		var objSelectType = document.getElementById("modifyModalPidSelect");
		selectElemValue(objSelectType, upLevelObj.domain);
		objSelectType.disabled=true;
	}
	util.getSpan(document, "modifyModalDomain").value = directedObj.domain;
	util.getSpan(document, "modifyModalNote").value = directedObj.remark;

	objSelectType = document.getElementById("modifyModalLevelTypeSelect");
	selectElemValue(objSelectType, tmpLevel);
	objSelectType.disabled=true;
	
	objSelectType = document.getElementById("modifyModalTypeSelect");
	selectElemValue(objSelectType, directedObj.type);
	objSelectType.disabled=true;
	
	objSelectType = document.getElementById("modifyModalStatusSelect");
	selectElemValue(objSelectType, directedObj.status);
}

function createModalPidSelector(domainIpAry){
	var tempStr = "<option value='*IP_ID*' *SELECTED*>*DOMAIN*</option>";
	var addModalPidSelector = util.getSpan(document, "addModalPidSelect");
	var modifyModalPidSelector = util.getSpan(document, "modifyModalPidSelect");
	var selectorInnerHTML = "";
	// var selectorInnerHTML = "<option value='0' SELECTED>主類別</option>";
	for (var i = 0; i < domainIpAry.length; i++) {
		var opt = tempStr;
		opt = opt.replace(/\*IP_ID\*/gi, domainIpAry[i]["id"]);
		opt = opt.replace(/\*SELECTED\*/gi, "");
		opt = opt.replace(/\*DOMAIN\*/gi, domainIpAry[i]["domain"]);
		selectorInnerHTML = selectorInnerHTML + opt;	
	}
	addModalPidSelector.innerHTML = selectorInnerHTML;
	modifyModalPidSelector.innerHTML = selectorInnerHTML;
}
function createTableTr(eachIp, num){
	var xmpData = util.getSpan(document, "xmpData").innerHTML;
	var td = xmpData;
	td = td.replace(/\*NUM\*/gi, num);
	td = td.replace(/\*ID\*/gi, eachIp.id);
	td = td.replace(/\*TYPE\*/gi, eachIp.type);
	td = td.replace(/\*DOMAIN\*/gi, eachIp.domain);
	if(eachIp.status =="Y"){
		td = td.replace(/\*STATUS\*/gi, "啟用");
	}else{
		td = td.replace(/\*STATUS\*/gi, "關閉");
	}
	if(eachIp.pid ==0){
		td = td.replace(/\*PID\*/gi, "");
	}else{
		td = td.replace(/\*PID\*/gi, eachIp.pid);
	}
	td = td.replace(/\*EDITOR\*/gi, eachIp.editor);
	td = td.replace(/\*UPDATETIME\*/gi, eachIp.lastUpdateTime);
	td = td.replace(/\*NOTE\*/gi, eachIp.remark);
	td = td.replace(/\*IP_ID\*/gi, eachIp.id);
	return td;
}

function setOnClickForAllIp(ipId){
	var modify_btn = util.getSpan(document, "modify_btn_" + ipId);
	var del_btn = util.getSpan(document, "del_btn_" + ipId);
	var test_btn = util.getSpan(document, "test_btn_" + ipId);
	listenEvt.addOnClick("modify_btn_" + ipId, modify_btn, this, ipId);
	listenEvt.addOnClick("del_btn_" + ipId, del_btn, this, ipId);
	listenEvt.addOnClick("test_btn_" + ipId, test_btn, this, ipId);
}

function showTable(domainIpAry) {//showTable
	closenewDomainModal();
	table_div.style.display = "";
	var xmpheader = util.getSpan(document, "xmpheader").innerHTML;
	var xmpEnd = util.getSpan(document, "xmpEnd").innerHTML;
	var dataStr = "";
	var num = 1;
	for (var i = 0; i < domainIpAry.length; i++) {
		dataStr += createTableTr(domainIpAry[i] ,num);
		num++;
		var ipList = domainIpAry[i]["ipList"];
		for (var j = 0; j < ipList.length; j++) {
			dataStr += createTableTr(ipList[j] ,num);
			num++;
		}
	}
	table_div.innerHTML = xmpheader + dataStr + xmpEnd;

	for (var i = 0; i < domainIpAry.length; i++) {
		setOnClickForAllIp(domainIpAry[i].id);
		var ipList = domainIpAry[i]["ipList"];
		for (var j = 0; j < ipList.length; j++) {
			setOnClickForAllIp(ipList[j].id);
		}
	}
}

function closenewDomainModal(){
	div_newModal.className = "modal";
	div_modifyModal.className = "modal";
}

function Socket_cmd() {
	//遠端命令執行
	var self = this;
	self.Data_proc = function(ComeInData) {
	  var arr = ComeInData.split(",");
	  var code = arr[0];
	  console.log(ComeInData);
	  //連線成功 000,connectSuccess
	  if (code == "000") {
		sock.sendToServer("941,pingRequest");
		return;
	  }
  
	  //註冊成功 942,registerOK,serverId
	  if (code == "942") {
		var responseServerId =arr[2];
		if(sock){
			if(sock.ws_open)sock.closeSocket();
			sock = null;
		}
		for(var i = 0; i< resultList.length; i++){
			if(resultList[i].tbid== 0){
				resultList[i].result = "Y";
			}
			if(resultList[i].server_id == responseServerId){
				resultList[i].result = "Y";
			}
		}
		cancleTimeout(true);
		return;
	  }

	  if (code == "999") {
		if(sock){
			if(sock.ws_open)sock.closeSocket();
			sock = null;
		}
		cancleTimeout(false);
		return;
	}
	}
}