<?php
include ("../../conf/config_admin.php");


if($action=="del"||$action=="newip"||$action=="updateIp"){
	$DB = $db;

}else{
	$DB = $dbr;
}
//====== 執行動作區 ======

if($action=="del"){
	$sql = "SELECT * FROM `flexibleIPList` WHERE `id` ='".$delid."' ;";
	$DB->query($sql);
	$originData = "";
	while($DB->next_record()){
		$originData = "id=".$DB->f("id").",pid=".$DB->f("pid").",domain=".$DB->f("domain").",status=".$DB->f("status").",editor=".$DB->f("editor").",lastUpdateTime=".$DB->f("lastUpdateTime").",remark=".$DB->f("remark").",type=".$DB->f("type");
	}
	$sql = "DELETE FROM `flexibleIPList` WHERE `id` = '".$delid."' ;";
	$DB->query($sql);
	//寫紀錄
	Write_Ctl_Record($MEM_DATA["username"],"ip_list_maintain","func/allowIpList/","M","刪除可替換IP : ".preg_replace("/'/","",$sql)."|初始資料:".$originData,$DB,$_SERVER['REMOTE_ADDR']);

}else if($action=="newip"){
	if($add_LevelType =="Main"){
		$add_Pid = "0";
	}
	$sql = "INSERT INTO flexibleIPList ";
	$sql.=" set id = NULL,pid='".$add_Pid."',";
	$sql.="domain='".$add_Domain."',";
	$sql.="status='".$add_Status."',";
	$sql.="type='".$add_Type."',";
	$sql.="remark='".$remark."',";
	$sql.="editor='".$MEM_DATA['username']."',";
	$sql.="lastUpdateTime=NOW();";
	$DB->query($sql);
	//寫紀錄
	Write_Ctl_Record($MEM_DATA["username"],"ip_list_maintain","func/allowIpList/","M","新增可替換IP : ".preg_replace("/'/","",$sql),$DB,$_SERVER['REMOTE_ADDR']);
}else if($action=="updateIp"){
	$sql = "UPDATE flexibleIPList set ";
	// $sql.="pid='".$pid."',";
	$sql.="domain='".$domain."',";
	$sql.="status='".$status."',";
	$sql.="remark='".$remark."',";
	// $sql.="type='".$ipType."',";
	$sql.="editor='".$MEM_DATA['username']."',";
	$sql.="lastUpdateTime=NOW() ";
	$sql.="WHERE `id`=".$modifyId." ;";
	// echo $sql;
	// exit;
	$DB->query($sql);
	//寫紀錄
	Write_Ctl_Record($MEM_DATA["username"],"ip_list_maintain","func/allowIpList/","M","更新可替換IP : ".preg_replace("/'/","",$sql),$DB,$_SERVER['REMOTE_ADDR']);
}

//====== 執行動作區 ======

//====== 主要資料區 ======

$domainIpAry = Array();
$sql = "SELECT * FROM  `flexibleIPList` WHERE `pid`=0 ORDER BY `id`";
$DB->query($sql);
if($DB->num_rows()> 0){
	while($DB->next_record()){
		$domainInfo = Array();
		$domainInfo["ipList"] = Array();
		$domainInfo["id"] = $DB->f("id");
		$domainInfo["pid"] = $DB->f("pid");
		$domainInfo["domain"] = $DB->f("domain");
		$domainInfo["status"] = $DB->f("status");
		$domainInfo["editor"] = $DB->f("editor");
		$domainInfo["type"] = $DB->f("type");
		$domainInfo["lastUpdateTime"] = $DB->f("lastUpdateTime");
		$domainInfo["remark"] = $DB->f("remark");
		$domainIpAry[]=$domainInfo;
	}
}

for($i=0; $i< count($domainIpAry);$i++){
	$tmpId = $domainIpAry[$i]["id"];
	$sql = "SELECT * FROM  `flexibleIPList` WHERE `pid`=".$tmpId." ORDER BY `id`";
	$DB->query($sql);
	if($DB->num_rows()> 0){
		while($DB->next_record()){
			$ipInfo = Array();
			$ipInfo["id"] = $DB->f("id");
			$ipInfo["pid"] = $DB->f("pid");
			$ipInfo["domain"] = $DB->f("domain");
			$ipInfo["status"] = $DB->f("status");
			$ipInfo["editor"] = $DB->f("editor");
			$ipInfo["type"] = $DB->f("type");
			$ipInfo["lastUpdateTime"] = $DB->f("lastUpdateTime");
			$ipInfo["remark"] = $DB->f("remark");
			$domainIpAry[$i]["ipList"][]=$ipInfo;
		}
	}
}

$gameRoomAry = Array();
$sql = "SELECT * FROM  `BA_lobby` WHERE `tbid`>0 ORDER BY `tbid` asc, `server_no` asc";
$DB->query($sql);
if($DB->num_rows()> 0){
	while($DB->next_record()){
		$gameRoomInfo = Array();
		$gameRoomInfo["id"] = $DB->f("id");
		$gameRoomInfo["tbid"] = $DB->f("tbid");
		$gameRoomInfo["server_id"] = $DB->f("server_id");
		$gameRoomInfo["server_no"] = $DB->f("server_no");
		$gameRoomInfo["name_c"] = $DB->f("name_c");
		$gameRoomInfo["port"] = $DB->f("port");
		$gameRoomAry[]=$gameRoomInfo;
	}
}

$out=Array();
$out["domainIps"] = $domainIpAry;
$out["gameRooms"] = $gameRoomAry;
$DB -> close();
echo json_encode($out);
exit;


?>