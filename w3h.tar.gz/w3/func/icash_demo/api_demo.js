var util = parent.util;
var listenEvt = parent.listenEvt;

var trObjArr = {
	"AGLogin" : ["AGID", "secretKey", "username", "password"],
	"CreateMember" : ["AGID", "secretKey", "token", "memname", "password", "currency"],
	"Deposit" : ["AGID", "secretKey", "token", "memname", "memid", "amount"],
	"Withdraw" : ["AGID", "secretKey", "token", "memname", "memid", "amount"],
	"LaunchGame" : ["AGID", "secretKey", "token", "memname", "memid", "langx", "password", "device", "gameid", "isSSL"],
	// "WagerUrl" : ["AGID", "secretKey", "token", "memname", "memid", "langx", "password", "device", "merchantlogo", "isSSL", "datestart", "dateend", "settle"],
	"ChkMemberBalance" : ["AGID", "secretKey", "token", "memname", "memid"],
	"ShowMember" : ["AGID", "secretKey", "token", "memname", "memid"],
	"ShowAllMembers" : ["AGID", "secretKey", "token", "page"],
	"MemWager" : ["AGID", "secretKey", "token", "memname", "memid", "datestart", "dateend", "settle", "page", "langx"],
	"ALLWager" : ["AGID", "secretKey", "token", "datestart", "dateend", "settle", "page", "langx"],
	"ChkTransInfo" : ["AGID", "secretKey", "token", "memname", "memid", "transidtype", "transid"],
	"GetTransInfo" : ["AGID", "secretKey", "token", "memname", "memid"],
	"MemWagerById" : ["AGID", "secretKey", "token", "memname", "memid", "wagerid", "settle", "page", "langx"],
	"ALLWagerById" : ["AGID", "secretKey", "token", "wagerid", "settle", "page", "langx"],
	"CheckWager" : ["AGID", "secretKey", "token", "wagerid", "settle", "page", "langx"],
	"CheckReport" : ["AGID", "secretKey", "token", "datestart", "dateend", "settle", "page"],
	"MemTrans" : ["AGID", "secretKey", "token", "memname", "memid", "datestart", "dateend", "page"],
	"ALLTrans" : ["AGID", "secretKey", "token", "datestart", "dateend", "page"],
	"GetGameList" : ["AGID", "secretKey", "token", "page", "langx"],
	"KickOutMem" : ["AGID", "secretKey", "token", "memname", "memid"],
	"KickOutAllMem" : ["AGID", "secretKey", "token"],
	"NotifyGPMaintaince" : ["AGID", "secretKey", "token", "datestart", "dateend"],
	"SetGameLogo" : ["AGID", "secretKey", "token", "gameid", "transitionlogo", "gameroomlogo"],
	"GetMemOfflineList" : ["AGID", "secretKey", "token", "lastofflineid"],
	"CreateAgent" : ["AGID", "secretKey", "token", "agid", "agname", "agpassword", "agsecuritykey"],
	"BackStageUrl" : ["AGID", "secretKey", "token", "gameid", "account", "password", "isSSL"],
	"WebsiteSetting" : ["AGID", "secretKey", "token", "notifymemofflineurl", "notifymaintainceurl", "refermemberurl"],
	"ALLAGWager" : ["AGID", "secretKey", "token", "datestart", "dateend", "settle", "page", "langx"],
};

//初始化
function init() {
	listenEvent = new listenEvent();
	phpEvent = new phpEvent();
	viewEvent = new viewEvent();

	{	//戴入畫面
		//按扭
		var xmp_methodBtn = util.getSpan(document, "xmp_methodBtn").innerText;
		var xmp_item_head = util.getSpan(document, "xmp_item_head").innerText;
		var xmp_item_body = util.getSpan(document, "xmp_item_body").innerText;
		var xmp_item_foot = util.getSpan(document, "xmp_item_foot").innerText;
		var outStr;

		outStr = ""
		for (var method in trObjArr) {
			outStr += xmp_methodBtn.replace(/\*METHOD\*/g, method);
		}
		util.getSpan(document, "method_table").innerHTML = outStr;

		//選項
		var itemArr = new Array();
		for (var method in trObjArr) trObjArr[method].forEach((item) => { if (!util.in_array(item, itemArr)) itemArr.push(item); });

		outStr = "";
		outStr += xmp_item_head;
		itemArr.forEach((item) => { outStr += xmp_item_body.replace(/\*ITEM\*/g, item); });
		outStr += xmp_item_foot;
		util.getSpan(document, "item_table").innerHTML = outStr;

		//預設值
		util.getSpan(document, "AGID").value = "101";
		util.getSpan(document, "secretKey").value = "0LRW7RzNc0KoKpB4";
		util.getSpan(document, "username").value = "sssI";
		util.getSpan(document, "password").value = "a1234";
		util.getSpan(document, "langx").value = "zh-tw";
		util.getSpan(document, "page").value = "1";
		util.getSpan(document, "device").value = "PC";
		util.getSpan(document, "gameid").value = "2";
		util.getSpan(document, "isSSL").value = "N";
		util.getSpan(document, "datestart").value = "2019-06-01 00:00:00";
		util.getSpan(document, "dateend").value = "2019-06-30 00:00:00";
		util.getSpan(document, "settle").value = "0";
		util.getSpan(document, "memid").value = "20";
		util.getSpan(document, "wagerid").value = "0";
	}

	listenEvent.addStaticListen();

	doSet();
}

//執行動作
function doSet() {
	viewEvent.showItem("AGLogin");
}

//監聽事件
function listenEvent() {
	var self = this;

	//建立監聽事件(靜態)
	self.addStaticListen = function () {
		var buttonArr = document.getElementsByName("button");

		buttonArr.forEach((button) => { listenEvt.addOnClick(button.id, button, this, button.getAttribute("data-func")); });
	}

	//監聽事件回應
	self.listenCenter = function (eventStr, obj) {
		console.log(eventStr, obj.object || "");

		var tmp = eventStr.split("_");
		var eventName = tmp[0];
		var eventType = tmp[1];

		if (eventName == "method") {
			eventType = eventStr.replace("method_", "");

			viewEvent.showItem(eventType);
			return;
		}

		if (eventName == "demo") {
			phpEvent.actDemo(obj.div.getAttribute("data-action"));

			return;
		}
	}
}

//PHP事件
function phpEvent() {
	var self = this;
	var path = "../../../func/icash_demo/api_demo.php";

	self.actDemo = function(method) {
		var parm = "action=" + method;
		trObjArr[method].forEach((item) => {
			parm += "&" + item + "=" + util.getSpan(document, item).value;
		});

		showMsg("執行 " + method + " 中，請稍等…");

		util.addPostPHP(method, path, parm, this);
	}

	self.phpDataCenter = function (eventName, obj) {
		console.log(eventName, obj);

		if (eventName == "AGLogin") {
			util.getSpan(document, "AGID").value = obj["agid"];
			util.getSpan(document, "token").value = obj["token"];
		} else if (eventName == "CreateMember") {
			if (obj["userdata"]) {
				util.getSpan(document, "memname").value = obj["userdata"]["username"];
				util.getSpan(document, "memid").value = obj["userdata"]["userid"];
			}
		} else if (eventName == "LaunchGame") {
			window.open(obj["url"],"_blank");
		}

		showMsg(JSON.stringify(obj));
	}
}

//畫面事件
function viewEvent() {
	var self = this;

	self.showItem = function (eventType) {
		var trArr = document.getElementsByName("tr");
		trArr.forEach((tr) => { tr.style.display = "none"; } );
		trObjArr[eventType].forEach((item) => {
			util.getSpan(document, "tr_" + item).style.display = "";
		});

		util.getSpan(document, "demo").value = eventType;
		util.getSpan(document, "demo").setAttribute("data-action", eventType);
	}
}

function showMsg(motion) {
	var str = "";

	if (!motion || motion == "") {
		return;
	} else if (motion == "") {

	} else {
		str = motion;
	}

	if (str != "") {
		document.getElementById("showdata").innerText = str;
	}
}