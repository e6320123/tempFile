<?php
include "../../conf/conf_ctl.php";

if ($action == "") {
	include "api_demo.html";
} else {
	$domain = $_SERVER['SERVER_NAME'];
	// $url = "http://iisc566-ctl.cvssp2017.com/w3_new/app/control_API/api_doaction.php";
	if(preg_match("/ctliiti566/",$domain)){
		$url = "http://agiiti566.cvssp2017.com/app/control_API/agents/api_doaction.php";
	}else if(preg_match("/ctlti566/",$domain)){
		$url = "http://agti566.cvssp2017.com/app/control_API/agents/api_doaction.php";
	}else{
		$url = "http://ag.iabc365.com/app/control_API/agents/api_doaction.php";
	}

	{	//傳遞資料
		$no_mem_fun_ary = Array("CheckWager", "CheckReport", "GetGameList", "NotifyGPMaintaince", "SetGameLogo", "GetMemOfflineList", "CreateAgent", "BackStageUrl", "WebsiteSetting", "ALLAGWager");

		$datetime = new DateTime();
		$timestamp = $datetime->getTimestamp();
		$remoteip = $_SERVER["REMOTE_ADDR"];
		$provider = "TI";

		$obj = Array();
		$obj["Method"] = $action;
		$obj["AGID"] = "" . $AGID;
		$obj["Vendor"] = "iCash";
		$request = Array();
		$request["method"] = $action;
		$request["provider"] = "" . $provider;
		$request["remoteip"] = "" . $remoteip;
		$request["timestamp"] = "" . $timestamp;
		
		if ($action != "AGLogin") {
			$request["token"] = $token;

			if (!preg_match("/all/i", $action) && !in_array($action, $no_mem_fun_ary)) {
				if (isset($memid)) $request["memid"] = $memid;
				if (isset($memname)) $request["memname"] = $memname;
				if (empty($memid) && empty($memname)) {
					$ret = Array();
					$ret["respcode"] = "0001";
					$ret["respmsg"] = "參數錯誤 : 會員帳號";
					echo json_encode($ret);
					exit;
				}
			}
		}
	}

	if ($action == "AGLogin") {
		$request["username"] = $username;
		$request["password"] = $password;
	} else if ($action == "CreateMember") {
		if (empty($currency)) $currency = "RMB";
		$request["password"] = $password;
		$request["currency"] = $currency;
	} else if ($action == "Deposit" || $action == "Withdraw") {
		$request["amount"] = $amount;
		$request["payno"] = $payno;
	} else if ($action == "LaunchGame") {
		$request["password"] = $password;
		$request["langx"] = $langx;
		$request["device"] = $device;
		$request["gameid"] = $gameid;
		$request["isSSL"] = $isSSL;
	/* } else if ($action == "WagerUrl") {
		$request["password"] = $password;
		$request["langx"] = $langx;
		$request["device"] = $device;
		$request["merchantlogo"] = $merchantlogo;
		$request["datestart"] = $datestart;
		$request["dateend"] = $dateend;
		$request["settle"] = $settle;
		$request["isSSL"] = $isSSL; */
	} else if ($action == "ChkMemberBalance" || $action == "ShowMember" || $action == "GetTransInfo" || $action == "KickOutMem" || $action == "KickOutAllMem") {
	} else if ($action == "ShowAllMembers") {
		$request["page"] = $page;
	} else if ($action == "MemWager" || $action == "ALLWager") {
		$request["langx"] = $langx;
		$request["datestart"] = $datestart;
		$request["dateend"] = $dateend;
		$request["settle"] = $settle;
		$request["page"] = $page;
	} else if ($action == "ChkTransInfo") {
		$request["transidtype"] = $transidtype;
		$request["transid"] = $transid;
	} else if ($action == "MemWagerById" || $action == "ALLWagerById" || $action == "CheckWager") {
		$request["langx"] = $langx;
		$request["wagerid"] = $wagerid;
		$request["settle"] = $settle;
		$request["page"] = $page;
	} else if ($action == "CheckReport") {
		$request["datestart"] = $datestart;
		$request["dateend"] = $dateend;
		$request["settle"] = $settle;
		$request["page"] = $page;
	} else if ($action == "MemTrans" || $action == "ALLTrans") {
		$request["datestart"] = $datestart;
		$request["dateend"] = $dateend;
		$request["page"] = $page;
	} else if ($action == "LaunchDemo") {
		$request["langx"] = $langx;
		$request["device"] = $device;
		$request["gameid"] = $gameid;
		$request["isSSL"] = $isSSL;
	} else if ($action == "GetGameList") {
		$request["langx"] = $langx;
		$request["page"] = $page;
	} else if ($action == "NotifyGPMaintaince") {
		$request["datestart"] = $datestart;
		$request["dateend"] = $dateend;
	} else if ($action == "SetGameLogo") {
		$request["gameid"] = $gameid;
		$request["transitionlogo"] = $transitionlogo;
		$request["gameroomlogo"] = $gameroomlogo;
	} else if ($action == "GetMemOfflineList") {
		$request["lastofflineid"] = $lastofflineid;
	} else if ($action == "CreateAgent") {
		$request["agid"] = $agid;
		$request["agname"] = $agname;
		$request["agpassword"] = $agpassword;
		$request["agsecuritykey"] = $agsecuritykey;
	} else if ($action == "BackStageUrl") {
		$request["gameid"] = $gameid;
		$request["account"] = $account;
		$request["password"] = $password;
	} else if ($action == "WebsiteSetting") {
		$request["notifymemofflineurl"] = $notifymemofflineurl;
		$request["notifymaintainceurl"] = $notifymaintainceurl;
		$request["refermemberurl"] = $refermemberurl;
	} else {
		errorExit("0014");
	}

	// if (count($request) > 5) {
		$obj["Request"] = AES_encrypt(json_encode($request), $secretKey);

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, Array('Content-Type: application/json'));	// 設置HTTP頭
		curl_setopt($ch, CURLOPT_POST, true);											// 啟用POST
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($obj));						// POST資料
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);									// 設定可傳
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);								// 驗證伺服器憑證
		$server_output = curl_exec($ch);

		if (curl_errno($ch)) print curl_error($ch);	// 列印錯誤訊息
		curl_close($ch);

		echo AES_decrypt($server_output, $secretKey);
	// }
}

//php mcrypt extension 必須加裝套件
function AES_encrypt($data, $secretKey, $app_cc_aes_iv = "") {
	$padding = 16 - (strlen($data) % 16);
	$data .= str_repeat(chr($padding), $padding);
	$encrypt = mcrypt_encrypt(MCRYPT_RIJNDAEL_128, $secretKey, $data, MCRYPT_MODE_ECB, $app_cc_aes_iv);
	$encrypt_text = base64_encode($encrypt);
	return $encrypt_text;
}

function AES_decrypt($data, $secretKey, $app_cc_aes_iv = "") {
	$encrypt = base64_decode($data);
	$data = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, $secretKey, $encrypt, MCRYPT_MODE_ECB, $app_cc_aes_iv);
	$padding = ord($data[strlen($data) - 1]);
	$decrypt_text = substr($data, 0, -$padding);
	return $decrypt_text;
}
?>