var funcAry = new Array();
// var mid = top.mid;
// var uid = top.uid;
// var langx = top.langx;
var util = null;				//共用的工具 可以去 /js/lib/util.js 看
var listenEvt = null;

// var gtypeAry = top.gtypeSw.split("|");
var navStatus = true;

function init() {
	/*
		setFuncAry("下單裝置數量與金額","/func/device-Count.php");
		setFuncAry("修改會員Ping值","/func/ping-set.php");
		setFuncAry("使用者設備資訊","/func/checkUser.php");
		setFuncAry("設定休盤日期","/func/set_StopGameDate.php");
	*/
	listenEvt = new ListenEvent();
	util = new Util();
	setFuncAry("/allowIpList/chk_ip", "三端IP允許列表");
	setFuncAry("/allowIpList/black_ip", "黑名單列表");
	setFuncAry("/allowIpList/chkipSW", "IP 白名單/阻擋區域 開關");
	setFuncAry("/api_rec/api_rec", "API 紀錄查詢");
	setFuncAry("/api_rec/api_add", "API 新增代理");
	setFuncAry("/api_rec/api_demo", "API Demo");
	setFuncAry("/icash_demo/api_demo", "iCash Demo");
	setFuncAry("/server_log/server_log_tab.php", "Server_Log");
	setFuncAry("/table_show/show_table", "會員端顯示桌子");
	setFuncAry("/flexibleIP/flexible_ip", "選擇Domain/IP");
	setFuncAry("/adjustVideo/adjustVideo", "頻道調整");
	setFuncAry("/adjustVideo/adjustVideoServer", "頻道內部線路調整");
	setFuncAry("/timezoneReport/timezoneReport", "結轉靜態報表");
	setFuncAry("pingStatus/pingStatus.php", "pingStatus");
	setFuncAry("/allRoad/allRoad", "全部珠路顯示");
	setFuncAry("/allResultCmp/allResultCmp", "全部結果比對");
	setFuncAry("/allResultDow/allResultDow", "全部結果下載");
	setFuncAry("/allHost/allHost", "全部線路控制");
	setFuncAry("videoTest/videoTestNew.php", "線路測試");
	setFuncAry("winloss/winloss.php", "成數");
	setFuncAry("show_region/show_region.php", "人數地區分析");
	setFuncAry("expectReward/expectReward.php", "下注期望值");
        setFuncAry("tiData/tiData", "Ti Data");
	show();
	openNav();
}

//將func裝進Array
//funcText= 中文敘述,funcName= 檔名
function setFuncAry(funcName, funcText) {
	funcAry[funcName] = new Array();
	funcAry[funcName] = funcText;
}

function show() {
	var menu = document.getElementById("mySidenav");
	var hrefXMP = document.getElementById("hrefXMP").innerHTML;
	var tmp = "";
	menu.innerHTML = "";

	//取得func 檔名
	//var funcNameAry = Object.keys(funcAry);
	var funcNameAry = new Array();
	for (key in funcAry) {
		if (Object.prototype.hasOwnProperty.call(funcAry, key)) {
			if (key == "MWGameList") {
				if (util.array_indexOf("MW", gtypeAry, true) > -1) {
					continue;
				}
			}
			funcNameAry.push(key);
		}
	}

	var len = funcNameAry.length;
	for (var i = 0; i < len; i++) {
		tmp = hrefXMP;
		var funcName = funcNameAry[i];
		var funcText = funcAry[funcName];
		tmp = tmp.replace("*FUNCNAME*", funcName);
		tmp = tmp.replace("*FUNCTEXT*", (i + 1) + "." + funcText);
		menu.innerHTML += tmp;
	}

	//監聽
	for (var i = 0; i < len; i++) {
		var funcName = funcNameAry[i];
		var funcText = funcAry[funcName];
		var func_menu = document.getElementById(funcName);
		//set menu style
		// set_MenuStyle(func_menu);
		//set btn_mouse action
		// listenEvt.addMouseOver("btn_MouseOver_"+funcName,func_menu,this,null);
		// listenEvt.addMouseOut("btn_MouseOut_"+funcName,func_menu,this,null);
		listenEvt.addOnClick("set_iframe_" + funcName, func_menu, this, funcName);
	}
}

function listenCenter(eventName, listenData) {
	var div = listenData.div;      //btn
	var obj = listenData.object;   //ojb
	var e = listenData.e;          //act
	//parent.changeMain("internal","confSetList","&file="+eventName);
	if (eventName.indexOf("btn_MouseOver_") != -1) {
		div.style.color = "blue";
		return;
	}

	if (eventName.indexOf("btn_MouseOut_") != -1) {
		div.style.color = "black";
		return;
	}

	if (eventName.indexOf("set_iframe_") != -1) {
		closeNav();
		show();
		var bodyframe = document.getElementsByTagName("iframe");
		var funcName = obj;
		if (funcName.indexOf(".php") != -1) {
			var aPath = "./" + funcName + "?uid=" + uid + "&logintype=" + top.logintype;
			if (funcName == "/server_log/server_log_tab.php") {
				window.open(aPath, "server_log");
			} else if (funcName.indexOf("pingStatus.php") > -1) {
				window.open(aPath, "pingStatus");
			}
		} else {
			var aPath = "./confSetList.php?uid=" + uid + "&logintype=" + top.logintype + "&file=" + funcName;
		}
		var navbarDiv = document.getElementById("navbarName");
		var nameStr = document.getElementById(funcName);

		navbarDiv.innerHTML = "☰ " + nameStr.innerHTML;
		nameStr.innerHTML = nameStr.innerHTML.fontcolor("red");
		bodyframe = bodyframe[0];
		document.getElementById(navbarName)
		bodyframe.style.display = "";
		bodyframe.src = aPath;
		return;
	}
}

function set_MenuStyle(func_menu) {
	func_menu.style.margin = "0px 3px";
	func_menu.style.borderStyle = "solid";
	func_menu.style.borderColor = "black";
	func_menu.style.backgroundColor = "white";
	func_menu.style.fontSize = "20px";
}
function openNav() {
	navStatus = true;
	document.getElementById("mySidenav").style.width = "250px";
	document.getElementById("main").style.marginLeft = "250px";
}

/* Set the width of the side navigation to 0 and the left margin of the page content to 0 */
function closeNav() {
	navStatus = false;
	document.getElementById("mySidenav").style.width = "0";
	document.getElementById("main").style.marginLeft = "0";
}

function navActive() {
	if (navStatus) closeNav();
	else openNav();
}
function reloadpage() {
	var bodyframe = document.getElementById("myiframe");
	var tmp_src = bodyframe.src;
	bodyframe.src = '';
	bodyframe.src = tmp_src;
}

function initFontColor() {
	var menu = document.getElementById("mySidenav");
	var hrefXMP = document.getElementById("hrefXMP").innerHTML;
	var tmp = "";
	menu.innerHTML = "";

	//取得func 檔名
	//var funcNameAry = Object.keys(funcAry);
	var funcNameAry = new Array();
	for (key in funcAry) {
		if (Object.prototype.hasOwnProperty.call(funcAry, key)) {
			if (key == "MWGameList") {
				if (util.array_indexOf("MW", gtypeAry, true) > -1) {
					continue;
				}
			}
			funcNameAry.push(key);
		}
	}

	var len = funcNameAry.length;
	for (var i = 0; i < len; i++) {
		tmp = hrefXMP;
		var funcName = funcNameAry[i];
		var funcText = funcAry[funcName];
		tmp = tmp.replace("*FUNCNAME*", funcName);
		tmp = tmp.replace("*FUNCTEXT*", funcText);
		menu.innerHTML += tmp;
	}
}
