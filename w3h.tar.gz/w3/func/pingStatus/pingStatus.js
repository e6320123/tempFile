var util = new Util();
var listenEvt = new ListenEvent();

function init() {
	listenEvent = new listenEvent();
	phpEvent = new phpEvent();
	threadEvent = new threadEvent();
	viewEvent = new viewEvent();

	doSet();
}

function doSet() {
	listenEvent.addListenEvent();
	phpEvent.getData();
	threadEvent.startReloadThread();
}

//監聽事件
function listenEvent() {
	var self = this;

	self.addListenEvent = function () {
		var buttonArr = document.getElementsByName("button");
		var tableArr = document.getElementsByName("table");

		for (var i = 0; i < buttonArr.length; i++) listenEvt.addOnClick(buttonArr[i].id, buttonArr[i], this, buttonArr[i].getAttribute("data-func"));
		for (var i = 0; i < tableArr.length; i++) listenEvt.addOnClick(tableArr[i].id, tableArr[i], this, "table");
	}

	//監聽事件回應
	self.listenCenter = function (eventStr, obj) {
		console.log(eventStr, obj.object);

		var tmp = eventStr.split(",");
		var eventName = tmp[0];
		var eventType = tmp[1];

		if (eventStr == "reload") {
			threadEvent.reload();
		}

		//查看/隱藏詳細資料
		if (obj.object == "table") {
			var tableArr = document.getElementsByName("table");
			for (var i = 0; i < tableArr.length; i++) {
				tableArr[i].className = tableArr[i].className.replace(" active", "");
			}

			if (eventStr == "detail") {
				if (obj.div.className == "navbtn hide") {
					viewEvent.setDetail(false);
				} else {
					phpEvent.getDataList();
				}
			} else {
				if (obj.div.className.indexOf("active") > -1) {
					viewEvent.setDetail(false);
				} else {
					obj.div.className = obj.div.className + " active";
					phpEvent.getDataList(eventStr);
				}
			}
		}
	}
}

//PHP事件
function phpEvent() {
	var self = this;
	var aPath = "/func/pingStatus/pingStatus.php";
	var parm = "&uid=" + uid;

	//取得資料
	self.getData = function () {
		var tmp_parm = parm;
		tmp_parm += "&action=getData";

		util.addPostPHP("getData", aPath, tmp_parm, this);
	}

	//取得列表
	self.getDataList = function (item) {
		var tmp_parm = parm;
		tmp_parm += "&action=getDataList";
		tmp_parm += "&item=" + (item || "");

		util.addPostPHP("getDataList", aPath, tmp_parm, this);
	}

	//PHP事件回應
	self.phpDataCenter = function (eventName, obj) {
		if (eventName == "getData") {
			viewEvent.setStatus(obj);
		}

		if (eventName == "getDataList") {
			var detailObj = util.getSpan(document, "detail_box");

			detailObj.value = "";
			for (var key in obj["pingData"]) {
				detailObj.value += obj["pingData"][key]["content"] + "\n";
			}

			viewEvent.setDetail(true);
		}
	}
}

//非同步事件
function threadEvent() {
	var self = this;

	var reload_interval = 60;
	var reload_time = reload_interval;
	var reload_thread = null;

	self.startReloadThread = function () {
		reload_thread = setInterval(() => {
			util.getSpan(document, "reload_time").innerText = (reload_time < 10) ? "0" + reload_time : reload_time;

			if (reload_time == 0) {
				reload_time = reload_interval;
				phpEvent.getData();
			}

			reload_time--;
		}, 1000);
	}

	self.reload = function () {
		reload_time = reload_interval;
		phpEvent.getData();
	}
}

//畫面事件
function viewEvent() {
	var self = this;

	//更新燈號
	self.setStatus = function (obj) {
		var pingData = obj["pingData"];

		for (var item in pingData) {
			if (itemObj = util.getSpan(document, item)) {
				var datalist = pingData[item];
				var status = true;

				datalist.forEach((data) => {
					status = (["content"].indexOf("is alive") > -1);
				});

				if (status) {
					itemObj.className = itemObj.className.replace(" error", "");
				} else {
					if (itemObj.className.indexOf(" error") > -1) {
						continue;
					} else if (itemObj.className.indexOf(" active") > -1) {
						itemObj.className = itemObj.className.replace(" active", " error active");
					} else {
						itemObj.className = itemObj.className + " error";
					}
				}
			}
		}

		var tableArr = document.getElementsByName("table");
		for (var i = 0; i < tableArr.length; i++) {
			if (pingData[tableArr[i].id] == null) tableArr[i].className = tableArr[i].className.replace(" error", "");
		}
	}

	//開關detail
	self.setDetail = function (open) {
		var detailObj = util.getSpan(document, "detail_box");

		if (open) {
			util.getSpan(document, "detail").innerText = "隱藏資料";
			util.getSpan(document, "detail").className = "navbtn hide";
			detailObj.style.display = "";
		} else {
			util.getSpan(document, "detail").innerText = "詳細資料";
			util.getSpan(document, "detail").className = "navbtn show";
			detailObj.style.display = "none";
		}
	}
}