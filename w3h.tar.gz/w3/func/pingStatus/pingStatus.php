<?php
include $_SERVER['DOCUMENT_ROOT']."/conf/config_admin.php";
// include $_SERVER['DOCUMENT_ROOT']."/conf/config_nouid.php";

if ($action == "") {
    include "pingStatus.html";
} else if ($action == "getData") {
    $dbr = new proc_DB(DB_HOST_R, DB_USER_R, DB_PWD_R, DB_NAME);

    $valid_minute = 10; //有效資料時間(分鐘)
    $today = getdate();
    $validtime = gmdate("Y-m-d H:i:s", mktime($today["hours"] + 8, $today["minutes"] - $valid_minute, $today["seconds"], $today["mon"], $today["mday"], $today["year"]));

    $sql = "SELECT * FROM pingfail_record";
    $sql .= " WHERE msgtime >= '".$validtime."'";
    $sql .= " AND (method LIKE '%MOXA%' OR method LIKE '%VIDEO%')";
    $sql .= " ORDER BY id ASC";
    $dbr->query($sql);

    $pingData = Array();
    while ($dbr->next_record()) {
        $item = $dbr->f("group") . "_" . $dbr->f("table_num") . "_" . $dbr->f("table_name");
        if (strpos($dbr->f("method"), "MOXA") > -1) $item .= "_M";
        if (strpos($dbr->f("method"), "VIDEO") > -1) $item .= "_V";
        $pingData[$item][] = $dbr->record;
    }

    $dbr->close();

    $out["pingData"] = $pingData;
    echo json_encode($out);
} else if ($action == "getDataList") {
    $dbr = new proc_DB(DB_HOST_R, DB_USER_R, DB_PWD_R, DB_NAME);

    $sql = "SELECT * FROM pingfail_record";
    if ($item != "") {
        $tmp = explode("_", $item);
        $sql .= " WHERE 1";
        $sql .= " AND `group` = '" . $tmp[0] . "'";
        $sql .= " AND `table_num` = '" . $tmp[1] . "'";
        $sql .= " AND `table_name` = '" . $tmp[2] . "'";
        if (count($tmp) > 3) {
            if ($tmp[3] == "M") {
                $sql .= " AND `method` LIKE '%MOXA%'";
            } else if ($tmp[3] == "V") {
                $sql .= " AND `method` LIKE '%VIDEO%'";
            }
        } else {
            $sql .= " AND (method LIKE '%MOXA%' OR method LIKE '%VIDEO%')";
        }
    }
    $sql .= " ORDER BY id DESC";
    $dbr->query($sql);

    $pingData = Array();
    while ($dbr->next_record()) {
        $pingData[] = $dbr->record;
    }

    $dbr->close();

    $out["pingData"] = $pingData;
    echo json_encode($out);
}
?>