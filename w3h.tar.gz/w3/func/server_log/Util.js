function Util() {
    var self = this;
    var retryCount = 0;
    var xmlRequestAry = new Array();

    //列印訊息
    self.log = function (msg) {
        if (window.console) console.log(msg);
    }

    //隱藏元件
    self.setHidden = function (el, oks) {
        if (el == null) return;
        el.style.display = (oks) ? "none" : "";
    }

    //取得元件
    self.getSpan = function (doc, Name) {
        var span = doc.getElementById(Name);
        return (span == null) ? null : span;
    }

    //取得元件(模糊搜尋)
    self.getSameNameSpan = function (template, SameName) {
        var list = new Array();
        if (template.children.length > 0) {
            var i = template.children.length;
            while (i-- > 0) {
                var tmp = template.children[i].id;
                if (tmp.indexOf(SameName) > -1) {
                    list.push(template.children[i]);
                } else {
                    var tmp = self.getSameNameSpan(template.children[i], SameName);
                    list = list.concat(tmp);
                }
            }
        }
        return list;
    }

    //設定格式
    self.setClassName = function (div, classStr) {
        if (div.className) {
            div.className = classStr;
        } else {
            div.setAttribute("class", classStr);
        }
    }

    //向PHP呼叫資料
    self.addPostPHP = function (eventName, url, parame, delegate) {
        var timer = null;
        var smstime = new Date().getTime();
        var tmp = "smstime=" + smstime;
        if (top.phpallms) tmp += "&allms=" + top.phpallms;
        if (top.logintype) tmp += "&logintype=" + top.logintype;
        parame = tmp + "&" + parame;
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                if (eventName == "betSubmit") {
                    clearTimeout(timer);
                    retryCount = 0;
                }
                var emstime = new Date().getTime();
                top.phpallms = emstime * 1 - smstime * 1;
                var phpData = self.strToObj(xmlhttp.responseText);
                if (delegate.phpDataCenter) delegate.phpDataCenter(eventName, phpData);
            } else {

            }
        };

        xmlhttp.open("POST", url, true);
        xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xmlhttp.send(parame);
    }

    //選舉區塊內容
    self.selectText = function (div) {
        div.focus();
        if (div.type == "text") div.setSelectionRange(0, div.size);
    }

    self.cleanXMLRequest = function () {
        for (var key in xmlRequestAry) {
            self.cleanKeyXMLRequest(key);
        }
        xmlRequestAry = new Array();
    }

    self.cleanKeyXMLRequest = function (key) {
        var xmlhttp = xmlRequestAry[key];
        xmlhttp.abort();
        xmlhttp.onreadystatechange = null;
        xmlhttp = null;
    }

    self.strToObj = function (str) {
        str = str.trim();
        if (str.match("window.open")) {
            str = str.replace("<script>", "");
            str = str.replace("</script>", "");
        }

        try {
            return (new Function("return " + str + ";"))();
        } catch (e) {
            return str;
        }
    }

    //回傳整數
    self.moneyCheck = function (val) {
        var ret = "";
        if (val == 0) return ret;

        var patt1 = new RegExp(/[^0-9]/g);
        var t = patt1.test(val);
        if (t) val = val.replace(/[^0-9]/g, '');
        return val;
    }

    self.merge_object = function (obj1, obj2) {
        var obj3 = {};
        for (var attrname in obj1) { obj3[attrname] = obj1[attrname]; }
        for (var attrname in obj2) { obj3[attrname] = obj2[attrname]; }
        return obj3;
    }

    self.in_array = function (txt, ary) {
        for (var i = 0; i < ary.length; i++) {
            if (ary[i] == txt) return true;
        }
        return false;
    }

    //by key
    self.in_array_key = function (txt, ary) {
        for (var key in ary) {
            if (ary[key] == txt) return true;
        }
        return false;
    }

    self.array_indexOf = function (txt, ary, isMatch) {
        for (var i = 0; i < ary.length; i++) {
            if (isMatch) {
                if (ary[i] == txt) return i;
            } else {
                if (ary[i].indexOf(txt) != -1) return i;
            }
        }
        return -1;
    }

    self.addZero = function (val, b) {
        val = val.toString();
        if (val == "" || b == "") return val;

        val += "";
        if (b == 0) {
            var index = val.indexOf(".");
            if (index == -1) return val;
            return val.replace(".", "");
        }

        var str = "";
        var index = val.indexOf(".");

        if (index == -1) {
            val += ".";
            index = val.length - 1;
        }

        var r = b * 1 - (val.length - index - 1);
        for (i = 0; i < r; i++) str += "0";
        str = val + str;

        return str;
    }

    self.formatFloat = function (num, pos) {
        var size = Math.pow(10, pos);
        var ok = self.accDiv(Math.round(self.accMul(num, size)), size);
        var ret = self.addZero(ok, pos);

        return ret;
    }

    self.formatFloatF = function (num, pos) {
        var size = Math.pow(10, pos);
        var ok;
        if (num > 0) {
            ok = self.accDiv(Math.floor(self.accMul(num, size)), size);
        } else {
            ok = self.accDiv(Math.ceil(self.accMul(num, size)), size);
        }
        var ret = self.addZero(ok, pos);

        return ret;
    }

    self.accAdd = function (arg1, arg2) {
        var r1, r2, m, c;
        try { r1 = arg1.toString().split(".")[1].length } catch (e) { r1 = 0 }
        try { r2 = arg2.toString().split(".")[1].length } catch (e) { r2 = 0 }
        c = Math.abs(r1 - r2);
        m = Math.pow(10, Math.max(r1, r2))
        if (c > 0) {
            var cm = Math.pow(10, c);
            if (r1 > r2) {
                arg1 = Number(arg1.toString().replace(".", ""));
                arg2 = Number(arg2.toString().replace(".", "")) * cm;
            } else {
                arg1 = Number(arg1.toString().replace(".", "")) * cm;
                arg2 = Number(arg2.toString().replace(".", ""));
            }
        } else {
            arg1 = Number(arg1.toString().replace(".", ""));
            arg2 = Number(arg2.toString().replace(".", ""));
        }
        return (arg1 + arg2) / m
    }

    self.accSub = function (arg1, arg2) {
        var r1, r2, m, n;
        try { r1 = arg1.toString().split(".")[1].length } catch (e) { r1 = 0 }
        try { r2 = arg2.toString().split(".")[1].length } catch (e) { r2 = 0 }
        m = Math.pow(10, Math.max(r1, r2));
        n = (r1 >= r2) ? r1 : r2;
        return ((arg1 * m - arg2 * m) / m).toFixed(n);
    }

    self.accMul = function (arg1, arg2) {
        var m = 0, s1 = arg1.toString(), s2 = arg2.toString();
        try { m += s1.split(".")[1].length } catch (e) { }
        try { m += s2.split(".")[1].length } catch (e) { }
        return Number(s1.replace(".", "")) * Number(s2.replace(".", "")) / Math.pow(10, m);
    }

    self.accDiv = function (arg1, arg2) {
        var t1 = 0, t2 = 0, r1, r2;
        try { t1 = arg1.toString().split(".")[1].length } catch (e) { }
        try { t2 = arg2.toString().split(".")[1].length } catch (e) { }
        with (Math) {
            r1 = Number(arg1.toString().replace(".", ""));
            r2 = Number(arg2.toString().replace(".", ""));
            return (r1 / r2) * pow(10, t2 - t1);
        }
    }

    //轉換時間格式
    self.paserStr = function (d) {
        var date = d.getFullYear() + "-" + (((d.getMonth() + 1) < 10) ? "0" : "") + (d.getMonth() + 1) + "-" + ((d.getDate() < 10) ? "0" : "") + d.getDate();
        var time = ((d.getHours() < 10) ? "0" : "") + d.getHours() + ":" + ((d.getMinutes() < 10) ? "0" : "") + d.getMinutes() + ":" + ((d.getSeconds() < 10) ? "0" : "") + d.getSeconds();
        return date + " " + time;
    }

    // For todays date;
    Date.prototype.today = function () {
        return this.getFullYear() + "/" + (((this.getMonth() + 1) < 10) ? "0" : "") + (this.getMonth() + 1) + "/" + ((this.getDate() < 10) ? "0" : "") + this.getDate();
    }

    // For the time now
    Date.prototype.timeNow = function () {
        return ((this.getHours() < 10) ? "0" : "") + this.getHours() + ":" + ((this.getMinutes() < 10) ? "0" : "") + this.getMinutes() + ":" + ((this.getSeconds() < 10) ? "0" : "") + this.getSeconds();
    }

    //--------------------------------local storage--------------------------------
    //get localStorage
    self.getLocalStorage = function () {
        var tmp_storage = null;

        try {
            tmp_storage = (window.localStorage) ? window.localStorage : window.globalStorage[strDomain];
            tmp_storage["init"] = "true";
        } catch (e) {
            //showErrorMsg(classname, "getLocalStorage", e.toString());
            return "initFail";
        }

        return tmp_storage;
    }

    //get localStorage item
    self.getLocalStorageItem = function (_key) {
        var tmp_value = null;

        if (top.local_storage) {
            if (top.local_storage[_key.toString()]) {
                tmp_value = top.local_storage[_key.toString()];
                return tmp_value;
            }
        }

        return null;
    }

    //set localStorage item
    self.setLocalStorageItem = function (_key, _value) {
        //if(!checkPrivate()) return "initFail";

        if (top.local_storage) {
            try {
                top.local_storage[_key.toString()] = _value;
                return true;
            } catch (err) {
                //showErrorMsg(classname, "setLocalStorageItem", e.toString());
            }
        }

        return false;
    }

    //remove localStorage item
    self.removeLocalStorageItem = function (_key) {
        if (!checkPrivate()) return "initFail";

        if (top.local_storage) {
            if (top.local_storage[_key.toString()]) {
                try {
                    top.local_storage.removeItem(_key.toString());
                    return true;
                } catch (err) {
                    //showErrorMsg(classname, "removeLocalStorageItem", e.toString());
                }
            }
        }

        return false;
    }

    //
    self.doTime = function (strTime_now, strTime_close) {
        /* Chrome   IE8 , ISO 8601
        var nowTime = new Date(strTime_now);
        var closeTime = new Date(strTime_close);
        var resultTime = closeTime - nowTime;
        */
        var temp1 = strTime_now.split(" ");
        var temp2 = strTime_close.split(" ");
        var temp1time1 = temp1[0].split("-");
        var temp2time1 = temp2[0].split("-");
        var temp1time2 = temp1[1].split(":");
        var temp2time2 = temp2[1].split(":");
        var nowTime = new Date(temp1time1[0], temp1time1[1] - 1, temp1time1[2], temp1time2[0], temp1time2[1], temp1time2[2]);
        var closeTime = new Date(temp2time1[0], temp2time1[1] - 1, temp2time1[2], temp2time2[0], temp2time2[1], temp2time2[2]);
        var resultTime = closeTime - nowTime;
        //
        nowTime = null;
        closeTime = null;
        temp1 = null;
        temp2 = null;
        temp1time1 = null;
        temp2time1 = null;
        temp1time2 = null;
        temp2time2 = null;
        return resultTime / 1000;
    }

    //計算物件數量
    self.getObjCount = function (obj) {
        var out = 0;
        for (var key in obj) {
            out++;
        }

        return out;
    }

    //取得物件位置
    self.getObjAbsolute = function (obj) {
        var abs = new Object();

        abs["left"] = obj.offsetLeft;
        abs["top"] = obj.offsetTop;

        while (obj = obj.offsetParent) {
            abs["left"] += obj.offsetLeft;
            abs["top"] += obj.offsetTop;
        }

        return abs;
    }

    //僅手機端使用    防止Android 手機 下拉滑動會重新整理
    self.blockMovedownRefreash = function (wd, doc) {

        if (top.device == "I") return;
        wd.addEventListener('load', function () {

            var isWindowTop = false;
            var lastTouchY = 0;

            var touchStartHandler = function (e) {
                if (e.touches.length !== 1) return;
                lastTouchY = e.touches[0].clientY;
                isWindowTop = (wd.pageYOffset <= 50);
            };

            var touchMoveHandler = function (e) {
                var touchY = e.touches[0].clientY;
                var touchYmove = touchY - lastTouchY;
                lastTouchY = touchY;

                if (isWindowTop) {
                    isWindowTop = false;
                    if (touchYmove > 0) {
                        e.preventDefault();
                        return;
                    }
                }
            };
            doc.addEventListener('touchstart', touchStartHandler, false);
            doc.addEventListener('touchmove', touchMoveHandler, { passive: false });
        });
    }
}