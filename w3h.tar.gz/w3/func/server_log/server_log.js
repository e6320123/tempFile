var util = null;
var listenEvt = null;
var allPath = null;
var now_level = 0;
var end_line = 0;
var tail_tread = null;
var what_server = "";
var php_data = null;

//初始化
function init() {
	util = new Util();
	listenEvt = new ListenEvent();
	phpEvent = new phpEvent();			//PHP事件
	listenEvent = new listenEvent();	//監聽事件
	showView = new showView();			//畫面控制
	chkData = new chkData();			//檢查資料
	func = new func();					//工具集

	showView.initFunc();
	var connectObj = util.getSpan(document, "server");
	listenEvt.addSelectOnChange(connectObj.id, connectObj, listenEvent, connectObj.getAttribute("data-func"));

	// doSet();	//預設動作
	util.getSpan(document, "table").style.height = 270 + "px";
	// util.getSpan(document, "log").style.width = 800 + "px";
	// util.getSpan(document, "log").style.height = 500 + "px";
}

//預設動作
function doSet(s) {
	if(s == "") return;
	var connectObj = util.getSpan(document, "server");
	if (connectObj[0].value == "")connectObj.remove(0);//移除請選擇
	now_level = 0
	var tableArr = document.getElementsByName("table");//清掉table
	for (var i = tableArr.length - 1; i >= now_level; i--) {
		util.getSpan(document, "table").removeChild(tableArr[i]);
	}
	what_server = s;
	phpEvent.initData();
}

//PHP事件
function phpEvent() {
	var self = this;
	var aPath = "./server_log.php";
	var parame = "uid=" + uid + "&logintype=" + logintype;
	//取得資料
	self.initData = function (str) {
		var tmp = parame + "&action=initData&what_server=" + what_server;
		util.addPostPHP("initData", aPath, tmp, this);
	}

	//取得資料
	self.getData = function (str) {
		var tmp = parame + "&action=getData&what_server=" + what_server;
		tmp += "&records=" + util.getSpan(document, "records").value + "&path=" + util.getSpan(document, "path").value;
		if (util.getSpan(document, "chk_keyword").checked) {
			tmp += "&keyword=" + util.getSpan(document, "keyword").value;
			if (!(str.indexOf("&page=") > -1)) tmp += "&page=" + util.getSpan(document, "page").value;
		}
		if (str) tmp += str;

		util.addPostPHP("getData", aPath, tmp, this);
	}

	//PHP事件回應
	self.phpDataCenter = function (eventName, obj) {
		if (eventName == "initData") {
			allPath = JSON.parse(obj["allPath"]);
			showView.openFunc();	//開放功能
			listenEvent.addHyperLink(); //建立監聽事件(靜態)
			util.selectText(util.getSpan(document, "path"));	//預設遊標位置
			phpEvent.getData();
			return;
		}
		if (eventName == "getData") {
			php_data = obj;
			showView.pasemainBody(obj);

			parent.chgTabName(window, obj["path"].substring(obj["path"].lastIndexOf("/") + 1));

			util.getSpan(document, "file_path").innerHTML = obj["path"];
			util.getSpan(document, "records").value = obj["LIMIT_PAGE"] || util.getSpan(document, "records").value;
			util.getSpan(document, "page").value = (util.getSpan(document, "tail").checked) ? 1 : obj["NOW_PAGE"] || 1;
			util.getSpan(document, "total_page").innerHTML = (util.getSpan(document, "tail").checked) ? 1 : obj["TOTAL_PAGE"] || 1;
			util.getSpan(document, "table").style.display = "";
			util.getSpan(document, "log_span").style.display = (!obj["FOLDER"]) ? "" : "none";
			return;
		}
	}
}

//監聽事件
function listenEvent() {
	var self = this;

	//建立監聽事件(靜態)
	self.addHyperLink = function () {
		var buttonArr = document.getElementsByName("button");	//按鈕
		var selectArr = document.getElementsByName("select");	//拉霸
		var textArr = document.getElementsByName("text");		//輸入文字

		buttonArr.forEach((button) => { listenEvt.addOnClick(button.id, button, this, button.getAttribute("data-func")); });
		selectArr.forEach((select) => { listenEvt.addSelectOnChange(select.id, select, this, select.getAttribute("data-func")); });
		textArr.forEach((text) => { listenEvt.addOnInput(text.id, text, this, text.getAttribute("data-func")); });

		listenEvt.addKeyUp("search_keyword", util.getSpan(document, "keyword"), this, "search");
		listenEvt.addKeyDown("key_log", util.getSpan(document, "log"), this, "clear");
		// listenEvt.addMouseDown("click_log", util.getSpan(document, "log"), this, "clear");
	}

	//建立監聽事件(動態)
	self.addListenEvent = function () {
		var buttonArr = document.getElementsByName("button");	//按鈕

		buttonArr.forEach((button) => { listenEvt.addOnClick(button.id, button, this, button.getAttribute("data-func")); });
	}

	//監聽事件回應
	self.listenCenter = function (eventStr, obj) {
		console.log(eventStr + "," + obj.object);

		var tmp = eventStr.split("_");
		var eventName = tmp[0];
		var eventType = tmp[1];

		if (obj.object == "connect") {
			doSet(obj.div.value);
			return;
		}

		//查詢
		if (obj.object == "search") {
			var str = "";
			if (eventStr == "records") {
				str = "&path=" + util.getSpan(document, "file_path").innerHTML;
				str += "&type=file";
				now_level--;
			} else if (eventType == "keyword") {
				if (eventStr == "search_keyword" && obj.e.code != "Enter") return;
				if (!util.getSpan(document, "chk_keyword").cheched) {
					showView.pasemainBody(php_data);
					return;
				}
				str = "&path=" + util.getSpan(document, "file_path").innerHTML;
				str += "&type=file";
				var tableArr = document.getElementsByName("table");
				for (var i = tableArr.length - 1; i >= now_level; i--) {
					util.getSpan(document, "table").removeChild(tableArr[i]);
				}
			} else if (eventStr == "search_tail_time") {
				return;
			} else {
				now_level = 0;
			}

			func.clearLog();
			phpEvent.getData(str);
			return;
		}

		//選擇資檔案
		if (obj.object == "path") {
			now_level = obj.div.getAttribute("data-level") * 1;
			var buttonArr = document.getElementsByName("button");
			buttonArr.forEach((button) => { if (button.getAttribute("data-level") * 1 >= now_level) button.className = ""; });
			obj.div.className = "LightGaryTD";

			var tableArr = document.getElementsByName("table");
			for (var i = tableArr.length - 1; i >= now_level; i--) {
				util.getSpan(document, "table").removeChild(tableArr[i]);
			}
			//檢查是否為可查看的檔案
			if (eventName == "file") {
				if (!util.in_array(eventStr.substring(eventStr.lastIndexOf(".") + 1), allPath["SUBNAME"])) {

					showMsg("FILE_READER_ERROR");
					return;
				} else {
					func.clearLog();
				}
			}

			var str = "&path=" + obj.div.getAttribute("data-path");
			str += "&type=" + eventName;
			phpEvent.getData(str);
			return;
		}

		//換頁
		if (obj.object == "page") {
			self.chgPage(eventStr);
			return;
		}

		//Tail
		if (eventName == "tail") {
			if (eventStr == "tail_time") {
				chkData.chkInt(obj.div);
				util.getSpan(document, "tail").checked = (obj.div.value != "");
			}

			clearTimeout(tail_tread);

			tail_tread = setInterval(() => {
				func.tailLog();
			}, (util.getSpan(document, "tail_time").value || 5) * 1000);
			return;
		}

		//log主題
		if (eventName == "color") {
			if (eventStr == "color") {
				util.getSpan(document, "color_box").style.display = "";
			} else {
				func.setLogTheme(eventType);
				func.setCookie("log_theme", eventType);
				util.getSpan(document, "color_box").style.display = "none";
			}
		} else {
			util.getSpan(document, "color_box").style.display = "none";
		}
		//log大小
		if (eventName == "log") {
			chkData.chkInt(obj.div);
			func.setLogSize(eventType, obj.div.value);
			func.setCookie("log_" + eventType, obj.div.value);
		}
		//清空
		if (obj.object == "clear") {
			if (eventName == "clear"
				|| (eventName == "key" && obj.e.metaKey && obj.e.code == "KeyK")
				// || (eventName == "click" && obj.e.button == 2)
			) {
				util.getSpan(document, "log").innerHTML = "";
			}
		}
	}

	//換頁
	self.chgPage = function (eventName) {
		var pageObj = util.getSpan(document, "page");
		var page_max = util.getSpan(document, "total_page").innerHTML * 1;

		var tmp_page = pageObj.value * 1;

		if (eventName == "prev") {
			if (pageObj.value > 1) {
				pageObj.value = pageObj.value * 1 - 1;
			}
		} else if (eventName == "next") {
			if (pageObj.value < page_max) {
				pageObj.value = pageObj.value * 1 + 1;
			}
		} else if (eventName == "prev_max") {
			pageObj.value = 1;
		} else if (eventName == "next_max") {
			pageObj.value = page_max;
		}

		//若無換頁則跳過
		if (eventName != "page" && pageObj.value == tmp_page) {
			parent.closeLoading();
			return;
		}

		var str = "&path=" + util.getSpan(document, "file_path").innerHTML;
		str += "&type=file";
		str += "&page=" + pageObj.value;

		phpEvent.getData(str);
	}
}

//畫面控制
function showView() {
	var self = this;
	self.initFunc = function () {
		var connectObj = util.getSpan(document, "server");
		connectObj.length = 0;
		connectObj.options.add(new Option("請選擇", ""));
		serverInfo.forEach((server) => {
			connectObj.options.add(new Option(server, server));
		});

	}
	//開放功能
	self.openFunc = function () {
		var pathObj = util.getSpan(document, "path");
		pathObj.length = 0;

		allPath["PATH"].forEach((path) => {
			pathObj.options.add(new Option(path, path));
		});

		func.setLogTheme(func.getCookie("log_theme"));
		func.setLogSize("width", func.getCookie("log_width"));
		func.setLogSize("height", func.getCookie("log_height"));
		// util.getSpan(document, "log").oncontextmenu = () => { return false; };
	}

	//建立表格
	self.pasemainBody = function (obj) {
		var outStr = "";


		if (obj["FOLDER"]) {
			var xmp_header = util.getSpan(document, "xmp_header").innerHTML;
			var xmp_content_folder = util.getSpan(document, "xmp_content_folder").innerHTML;
			var xmp_content_file = util.getSpan(document, "xmp_content_file").innerHTML;
			var xmp_footer = util.getSpan(document, "xmp_footer").innerHTML;
			var forder_data = obj["FOLDER"];
			var file_data = obj["FILE"];
			now_level++;

			outStr += xmp_header;

			forder_data.sort();
			forder_data.forEach((folder) => {
				var tmp_content = xmp_content_folder;
				tmp_content = tmp_content.replace(/\*FOLDER\*/g, folder);
				tmp_content = tmp_content.replace("*PATH*", obj["path"]);
				tmp_content = tmp_content.replace(/\*LEVEL\*/g, now_level);

				outStr += tmp_content;
			});

			file_data.sort();
			file_data.forEach((file) => {
				var tmp_content = xmp_content_file;
				tmp_content = tmp_content.replace(/\*FILE\*/g, file);
				if (file.length > 20) file = file.substring(0, 10) + "..." + file.substring(file.lastIndexOf(".") - 5);
				tmp_content = tmp_content.replace("*SORT_FILE*", file);
				tmp_content = tmp_content.replace("*PATH*", obj["path"]);
				tmp_content = tmp_content.replace(/\*LEVEL\*/g, now_level);

				outStr += tmp_content;
			});

			xmp_footer = xmp_footer.replace("*PATH*", obj["path"]);
			outStr += xmp_footer;

			var pathArr = obj["path"].split("/");
			pathArr.length -= 1;
			util.getSpan(document, "table").innerHTML += outStr;

			listenEvent.addListenEvent();
		} else {
			var logObj = util.getSpan(document, "log");
			var is_tail = util.getSpan(document, "tail").checked;

			if (obj["DATA"]) {
				if (!is_tail) logObj.innerHTML = "";
				if (is_tail && end_line == obj["END_LINE"]) return;

				var keyword = util.getSpan(document, "keyword").value;
				keyword = keyword.replace(/</g, "&lt;");
				keyword = keyword.replace(/>/g, "&gt;");
				var r = new RegExp(keyword, "g");

				var data_list = obj["DATA"].split("/n");

				for (var i = 0; i < data_list.length; i++) {
					if (obj["END_LINE"] - end_line - obj["LIMIT_LINE"] + i + 1 < 0) continue;

					var data = data_list[i];
					data = data.replace(/</g, "&lt;");
					data = data.replace(/>/g, "&gt;");
					if (keyword != "") data = data.replace(r, "<font color='red'>" + keyword + "</font>");
					var tr = logObj.insertRow(logObj.length);
					var td = tr.insertCell(0);
					td.innerHTML = data;
				}

				while (logObj.length > util.getSpan(document, "records").value) {
					logObj.deleteRow(0);
				}

				end_line = obj["END_LINE"];
			} else {
				outStr += obj["MSG"];

				logObj.innerHTML = outStr;
			}
		}
	}
}

//檢查資料
function chkData() {
	var self = this;

	//檢查整數
	self.chkInt = function (div) {
		var val = div.value;
		val = val.replace(/[^\d]/g, "");
		div.value = val;
	}
}

//工具集
function func() {
	var self = this;

	//持續取得log
	self.tailLog = function () {
		var file_path = util.getSpan(document, "file_path").innerHTML;
		if (util.getSpan(document, "tail").checked && util.in_array(file_path.substring(file_path.lastIndexOf(".") + 1), allPath["SUBNAME"])) {
			var str = "&path=" + util.getSpan(document, "file_path").innerHTML;
			str += "&type=file_tail";
			now_level--;
			phpEvent.getData(str);
		}
	}

	//清除log
	self.clearLog = function () {
		end_line = 0;
		util.getSpan(document, "log").innerHTML = "";
	}

	//設定主題
	self.setLogTheme = function (theme) {
		if (!theme) return;

		var logObj = util.getSpan(document, "log");
		var log_bgObj = util.getSpan(document, "log_bg");
		var colorObj = util.getSpan(document, "color_" + theme);
		logObj.className = colorObj.className;
		log_bgObj.className = "log_txtG " + colorObj.className

		util.getSpan(document, "color").innerHTML = colorObj.innerHTML;
	}
	//設定大小
	self.setLogSize = function (type, size) {
		if (type == "width") {
			util.getSpan(document, "log_bg").style.width = ((size == "") ? 800 : size) + "px";
		} else {
			util.getSpan(document, "log_bg").style.height = ((size == "") ? 300 : size) + "px";
		}

		if (util.getSpan(document, "log_" + type).value != size) util.getSpan(document, "log_" + type).value = size;
	}
	//寫入 cookie
	self.setCookie = function (key, value) {
		document.cookie = key + "=" + value;
	}

	//取得 cookie
	self.getCookie = function (key) {
		var cookie_list = document.cookie.split("; ");
		for (var i = 0; i < cookie_list.length; i++) {
			var tmp = cookie_list[i].split("=");
			if (key == tmp[0]) return tmp[1];
		}

		return "";
	}
}

//提示訊息
function showMsg(motion, data) {
	var str = "";

	if (motion == "FILE_READER_ERROR") {
		str += "不可讀取的檔案類型";
	}

	util.getSpan(document, "log_span").style.display = "";
	var logObj = util.getSpan(document, "log");
	logObj.innerHTML = "";
	var tr = logObj.insertRow(logObj.length);
	var td = tr.insertCell(0);
	td.innerHTML = str;
}