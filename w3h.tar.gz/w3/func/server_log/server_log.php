<?php
// include("../../conf/conf_ctl.php");
include("../../conf/config_admin.php");
// include("../../lib/pub_admin.php");
include("./totp/base32.php");
include("./totp/otphp.php");
// print_r($MEM_DATA);
// if ($MEM_DATA["root"] != "Y") exit;
if (!test()) exit;
$what_server = $what_server;
$serverInfoAry = array("OLD" => array("ip" => "192.168.201.119", "port" => "14003"),
                       "INFO"=> array("ip" => "192.168.201.119", "port" => "24003"));
//線上Server
// $serverInfoAry = array(
//     "BaServer(1,3,5,13)[31]" => array("ip" => "192.168.130.31","port" => "14003"),
//     "BaServer(1,3,5,13)[32]" => array("ip" => "192.168.130.32","port" => "14003"),
//     "BaServer(1,3,5,13)[33]" => array("ip" => "192.168.130.33","port" => "14003"),
//     "BaServer(1,3,5,13)[34]" => array("ip" => "192.168.130.34","port" => "14003"),
//     "BaServer(2,4,6,14)[35]" => array("ip" => "192.168.130.35","port" => "14003"),
//     "BaServer(2,4,6,14)[36]" => array("ip" => "192.168.130.36","port" => "14003"),
//     "BaServer(2,4,6,14)[37]" => array("ip" => "192.168.130.37","port" => "14003"),
//     "BaServer(2,4,6,14)[38]" => array("ip" => "192.168.130.38","port" => "14003"),
//     "BaServer(7,9,11)[39]" => array("ip" => "192.168.130.39","port" => "14003"),
//     "BaServer(7,9,11)[40]" => array("ip" => "192.168.130.40","port" => "14003"),
//     "BaServer(7,9,11)[41]" => array("ip" => "192.168.130.41","port" => "14003"),
//     "BaServer(7,9,11)[42]" => array("ip" => "192.168.130.42","port" => "14003"),
//     "BaServer(8,10,12[43]" => array("ip" => "192.168.130.43","port" => "14003"),
//     "BaServer(8,10,12)[44]" => array("ip" => "192.168.130.44","port" => "14003"),
//     "BaServer(8,10,12)[45]" => array("ip" => "192.168.130.45","port" => "14003"),
//     "BaServer(8,10,12)[46]" => array("ip" => "192.168.130.46","port" => "14003"),
//     "BaServer(1,3,5,13)[47]" => array("ip" => "192.168.130.47","port" => "14003"),
//     "BaServer(2,4,6,14)[48]" => array("ip" => "192.168.130.48","port" => "14003"),
//     "BaServer(7,9,11)[49]" => array("ip" => "192.168.130.49","port" => "14003"),
//     "BaServer(8,10,12)[50]" => array("ip" => "192.168.130.50","port" => "14003"),
//     "BaServer(1,3,5,13)[172]" => array("ip" => "192.168.130.172","port" => "14003"),
//     "BaServer(1,3,5,13)[173]" => array("ip" => "192.168.130.173","port" => "14003"),
//     "BaServer(2,4,6,14)[174]" => array("ip" => "192.168.130.174","port" => "14003"),
//     "BaServer(2,4,6,14)[175]" => array("ip" => "192.168.130.175","port" => "14003"),
//     "BaServer(7,9,11)[176]" => array("ip" => "192.168.130.176","port" => "14003"),
//     "BaServer(7,9,11)[177]" => array("ip" => "192.168.130.177","port" => "14003"),
//     "BaServer(8,10,12)[178]" => array("ip" => "192.168.130.178","port" => "14003"),
//     "AutoDealer/BaServer(8,10,12)[179]" => array("ip" => "192.168.130.179","port" => "14003"),
//     "ba(1,3,5,7,9,11,13)Video[181]" => array("ip" => "192.168.130.181","port" => "14003"),
//     "ba(2,4,6,8,10,12,14)Video[182]" => array("ip" => "192.168.130.182","port" => "14003"),
//     "ba(15,16,17,18,19,20)Video[183]" => array("ip" => "192.168.130.183","port" => "14003"),
//     "Road/Lobby/BlanceServer[170]" => array("ip" => "192.168.130.170","port" => "14003"),
//     "API/loginServer[185]" => array("ip" => "192.168.130.185","port" => "14003"),
//     "API/loginServer[186]" => array("ip" => "192.168.130.186","port" => "14003"),
//     "API/loginServer[187]" => array("ip" => "192.168.130.187","port" => "14003"),
//     "CTL_Server[165]" => array("ip" => "192.168.130.165","port" => "14003"),
//     "loginServer[161]" => array("ip" => "192.168.130.161","port" => "14003"),
//     "loginServer[162]" => array("ip" => "192.168.130.162","port" => "14003"),
//     "loginServer[163]" => array("ip" => "192.168.130.163","port" => "14003"));

if($what_server != ""){
    $IP = $serverInfoAry[$what_server]["ip"];
    $port = $serverInfoAry[$what_server]["port"];
}
$seed = "JBSWY3DPEHPK3PXP";
$totp = new \OTPHP\TOTP($seed);
$totpKey = $totp->now(); // => 492039
if ($action == "") {
    $serverInfo = array();
    foreach ($serverInfoAry as $key => $value){
        $serverInfo[] = $key;
    }
    $serverInfo = json_encode($serverInfo);
	$rand = rand(1, 10000);
	include("server_log.html");
}else if ($action == "initData") {  //初始化
    $code = "300,allPath,".$totpKey;
    $allPath = javaConnnection($code, $IP, $port, true);
    $allPath = str_replace("\n", "", $allPath);
    $out["allPath"] = $allPath;
    echo json_encode($out);
 } else if ($action == "getData") {  //取得資料
    if ($type == "") $type = "folder";
    if ($path == "") $path = "..".$path;

    if ($type == "folder") {
        $code = "301,listFolder,".$totpKey.",".$path;
    } else if ($type == "file") {
        if ($records == "") $records = 1000;	//顯示行數
        if ($page == "") $page = 1;

        $code = "305,Q,".$totpKey.",".$path.",".$keyword.",".$page.",".$records;
    } else if ($type == "file_tail") {
        $code = "307,lastQ,".$totpKey.",".$path.",".$keyword.",".$records;
    } else {
        $out["motion"] = "ERROR";
        echo json_encode($out);
        exit;
    }

    $backCode = javaConnnection($code, $IP, $port, true);

    $out = json_decode($backCode, true);
    $out["cmd"] = $code;
    $out["path"] = $path;
    echo json_encode($out);
}
//測試
function test($username = "") {
	Global $MEM_DATA;

	$test = false;

	if ($username != "") {
		if ($MEM_DATA["username"] == $username) $test = true;
	} else {
		if ($MEM_DATA["username"] == "brian") $test = true;
		if ($MEM_DATA["username"] == "ice") $test = true;
		if ($MEM_DATA["username"] == "niter") $test = true;
		if ($MEM_DATA["username"] == "paul") $test = true;
		if ($MEM_DATA["username"] == "victor") $test = true;
		if ($MEM_DATA["username"] == "harlen") $test = true;
		if ($MEM_DATA["username"] == "arvin") $test = true;
		if ($MEM_DATA["username"] == "roland") $test = true;
        if ($MEM_DATA["username"] == "stan") $test = true;
        if ($MEM_DATA["username"] == "quanto") $test = true;
		if ($MEM_DATA["username"] == "gama") $test = true;
	}

	return $test;
}
function javaConnnection($command,$ip,$port,$back=false){
    $get="";
    $fp = fsockopen($ip, $port, $errno, $errstr, 5);
    if (!$fp) {
        return "Server error";
        //echo "<script>alert('$errno:$errstr');</script>";
    } else {
        fwrite($fp, $command."\n");
        if($back){
            while (!feof($fp)) {
                $get.= fgets($fp, 256);
                if(strpos($get , "\n") > -1) break;
                //echo $get;
            }
        }
        fclose($fp);
    }
    return $get;
}
?>