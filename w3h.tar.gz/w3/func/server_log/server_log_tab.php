<?php
$rand = rand(1, 10000);
include("server_log_tab.html");
?>