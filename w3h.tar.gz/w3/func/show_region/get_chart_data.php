<?php
include $_SERVER['DOCUMENT_ROOT']."/conf/config_admin.php";
include $_SERVER['DOCUMENT_ROOT']."/lib/pub_admin.php";

$today = getdate();
$today_date = gmdate("Y-m-d", mktime($today["hours"] + WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
$today_time = gmdate("Y-m-d H:i:s", mktime($today["hours"] + WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));

$search_username = (!empty($_POST["search_username"]))? $search_username : "";
$startDate = (!empty($_POST["startDate"]))? $startDate : $today_date;
$endDate = (!empty($_POST["endDate"]))? $endDate : $today_date;

$aid = "";
$regionNumData = Array();
$regionNumData["data"] = Array();
$out = "";

// DB_ACTION_HOST_R   192.168.130.78
// DB_ACTION_NAME     baaRecord
$db = new proc_DB(DB_HOST,DB_USER,DB_PWD,DB_NAME);
$db_record = new proc_DB(DB_ACTION_HOST_R,DB_USER,DB_PWD,DB_ACTION_NAME);

//地區
if($search_kind == "region") {
    //all or 指定ag
    if($search_username != "") {
        //取aid
        $sql = "SELECT id FROM agents WHERE username = '".$search_username."';";
        $db->query($sql,1);
        
        $aid = $db->f("id");
        $cond = " aid ='".$aid."' AND";
    } else {
        $aid = 0;  //不指定ag的話 aid 預設為 0 
        $cond = "";
    }
    $sql = "SELECT COUNT(1) AS memNum, region FROM memberRegion WHERE".$cond." date >= '".$startDate."' AND date <= '".$endDate."' GROUP BY region ORDER BY memNum DESC";
    $db_record->query($sql);
    
    $regionNumData["aid"] = $aid;
    // $regionNumData["username"] = ($aid != 0)? $search_username : "all";
    $tmpArray = Array();
    $tmpkey = 0;
    while ($db_record->next_record()) {
        $tmp_region = $db_record->f("region");
        $tmp_memNum = $db_record->f("memNum");

        $tmpArray[$tmpkey]["region"] = $tmp_region;
        $tmpArray[$tmpkey]["memNum"] = $tmp_memNum;
        $tmpkey++;
    }
    $regionNumData["data"] = $tmpArray;

    $out = $regionNumData;
}

//裝置
if($search_kind == "device") {

}

echo json_encode($out);
exit;

?>