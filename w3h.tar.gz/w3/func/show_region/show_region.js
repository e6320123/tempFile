var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;
var DTF;

var listenObj;
// var timet = null;
var barCountryChart = null;
var barRegionChart = null;

var ag_username = "";
var startDate = "";
var endDate = "";
var searchKind = "region";

var page = 1;                   //第幾頁
var pageNum = 50;               //一頁的筆數
var isFilter = false            //資料是否過濾國家跟地區相同 ex:China-China
var initDateLimit = "2018-01-01";   //月曆的初始日期限制

function init() {
    util = new Util();
    listenObj = new listenEvent();
    listenObj.addHyperLink();
    // timer = new timeThread();
    // timer.Start();

    setCalendarInit();
    initChart();
}

function listenEvent(){
    var self = this;

    self.addHyperLink = function(){
        listenEvt.addOnClick("chgRegion", util.getSpan(document, "search_region"), this, null);
        listenEvt.addOnClick("chgDevice", util.getSpan(document, "search_device"), this, null);

        listenEvt.addOnClick("Search", util.getSpan(document, "search"), this, null);
        listenEvt.addOnClick("Cancel", util.getSpan(document, "cancel"), this, null);

        var buttonArr = document.getElementsByName("button");
        buttonArr.forEach((button) => { listenEvt.addOnClick(button.id, button, this, button.getAttribute("data-func")); });
    }
    
    self.listenCenter = function (eventString, listenData) {
        var tmpData = eventString.split("_");
        var eventName = tmpData[0];
        var eventData = (tmpData[1]) ? tmpData[1] : "";

        //切換查詢種類
        if (eventName == "chgRegion") {
            searchKind = "region";
            util.getSpan(document, "search_region").className = "nav-link active";
            util.getSpan(document, "search_device").className = "nav-link ";
        }
        if (eventName == "chgDevice") {
            searchKind = "device";
            util.getSpan(document, "search_region").className = "nav-link ";
            util.getSpan(document, "search_device").className = "nav-link active";
        }

        //打開月曆
        if (eventName.indexOf("calendar") != -1) {
            if (eventData == "startdate") {
                var startdate = DTF.timeToString(DTF.getTime(null, { "time": initDateLimit }), "day");
                var enddate = util.getSpan(document, "enddate_0").value;
            } else {
                // var startdate = util.getSpan(document, "startdate_0").value;
                var startdate = DTF.timeToString(DTF.getTime(null, { "time": initDateLimit }), "day");
                var enddate = DTF.timeToString(DTF.getTime(), "day");
            }
            DTF.setDateLimit(startdate, "start");
            DTF.setDateLimit(enddate, "end");

            calendar.window.setSpan(listenData.div.children[1], "value", 30, 40);
            calendar.window.setDay(listenData.div.children[1].value);

            return true;
        }

        if (eventName == "Search") {
            ag_username = util.getSpan(document, "ag_username").value;
            startDate = util.getSpan(document, "startdate_0").value;
            //initDateLimit = util.getSpan(document,"startdate_1").value;
            endDate = util.getSpan(document, "enddate_0").value;
            //endtime = util.getSpan(document,"enddate_1").value;

            // console.log(ag_username);
            // console.log(startDate);
            // console.log(endDate);
            //施工中 目前點了會被踢 191220
            getChartData(ag_username, startDate, endDate, searchKind);
            //showLoading
            // barRegionChart.showLoading();
            // barCountryChart.showLoading();
        }
    }
}

//set 日曆
function setCalendarInit() {
    var calendar = util.getSpan(document, "calendar");
    calendar.src = "/tpl/control/" + top.langx + "/calendar.html";
    DTF = new DateTimeFormat();	//取得時間格式
    //預設日期時間
    //預設開始時間為臨近整點
    var time = DTF.getTime(null, { "dd": -7, "hh": "0", "mm": "0", "ss": "0" });
    var timeObj = DTF.timeToString(time, "split");
    util.getSpan(document, "startdate_0").value = util.getSpan(document, "startdate_0").value || timeObj[0];
    util.getSpan(document, "startdate_1").value = util.getSpan(document, "startdate_1").value || timeObj[1];
    time = DTF.getTime(time, { "dd": 7, "hh": "23", "mm": "59", "ss": "59" });	//預設結束時間延後一天
    timeObj = DTF.timeToString(time, "split");
    util.getSpan(document, "enddate_0").value = util.getSpan(document, "enddate_0").value || timeObj[0];
    util.getSpan(document, "enddate_1").value = util.getSpan(document, "enddate_1").value || timeObj[1];
    if (calendar.window) calendar.window.setAutoClose(document, document);

    setCalendarEnd();
}

function setCalendarEnd() {
    startDate = util.getSpan(document, "startdate_0").value;
    endDate = util.getSpan(document, "enddate_0").value;
    getChartData(ag_username, startDate, endDate, searchKind);
}

function initChart() {
    barRegionChart = echarts.init(util.getSpan(document, "allContainer"));
    barCountryChart = echarts.init(util.getSpan(document, "container"));
    //標題 圖例 座標軸
    barRegionChart.setOption({
        title: {
            text: '會員登入地區分布'
        },
        legend: {
            data: ['人數']
        },
        tooltip: {},
        xAxis: {
            // type: 'category',
            // nameGap: 5,
            axisLabel: {
                interval: 0,      //坐标轴刻度标签的显示间隔(在类目轴中有效) 0:显示所有  1：隔一个显示一个 :3：隔三个显示一个...
                rotate: -20       //标签倾斜的角度，显示不全时可以通过旋转防止标签重叠（-90到90）
            },
            data: []
        },
        yAxis: {},
        series: [{
            name: '人數',
            type: 'bar',
            barWidth: 30,  //柱图宽度
            data: []
        }]
    });

    barCountryChart.setOption({
        title: {
            text: '會員登入國家分布'
        },
        legend: {
            data: ['人數']
        },
        tooltip: {},
        xAxis: {
            axisLabel: {
                interval: 0,      //坐标轴刻度标签的显示间隔(在类目轴中有效) 0:显示所有  1：隔一个显示一个 :3：隔三个显示一个...
                rotate: -20       //标签倾斜的角度，显示不全时可以通过旋转防止标签重叠（-90到90）
            },
            data: []
        },
        yAxis: {},
        series: [{
            name: '人數',
            type: 'bar',
            barWidth: 30,  //柱图宽度
            data: []
        }]
    });

    barCountryChart.showLoading();
    barRegionChart.showLoading();
}

function setChartData(chartDiv, chartData) {
    //closeLoading
    chartDiv.hideLoading();

    // set data
    chartDiv.setOption({
        xAxis: {
            // data: chartData.categories
            data: chartData.region
        },
        series: [{
            // 根据名字对应到相应的系列
            name: '人數',
            // data: chartData.data
            data: chartData.memNum
        }]
    });
}

function parseRegionNumTable(regionNumObj) {
    var startNum = pageNum * (page -1);  //從哪一筆開始畫表格

    var showRegionNumTable = util.getSpan(document, "showRegionNumTable");

    var xmpRegionNumHeader = util.getSpan(document, "xmpRegionNumHeader").innerHTML;
    var xmpRegionNumData = util.getSpan(document, "xmpRegionNumData").innerHTML;
    var xmpRegionNumFooter = util.getSpan(document, "xmpRegionNumFooter").innerHTML;

    // var regionNumTableHeader = xmpRegionNumHeader.replace(/\*USERNAME\*/g, regionNumObj.username);

    var regionNumTableStr = "";
    for(var i = startNum;i < pageNum; i++) {
        var tmpRegionNumTableStr = xmpRegionNumData ;
        tmpRegionNumTableStr = tmpRegionNumTableStr.replace(/\*REGION\*/g, regionNumObj.data[i].region);
        tmpRegionNumTableStr = tmpRegionNumTableStr.replace(/\*COUNT\*/g, regionNumObj.data[i].memNum);

        regionNumTableStr += tmpRegionNumTableStr;
    }

    showRegionNumTable.innerHTML = xmpRegionNumHeader + regionNumTableStr + xmpRegionNumFooter;
}

function parseChart(regionNumObj, kind) {
    if(kind == "region") {
        isFilter = true;
        var regionData = sortPeopleNumData(regionNumObj);
        console.log(regionData);
        setChartData(barRegionChart, regionData);

        barRegionChart.hideLoading();
    }

    if(kind == "country") {
        isFilter = false;
        var countryData = sortPeopleNumData(regionNumObj);
        console.log(countryData);
        setChartData(barCountryChart, countryData);

        barCountryChart.hideLoading();
    }
}

function sortPeopleNumData(obj) {
    var returnData = new Object();
    returnData["region"] = new Array();
    returnData["memNum"] = new Array();
    // var previousCountry = "";
    // var totalNum = 0;
    // var isFirstData = true;
    var countryNumObj = new Object();
    var rank = 1;  //用來判斷排名
    var data = obj.data;

    for (var key in data) {
        var tmpRegionName = data[key]["region"];
        var tmpRegionNum = (data[key]["memNum"]) * 1;
        var tmpArray = tmpRegionName.split("-");  //ex: China-China
        var tmpCountry = tmpArray[0];
        var tmpRegion = tmpArray[1];

        if(isFilter) {
            if (tmpCountry != tmpRegion) {
                returnData["region"].push(data[key]["region"]);
                returnData["memNum"].push(data[key]["memNum"]);

                rank++
            }
        } else {
            if(Object.keys(countryNumObj).indexOf(tmpCountry) == -1) {
                countryNumObj[tmpCountry] = tmpRegionNum;
                rank++
            } else {
                countryNumObj[tmpCountry] += tmpRegionNum;
            }
        }
        

        //取前10名
        if (rank > 10) break;
    }

    if(isFilter == false) {
        returnData["region"] = Object.keys(countryNumObj);

        for(var key in countryNumObj) {
            returnData["memNum"].push(countryNumObj[key]);
        }
    }

    return returnData;
}

function phpDataCenter(eventName, phpData) {
    if (eventName == "getChartData") {
        console.log(phpData);
        parseRegionNumTable(phpData);
        parseChart(phpData, "region");
        parseChart(phpData, "country");

        return;
    }
}

function getChartData(ag_username, startDate, endDate, searchKind) {
    var url = "get_chart_data.php";
    var parame = "uid=" + top.uid;
    parame += "&langx=" + top.langx;
    parame += "&search_username=" + ag_username;
    parame += "&startDate=" + startDate;
    parame += "&endDate=" + endDate;
    parame += "&search_kind=" + searchKind;

    util.addPostPHP("getChartData", url, parame, this);
}