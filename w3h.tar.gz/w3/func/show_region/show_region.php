<?php
include $_SERVER['DOCUMENT_ROOT']."/conf/config_admin.php";

include "show_region.html";

exit;
?>