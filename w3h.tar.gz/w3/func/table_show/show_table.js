// var langx = top.langx;
// var langStr = top.langStr;
var util = parent.util;
var listenEvt = parent.listenEvt;
// var usertype = top.usertype;
// var mid = top.mid;
var uid = parent.uid;
var SWobj = null;//存放other_set 資料

function init() {
	phpEvent = new phpEvent();
	listenEvent = new listenEvent();
	showView = new showView();

	phpEvent.getData();
}

function phpEvent() {
	var self = this;

	//取得預設資料
	self.getData = function () {
		var aPath = "../func/table_show/show_table.php";
		var parame = "uid=" + uid + "&action=reload";
		util.addPostPHP("reload_data", aPath, parame, this);
	}
    
	//修改資料
	self.setData = function () {
		var aPath = "../func/table_show/show_table.php";
		var parame = "uid=" + uid + "&action=modify";

		var parameObj = SWobj;
		for (var key in parameObj) {
			parameObj[key]["status"] = util.getSpan(document, parameObj[key]["id"]).value;
		}
		var tempStr = JSON.stringify(parameObj).replace(/"/gi, "@");
		parame += "&updateJson=" + tempStr;
        util.addPostPHP("update_data", aPath, parame, this);
        console.log(tempStr);
    }
    
    self.setSingleData = function(id){
        var sendObj = [];
        var aPath = "../func/table_show/show_table.php";
        var parame = "uid=" + uid + "&action=modify";
        
        var parameObj = SWobj;
		var key = id;
		parameObj[key]["status"] = util.getSpan(document, parameObj[key]["id"]).value;
        sendObj.push(parameObj[key]);
		var tempStr = JSON.stringify(sendObj).replace(/"/gi, "@");
		parame += "&updateJson=" + tempStr;
        util.addPostPHP("update_data", aPath, parame, this);
        console.log(tempStr);

    }

	//預設資料顯示
	self.phpDataCenter = function (eventName, phpData) {
		var obj = phpData;

		//顯示預設資料
		if (eventName == "reload_data") {
			SWobj = obj
			showView.showTable(SWobj);
		}

		//重新載入資料
		if (eventName == "update_data") {
			showMsg(obj["motion"]);
			self.getData();
		}
	}
}

function listenEvent() {
	var self = this;

	self.addHyperLink = function () {
        listenEvt.addOnClick("setData", util.getSpan(document, "editeBTN"), this, null);
        var sBtn = document.getElementsByName("single_edit");
        for(var i=0;i<sBtn.length;i++){
            listenEvt.addOnClick("setSingleData_"+i, sBtn[i], this, null);
        }
	}

	self.listenCenter = function (eventNameData, listenData) {
        var eventName = eventNameData.split("_")[0];
		if (eventName == "setData") {
			if (confirm("確定修改？")) {
				phpEvent.setData();
            }
            return;
        }
        
        if (eventName == "setSingleData"){
            var target = listenData;
            var  id =target.div.id.split("_")[0];
            var  name = SWobj[id]["name"];
            if (confirm("確定修改"+name+"？")) {
				phpEvent.setSingleData(id);
            }
            return;
        }
	}
}

function showView() {
	var self = this;

	self.showTable = function (data) {
		var show_main = util.getSpan(document, "show_main");
		var xmp_header = util.getSpan(document, "xmp_header").innerHTML;
		var xmp_footer = util.getSpan(document, "xmp_footer").innerHTML;
		var xmp_content = util.getSpan(document, "xmp_content").innerHTML;
		var dataStr = "";

		for (var key in data) {
			var td = xmp_content;
			td = td.replace(/\*NAME\*/gi, data[key]["name"]);
			td = td.replace(/\*ONAME\*/gi, key);
			
			td = td.replace("*SELECTED" + data[key]["status"] + "*", "selected");

			dataStr += td;
		}
		show_main.innerHTML = xmp_header + dataStr + xmp_footer;
		listenEvent.addHyperLink();
	}
}

function showMsg(code) {
	if (code == "UPDATE_SUCCESS") {
		alert("修改成功!");
	}
}