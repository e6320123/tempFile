var resData;  
var allNum;  
var url = "./tiData/tiData.php"; 
function init(){   
	ajax(url);    
}  
function processData(res){   
console.log(res); 	
resData = JSON.parse(res); 
	var values =resData.valueOf();     
	
console.log(values);  
showData(values); 
	
} 
function ajax(url){ 
	var AJAXstate = document.getElementById("state");  
	var xmlhttp = new XMLHttpRequest(); 
	var flag = setTimeout(() => {
		AJAXstate.innerHTML = "error";
	}, 1000);
	xmlhttp.onreadystatechange = function () { 
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
			processData(xmlhttp.responseText); 
			AJAXstate.innerHTML = "";
			clearTimeout(flag);
		}  
	};
	xmlhttp.open("POST", url, true);
	xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xmlhttp.send();
}  
function showData(valsAry){ 
	var table_head = document.getElementById("table_head").innerHTML;
	var table_content = document.getElementById("table_content").innerHTML;
	var table_boot = document.getElementById("table_boot").innerHTML; 

	var alltable = "";
	alltable += table_head; 
	for (var i = 0; i < valsAry.length; i++) { 
		if(!i) continue; 
		console.log(valsAry[i]); 
		var onetr = table_content.replace("*tbid*", valsAry[i]['tbid']);
		onetr = onetr.replace("*name_c*", valsAry[i]['name_c']);
        onetr = onetr.replace("*lobby_enable*", valsAry[i]['lobby_enable']);
		onetr = onetr.replace("*lobby_display*", valsAry[i]['lobby_display']);
        onetr = onetr.replace("*admin_enable*", valsAry[i]['admin_enable']);  
		alltable += onetr 
	}  
	alltable += table_boot; 
	document.getElementById("div_show").innerHTML = alltable; 
}  
 

