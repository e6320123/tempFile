<?php

include "../../../config/pub_config_admin.php";   
include WEB_PATH."/lib/mysqllib.php";   

$dbLink = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);  
$ret = select($dbLink); 
$dbLink->close();  
echo $ret;
exit(); 

function select($db){   
    $allAry = array();  
    $db->query($sql); 
    $sql = "SELECT `id`,`tbid`,`name_c`,`lobby_enable` ,`lobby_display` ,`admin_enable` FROM `BA_lobby` ORDER BY tbid asc";
    $db->query($sql);
    $lastTbid = -1;
    $lastID =-1;
    while($db->next_record()){ 
        $conti = false;
        $temp = array();  
        if($db->f("tbid") == $lastTbid){
            $conti = true;
            if($db->f("name_c") != $allAry[$lastID]["name_c"]) $allAry[$lastID]["name_c"] = "errorData";
            if($db->f("lobby_enable") != $allAry[$lastID]["lobby_enable"]) $allAry[$lastID]["lobby_enable"] = "errorData";
            if($db->f("lobby_display") != $allAry[$lastID]["lobby_display"]) $allAry[$lastID]["lobby_display"] = "errorData";
            if($db->f("admin_enable") != $allAry[$lastID]["admin_enable"]) $allAry[$lastID]["admin_enable"] = "errorData";
        }
        if($conti) continue; 
        $temp["tbid"] = $db->f("tbid");
        $temp["name_c"] = $db->f("name_c");
        $temp["lobby_enable"] = $db->f("lobby_enable");
        $temp["lobby_display"] = $db->f("lobby_display");
        $temp["admin_enable"] = $db->f("admin_enable"); 
        array_push($allAry,$temp); 
        $lastID = $db->f("id");
        $lastTbid = $db->f("tbid");
    } 
    $response = json_encode($allAry); 
    return $response;
}   
?>
