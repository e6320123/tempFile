
var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;

var processingModal;
var modalText;

var nowDomainData;
var nowServerData;
var nowModifyId;
var resultList;


var useIframe = false;
var maxTryTimes = 2;

var sock;
var cmd;

var retrySocketTimeout = 0;
function init() {
	processingModal = util.getSpan(document, "processingModal");
	modalText = util.getSpan(document, "modalText");
	btn_submitTimeZoneReport = util.getSpan(document, "submitTimeZoneReport");
	btn_delTimeZoneReport = util.getSpan(document, "delTimeZoneReport");
	btn_closeModal = util.getSpan(document, "closeModal");
	btn_confirmModal = util.getSpan(document, "confirmModal");

	opt_staticReportTimezone = util.getSpan(document, "staticReportTimezone");
	text_staticReportDate = util.getSpan(document, "staticReportDate");
	
	listenEvt.addOnClick("btn_submitTimeZoneReport", btn_submitTimeZoneReport, this, null);
	listenEvt.addOnClick("btn_delTimeZoneReport", btn_delTimeZoneReport, this, null);
	listenEvt.addOnClick("closeModal", btn_closeModal, this, null);

	util.getSpan(document, "staticReportDate").value = GetDateStr(-1);
}

function GetDateStr(AddDayCount) {
	var dd = new Date();
	dd.setDate(dd.getDate()+AddDayCount);//获取AddDayCount天后的日期
	var y = dd.getFullYear();
	var m = dd.getMonth()+1;//获取当前月份的日期
	if(m<10){
		m = "0"+m;
	}
	var d = dd.getDate();
	if(d<10){
		d = "0"+d;
	}
	return y+"-"+m+"-"+d;
}

function getSelectValue(elem){
	var objS = elem;
	return objS.options[objS.selectedIndex].value;
}

function listenCenter(eventName, listenData) {
	if (eventName == "btn_submitTimeZoneReport") {//結轉報表按鈕
		processingModal.className = "modal show";
		modalText.innerHTML = "確認結轉報表？<br>日期："+text_staticReportDate.value+"<br>時區："+getSelectValue(opt_staticReportTimezone);
		listenEvt.addOnClick("confirmGenerateReport", btn_confirmModal, this, null);
		btn_confirmModal.style.display = "";
	}else if (eventName == "btn_delTimeZoneReport") {//清空報表按鈕
		processingModal.className = "modal show";
		modalText.innerHTML = "確認清空報表？<br>日期："+text_staticReportDate.value+"<br>時區："+getSelectValue(opt_staticReportTimezone);
		listenEvt.addOnClick("confirmDeleteReport", btn_confirmModal, this, null);
		btn_confirmModal.style.display = "";
	}else if (eventName == "closeModal") {//回到顯示畫面
		modalText.innerHTML ="";
		processingModal.className = "modal";
	} else if (eventName == "confirmGenerateReport") {//結轉報表
		modalText.innerHTML = "靜態報表結轉中";
		btn_confirmModal.style.display = "none";
		btn_closeModal.className = "btn-disabled";
		listenEvt.addOnClick("", btn_closeModal, this, null);
		generateReport();
	} else if (eventName == "confirmDeleteReport") {//清空報表
		modalText.innerHTML = "靜態報表清除中";
		btn_confirmModal.style.display = "none";
		btn_closeModal.className = "btn-disabled";
		listenEvt.addOnClick("", btn_closeModal, this, null);
		deleteReport();
	} 
}

function generateReport(){
	processingModal.className = "modal show";
	var Path = "/app/control/admin/report_new2/static_data_report_total.php";
	// var code = "uid=" + uid;
	code = "report_kind=A&code=RMB&currency=1&rp_num=100&result_type=Y";
	code += "&report_kind=A&code=RMB&currency=1&rp_num=100&result_type=Y";
	code += "&ReportTimezone="+ getSelectValue(opt_staticReportTimezone);
	code += "&date_start="+ text_staticReportDate.value;
	code += "&action=genReport";
	util.addPostPHP("OK", Path, code, this);
}

function deleteReport(){
	var Path = "/app/control/admin/report_new2/static_data_report_total.php";
	// var code = "uid=" + uid;
	var code = "report_kind=A&code=RMB&currency=1&rp_num=100&result_type=Y";
	code += "&ReportTimezone="+ getSelectValue(opt_staticReportTimezone);
	code += "&date_start="+ text_staticReportDate.value;
	code += "&action=delReport";
	util.addPostPHP("OK", Path, code, this);
}

function phpDataCenter(eventName, phpData) {
	console.log(phpData);
	if(phpData == "CLEAN FIRST"){
		alert("CLEAN FIRST");
		if(modalText.innerHTML == "靜態報表結轉中"){
			modalText.innerHTML = "靜態報表結轉失敗";
		}else if(modalText.innerHTML == "靜態報表清除中"){
			modalText.innerHTML = "靜態報表清除完成";
		}
		btn_closeModal.className = "btn-danger";
		listenEvt.addOnClick("closeModal", btn_closeModal, this, null);
	}else if(phpData == "REPORT FINISH"){
		btn_closeModal.className = "btn-danger";
		listenEvt.addOnClick("closeModal", btn_closeModal, this, null);
		if(modalText.innerHTML == "靜態報表結轉中"){
			modalText.innerHTML = "靜態報表結轉完成";
		}else if(modalText.innerHTML == "靜態報表清除中"){
			modalText.innerHTML = "靜態報表清除完成";
		}
	}
}
