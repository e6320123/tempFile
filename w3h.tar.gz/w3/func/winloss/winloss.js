//lib
var uid = parent.uid;
var util = parent.util;
var listenEvt = parent.listenEvt;;
//class
var phpEvent;
var listenObj;
var jlog ;
var layerFuncObj;

//config
//var _top = {};
// var map_layer = new Array("sc","c","s","a","m");

// data
var accData;
var layerData;
var levelData;
var all_data;

var showAllCheck = false;
function init(){
    jlog = new json_log();
    phpEvent = new phpEvent();	        //PHP事件
    layerFuncObj = new layerFunc();
    listenObj= new listenEvent();
    listenObj.setStaticListen();

}

function layerFunc(){
    var _self = this;
    _self.classname = "layerFunc";
    var map_layer = new Array("sc","c","s","a","m");
    _self.getNumByLayer = function(layer){
        var ret=-1;
        for(var i=0;i<map_layer.length;i++){
            if(map_layer[i] == layer){
                ret = i;
                return ret;
            }
        }
        return ret;
    }
    _self.getLayerByNum = function(num){
        return map_layer[num];
    }
    _self.getMap = function(){
        return map_layer;
    }
}

function json_log(){
    var _self = this;
    var out_div = null;
    var css_setting ={};
    css_setting["k_class"] = "key_str";
    css_setting["v_class"] = "val_str";
    css_setting["obj_class"] = "obj_str";
    css_setting["ary_class"] = "ary_str";
    _self.setOutDiv = function(div){
        out_div = div;
    }
    _self.output = function(json){
        // var ret=JSON.stringify(json,undefined,4);
        // ret=ret.replace(/\n/g,"<br>\n").replace(/ /g,"&nbsp;");
        // out_div.innerHTML = ret;
        out_div.innerHTML = _self.echo(json,0);
        _self.setClick();
    }
    _self.setClick =function(){
        var ary=out_div.getElementsByClassName("array");
        for(var i=0;i<ary.length;i++){
            ary[i].onclick = _self.click_show;
        }
        var ary=out_div.getElementsByClassName("object");
        for(var i=0;i<ary.length;i++){
            ary[i].onclick = _self.click_show;
        }
    }
    _self.showAll =function(){
        var ary=out_div.getElementsByClassName("sub");
        for(var i=0;i<ary.length;i++){
            ary[i].style.display="";
        }
    }
    _self.hideAll =function(){
        var ary=out_div.getElementsByClassName("sub");
        for(var i=0;i<ary.length;i++){
            ary[i].style.display="none";
        }
    }
    _self.whatIsIt =function(object) {
        if (object == null) {
            return "null";
        }
        if (object == undefined) {
            return "undefined";
        }
        if (typeof object =="string") {
            return "String";
        }
        if (Array.isArray(object)) {
            return "Array";
        }
        if (typeof object == 'object') {
            return "Object";
        }
        if (typeof object == 'number') {
            return "Number";
        }
        return "error";
        
    }
    _self.echo =function(obj){
        var ret_str="";
        var newline = "<br>\n";
        ret_str+="{"+newline;
        for(var k in obj){
            ret_str+= _self.echo_value(obj,k,0);
        }
        ret_str+="}"+newline;
        return ret_str;
    }
    _self.echo_value =function(json,key,layer){
        var ret_str="";
        var obj=json[key];
        var type = _self.whatIsIt(obj);
        var newline = "<br>\n";
        layer+=1;
        console.log(type,obj,layer);
        if(type=="Array"){
            ret_str+="<div name='array' class='array'>"
            ret_str+=_self.blank(layer)+_self.aryCSS(key)+" => ["+newline;
            ret_str+="</div>";
            ret_str+="<div name='sub' class='sub'>";
            for(var k=0;k<obj.length;k++){
                ret_str+= _self.echo_value(obj,k,layer)+"";
            }
            ret_str+="</div>";
            ret_str+=_self.blank(layer)+"]"+newline;
            
        }
        if(type=="Object"){
            ret_str+="<div name='object' class='object'>";
            ret_str+=_self.blank(layer)+_self.objCSS(key)+" => {"+newline;
            ret_str+="</div>";
            ret_str+="<div name='sub' class='sub'>";
            for(var k in obj){
                ret_str+= _self.echo_value(obj,k,layer)+"";
            }
            ret_str+="</div>";
            ret_str+=_self.blank(layer)+"}"+newline;
        }
        if(type=="undefined" || type=="Number"){
            ret_str+= "<span class='"+type+"'>"+_self.blank(layer)+_self.keyCSS(key)+" =>  "+_self.valCSS(obj)+newline+"</span>";
        }
        
        if(type=="String"){
            ret_str+= "<span class='"+type+"'>"+_self.blank(layer)+_self.keyCSS(key)+" => "+_self.valCSS(obj)+newline+"</span>";
        }
        return ret_str;
    }
    _self.blank =function(num){
        var str=""
        for(var i=0;i<num;i++){
            str+="&nbsp;&nbsp;&nbsp;&nbsp;";
        }
        return str;
    }
    _self.keyCSS=function(val){
        return "<span class='"+css_setting["k_class"]+"'>"+val+"</span>";
    }
    _self.valCSS=function(val){
        return "<span class='"+css_setting["v_class"]+"'>"+val+"</span>";
    }
    _self.objCSS=function(val){
        //
        return val;
        return "<span class='"+css_setting["obj_class"]+"'>"+val+"</span>";
    }
    _self.aryCSS=function(val){
        //
        return val;
        return "<span class='"+css_setting["ary_class"]+"'>"+val+"</span>";
    }
    _self.click_show =function(e){
        var obj=e.target;
        var ary=obj.parentElement.children;
        var flag=false;
        var div=null;
        for(var i=0;i<ary.length;i++){
            tmp=ary[i];
            if(tmp == obj){
                flag=true;
            }
            if(flag){
                if(tmp.getAttribute("name")=="sub"){
                    div=tmp;
                    break;
                }
            }
        }
        //var div=obj.parentElement.children["sub"]
        if(div.style.display=="none"){
            div.style.display = "";
        }else{
            div.style.display = "none";
        }
    }
}
function parse(aa){
    var debug = false;
    var ret = new Array();
    var layer_map = new Array("sc","c","s","a","m");
    var all_data = {};
    for(var num in aa){
        var data = aa[num];
        //console.log(data);
        var layer = layer_map[num];
        var d_layer = "";
        var u_layer = "";
        if(debug)console.log("----- "+layer+" ------");
        if(num < layer_map.length-1){
            d_layer = layer_map[num*1+1];
        }
        if(num > 0){
            u_layer = layer_map[num*1-1];
        }
        if(debug)console.log(u_layer+"|"+layer+"|"+d_layer);
        for(var k in data){
            //clone
            var tmp = JSON.parse(JSON.stringify(data[k]));
            if(debug)console.log(tmp);

            var id=tmp["id"];
            var u_id = tmp[u_layer+"id"];
            var u_key = u_layer+u_id;
            tmp["down_layer"] = new Array();
            all_data[""+layer+id] = tmp;
            if(debug)console.log(u_key);
            if(all_data[u_key]!=null)all_data[u_key]["down_layer"].push(tmp);
        }
    }
    if(debug)console.log(all_data);
    return all_data["sc"+aa[0][0]["id"]];
}
//PHP事件
function phpEvent() {
    var self = this;
    var aPath = "/func/winloss/winloss_func.php";
    //桌次Data
    self.getLayerData = function () {
        var user_layer=document.getElementById("user_layer").value;
        var user_id=document.getElementById("user_id").value;
        var user_username=document.getElementById("user_username").value;
        var parame = "&action=getLayerData";
        parame += "&uid=" + uid;
        parame += "&user_layer=" + user_layer;
        parame += "&user_id=" + user_id;
        parame += "&user_username=" + user_username;
        util.addPostPHP("getLayerData", aPath, parame, this);
    }
    //PHP事件回應
    self.phpDataCenter = function (eventName, phpData) {

        //get 全部桌Data
        if (eventName == "getLayerData") {
            console.log(phpData);
            if(phpData["status"]=="success"){
                jlog.setOutDiv(document.getElementById("showDiv"));
                layerData = phpData["datas"];
                levelData = phpData["level_datas"];
                accData = parse(layerData,levelData);
                jlog.output(accData);
                // jlog.output(phpData);
                jlog.hideAll();
            }else{
                //console.log("no data");
                alert("no data");
            }
        }
    }
}

function listenEvent() {
    var self = this;
    //建立監聽事件
    self.setStaticListen = function () {
        listenEvt.addOnClick("search", util.getSpan(document, "search"), this, "");
        listenEvt.addOnClick("hideAll", util.getSpan(document, "hideAll"), this, "");
        listenEvt.addOnClick("showAll", util.getSpan(document, "showAll"), this, "");
        listenEvt.addOnClick("chkWinloss", util.getSpan(document, "chkWinloss"), this, "");
        listenEvt.addOnClick("closeChkWinloss", util.getSpan(document, "closeChkWinloss"), this, "");
    }
    self.listenCenter = function (eventName, obj) {
        // console.log(eventName);
        //是否顯示流局
        if (eventName == "search" ) {
            phpEvent.getLayerData();
        }
        if (eventName == "hideAll" ) {
            jlog.hideAll();
        }
        if (eventName == "showAll" ) {
            jlog.showAll();
        }
        if (eventName == "chkWinloss" ) {
            chkWinlossfunc(accData);
        }
        if (eventName == "closeChkWinloss" ){
            document.getElementById("checkDiv").style.display="none";
        }
    }
}

function parse(aa,level_data){
    var debug = false;
    var ret = new Array();
    all_data = {};
    for(var num in aa){
        var data = aa[num];
        //console.log(data);
        var map_layer=layerFuncObj.getMap();
        var layer = map_layer[num];
        var d_layer = "";
        var u_layer = "";
        if(debug)console.log("----- "+layer+" ------");
        if(num < map_layer.length-1){
            d_layer = map_layer[num*1+1];
        }
        if(num > 0){
            u_layer = map_layer[num*1-1];
        }
        if(debug)console.log(u_layer+"|"+layer+"|"+d_layer);
        for(var k in data){
            //clone
            var tmp = JSON.parse(JSON.stringify(data[k]));
            if(debug)console.log(tmp);

            var id=tmp["id"];
            var u_id = tmp[u_layer+"id"];
            tmp["down_layer"] = new Array();
            all_data[""+layer+id] = tmp;


            var u_key = u_layer+u_id;
            if(debug)console.log(u_key);
            if(all_data[u_key]!=null)all_data[u_key]["down_layer"].push(tmp);
        }
        if(layer=="a"){
            for(var k in level_data){
                //clone
                var tmp = JSON.parse(JSON.stringify(level_data[k]));
                var isTop = (tmp["id"]==tmp["top_aid"])?"Y":"N";
                
                if(isTop=="Y"){
                    tmp = all_data["a"+tmp["id"]];
                }else{
                    all_data["a"+tmp["id"]] = tmp;
                    tmp["down_layer"] = new Array();
                }
                tmp["down_level"] = new Array();
                
                if(tmp["up_aid"]!="0"){
                    all_data["a"+tmp["up_aid"]]["down_level"].push(tmp);
                }
            }
        }
    }
    // no_layer
    if(debug)console.log(all_data);
    return all_data["sc"+aa[0][0]["id"]];
}
function getDataById(datas,key,val){
    var ary = new Array();
    var id_str=","+val.join(",")+",";
    for(var i=0;i<datas.length;i++){
        var d_id = datas[i][key];
        if(id_str.indexOf(","+d_id+",")!=-1){
            ary.push(datas[i]);
        }
    }
    return ary;
}
function chkWinlossfunc(objData){


    var sc_winloss_max = "" ;// 總和成數上限
    var sc_fix8 = "";
    var other_set = {};
    other_set["conf_winloss_max"] = 100;
    other_set["conf_winloss_min"] = 0;
    var newLine = "<br>\n";

    var faileCSS = "faile_class";
    // other_set["winloss_fix8"] = 5;

    console.log("objData",objData);
    console.log("layerData",layerData);
    console.log("all_data",all_data);
    var map_layer=layerFuncObj.getMap();
    var ret = new Array();

    var sc_data = layerData[0];
    sc_fix8 = sc_data[0]["fix8"];

    //1.特殊總監下，總監固定帶0.5成，股東固定帶9成，(client畫面鎖死)
    ret.push("1.特殊總監下，總監固定帶0.5成，股東固定帶9成，(client畫面鎖死)");
    if(sc_fix8=="Y"){
        var flag=true;
        for(var i=0;i<layerData[1].length;i++){
            var c_data=layerData[1][i];
            var tmp_c_winloss = sc_data["winloss_max"] -  sc_data["winloss_fix8"];
            if(c_data["winloss_sc"] != sc_data["winloss_fix8"]){
                flag=false;
                ret.push("check faile c ["+c_data["username"]+"] winloss_sc("+c_data["winloss_sc"]+") != winloss_fix8"+"("+sc_data["winloss_fix8"]+")");
            }else if(c_data["winloss_c"] != tmp_c_winloss){
                flag=false;
                ret.push("check faile c ["+c_data["username"]+"] winloss_c("+c_data["winloss_c"]+") != winloss_max - winloss_fix8 "+"("+tmp_c_winloss+")");
            }
        }
        if(flag)ret.push("check ok fix8 is Y");

    }else{
        ret.push("check ok fix8 is N"+"");
    }

    ret.push("2.股東成數(畫面) < 整線最小成數");

    var flag=true;
    for(var i=0;i<layerData[1].length;i++){
        var c_data=layerData[1][i];
        
        if(showAllCheck||c_data["winloss"] < other_set["conf_winloss_min"]){
            flag=false;
            ret.push("check faile c ["+c_data["username"]+"] winloss("+c_data["winloss"]+") < conf_winloss_min("+other_set["conf_winloss_min"]+")");
        }
    }
    if(flag)ret.push("check ok conf_winloss_min("+other_set["conf_winloss_min"]+")");

    ret.push("3.總監成數(畫面) + 股東成數(畫面) > 整線最大成數");

    var flag=true;
    for(var i=0;i<layerData[1].length;i++){
        var c_data=layerData[1][i];
        
        if(showAllCheck||c_data["winloss"]*1+c_data["winloss_sc"]*1 > other_set["conf_winloss_max"]){
            flag=false;
            ret.push("check faile c ["+c_data["username"]+"] winloss_sc("+c_data["winloss_sc"]+") + winloss("+c_data["winloss"]+") > conf_winloss_max("+ other_set["conf_winloss_max"]+")" );
        }
    }
    if(flag)ret.push("check ok conf_winloss_max("+other_set["conf_winloss_max"]+")");


    ret.push("4.總監成數(畫面) + 股東成數(畫面) < 整線最小成數");
    var flag=true;
    for(var i=0;i<layerData[1].length;i++){
        var c_data=layerData[1][i];
        
        if(showAllCheck||c_data["winloss"]+c_data["winloss_sc"] < other_set["conf_winloss_min"]){
            flag=false;
            ret.push("check faile c ["+c_data["username"]+"] winloss_sc("+c_data["winloss_sc"]+") + winloss("+c_data["winloss"]+") < conf_winloss_min("+ other_set["conf_winloss_max"]+")" );
        }
    }
    if(flag)ret.push("check ok conf_winloss_min("+other_set["conf_winloss_min"]+")");


    ret.push("5.股東最低佔成(畫面) > 股東最高佔成(畫面)");
    var flag=true;

    for(var i=0;i<layerData[1].length;i++){
        var c_data=layerData[1][i];
        
        var min_sw = c_data["winloss_min_sw"];
        var min_winloss =(min_sw=="N")?"0":c_data["winloss_min"];

        if(showAllCheck||min_winloss > c_data["winloss"]){
            flag=false;
            ret.push("check faile c ["+c_data["username"]+"] winloss_sc("+c_data["winloss_sc"]+") + winloss("+c_data["winloss"]+") < conf_winloss_min("+ other_set["conf_winloss_max"]+")" );
        }
    }
    if(flag)ret.push("check ok conf_winloss_min("+other_set["conf_winloss_min"]+")");

    
    ret.push("6.如果有股東強佔  co的 winloss_min_sw=Y  winloss_min=winloss");
    var flag=true;
    for(var i=0;i<layerData[1].length;i++){
        var c_data=layerData[1][i];

        var c_data_winloss = c_data["winloss"];
        var min_sw = c_data["winloss_min_sw"];
        var c_data_winloss_min = c_data["winloss_min"];
        if(min_sw=="Y" && c_data_winloss == c_data_winloss_min){ // 強佔
            var cid = c_data["id"];
            for(var k=0;k<layerData[2].length;k++){
                var s_data = layerData[2][k];
                if(s_data["cid"] == cid){
                    var sid=s_data["id"];
                    var s_back = s_data["back"];
                    var s_winloss_bak = s_data["winloss_bak"];
                    for(var j=0;j<layerData[3].length;j++){
                        var a_data = layerData[3][j];
                        var aid = a_data["id"];
                        if(a_data["sid"] == sid){
                            var allwinloss = a_data["winloss_c"]+a_data["winloss_s"]+a_data["winloss_a"];

                            if(s_back=="Y"){
                                if(showAllCheck|| allwinloss*1+s_winloss_bak*1 < c_data_winloss ){
                                    flag=false;
                                    ret.push("check faile a ["+a_data["username"]+"] allwinloss("+a_data["winloss_c"]+"+"+a_data["winloss_s"]+"+"+a_data["winloss_a"]+")+ s_winloss_bak("+s_winloss_bak+") < c_data_winloss("+c_data_winloss+")");
                                }
                            }else{
                                if(showAllCheck||allwinloss != c_data_winloss){
                                    flag=false;
                                    ret.push("check faile a ["+a_data["username"]+"] allwinloss("+a_data["winloss_c"]+"+"+a_data["winloss_s"]+"+"+a_data["winloss_a"]+") != c_data_winloss("+c_data_winloss+")");
                                }
                            }
                        }
                    }
                }
            }
        }else{
            flag=false;
            ret.push("check ok c ["+c_data["username"]+"] winloss_min_sw("+min_sw+")"+" winloss_min("+c_data_winloss_min+") != winloss("+c_data_winloss+")");
        }
    }
    if(flag)ret.push("check ok");



    ret.push("7.股東最低佔成(c.winloss_min) <= 股東成數(a.winloss_c)+總代成數(a.winloss_s)+代理成數(a.winloss_a) <= 股東佔成上限(c.winloss)");

    var flag=true;
    for(var i=0;i<layerData[1].length;i++){
        var c_data=layerData[1][i];
        var c_data_winloss = c_data["winloss"];
        // var c_data_winloss_min_sw = c_data["winloss_min_sw"];
        // var c_data_winloss_min = c_data["winloss_min"];
        var c_winkoss_min = (c_data["winloss_min_sw"]=="Y")?c_data["winloss_min"]:0;
        var cid = c_data["id"];
        for(var k=0;k<layerData[2].length;k++){
            var s_data = layerData[2][k];
            if(s_data["cid"] == cid){
                var sid=s_data["id"];
                var s_back = s_data["back"];
                var s_winloss_bak = s_data["winloss_bak"];
                for(var j=0;j<layerData[3].length;j++){
                    var a_data = layerData[3][j];
                    var aid = a_data["id"];
                    if(a_data["sid"] == sid){
                        var allwinloss = a_data["winloss_c"]+a_data["winloss_s"]+a_data["winloss_a"];
                        var tmp_res=0;
                        if(s_back=="Y"){
                            /*
                            c_winkoss_min // 強占最小
                            allwinloss // c+s+a
                            s_winloss_bak // s 回補
                            c_data_winloss // 股東下放總和
                            c_winkoss_min < allwinloss < c_data_winloss

                            if(c_winkoss_min > allwinloss && allwinloss > c_data_winloss)
                            */
                            tmp_res = c_data_winloss - allwinloss;
                            if(tmp_res > s_winloss_bak){
                                tmp_res = s_winloss_bak;
                            }
                        }
                        if(showAllCheck|| allwinloss*1+tmp_res*1 > c_data_winloss ){
                            flag=false;
                            ret.push("check faile a ["+a_data["username"]+"] allwinloss("+a_data["winloss_sc"]+"+"+a_data["winloss_c"]+"+"+a_data["winloss_s"]+"+"+a_data["winloss_a"]+")+ res("+tmp_res+") > c_data_winloss("+c_data_winloss+")");
                        }
                        if(showAllCheck|| c_winkoss_min > allwinloss*1+tmp_res*1  ){
                            flag=false;
                            ret.push("check faile a ["+a_data["username"]+"] allwinloss("+a_data["winloss_sc"]+"+"+a_data["winloss_c"]+"+"+a_data["winloss_s"]+"+"+a_data["winloss_a"]+")+ res("+tmp_res+") < c_winkoss_min("+c_winkoss_min+")");
                        }
                    }
                }
            }
        }
        
    }
    if(flag)ret.push("check ok");


    ret.push("0.限制最多只能到50%(客服直客需求) winloss_c*1> 50");
    flag=true;
    for(var i=0;i<layerData[2].length;i++){
        var s_data=layerData[2][i];
        if(showAllCheck||s_data["winloss_c"] > 50){
            flag=false;
            ret.push("check faile s ["+s_data["username"]+"] winloss_c("+s_data["winloss_c"]+") > 50");
        }
    }
    if(flag)ret.push("check ok");


    ret.push("1.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) > 整線最大成數");
    flag=true;
    for(var i=0;i<layerData[2].length;i++){
        var s_data=layerData[2][i];
        var all_winloss = s_data["winloss_sc"]*1+s_data["winloss_c"]*1+s_data["winloss"]*1;
        if(showAllCheck||all_winloss > other_set["conf_winloss_max"]){
            flag=false;
            ret.push("check faile s ["+s_data["username"]+"] all_winloss("+s_data["winloss_sc"]*1+" "+s_data["winloss_c"]*1+" "+s_data["winloss"]*1+") > conf_winloss_max("+other_set["conf_winloss_max"]+")");
        }
    }
    if(flag)ret.push("check ok");

    ret.push("2.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) < 整線最小成數");
    flag=true;
    for(var i=0;i<layerData[2].length;i++){
        var s_data=layerData[2][i];
        var all_winloss = s_data["winloss_sc"]*1+s_data["winloss_c"]*1+s_data["winloss"]*1;
        if(showAllCheck||all_winloss < other_set["conf_winloss_min"]){
            flag=false;
            ret.push("check faile s ["+s_data["username"]+"] all_winloss("+s_data["winloss_sc"]*1+" "+s_data["winloss_c"]*1+" "+s_data["winloss"]*1+") < conf_winloss_min("+other_set["conf_winloss_min"]+")");
        }
    }
    if(flag)ret.push("check ok");


    ret.push("3.股東最低佔成(c.winloss_min) <= 股東成數(畫面) + 總代成數(畫面) <= 股東佔成上限(c.winloss)");
    ret.push("  股東最低佔成(c.winloss_min) <= 股東成數(畫面)");
    flag=true;
    for(var i=0;i<layerData[2].length;i++){
        var s_data=layerData[2][i];
        var all_winloss = s_data["winloss_c"]*1+s_data["winloss"]*1;
        var cid = s_data["cid"];
        var c_data=all_data["c"+cid];
        var c_data_winloss_min = (c_data["winloss_min_sw"]=="Y")?c_data["winloss_min"]:0;

        if(showAllCheck||c_data_winloss_min > s_data["winloss_c"]){
            flag=false;
            ret.push("check faile s ["+s_data["username"]+"] c_data_winloss_min("+c_data_winloss_min+") > winloss_c("+s_data["winloss_c"]+")");
        }
        if(c_data_winloss_min < other_set["conf_winloss_min"]){
            c_data_winloss_min = other_set["conf_winloss_min"];
        }
        if(showAllCheck||c_data_winloss_min > all_winloss){
            flag=false;
            ret.push("check faile s ["+s_data["username"]+"] all_winloss("+s_data["winloss_sc"]*1+" "+s_data["winloss_c"]*1+" "+s_data["winloss"]*1+") < c_data_winloss_min("+c_data_winloss_min+")");
        }

        if(showAllCheck||all_winloss > c_data["winloss"]){
            flag=false;
            ret.push("check faile s ["+s_data["username"]+"] all_winloss("+s_data["winloss_sc"]*1+" "+s_data["winloss_c"]*1+" "+s_data["winloss"]*1+") < c_data_winloss("+c_data["winloss"]+")");
        }
    }
    if(flag)ret.push("check ok");
    
    ret.push("4.總代強佔下(su_agent.fix8)，總代成數(畫面) != 總代成數(a.winloss_s) + 代理成數(a.winloss_a) 檢查總代下代理的sa+a佔成有無佔滿");
    flag=true;
    for(var i=0;i<layerData[2].length;i++){
        var s_data=layerData[2][i];
        var sa_fix8 = s_data["fix8"];
        if(showAllCheck||sa_fix8 == "Y"){
            var sid = s_data["id"];
            for(var k=0;k<layerData[3].length;k++){
                var a_data=layerData[3][k];
                if(a_data["sid"] == sid){
                    var all_winloss = a_data["winloss_s"] + a_data["winloss_a"];
                    if(showAllCheck||all_winloss != s_data["winloss"]){
                        flag=false;
                        ret.push("check faile a ["+a_data["username"]+"] all_winloss("+a_data["winloss_s"]*1+" "+a_data["winloss_a"]*1+") != s_data_winloss("+s_data["winloss"]+")");
                    }
                }
            }
        }
    }
    if(flag)ret.push("check ok");


    ret.push("5.股東強佔下，檢查股東回補成數，不得小於總代+代理未佔滿成數");
    flag=true;
    for(var i=0;i<layerData[2].length;i++){
        var s_data=layerData[2][i];
        var sid = s_data["id"];
        var cid = s_data["cid"];
        var c_data = all_data["c"+cid];
        if(showAllCheck||c_data["winloss_min_sw"]=="Y" && c_data["winloss_min"] == c_data["winloss"]){
            var s_winloss_back = (s_data["back"]=="Y")?s_data["winloss_bak"]:0;
            
            for(var k=0;k<layerData[3].length;k++){
                var a_data = layerData[3][k];
                var aid=a_data["id"];
                if(a_data["sid"]==sid){
                    sum_winloss_csa = a_data["winloss_c"]*1+a_data["winloss_s"]*1+a_data["winloss_a"]*1;
                    if(showAllCheck||sum_winloss_csa+s_winloss_back*1 < s_data["winloss_c"]*1+s_data["winloss"]*1){
                        flag=false;
                        ret.push("check faile a ["+a_data["username"]+"] sum_winloss_csa("+sum_winloss_csa+") +s_winloss_back("+s_winloss_back+")  < winloss_c("+s_data["winloss_c"]+") + s_data_winloss ("+s_data["winloss"]+") ");
                    }
                }
            }
        }
    }
    if(flag)ret.push("check ok");

    ret.push("6.特殊股東(fix8)下，股東回歸成數拉霸檢查  強制回歸滿  檢查winloss_bak");
    flag=true;
    for(var i=0;i<layerData[2].length;i++){
        var s_data=layerData[2][i];
        var s_winloss = s_data["winloss"];
        var s_winloss_bak = (s_data["back"]=="Y")?s_data["winloss_bak"]:0;

        var sid = s_data["id"];
        var cid = s_data["cid"];
        var c_data = all_data["c"+cid];
        if(showAllCheck||c_data["fix8"]=="Y"){
            for(var k=0;k<layerData[3].length;k++){
                var a_data = layerData[3][k];
                var aid=a_data["id"];
                if(a_data["sid"]==sid){
                    if(showAllCheck||s_winloss*1 - a_data["winloss_s"]*1-a_data["winloss_a"]*1 > s_winloss_bak ){
                        flag=false;
                        ret.push("check faile a ["+a_data["username"]+"] s_winloss("+s_winloss+") - winloss_s("+a_data["winloss_s"]+") -winloss_a("+a_data["winloss_a"]+")  > s_winloss_bak("+s_winloss_bak+") ");
                    }
                }
            }
        }
    }
    if(flag)ret.push("check ok");

    ret.push("7.股東最低佔成(c.winloss_min) <= 股東成數(a.winloss_c)+總代成數(a.winloss_s)+代理成數(a.winloss_a) <= 股東佔成上限(c.winloss)");
    flag=true;
    for(var i=0;i<layerData[2].length;i++){
        var s_data = layerData[2][i];
        var cid = s_data["cid"];
        var c_data = all_data["c"+cid];
        var sid=s_data["id"];
        var s_back = s_data["back"];
        var s_winloss_bak = s_data["winloss_bak"];
        for(var j=0;j<layerData[3].length;j++){
            var a_data = layerData[3][j];
            var aid = a_data["id"];
            if(a_data["sid"] == sid){
                var allwinloss = a_data["winloss_c"]+a_data["winloss_s"]+a_data["winloss_a"];
                var tmp_res=0;
                if(s_back=="Y"){
                    tmp_res = c_data_winloss - allwinloss;
                    if(tmp_res > s_winloss_bak){
                        tmp_res = s_winloss_bak;
                    }
                }
                if(showAllCheck|| allwinloss*1+tmp_res*1 > c_data_winloss ){
                    flag=false;
                    ret.push("check faile a ["+a_data["username"]+"] allwinloss("+a_data["winloss_sc"]+"+"+a_data["winloss_c"]+"+"+a_data["winloss_s"]+"+"+a_data["winloss_a"]+")+ res("+tmp_res+") > c_data_winloss("+c_data_winloss+")");
                }
                if(showAllCheck|| c_winkoss_min > allwinloss*1+tmp_res*1  ){
                    flag=false;
                    ret.push("check faile a ["+a_data["username"]+"] allwinloss("+a_data["winloss_sc"]+"+"+a_data["winloss_c"]+"+"+a_data["winloss_s"]+"+"+a_data["winloss_a"]+")+ res("+tmp_res+") < c_winkoss_min("+c_winkoss_min+")");
                }
            }
        }
        
    }
    if(flag)ret.push("check ok");

    ret.push("1.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) > 整線最大成數");
    flag=true;
    for(var i=0;i<layerData[3].length;i++){
        var a_data = layerData[3][i];
        var a_all_winloss = a_data["winloss_sc"]*1+a_data["winloss_c"]*1+a_data["winloss_s"]*1+a_data["winloss_a"]*1;
        if(showAllCheck||a_all_winloss > other_set["conf_winloss_max"]){
            flag=false;
            ret.push("check faile a ["+a_data["username"]+"] a_all_winloss("+a_data["winloss_sc"]*1+" "+a_data["winloss_c"]*1+" "+a_data["winloss_s"]*1+" "+a_data["winloss_a"]*1+") > conf_winloss_max("+other_set["conf_winloss_max"]+")");
        }
    }
    if(flag)ret.push("check ok");
    //agent 

    ret.push("2.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) < 整線最小成數");
    flag=true;
    for(var i=0;i<layerData[3].length;i++){
        var a_data = layerData[3][i];
        var a_all_winloss = a_data["winloss_sc"]*1+a_data["winloss_c"]*1+a_data["winloss_s"]*1+a_data["winloss_a"]*1;
        if(showAllCheck||a_all_winloss < other_set["conf_winloss_min"]){
            flag=false;
            ret.push("check faile a ["+a_data["username"]+"] a_all_winloss("+a_data["winloss_sc"]*1+" "+a_data["winloss_c"]*1+" "+a_data["winloss_s"]*1+" "+a_data["winloss_a"]*1+") < conf_winloss_max("+other_set["conf_winloss_min"]+")");
        }
    }
    if(flag)ret.push("check ok");
    
    ret.push("3.總代成數(畫面) + 代理成數(畫面) > 總代開下來的成數(s.winloss) ");
    flag=true;
    for(var i=0;i<layerData[3].length;i++){
        var a_data = layerData[3][i];
        var sid = a_data["sid"];
        var sum_winloss_sa = a_data["winloss_s"]*1+a_data["winloss_a"]*1;
        var s_data = all_data["s"+sid];
        if(showAllCheck||sum_winloss_sa > s_data["winloss"]){
            flag=false;
            ret.push("check faile a ["+a_data["username"]+"] sum_winloss_sa("+a_data["winloss_s"]+" "+a_data["winloss_a"]+") >  s.winloss"+ s_data["winloss"]+" ");
        }
    }
    if(flag)ret.push("check ok");
    

    ret.push("4.股東強佔，股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) != 股東成數(c.winloss) ");
    ret.push("co的 winloss_min_sw='Y' and winloss=winloss_min  且 csa != co的winloss");
    flag=true;
    for(var i=0;i<layerData[3].length;i++){
        var a_data = layerData[3][i];
        var sid = a_data["sid"];
        var s_data = all_data["s"+sid];
        var cid = s_data["cid"];
        var c_data = all_data["c"+cid];

        var sum_winloss_csa = a_data["winloss_c"]*1+a_data["winloss_s"]*1+a_data["winloss_a"]*1;
        //強戰
        if(showAllCheck||c_data["winloss_min_sw"] == "Y" && c_data["winloss"] == c_data["winloss_min"]){
            if(showAllCheck|| sum_winloss_csa != c_data["winloss_min"]){
                flag=false;
                ret.push("check faile a ["+a_data["username"]+"] sum_winloss_csa("+a_data["winloss_c"]+" "+a_data["winloss_s"]+" "+a_data["winloss_a"]+") <  c.winloss_min"+ c_data["winloss_min"]+" ");
            }
        }
    }
    if(flag)ret.push("check ok");
    
    ret.push("5.股東最低佔成(c.winloss_min) <= 股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) <= 股東佔成上限(c.winloss)");
    flag=true;
    for(var i=0;i<layerData[3].length;i++){
        var a_data = layerData[3][i];
        var sid = a_data["sid"];
        var s_data = all_data["s"+sid];
        var cid = s_data["cid"];
        var c_data = all_data["c"+cid];
        var sum_winloss_csa = a_data["winloss_c"]*1+a_data["winloss_s"]*1+a_data["winloss_a"]*1;
        
        var c_winloss_min = (c_data["winloss_min_sw"]=="Y")?c_data["winloss_min"]*1:0;
        c_winloss_min = (c_winloss_min < other_set["conf_winloss_min"]*1)?c_winloss_min:other_set["conf_winloss_min"]
        if(showAllCheck || c_winloss_min > sum_winloss_csa ){
            flag=false;
            ret.push("check faile a ["+a_data["username"]+"] c_winloss_min("+c_winloss_min+") > sum_winloss_csa("+a_data["winloss_c"]+" "+a_data["winloss_s"]+" "+a_data["winloss_a"]+") ");
        }
        if(showAllCheck || sum_winloss_csa > c_data["winloss"] ){
            flag=false;
            ret.push("check faile a ["+a_data["username"]+"] sum_winloss_csa("+a_data["winloss_c"]+" "+a_data["winloss_s"]+" "+a_data["winloss_a"]+") > c.winloss("+c_data["winloss"]+")");
        }
    }
    if(flag)ret.push("check ok");

    ret.push("6.代理成數(畫面) < 平層代理層數");
    flag=true;
    for(var i=0;i<layerData[3].length;i++){
        var a_data = layerData[3][i];
        var aid = a_data["id"];
        for(var k=0;k<levelData.length;k++){
            var l_data = levelData[k];
            if( aid == l_data["up_aid"]){
                if(showAllCheck||l_data["winloss_a"] > a_data["winloss_a"]){
                    flag=false;
                    ret.push("check faile a ["+l_data["username"]+"] winloss("+l_data["winloss_a"]+") > ["+a_data["username"]+"] winloss("+a_data["winloss_a"]+")");
                }
            }
        }
    }
    if(flag)ret.push("check ok");

    //layer_agent 
    //1.down.winloss < winloss < up.winloss
    ret.push("1.up.winloss < 本層 winloss < 下層 winloss");
    flag=true;
    for(var k=0;k<levelData.length;k++){
        var a_data=levelData[k];
        var up_data=all_data["a"+a_data["up_aid"]];
        if(up_data!=null){
            if(showAllCheck||a_data["winloss_a"]*1 > up_data["winloss_a"]*1){
                flag=false;
                ret.push("check faile a ["+a_data["username"]+"] winloss("+a_data["winloss_a"]+") > ["+up_data["username"]+"] winloss("+up_data["winloss_a"]+")");
            }
        }
    }
    if(flag)ret.push("check ok");

    for(var i=0;i<ret.length;i++){
        var str=ret[i];
        if(str.indexOf("faile")!=-1){
            str = "<span class='"+faileCSS+"'>"+str+"</span>";
            ret[i] = str;
        }
    }
    //============
    //console.log(ret);
    var checkDiv_obj =document.getElementById("checkDiv");
    checkDiv_obj.innerHTML = ret.join(newLine);
    checkDiv_obj.style.display = "";
    //corp
    //1.特殊總監下，總監固定帶0.5成，股東固定帶9成，(client畫面鎖死)
    //2.股東成數(畫面) < 整線最小成數 
    //3.總監成數(畫面) + 股東成數(畫面) > 整線最大成數
    //4.總監成數(畫面) + 股東成數(畫面) < 整線最小成數
    //5.股東最低佔成(畫面) > 股東最高佔成(畫面)
    //6.如果有股東強佔  co的 winloss_min_sw=Y  winloss_min=winloss
    //勾股東回補，未佔滿成數(股東開下來的成數-(股東+總代+代理))需全部回股東。
    //未勾股東回補，股東+總代+代理需等於股東開下來的成數。
    //7.股東最低佔成(c.winloss_min) <= 股東成數(a.winloss_c)+總代成數(a.winloss_s)+代理成數(a.winloss_a) <= 股東佔成上限(c.winloss)

    //su_ag
    //0.限制最多只能到50%(客服直客需求) winloss_c*1> 50
    //1.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) > 整線最大成數
    //2.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) < 整線最小成數
    //3.股東最低佔成(c.winloss_min) <= 股東成數(畫面) + 總代成數(畫面) <= 股東佔成上限(c.winloss)
    //4.總代強佔下(su_agent.fix8)，總代成數(畫面) != 總代成數(a.winloss_s) + 代理成數(a.winloss_a) 檢查總代下代理的sa+a佔成有無佔滿
    //被拿掉 
	//5.股東強佔下，檢查股東回補成數，不得小於總代+代理未佔滿成數
    //6.特殊股東(fix8)下，股東回歸成數拉霸檢查  強制回歸滿  檢查winloss_bak
    //總代成數(su_agents.winloss)-總代成數(a.winloss_s)-代理成數(a.winloss_a) >＝ 股東回補成數(sa.winloss_bak)
    //7.股東最低佔成(c.winloss_min) <= 股東成數(a.winloss_c)+總代成數(a.winloss_s)+代理成數(a.winloss_a) <= 股東佔成上限(c.winloss)

    //agent  新增沒檢查
    //1.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) > 整線最大成數
    //2.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) < 整線最小成數
    //3.總代成數(畫面) + 代理成數(畫面) > 總代開下來的成數(s.winloss) 
    //4.股東強佔，股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) != 股東成數(c.winloss) 
    //  co的 winloss_min_sw='Y' and winloss=winloss_min  且 csa != co的winloss
    //5.股東最低佔成(c.winloss_min) <= 股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) <= 股東佔成上限(c.winloss)

}