<?php
include $_SERVER['DOCUMENT_ROOT']."/conf/config_admin.php";

if ($action == "") {
    include "winloss.html";
}else{
    
}
?>