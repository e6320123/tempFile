<?php
include $_SERVER['DOCUMENT_ROOT']."/conf/config_admin.php";
ob_start();
$debug_flag=true;

$idstr_ary = Array(); // layer id Array
$dbdata_ary = Array(); // layer 
$no_data_ary = Array();

//$layer_ary = Array("sc"=>"su_corp","c"=>"corprator","s"=>"su_agents","a"=>"agents","al"=>"agents");
$map_layer_num = Array("sc","c","s","a","m");
$map_layer_table = Array("su_corp","corprator","su_agents","agents","members");

$fieldStr_ary = Array(); // select field
// winloss_max
$fieldStr_ary["sc"] = "id,username,winloss,winloss_bak,fix8,winloss_max,winloss_fix8";
// winloss_sc	winloss winloss_min(股東最低佔成)	winloss_min_sw(股東最低佔成) winloss_occupy(股東強制佔成) back("") winloss_bak(0) fix8(N)
$fieldStr_ary["c"] = "id,username,scid,winloss_sc,winloss,winloss_min,winloss_min_sw,winloss_occupy,back,winloss_bak,fix8";
// winloss_sc winloss_c winloss back(股東回歸成數) winloss_bak(股東回歸成數) fix8(總代理強制佔成)
$fieldStr_ary["s"] = "id,username,cid,winloss_sc,winloss_c,winloss,back,winloss_bak,fix8";
// winloss_sc winloss_c winloss_s winloss_a
$fieldStr_ary["a"] = "id,username,top_aid,up_aid,level,sid,winloss_sc,winloss_c,winloss_s,winloss_a";

$fieldStr_ary["m"] = "id,username,aid";

$dbMAIN_R = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);
$dbMAIN_R2 = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);

if(empty($user_layer)) $user_layer = "sc"; // sc/c/s/a/al
$layer_num = array_search($user_layer,$map_layer_num);



if(empty($user_id)) {
    if(empty($user_username)){
        $user_id = "-1";//mid
    }else{
        $sql = "select * from ".$map_layer_table[$layer_num]." where username='".$user_username."'";
        echo $sql."<br>\n";
        $dbMAIN_R->query($sql,1);
        $user_id=$dbMAIN_R->f("id");
        if($user_id*1==0)$user_id=-1;
    }
}
$idstr_ary[$layer_num] = $user_id;

$user_id=$user_id*1;
if(!is_int($user_id*1) || $user_id == 0) $user_id = "10";


for($i=0;$i<count($map_layer_num);$i++){
    $v=$map_layer_num[$i];
    $next = $i+1;

    if($v=="m")continue;
    $v_next = $map_layer_num[$next];
    //echo $i." ".$v."<br>\n";
    if($i >= $layer_num){
        if($idstr_ary[$i]=="")continue;
        $sub_sql ="";
        if( $v_next!="m" && $v_next!="" )$sub_sql .= " and ".$v_next."id = 0";
        //if( $v_next == "a") $sub_sql .= " and id = top_aid";

        $sql = "select * from ".$map_layer_table[$next]." where ".$v."id in (".$idstr_ary[$i].") ".$sub_sql ;
        echo $sql."<br>\n";
        $dbMAIN_R->query($sql);
        $dbdata_ary[$next] = Array();
        $str = Array();
        while($dbMAIN_R->next_record()){
            //print_r($dbMAIN_R->record);
            $record=$dbMAIN_R->record;
            $record = getDBArrayByFieldString($record,$fieldStr_ary[$map_layer_num[$next]]);
            if($v_next=="a"){
                $no_data_ary[] = $record;
                if($record["top_aid"] == $record["id"]){
                    $dbdata_ary[$next][] = $record;   
                }
            }else{
                $dbdata_ary[$next][] = $record;
            }
            
            $str[] = $record["id"];
        }
        if(count($str)>0)$idstr_ary[$next]=implode(",",$str);
        // print_r($dbdata_ary[$i]);
    }
}
for($i=count($map_layer_num)-1;$i>=0;$i--){
    $v=$map_layer_num[$i];
    $v_1=$map_layer_num[$i-1];
    //echo $i." ".$v."<br>\n";
    if($i <= $layer_num){
        if($idstr_ary[$i]=="")continue;
        $sql = "select * from ".$map_layer_table[$i]." where id =".$idstr_ary[$i]."";
        echo $sql."<br>\n";
        $dbMAIN_R->query($sql);
        $dbdata_ary[$i] = Array();
        $str = Array();
        while($dbMAIN_R->next_record()){
            $have_data_flag=true;
            //print_r($dbMAIN_R->record);
            $record=$dbMAIN_R->record;
            $record = getDBArrayByFieldString($record,$fieldStr_ary[$v]);
            $dbdata_ary[$i][] = $record;
            $str[] = $record[$v_1."id"];
        }
        if(count($str)>0)$idstr_ary[$i-1]=implode(",",$str);
    }
}

function getAgLevelByAid($aid,$dbMAIN_R){
    $ret = Array();
    // $sql = "select * from agents where top_aid=".$aid." and aid=0 and type = 1 order by level asc";
    // $dbMAIN_R->query($sql);
    // $fieldStr = "id,sid,aid,top_aid,up_aid,winloss_a";
    // while($dbMAIN_R->next_record()){
    //     $db_data = getDBArrayByFieldString($dbMAIN_R->record,$fieldStr);
    //     $ret[$db_data["id"]] = Array();
    //     $ret[$db_data["id"]]["data"] = $db_data;
    // }
    return $ret;
}
function getDBArrayByFieldString($record,$str){
    $ret = Array();
    $ary=explode(",",$str);
    $len=count($ary);
    for($i=0;$i<$len;$i++){
        $key = $ary[$i];
        $ret[$key] = $record[$key];
    }
    return $ret;
}
$debug_str=ob_get_contents();
ob_end_clean();

$ret = Array();
if($have_data_flag){
    $ret["status"] = "success";
}else{
    $ret["status"] = "faile";
}
$ret["code"] = $action;
$ret["datas"] = $dbdata_ary;
$ret["level_datas"] = $no_data_ary;
if($debug_flag) $ret["debug"] =$debug_str;
echo json_encode($ret);
// echo "<script>\n";
// echo "var aa=".json_encode($dbdata_ary).";\n";
// echo "console.log(aa);\n";
// echo "</script>\n";
?>