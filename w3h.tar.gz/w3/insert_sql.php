<?php
# @Author: roland
# @Date:   2017-05-15T11:58:24+08:00
# @Last modified by:   roland
# @Last modified time: 2017-05-29T16:56:23+08:00



include("conf/config_admin.php");
/*
$db = new proc_DB(DB_HOST,DB_USER,DB_PWD,DB_NAME);
$dbr = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);
$dbFT = new proc_DB(DB_HOST_FT,DB_USER,DB_PWD,DB_NAME_FT);

http://ctlti566.cvssp2017.com/insert_sql.php?uid=75cc10df7f306782
*/
$co_ary = Array("scid","winloss_sc","winloss","winloss_min","winloss_min_sw","winloss_occupy","back","winloss_bak","fix8");
$su_ary = Array("cid","winloss_sc","winloss_c","winloss","back","winloss_bak","fix8");
$ag_ary = Array("sid","winloss_sc","winloss_c","winloss_s","winloss_a");


/*

sc_conf
id	scid	gtype	rtype	SC	SO	W_WAR	L_WAR	ST

co_conf
id	cid	gtype	rtype	SC	SO	W_WAR	L_WAR	ST

su_conf
id	sid	gtype	rtype	SC	SO	W_WAR	L_WAR

ag_conf
id	aid	gtype	rtype	SC	SO	W_WAR	L_WAR


mem_conf
id	mid	gtype	rtype	SC	SO	W_WAR	L_WAR
*/
/*
$W_WAR=90;
$L_WAR=90;
$ST = 20000;
*/



/*
$sql = "select * from su_corp where scid=0 ";
$dbr->query($sql);
while($dbr->next_record()){
  $f_id = $dbr->f("id");
  $sql="select * from sc_conf where gtype='GM' and scid =".$f_id;
  $db->query($sql);
  if(!$db->next_record()){
    $sql = "insert sc_conf set ";
    $sql .= "ST='".$ST."',gtype='GM',rtype='GM',scid = '".$f_id."',";
    $sql .= "SC='0',SO='0',";
    $sql .= "W_WAR='".$W_WAR."',L_WAR='".$L_WAR."'";
    echo $sql."<br>\n";
    // $db->query($sql);
  }

}


$sql = "select * from corprator where cid=0 ";
$dbr->query($sql);
while($dbr->next_record()){
  $f_id = $dbr->f("id");
  $sql="select * from co_winloss where cid =".$f_id;
  $db->query($sql);
  if(!$db->next_record()){
    $sql = "insert co_winloss set gtype='gm',cid = '".$f_id."'";
    foreach($co_ary as $key=>$val){
      $sql .= ",".$val." = '".$dbr->f($val)."'";
    }
    $sql .=";";
    echo $sql."<br>\n";
    //$db->query($sql);
  }

  $sql="select * from co_conf where gtype='GM' and cid =".$f_id;
  $db->query($sql);
  if(!$db->next_record()){
    $sql = "insert co_conf set ";
    $sql .= "ST='".$ST."',gtype='GM',rtype='GM',cid = '".$f_id."',";
    $sql .= "SC='0',SO='0',";
    $sql .= "W_WAR='".$W_WAR."',L_WAR='".$L_WAR."'";
    echo $sql."<br>\n";
    // $db->query($sql);
  }

}
$sql = "select * from su_agents where sid=0 ";
$dbr->query($sql);
while($dbr->next_record()){
  $f_id = $dbr->f("id");
  $sql="select * from su_winloss where sid =".$f_id;
  $db->query($sql);
  if(!$db->next_record()){
    $sql = "insert su_winloss set gtype='gm',sid = '".$f_id."'";
    foreach($su_ary as $key=>$val){
      $sql .= ",".$val." = '".$dbr->f($val)."'";
    }
    $sql .=";";
    echo $sql."<br>\n";
    //$db->query($sql);
  }
  $sql="select * from su_conf where gtype='GM' and sid =".$f_id;
  $db->query($sql);
  if(!$db->next_record()){
    $sql = "insert su_conf set ";
    $sql .= "gtype='GM',rtype='GM',sid = '".$f_id."',";
    $sql .= "SC='0',SO='0',";
    $sql .= "W_WAR='".$W_WAR."',L_WAR='".$L_WAR."'";
    echo $sql."<br>\n";
    // $db->query($sql);
  }
}
$sql = "select * from agents where aid=0 ";
$dbr->query($sql);
while($dbr->next_record()){
  $f_id = $dbr->f("id");
  $sql="select * from ag_winloss where aid =".$f_id;
  $db->query($sql);
  if(!$db->next_record()){
    $sql = "insert ag_winloss set gtype='gm',aid = '".$f_id."'";
    foreach($ag_ary as $key=>$val){
      $sql .= ",".$val." = '".$dbr->f($val)."'";
    }
    $sql .=";";
    echo $sql."<br>\n";
    //$db->query($sql);
  }
  $sql="select * from ag_conf where gtype='GM' and aid =".$f_id;
  $db->query($sql);
  if(!$db->next_record()){
    $sql = "insert ag_conf set ";
    $sql .= "gtype='GM',rtype='GM',aid = '".$f_id."',";
    $sql .= "SC='0',SO='0',";
    $sql .= "W_WAR='".$W_WAR."',L_WAR='".$L_WAR."'";
    echo $sql."<br>\n";
    // $db->query($sql);
  }

}

$sql = "select * from members where 1 ";
$dbr->query($sql);
while($dbr->next_record()){
  $f_id = $dbr->f("id");
  $sql="select * from mem_conf where gtype='GM' and mid =".$f_id;
  $db->query($sql);
  if(!$db->next_record()){
    $sql = "insert mem_conf set ";
    $sql .= "gtype='GM',rtype='GM',mid = '".$f_id."',";
    $sql .= "SC='0',SO='0',";
    $sql .= "W_WAR='".$W_WAR."',L_WAR='".$L_WAR."'";
    echo $sql."<br>\n";
    // $db->query($sql);
  }

}
*/

$sql = "select id,adddate from su_corp where 1";
$dbr->query($sql);
$i=0;
while($dbr->next_record()){
  $tmp[$i]["id"] = $dbr->f("id");
  $tmp[$i]["adddate"] = $dbr->f("adddate");
  $i++;
}

for($i=0;$i<count($tmp);$i++){
  $sql="select id from sc_right_table where scid='".$tmp[$i]["id"]."'";
  $dbr->query($sql,1);
  if($dbr->num_rows()*1>0) continue;
  $sql_sc=  "INSERT INTO sc_right_table set ";
  $sql_sc.= " scid='".$tmp[$i]["id"]."'";
  $sql_sc.= " ,content='ALL'";
  $sql_sc.= ",adddate='".$tmp[$i]["adddate"]."'";
  // $db->query($sql_sc);
  echo $sql_sc."\n";
}
echo "OK";
?>