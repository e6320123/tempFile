<?php
include ("../conf/config_ctl.php");

$tableId = $tableId;
$old_btid =  $old_btid;	//這是因為junket 已經將 BA_boot 該靴 壓成第一靴並且更新日期
$old_date =  $old_date;	//這是因為junket 已經將 BA_boot 該靴 壓成第一靴並且更新日期
//ex   http://ctlti566.cvssp2017.com/junket/movePicture.php?uid=19e2a6a571901c2e&tableId=21&old_btid=4&old_date=2019-04-24

$today = getdate();
$now_date_for_game_set = gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
// echo $now_date_for_game_set."/n<br>";
$dbimg_w = new proc_DB(DB_IMG_HOST_W,DB_IMG_USER,DB_IMG_PWD,DB_IMG_NAME);

if($old_date != $now_date_for_game_set){
	$sql = "SELECT id FROM BA WHERE `date` = '".$old_date."' AND `tbid` = '".$tableId."' AND `btid` = '".$old_btid."' AND `gmid` = '1' order by id DESC limit 1;";
	$dbFT->query($sql, 1);
	if ($dbFT->num_rows() == 1) {
		$startGid = $dbFT->f("id");
		$old_date_for_check=str_replace("-","", $old_date);
		for($minusDay = 1;$minusDay <= 3;$minusDay ++){
			$pre_date = gmdate("Ymd",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday] -$minusDay ,$today[year]));
			if($old_date_for_check *1 <= $pre_date *1){
				$newImgDate=str_replace("-","", $now_date_for_game_set);
				$picTableSql =  "CREATE TABLE IF NOT EXISTS `pic_".$newImgDate."` LIKE `pic`;";
				// echo $picTableSql."/n<br>";
				$dbimg_w->insert_id($picTableSql);
				$picsql = "INSERT IGNORE INTO `pic_".$newImgDate."` SELECT null, `tbid`, 1, `gmid`, `gid`, `result`, `content`, `pic_user`, `adddate` FROM `pic_".$pre_date."` where `tbid`=".$tableId." and `btid`=".$old_btid ." and `gid` >= ".$startGid." ;";
				// echo $picsql."/n<br>";
				$dbimg_w->insert_id($picsql);
			}else{
				break;
			}
		}
	}
}else{
    $sql = "SELECT id FROM BA WHERE `tbid` = '".$tableId."' AND `gmid` = '1' order by id DESC limit 1;";
	$dbFT->query($sql, 1);
	if ($dbFT->num_rows() == 1) {
		$startGid = $dbFT->f("id");
        $newImgDate=str_replace("-","", $now_date_for_game_set);
		$picTableSql =  "CREATE TABLE IF NOT EXISTS `pic_".$newImgDate."` LIKE `pic`;";
		// echo $picTableSql."/n<br>";
		$dbimg_w->insert_id($picTableSql);
		$picsql = "update `pic_".$newImgDate."` set btid=1 where `tbid`=".$tableId." and `btid`=".$old_btid ." and `gid` >= ".$startGid." ;";
		// echo $picsql."/n<br>";
		$dbimg_w->update_rows($picsql);
	}
}
?>