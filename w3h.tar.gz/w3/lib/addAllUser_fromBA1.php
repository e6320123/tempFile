<?php
include("../conf/config_admin_nouid.php");
include("../lib/pub_edit.php");
include("../lib/pub_admin.php");

$dbr_BA1 = new proc_DB(BA1_DB_HOST_R,DB_USER,DB_PWD,BA1_DB_NAME);
$db = new proc_DB(DB_HOST_R,DB_USER,DB_PWD,DB_NAME);

function add_i_before_username($username){
	return "i".$username;
}

$scid = "";
$useScid = "N";


$sc_id_ary = array();
if($useScid == "Y"){
	$tmpSql = "select id, username from su_corp where id ='".$scid."';";
	// echo $tmpSql."<br>\n";
	$dbr_BA1->query($tmpSql, 1);
	$sc_id = $dbr_BA1->f("id");
	$sc_username = $dbr_BA1->f("username");
	$ori_sc_username = $sc_username;
	$j = 0;
	while(true){
		$db->query("select * from su_corp where  username='".$sc_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$sc_username = add_i_before_username($sc_username);
		}else{
			echo "sc\t,\t".$sc_id."\t,\t".$ori_sc_username."\t,\t".$sc_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}else{
	$tmpSql = "select id, username from su_corp where 1;";
	// echo $tmpSql."<br>\n";
	$dbr_BA1->query($tmpSql);
	$ba1_acc_sc_num = $dbr_BA1->num_rows();
	$ba1_acc_sc_data = $dbr_BA1->get_total_data();
	for ($i=0; $i < $ba1_acc_sc_num; $i++) {
		$sc_id = $ba1_acc_sc_data[$i]["id"];
		$sc_username = $ba1_acc_sc_data[$i]["username"];
		$sc_id_ary[] = $sc_id;
		$ori_sc_username = $sc_username;
		$j = 0;
		while(true){
			$db->query("select * from su_corp where  username='".$sc_username."';");
			if($db->num_rows()!=0){
				$j ++;
				$sc_username = add_i_before_username($sc_username);
			}else{
				echo "sc\t,\t".$sc_id."\t,\t".$ori_sc_username."\t,\t".$sc_username."\t,\t".$j."<br>\n";
				break;
			}
		}
	}
}

$tmpSql = "select id, username from su_corp where scid in (".join(",",$sc_id_ary).");";
$dbr_BA1->query($tmpSql);
$ba1_acc_sc_num = $dbr_BA1->num_rows();
$ba1_acc_sc_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_sc_num; $i++) {
	$sc_id = $ba1_acc_sc_data[$i]["id"];
	$sc_username = $ba1_acc_sc_data[$i]["username"];
	$ori_sc_username = $sc_username;
	$j = 0;
	while(true){
		$db->query("select * from su_corp where  username='".$sc_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$sc_username = add_i_before_username($sc_username);
		}else{
			echo "SUB_sc\t,\t".$sc_id."\t,\t".$ori_sc_username."\t,\t".$sc_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}

$co_id_ary = array();
if($useScid == "Y"){
	$tmpSql = "select id, username from corprator where scid ='".$scid."';";
}else{
	$tmpSql = "select id, username from corprator where scid in (".join(",",$sc_id_ary).");";
}
// echo $tmpSql."<br>\n";
$dbr_BA1->query($tmpSql);
$ba1_acc_co_num = $dbr_BA1->num_rows();
$ba1_acc_co_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_co_num; $i++) {
	$co_id = $ba1_acc_co_data[$i]["id"];
	$co_username = $ba1_acc_co_data[$i]["username"];
	$co_id_ary[] = $co_id;
	$ori_co_username = $co_username;
	$j = 0;
	while(true){
		$db->query("select * from corprator where  username='".$co_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$co_username = add_i_before_username($co_username);
		}else{
			echo "co\t,\t".$co_id."\t,\t".$ori_co_username."\t,\t".$co_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}

$tmpSql = "select id, username from corprator where cid in (".join(",",$co_id_ary).");";
$dbr_BA1->query($tmpSql);
$ba1_acc_co_num = $dbr_BA1->num_rows();
$ba1_acc_co_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_co_num; $i++) {
	$co_id = $ba1_acc_co_data[$i]["id"];
	$co_username = $ba1_acc_co_data[$i]["username"];
	$ori_co_username = $co_username;
	$j = 0;
	while(true){
		$db->query("select * from corprator where  username='".$co_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$co_username = add_i_before_username($co_username);
		}else{
			echo "SUB_co\t,\t".$co_id."\t,\t".$ori_co_username."\t,\t".$co_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}

$sa_id_ary = array();
$tmpSql = "select id, username from su_agents where cid in (".join(",",$co_id_ary).");";
// echo $tmpSql."<br>\n";
$dbr_BA1->query($tmpSql);
$ba1_acc_sa_num = $dbr_BA1->num_rows();
$ba1_acc_sa_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_sa_num; $i++) {
	$sa_id = $ba1_acc_sa_data[$i]["id"];
	$sa_username = $ba1_acc_sa_data[$i]["username"];
	$sa_id_ary[] = $sa_id;
	$ori_sa_username = $sa_username;
	$j = 0;
	while(true){
		$db->query("select * from su_agents where  username='".$sa_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$sa_username = add_i_before_username($sa_username);
		}else{
			echo "sa\t,\t".$sa_id."\t,\t".$ori_sa_username."\t,\t".$sa_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}


$tmpSql = "select id, username from su_agents where sid in (".join(",",$sa_id_ary).");";
$dbr_BA1->query($tmpSql);
$ba1_acc_sa_num = $dbr_BA1->num_rows();
$ba1_acc_sa_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_sa_num; $i++) {
	$sa_id = $ba1_acc_sa_data[$i]["id"];
	$sa_username = $ba1_acc_sa_data[$i]["username"];
	$ori_sa_username = $sa_username;
	$j = 0;
	while(true){
		$db->query("select * from su_agents where  username='".$sa_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$sa_username = add_i_before_username($sa_username);
		}else{
			echo "SUB_sa\t,\t".$sa_id."\t,\t".$ori_sa_username."\t,\t".$sa_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}


$ag_id_ary = array();
$tmpSql = "select id, username from agents where sid in (".join(",",$sa_id_ary).");";
// echo $tmpSql."<br>\n";
$dbr_BA1->query($tmpSql);
$ba1_acc_ag_num = $dbr_BA1->num_rows();
$ba1_acc_ag_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_ag_num; $i++) {
	$ag_id = $ba1_acc_ag_data[$i]["id"];
	$ag_username = $ba1_acc_ag_data[$i]["username"];
	$ag_id_ary[] = $ag_id;

	$ori_ag_username = $ag_username;
	$j = 0;
	while(true){
		$db->query("select * from su_agents where  username='".$ag_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$ag_username = add_i_before_username($ag_username);
		}else{
			echo "ag\t,\t".$ag_id."\t,\t".$ori_ag_username."\t,\t".$ag_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}

$tmpSql = "select id, username from agents where aid in (".join(",",$ag_id_ary).");";
// echo $tmpSql."<br>\n";
$dbr_BA1->query($tmpSql);
$ba1_acc_ag_num = $dbr_BA1->num_rows();
$ba1_acc_ag_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_ag_num; $i++) {
	$ag_id = $ba1_acc_ag_data[$i]["id"];
	$ag_username = $ba1_acc_ag_data[$i]["username"];
	$ori_ag_username = $ag_username;
	$j = 0;
	while(true){
		$db->query("select * from su_agents where  username='".$ag_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$ag_username = add_i_before_username($ag_username);
		}else{
			echo "SUB_ag\t,\t".$ag_id."\t,\t".$ori_ag_username."\t,\t".$ag_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}

$tmpSql = "select id, username from members where aid in (".join(",",$ag_id_ary).");";
// echo $tmpSql."<br>\n";
$dbr_BA1->query($tmpSql);
$ba1_acc_mem_num = $dbr_BA1->num_rows();
$ba1_acc_mem_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_mem_num; $i++) {
	$mem_id = $ba1_acc_mem_data[$i]["id"];
	$mem_username = $ba1_acc_mem_data[$i]["username"];

	$ori_mem_username = $mem_username;
	$j = 0;
	while(true){
		$db->query("select * from members where  username='".$mem_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$mem_username = add_i_before_username($mem_username);
		}else{
			echo "mem\t,\t".$mem_id."\t,\t".$ori_mem_username."\t,\t".$mem_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}

//app/control/admin/subuser/subuser_edit.php?
// new_user: qua11444
// new_pass: a1234
// new_alias: a1234
// upname: qua
// active: 1
// ident: 0
// uid: 534dc10562ec7775
// npower: A,D,C,E
function addSubUser($userType) {	//Users/quanto/Git/TI/TI_Web_ctl/w3/app/control/admin/subuser/subuser_edit.php
	if ($active=="1") { // 新增
		// ===== Variable of Control_Record == Begin =====
		 $REC_level="1";					// 超帳
		 $REC_status="1";				// NOTE
		 $REC_action="1";				// 新增
		 $REC_table="record_ag";			// DB Table
		 $REC_sub_table="record_ag_sub";	// DB sub_Table
		 // ===== Variable of Control_Record == End =======
		$today=getdate();
		$today_gmt=gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
		$now_gmt=gmdate("H:i:s",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
		$adddate=$today_gmt." ".$now_gmt;
	
		$dbr->query("select id from ".$table[$ident]." where username='".$new_user."'");
		if ($dbr->num_rows()>0){ // 帳號已有人使用
			up_alert($LVar["Err_account"]);
			exit;
		}
		$dbr->query("select * from ".$table[$ident]." where username='".$upname."'",1);
		if ($dbr->num_rows()==0){ // 母帳號不存在
			up_alert($str_acc_ext);
			exit;
		}
	
		$upid=$dbr->f("id");
	
		$ins_sql  = "INSERT INTO ".$table[$ident];
		$ins_sql .= " set ".$level[$ident]."='". $upid."',";
		$ins_sql .= "username='".$new_user."',";
		$ins_sql .= "password=PASSWORD('".$new_pass."'),";
		$ins_sql .= "passwd='".$new_pass."',";
		$ins_sql .= "alias='".$new_alias."',";
		$ins_sql .= "enable='Y',";
		$ins_sql .= "type='3',";
		if($ident=="3" || $ident=="5"){
			$top_aid = $dbr->f("top_aid");
			$up_aid = $dbr->f("up_aid");
			$level = $dbr->f("level");
			$ins_sql .= "top_aid='".$top_aid."',";
			$ins_sql .= "up_aid='".$up_aid."',";
			$ins_sql .= "level='".$level."',";
		}
		$ins_sql .= "adddate='".$adddate."',";
		$ins_sql .= "LOA='".$npower."';";
		$ins_sql .= "SELECT LAST_INSERT_ID() AS sub_id;";
		if(chk_sql($ins_sql)==0){
			$error_msg="system err"	;
			up_alert($error_msg);
			exit;
		}
		$db->muti_query($ins_sql);
		$sub_id=$db->f("sub_id");
	
		$record_rid=ctrl_record($db,$REC_table,$uid,$REC_level,$REC_status,$REC_action,"新增 [子帳號] [子帳號ID=".$sub_id."], 主帳號資料為 [".rtnSubLev($level[$ident])."ID=".$upid."]");
		ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,"新增 [子帳號] [子帳號ID=".$sub_id."] 帳號 : username=".$new_user.", PW=".$new_pass.", alias=".$new_alias.", ".$field_type."=1, enable=Y, 新增日期=".$adddate." LOA=".$npower,$ins_sql);
		header("location:./get_data.php?uid=$uid&upid=$upid&langx=$langx&actions=YES&ident=$ident");exit;
	}
}

// /app/control/admin/SC/body_sucorp_add.php
// uid: 534dc10562ec7775
// langx: zh-tw
// mid: undefined
// action: add
// currency: 1:
// maxcredit: 0
// cash: 1234567
// username: qqua
// password: a1234
// repassword: a1234
// alias: qqua
// max_mem: 
// OK: 新增
function sucorpAdd($currency, $maxcredit, $cash, $username, $password, $alias, $max_mem){
	if (empty($c_back)) $c_back='M';
	if (empty($term_cash)) $term_cash='N';
	if (empty($xratio)) $xratio=0;
	if (empty($multiple)) $multiple=99;
	$cash = SetDecimal($cash,2);

	//==========================================================================================================原本if裡面的東西
	$REC_level='1';						// 超帳
 	$REC_status='1';						// NOTE
 	$REC_action='1';						// 新增
 	$REC_table='record_ag';				// DB Table
 	$REC_sub_table='record_ag_sub';	// DB sub_Table
	$setHash = Array();
	$winloss_max = "90";

	chk_account("su_corp",$dbr,$username);	 //檢查是否有己有人用此帳號

	$dbr->query("select name,text from other_set where name in('total_max_mem','conf_winloss_max');");//0923,Leslie
	while ($dbr->next_record()) {
			$setHash[$dbr->f('name')] = $dbr->f('text');
	}

	if (isset($setHash["conf_winloss_max"])) {
			$winloss_max = $setHash["conf_winloss_max"];
	}

	if (isset($setHash["total_max_mem"])) {
			$total = $setHash["total_max_mem"];
			$dbr->query("select sum(max_mem)as max_mem from su_corp",1);
			$use_mem=$dbr->f('max_mem');
			if ($max_mem+$use_mem>$total) {
					err_msg($tpl,$str_over.$str_web_max_mem.$total."!!");
					exit;
			}
	}
	$adddate=get_adddate();
	$qstr = "INSERT INTO su_corp set scid='0',";
	$qstr.= "username='".$username."',";
	$qstr.= "password=PASSWORD('".$password."'),";
	$qstr.= "passwd='".$repassword."',";
	$qstr.= "alias='".addslashes($alias)."',";
	$qstr.= "enable='Y',type='1',";
	//$qstr.= "maxcredit='".$maxcredit."',";
	$qstr.= "cash='".$cash."',";
	$qstr.= "winloss='0',";
	$qstr.= "adddate='".$adddate."',";
	$qstr.= "max_mem='9999',";
	$qstr.= "c_back='".$c_back."',";
	$qstr.= "term_cash='".$term_cash."',";
	$qstr.= "xratio='".$xratio."',";
	$qstr.= "winloss_max='".$winloss_max."',";  //0923,Leslie
	$qstr.= "multiple='".$multiple."'";
	if ($currency)	$qstr.= ",currency='".$currency."'";

	$qstr.=";";
	$record_qstr=$qstr;
	$qstr.="SELECT LAST_INSERT_ID() AS acc_id;";
	$db->muti_query($qstr);
	$scid=$db->f('acc_id');
	$record_rid=ctrl_record($db,$REC_table,$uid,$REC_level,$REC_status,$REC_action,"新增 [總監ID=".$scid."] 帳號及群組 的 [基本資料]");
	ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,"新增 [總監ID=".$scid."] 帳號 : NAME=".$username.", PW=".$password.", 暱稱=".$alias.", 可用點數=".$cash.", 會員人數限制=".$max_mem.", 回歸成數=".$rest,$record_qstr);

	$db->query("SELECT ".$scid." as scid,gtype,rtype,SC,SO,W_WAR,L_WAR,200000 as ST  FROM conf_def");
	$conf_data = $db->get_total_data();
	for ($j=0;$j < count($conf_data);$j++) {
		$sql_sc=  "INSERT INTO sc_conf set ";
		$sql_sc.= " scid='".$conf_data[$j]["scid"]."'";
		$sql_sc.= ",gtype='".$conf_data[$j]["gtype"]."'";
		$sql_sc.= ",rtype='".$conf_data[$j]["rtype"]."'";
		$sql_sc.= ",SC='".$conf_data[$j]["SC"]."'";
		$sql_sc.= ",SO='".$conf_data[$j]["SO"]."'";
		$sql_sc.= ",W_WAR='".$conf_data[$j]["W_WAR"]."'";
		$sql_sc.= ",L_WAR='".$conf_data[$j]["L_WAR"]."'";
		$sql_sc.= ",ST='".$conf_data[$j]["ST"]."'";
		ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,"新增 [總監ID=".$scid."]"."[".$conf_data[$j]["gtype"]."][".$conf_data[$j]["rtype"]."] 的 [詳細設定]",$sql_sc);
		$db->query($sql_sc);
	}
	$show_table = explode(",",$selecttable);
	$maxTable = get_table_count("BA",$db);
	if(count($show_table)==0||!$show_table||$selecttable=="") $show_table_str="None";
	else if(count($show_table)==$maxTable*1) $show_table_str="ALL";
	else{
		$show_table_str = implode(",",$show_table);
	}
	if ($cash > 0)  Write_Cash_Record("su_corp",$MEM_DATA['username'],$db,$scid,$cash,"0","RMB","H","CTL",$_SERVER["REMOTE_ADDR"],"","","");
}

// /app/control/admin/C/body_corprator_add.php
// adddate: {ADDDATE}
// uid: 534dc10562ec7775
// action: add
// up_sel: 
// langx: zh-tw
// mid: undefined
// items: 
// currency: 1:
// maxcredit: 0
// cash: 234567
// scid: 122
// searchname: q
// username: qqua
// password: a1234
// repassword: a1234
// alias: qqan
// max_mem: 
// winloss_sc: 10	總監上限
// winloss_gm_sc: 0
// winloss_c: 15	股東上限
// winloss_gm_c: 0

// 另外可以有這個
// winloss_min_sw: Y	股東最低佔成 Y
// winloss_min: 10		股東最低佔成

// OK: 新增
function corpratorAdd($currency, $maxcredit, $cash, $scid, $searchname, $username, $password, $alias, $max_mem, $winloss_sc, $winloss_gm_sc, $winloss_c, $winloss_gm_c, $winloss_min_sw, $winloss_min){			///Users/quanto/Git/TI/TI_Web_ctl/w3/app/control/admin/C/body_corprator_add.php
	if (empty($c_back)) $c_back='M';
	if (empty($term_cash)) $term_cash='N';
	if (empty($xratio)) $xratio=0;
	if (empty($multiple)) $multiple=99;
	if(!empty($winloss_sc))$winloss_sc=abs($winloss_sc);
	if(!empty($winloss_c))$winloss_c=abs($winloss_c);
	if(!empty($winloss_min))$winloss_min=abs($winloss_min);
	if(!empty($winloss_gm_sc))$winloss_gm_sc=abs($winloss_gm_sc);
	if(!empty($winloss_gm_c))$winloss_gm_c=abs($winloss_gm_c);
	if(!empty($winloss_gm_min))$winloss_gm_min=abs($winloss_gm_min);

	$wlgm = Array();
	$wlgm["winloss_sc"] = $winloss_gm_sc;
	$wlgm["winloss_c"] = $winloss_gm_c;
	$wlgm["winloss_min_sw"] = $winloss_gm_min_sw;
	$wlgm["winloss_min"] = $winloss_gm_min;


	$cash = SetDecimal($cash,2);
	$chk_min_sw = $_REQUEST["winloss_min_sw"]; //1217,Leslie,新增股東最低佔成
	$chk_min = $_REQUEST["winloss_min"];
	$wlgm["chk_min_sw"] = $_REQUEST["winloss_gm_min_sw"];
	$wlgm["chk_min"] = $_REQUEST["winloss_gm_min"];

	//==========================================================================================================原本if裡面的東西
	// ===== Variable of Control_Record == Begin =====
	$REC_level='1';						// 超帳
	$REC_status='1';						// NOTE
	$REC_action='1';						// 新增
	$REC_table='record_ag';				// DB Table
	$REC_sub_table='record_ag_sub';	// DB sub_Table
	// ===== Variable of Control_Record == End =======

   chk_account("corprator",$dbr,$username);
   chk_mem($dbr,1,$id,$scid,$max_mem);
   chk_lowlevel_mem("corprator",$id,$dbr,$max_mem);
   chk_uplevel_cash("corprator",$scid,$dbr,$cash);

   //----------- 0926,Leslie -----------
   $up_level = "0";
   $up_id = $scid;
   $sc_hash = get_fix_sc($dbr,$up_level,Array($up_id));
   $tmp_id = $up_level."_".$up_id;
   $winloss_max = get_fix_sc_f($sc_hash,$tmp_id,"winloss_max");
   $winloss_min = get_fix_sc_f($sc_hash,$tmp_id,"winloss_min");
   $wlgm["winloss_max"] = get_fix_sc_f($sc_hash,$tmp_id,"gm_winloss_max");
   $wlgm["winloss_min"] = get_fix_sc_f($sc_hash,$tmp_id,"gm_winloss_min");
   $sc_fix8 = get_fix_sc_f($sc_hash,$tmp_id,"fix8");


   //1.特殊總監下，總監固定帶0.5成，股東固定帶9成，(client畫面鎖死)
   if ($sc_fix8=="Y") {
		   $winloss_sc = get_fix_sc_f($sc_hash,$tmp_id,"winloss_fix8");
		   $winloss_c = $winloss_max*1-$winloss_sc*1;
		   $wlgm["winloss_c"] = $gm_winloss_max*1-$winloss_sc*1;
		   //$chkbox_winloss = "Y";

		   //1217,Leslie,新增股東最低佔成
		   $chk_min_sw = "Y";
		   $chk_min = $winloss_c;
		   $wlgm["chk_min_sw"] = "Y";
		   $wlgm["chk_min"] = $wlgm["winloss_c"];
   }

   //2.股東成數(畫面) < 整線最小成數
   if ($winloss_c*1 < $winloss_min*1) {
		   err_msg($tpl,$str_corprator.$str_small_winloss.$winloss_min."%~~".$str_afresh_sel);
		   //股東成數不可小於XX%~~請重新選擇
		   exit;
   }
   if ($wlgm["winloss_c"]*1 < $wlgm["winloss_min"]*1) {
		   err_msg($tpl,$LVar["GM"]." ".$str_corprator.$str_small_winloss.$wlgm["winloss_min"]."%~~".$str_afresh_sel);
		   //股東成數不可小於XX%~~請重新選擇
		   exit;
   }
   //3.總監成數(畫面) + 股東成數(畫面) > 整線最大成數
   if ($winloss_sc*1 + $winloss_c*1 > $winloss_max*1) {
		   err_msg($tpl,$str_max_winloss.$winloss_max."%~~".$str_afresh_sel);
		   //超過總成數最大值XX%~~請重新選擇
		   exit;
   }
   if ($wlgm["winloss_sc"]*1 + $wlgm["winloss_c"]*1 > $wlgm["winloss_max"]*1) {
		   err_msg($tpl,$LVar["GM"]." ".$str_max_winloss.$wlgm["winloss_max"]."%~~".$str_afresh_sel);
		   //超過總成數最大值XX%~~請重新選擇
		   exit;
   }
   //4.總監成數(畫面) + 股東成數(畫面) < 整線最小成數
   if ($winloss_sc*1 + $winloss_c*1 < $winloss_min*1) {
		   err_msg($tpl,$str_min_winloss.$winloss_min."%~~".$str_afresh_sel);
		   //小於總成數最小值XX%~~請重新選擇
		   exit;
   }
   if ($wlgm["winloss_sc"]*1 + $wlgm["winloss_c"]*1 < $wlgm["winloss_min"]*1) {
		   err_msg($tpl,$LVar["GM"]." ".$str_min_winloss.$wlgm["winloss_min"]."%~~".$str_afresh_sel);
		   //小於總成數最小值XX%~~請重新選擇
		   exit;
   }
   //-----------------------------------

   $adddate=get_adddate();

   //1217,Leslie,新增股東最低佔成
   $chk_min_sw = format_winloss_sw($chk_min_sw);
   $chk_min = ($chk_min_sw=="N")?"0":format_winloss($chk_min);
   $winloss_occupy = checkOccupy($chk_min_sw,$winloss_c,$chk_min);

   $wlgm["chk_min_sw"] = format_winloss_sw($wlgm["chk_min_sw"]);
   $wlgm["chk_min"] = ($wlgm["chk_min_sw"]=="N")?"0":format_winloss($wlgm["chk_min"]);
   $wlgm["winloss_occupy"] = checkOccupy($wlgm["chk_min_sw"],$wlgm["winloss_c"],$wlgm["chk_min"]);

   //5.股東最低佔成(畫面) > 股東最高佔成(畫面)
   if ($chk_min*1 > $winloss_c*1) {
		   err_msg($tpl,$str_co_min_more_max);
		   //股東最低佔成不得高於股東佔成上限
		   exit;
   }
   if ($wlgm["chk_min"]*1 > $wlgm["winloss_c"]*1) {
		   err_msg($tpl,$LVar["GM"]." ".$str_co_min_more_max);
		   //股東最低佔成不得高於股東佔成上限
		   exit;
   }

   $qstr = "INSERT INTO corprator set scid='".$scid."',";
   $qstr.="cid='0',";
   $qstr.="username='".$username."',";
   $qstr.="password=PASSWORD('".$password."'),";
   $qstr.="passwd='".$password."',";
   $qstr.="alias='".addslashes($alias)."',";
   $qstr.="enable='Y',";
   $qstr.="type='1',";
   //$qstr.="maxcredit='".$maxcredit."',";
   $qstr.="cash='".$cash."',";
   $qstr.="winloss_sc='".$winloss_sc."',";
   $qstr.="winloss='".$winloss_c."',";
   $qstr.="winloss_min_sw='".$chk_min_sw."',"; //1217,Leslie,新增股東最低佔成
   $qstr.="winloss_min='".$chk_min."',";
   $qstr.="adddate='".$adddate."',";
   $qstr.="max_mem ='9999',";
   $qstr.="term_cash='".$term_cash."',";
   $qstr.="xratio='".$xratio."',";
   $qstr.="multiple='".$multiple."',";
   $qstr.="c_back='".$c_back."',";
   $qstr.="back='".$rest."'";
   $qstr.= ",winloss_occupy='".$winloss_occupy."'";
   //if ($chkbox_winloss!="") $qstr.= ",winloss_occupy='Y'";
   //else $qstr.= ",g='N'";

   if ($currency)	$qstr.= ",currency='".$currency."'";
   if ($rest=='Y') {
		   $qstr.=",winloss_bak='".$winloss_bak."'";
   }
   $qstr.=";";
   $record_qstr=$qstr;
   //echo $qstr;
   $qstr.="SELECT LAST_INSERT_ID() AS acc_id;";
   $db->muti_query($qstr);
   $cid=$db->f('acc_id');

   $qstr_gm = "Insert co_winloss set gtype = 'gm'";
   $qstr_gm.= ",scid = '".$scid."'";
   $qstr_gm.= ",cid = '".$cid."'";
   $qstr_gm.= ",winloss_sc = '".$wlgm["winloss_sc"]."'";
   $qstr_gm.= ",winloss = '".$wlgm["winloss_c"]."'";
   $qstr_gm.= ",winloss_min = '".$wlgm["chk_min"]."'";
   $qstr_gm.= ",winloss_min_sw = '".$wlgm["chk_min_sw"]."'";
   $qstr_gm.= ",winloss_occupy = '".$wlgm["winloss_occupy"]."'";
   $qstr_gm.= ",back = '".$rest."'";
   if ($rest=='Y') {
		   $qstr_gm.=",winloss_bak='".$winloss_bak."'";
   }
   //$qstr.= ",fix8	 = '".$wlgm[""]."'";
   $record_qstr.=$qstr_gm;
   $db->query($qstr_gm);

   $record_rid=ctrl_record($db,$REC_table,$uid,$REC_level,$REC_status,$REC_action,"新增 [股東ID=".$cid."] 帳號及群組 的 [基本資料]");
   $ctrl_sub_str = "新增 [股東ID=".$cid."] 帳號=".$username.", 密碼=".$password.", 暱稱=".$alias.", 可用點數=".$cash.", 總監佔成數=".$winloss_sc.", 股東佔成數=".$winloss_c.", 股東最低佔成開關=".$chk_min_sw.", 股東最低佔成數=".$chk_min.", 會員人數限制=".$max_mem.",股東強制佔成=".$winloss_occupy;
   $ctrl_sub_str+= "電動總監佔成數=".$wlgm["winloss_sc"].", 電動股東佔成數=".$wlgm["winloss_c"].", 電動股東最低佔成開關=".$wlgm["chk_min_sw"].", 電動股東最低佔成數=".$wlgm["chk_min"].",電動股東強制佔成=".$wlgm["winloss_occupy"];
   ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,$ctrl_sub_str,$record_qstr);

   $db->query("SELECT ".$cid." as cid,gtype,rtype,SC,SO,W_WAR,L_WAR,ST FROM sc_conf where scid='".$scid."'");
   $conf_data = $db->get_total_data();
   for ($j=0;$j < count($conf_data);$j++) {
	   $sql_sc=  "INSERT INTO co_conf set ";
	   $sql_sc.= " cid='".$conf_data[$j]["cid"]."'";
	   $sql_sc.= ",gtype='".$conf_data[$j]["gtype"]."'";
	   $sql_sc.= ",rtype='".$conf_data[$j]["rtype"]."'";
	   $sql_sc.= ",SC='".$conf_data[$j]["SC"]."'";
	   $sql_sc.= ",SO='".$conf_data[$j]["SO"]."'";
	   $sql_sc.= ",W_WAR='".$conf_data[$j]["W_WAR"]."'";
	   $sql_sc.= ",L_WAR='".$conf_data[$j]["L_WAR"]."'";
	   $sql_sc.= ",ST='".$conf_data[$j]["ST"]."'";
	   ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,"新增 [股東ID=".$cid."] "."[".$conf_data[$j]["gtype"]."][".$conf_data[$j]["rtype"]."] 的 [詳細設定]".", 所屬 [總監ID=".$scid."]",$sql_sc);
	   $db->query($sql_sc);
   }

   if ($cash > 0)  updateCash($db,"corprator",$cid,$scid,$cash,$cash,"RMB",$MEM_DATA['username'],$username,"H","L","CTL");
}


// /app/control/admin/S/body_su_agents_add.php
// uid: 534dc10562ec7775
// mid: undefined
// suname: qqan
// langx: zh-tw
// action: add
// currency: 1:
// maxcredit: 0
// cash: 34567
// cid: 123
// searchname: qq
// setusername: qan
// password: a1234
// repassword: a1234
// alias: qqan
// max_mem: 
// rest: N
// gm_rest: N
// winloss_c: 4			//股東上限
// winloss_gm_c: 0
// winloss_s: 11		//總代上限
// winloss_gm_s: 0

// 另外還有
// sa_fix8: Y				//總代強制佔成		

// OK: 新增

function suagentAdd($suname, $currency, $maxcredit, $cash, $cid, $searchname, $setusername, $password, $alias, $max_mem, $rest, $gm_rest,  $winloss_c, $winloss_gm_c, $winloss_s, $winloss_gm_s, $sa_fix8){
	if (empty($c_back)) $c_back='M';
	if (empty($term_cash)) $term_cash='N';
	if (empty($xratio)) $xratio=0;
	if (empty($multiple)) $multiple=99;

	if (empty($sa_fix8))  $sa_fix8_str="N";
	else                 $sa_fix8_str="Y";

	if(!empty($winloss_bak))$winloss_bak=abs($winloss_bak);
	if(!empty($winloss_c))$winloss_c=abs($winloss_c);
	if(!empty($winloss_s))$winloss_s=abs($winloss_s);
	if(!empty($winloss_gm_bak))$winloss_gm_bak=abs($winloss_gm_bak);
	if(!empty($winloss_gm_c))$winloss_gm_c=abs($winloss_gm_c);
	if(!empty($winloss_gm_s))$winloss_gm_s=abs($winloss_gm_s);

	$wlgm = Array();
	$wlgm["winloss_bak"] = $winloss_gm_bak;
	$wlgm["rest"] = $gm_rest;
	$wlgm["winloss_c"] = $winloss_gm_c;
	$wlgm["winloss_s"] = $winloss_gm_s;

	if (empty($gm_sa_fix8))  $wlgm["sa_fix8_str"]="N";
	else                 $wlgm["sa_fix8_str"]="Y";


	//==========================================================================================================原本if裡面的東西
	// ===== Variable of Control_Record == Begin =====
	$REC_level='1';						// 超帳
	$REC_status='1';						// NOTE
	$REC_action='1';						// 新增
	$REC_table='record_ag';				// DB Table
	$REC_sub_table='record_ag_sub';	// DB sub_Table
	// ===== Variable of Control_Record == End =======
   chk_account("su_agents",$dbr,$suname);
   chk_mem($dbr,2,$id,$cid,$max_mem);
   chk_lowlevel_mem("su_agents",$id,$dbr,$max_mem);
   chk_uplevel_cash("su_agents",$cid,$dbr,$cash);


   //----------- 0926,Leslie -----------
   $up_level = "1";
   $up_id = $cid;
   $up_name = $str_corprator;
   $up_table = "corprator";
   $sc_hash = get_fix_sc($dbr,$up_level,Array($up_id));
   $tmp_id = $up_level."_".$up_id;
   $winloss_max = get_fix_sc_f($sc_hash,$tmp_id,"winloss_max");
   $winloss_min = get_fix_sc_f($sc_hash,$tmp_id,"winloss_min");
   $wlgm["winloss_max"] = get_fix_sc_f($sc_hash,$tmp_id,"gm_winloss_max");
   $wlgm["winloss_min"] = get_fix_sc_f($sc_hash,$tmp_id,"gm_winloss_min");

   $sql="select winloss_sc,winloss,winloss_min,winloss_min_sw from ".$up_table." where id='".$up_id."' limit 1;";
   $dbr->query($sql,1);
   $up_winloss = $dbr->f('winloss');
   $up_winloss_sc = $dbr->f('winloss_sc');
   $up_winloss_min = $dbr->f('winloss_min');
   $up_winloss_min_sc = $dbr->f('winloss_min_sc');
   $winloss_sc = $dbr->f('winloss_sc');  //總代層不能修改總監成數

   $sql="select winloss_sc,winloss,winloss_min,winloss_min_sw from co_winloss where cid='".$up_id."' limit 1;";
   $dbr->query($sql,1);
   $wlgm["up_winloss"] = $dbr->f('winloss');
   $wlgm["up_winloss_sc"] = $dbr->f('winloss_sc');
   $wlgm["up_winloss_min"] = $dbr->f('winloss_min');
   $wlgm["up_winloss_min_sc"] = $dbr->f('winloss_min_sc');
   $wlgm["winloss_sc"] = $dbr->f('winloss_sc');  //總代層不能修改總監成數

   //1.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) > 整線最大成數
   if ($winloss_sc*1+$winloss_c*1+$winloss_s*1 > $winloss_max*1) {
		   err_msg($tpl,$str_max_winloss.$winloss_max."%~~".$str_afresh_sel);
		   //超過總成數最大值XX%~~請重新選擇
		   exit;
   }
   if ($wlgm["winloss_sc"]*1+$wlgm["winloss_c"]*1+$wlgm["winloss_s"]*1 > $wlgm["winloss_max"]*1) {
		   err_msg($tpl,$LVar["GM"]." ".$str_max_winloss.$wlgm["winloss_max"]."%~~".$str_afresh_sel);
		   //超過總成數最大值XX%~~請重新選擇
		   exit;
   }

   //2.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) < 整線最小成數
   if ($winloss_sc*1+$winloss_c*1+$winloss_s*1 < $winloss_min*1) {
		   err_msg($tpl,$str_min_winloss.$winloss_min."%~~".$str_afresh_sel);
		   //小於總成數最小值XX%~~請重新選擇
		   exit;
   }
   if ($wlgm["winloss_sc"]*1+$wlgm["winloss_c"]*1+$wlgm["winloss_s"]*1 < $wlgm["winloss_min"]*1) {
		   err_msg($tpl,$LVar["GM"]." ".$str_min_winloss.$wlgm["winloss_min"]."%~~".$str_afresh_sel);
		   //小於總成數最小值XX%~~請重新選擇
		   exit;
   }
   /*
   //3.股東成數(畫面) + 總代成數(畫面) != 股東開下來的成數(c.winloss)
   if (($winloss_c*1 + $winloss_s*1) != $up_winloss*1) {
		   $tmp_winloss = ($langx=='en-us')? $up_winloss:$up_winloss*1/10;
		   err_msg($tpl,$str_corprator."+".$str_su_agents.$str_equal.$str_winloss_canused.$tmp_winloss.$str_prasent);
		   //股東+總代必需等於可使用成數XX成
		 exit;
   }
   //4.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) != 總監成數(c.winloss_sc) + 股東開下來的成數(c.winloss)
   if (($winloss_sc*1 + $winloss_c*1 + $winloss_s*1) != ($up_winloss_sc*1 + $up_winloss*1)) {
		   $tmp_winloss = ($langx=='en-us')? ($up_winloss_sc*1+$up_winloss*1):($up_winloss_sc*1+$up_winloss*1)/10;
		   err_msg($tpl,$str_cor_winloss.$tmp_winloss.$str_prasent);
		   //必需等於成數XX成
		   exit;
   }
   */

   //3.股東最低佔成(c.winloss_min) <= 股東成數(畫面) + 總代成數(畫面) <= 股東佔成上限(c.winloss)
   //1217,Leslie 新增股東最低佔成
   $tmp_wl = $winloss_c*1 + $winloss_s*1;
   if ($tmp_wl > $up_winloss*1) {
		   err_msg($tpl,$str_corprator."+".$str_su_agents.$str_bigger_than.$str_corprator.$str_winloss_max."1");
		   //股東+總代大於股東佔成上限
		 exit;
   }

   if ($tmp_wl < $up_winloss_min*1) {
		   err_msg($tpl,$str_corprator."+".$str_su_agents.$str_small.$str_corprator.$str_winloss_min);
		   //股東+總代小於股東最低佔成
		 exit;
   }

   $wlgm["tmp_wl"] = $wlgm["winloss_c"]*1 + $wlgm["winloss_s"]*1;
   if ($wlgm["tmp_wl"] > $wlgm["up_winloss"]*1) {
		   err_msg($tpl,$LVar["GM"]." ".$str_corprator."+".$str_su_agents.$str_bigger_than.$str_corprator.$str_winloss_max);
		   //股東+總代大於股東佔成上限
		   exit;
   }

   if ($wlgm["tmp_wl"] < $wlgm["up_winloss_min"]*1) {
		   err_msg($tpl,$LVar["GM"]." ".$str_corprator."+".$str_su_agents.$str_small.$str_corprator.$str_winloss_min);
		   //股東+總代小於股東最低佔成
		   exit;
   }


   //-----------------------------------

   $adddate=get_adddate();
   $qstr="insert into su_agents set cid='".$cid."',";
   $qstr.="sid='0',";
   $qstr.="username='".$suname."',";
   $qstr.="password=PASSWORD('".$password."'),";
   $qstr.="passwd='".$repassword."',";
   $qstr.="alias='".addslashes($alias)."',";
   $qstr.="enable='Y',";
   $qstr.="type='1',";
   //$qstr.="maxcredit='".$maxcredit."',";
   $qstr.="cash='".$cash."',";
   $qstr.="winloss_sc='".$winloss_sc."',";
   $qstr.="winloss_c='".$winloss_c."',";
   $qstr.="winloss='".$winloss_s."',";
   $qstr.="adddate='".$adddate."',";
   $qstr.="term_cash='".$term_cash."',";
   $qstr.="c_back='".$c_back."',";
   $qstr.="fix8='".$sa_fix8_str."',";
   $qstr.="xratio='".$xratio."',";
   $qstr.="multiple='".$multiple."',";
   $qstr.="back='".$rest."',";

   if ($rest=='Y') {
		   $qstr.="winloss_bak='".$winloss_bak."',";
   }
   if ($currency)	$qstr.= "currency='".$currency."',";
   $qstr.="max_mem='9999';";
   $record_qstr=$qstr;
   $qstr.="SELECT LAST_INSERT_ID() AS acc_id;";

   $db->muti_query($qstr);
   $sid=$db->f('acc_id');

   $qstr_gm="insert into su_winloss set gtype='gm' ,cid='".$cid."',";
   $qstr_gm.="sid='".$sid."',";
   $qstr_gm.="winloss_sc='".$wlgm["winloss_sc"]."',";
   $qstr_gm.="winloss_c='".$wlgm["winloss_c"]."',";
   $qstr_gm.="winloss='".$wlgm["winloss_s"]."',";
   $qstr_gm.="back='".$wlgm["rest"]."',";
   if ($wlgm["rest"]=='Y') {
		   $qstr_gm.="winloss_bak='".$wlgm["winloss_bak"]."',";
   }
   $qstr_gm.="fix8='".$wlgm["sa_fix8_str"]."' ";
   $record_qstr.=$qstr_gm;
   $db->query($qstr_gm);

   $record_rid=ctrl_record($db,$REC_table,$uid,$REC_level,$REC_status,$REC_action,"新增 [總代理ID=".$sid."] 帳號及群組 的 [基本資料]");
   $ctrl_sub_str = "新增 [總代理ID=".$sid."] 帳號 : NAME=".$suname.", 所屬股東 id=".$cid.", PW=".$password.", 暱稱=".$alias.", 可用點數=".$cash.", 總監佔成=".$winloss_sc.", 股東佔成=".$winloss_c.", 總代理佔成=".$winloss_s.", 會員人數限制=".$max_mem.", 總代理強制佔成=".$sa_fix8_str;
   $ctrl_sub_str .= ", 電動總監佔成=".$wlgm["winloss_sc"].", 電動股東佔成=".$wlgm["winloss_c"].", 電動總代理佔成=".$wlgm["winloss_s"].", 電動總代理強制佔成=".$wlgm["sa_fix8_str"];
   ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,$ctrl_sub_str,$record_qstr);

   $db->query("SELECT ".$sid." as sid,gtype,rtype,SC,SO,W_WAR,L_WAR FROM co_conf where cid='".$cid."'");
   $conf_data = $db->get_total_data();
	for ($j=0;$j < count($conf_data);$j++) {
		$sql_sc=  "INSERT INTO su_conf set ";
		$sql_sc.= " sid='".$conf_data[$j]["sid"]."'";
		$sql_sc.= ",gtype='".$conf_data[$j]["gtype"]."'";
		$sql_sc.= ",rtype='".$conf_data[$j]["rtype"]."'";
		$sql_sc.= ",SC='".$conf_data[$j]["SC"]."'";
		$sql_sc.= ",SO='".$conf_data[$j]["SO"]."'";
		$sql_sc.= ",W_WAR='".$conf_data[$j]["W_WAR"]."'";
		$sql_sc.= ",L_WAR='".$conf_data[$j]["L_WAR"]."'";
		ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,"新增 [總代理ID=".$sid."]"."[".$conf_data[$j]["gtype"]."][".$conf_data[$j]["rtype"]."] 的 [詳細設定]".", 所屬 [股東ID=".$cid."]",$sql_sc);
		$db->query($sql_sc);
	}
   if ($cash > 0)  updateCash($db,"su_agents",$sid,$cid,$cash,$cash,"RMB",$MEM_DATA['username'],$suname,"H","L","CTL");
}

// /app/control/admin/A/body_agents_add.php
// uid: 534dc10562ec7775
// agname: qquanto
// langx: zh-tw
// mid: 
// action: add
// currency: 1:
// maxcredit: 0
// cash: 4567
// sid: 153
// searchname: qq
// username: uanto
// password: a1234
// repassword: a1234
// alias: qquanto
// max_mem: 
// winloss_sc: 10		//總監佔成
// winloss_gm_sc: 0
// winloss_c: 4		//股東佔成
// winloss_gm_c: 0
// winloss_s: 6		//總代佔成
// winloss_gm_s: 0
// winloss_a: 5		//代理佔成
// winloss_gm_a: 0
// OK: 新增

function agentAdd($agname, $currency, $maxcredit, $cash, $sid, $searchname, $username, $password, $alias, $max_mem, $winloss_sc, $winloss_gm_sc, $winloss_c, $winloss_gm_c, $winloss_s, $winloss_gm_s, $winloss_a, $winloss_gm_a){
	if (empty($c_back)) $c_back='M';
	if (empty($term_cash)) $term_cash='N';
	if (empty($xratio)) $xratio=0;
	if(!empty($winloss_sc)) $winloss_sc = abs($winloss_sc);
	if(!empty($winloss_c)) $winloss_c = abs($winloss_c);
	if(!empty($winloss_s)) $winloss_s = abs($winloss_s);
	if(!empty($winloss_a)) $winloss_a = abs($winloss_a);
	if(!empty($winloss_gm_sc)) $winloss_gm_sc = abs($winloss_gm_sc);
	if(!empty($winloss_gm_c)) $winloss_gm_c = abs($winloss_gm_c);
	if(!empty($winloss_gm_s)) $winloss_gm_s = abs($winloss_gm_s);
	if(!empty($winloss_gm_a)) $winloss_gm_a = abs($winloss_gm_a);

	$close_item = true; // 預設開啟改代理設定

	$cash = SetDecimal($cash,2);
	$winloss_c_post = $winloss_c;

	$wlgm=Array();

	$wlgm["winloss_sc"] = $winloss_gm_sc;
	$wlgm["winloss_c"] = $winloss_gm_c;
	$wlgm["winloss_s"] = $winloss_gm_s;
	$wlgm["winloss_a"] = $winloss_gm_a;
	$wlgm["winloss_c_post"] = $winloss_gm_c;

	//==========================================================================================================原本if裡面的東西

	// ===== Variable of Control_Record == Begin =====
	$REC_level='1';					// 超帳
	$REC_status='1';				// NOTE
	$REC_action='1';				// 新增
	$REC_table='record_ag';			// DB Table
	$REC_sub_table='record_ag_sub';	// DB sub_Table
	// ===== Variable of Control_Record == End =======
   chk_account("agents",$dbr,$agname);
   //chk_credit($dbr,3,'',$sid,$maxcredit,$max_mem); //檢查上層的信用額度及會員人數
   chk_mem($dbr,3,$id,$sid,$max_mem);
   chk_lowlevel_mem("agents",$id,$dbr,$max_mem);
   chk_uplevel_cash("agents",$sid,$dbr,$cash);

   //----------- 0926,Leslie -----------
   $up_level = "2";
   $up_id = $sid;
   $up_name = $str_su_agents;
   $up_table = "su_agents";
   $sc_hash = get_fix_sc($dbr,$up_level,Array($up_id));
   $tmp_id = $up_level."_".$up_id;
   $winloss_max = get_fix_sc_f($sc_hash,$tmp_id,"winloss_max");
   $winloss_min = get_fix_sc_f($sc_hash,$tmp_id,"winloss_min");
 $wlgm["winloss_max"] = get_fix_sc_f($sc_hash,$tmp_id,"gm_winloss_max");
   $wlgm["winloss_min"] = get_fix_sc_f($sc_hash,$tmp_id,"gm_winloss_min");
 $dbr->query("select cid,winloss_sc,winloss_c,winloss from su_agents where id=".$sid,1);
   $cid = $dbr->f("cid");
   $winloss_sc=$dbr->f('winloss_sc');
   $db_winloss_c=$dbr->f('winloss_c');
 $up_winloss = $dbr->f('winloss');


 $sql="select winloss_sc,winloss_c,winloss from su_winloss where sid='".$sid."' limit 1;";
   $dbr->query($sql,1);
 $wlgm["winloss_sc"]=$dbr->f('winloss_sc');
 $wlgm["db_winloss_c"]=$dbr->f('winloss_c');
 $wlgm["up_winloss"] = $dbr->f('winloss');

   //1.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) > 整線最大成數
   if ($winloss_sc*1+$winloss_c*1+$winloss_s*1+$winloss_a*1 > $winloss_max*1) {
		   err_msg($tpl,$str_max_winloss.$winloss_max."%~~".$str_afresh_sel);
		   //超過總成數最大值XX%~~請重新選擇
		   exit;
   }
 if ($wlgm["winloss_sc"]*1+$wlgm["winloss_c"]*1+$wlgm["winloss_s"]*1+$wlgm["winloss_a"]*1 > $wlgm["winloss_max"]*1) {
		   err_msg($tpl,$LVar["GM"]." ".$str_max_winloss.$wlgm["winloss_max"]."%~~".$str_afresh_sel);
		   //超過總成數最大值XX%~~請重新選擇
		   exit;
   }


   //2.總監成數(畫面) + 股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) < 整線最小成數
   if ($winloss_sc*1+$winloss_c*1+$winloss_s*1+$winloss_a*1 < $winloss_min*1) {
		   err_msg($tpl,$str_min_winloss.$winloss_min."%~~".$str_afresh_sel);
		   //小於總成數最小值XX%~~請重新選擇
		   exit;
   }
 if ($wlgm["winloss_sc"]*1+$wlgm["winloss_c"]*1+$wlgm["winloss_s"]*1+$wlgm["winloss_a"]*1 < $wlgm["winloss_min"]*1) {
	 err_msg($tpl,$LVar["GM"]." ".$str_min_winloss.$winloss_min."%~~".$str_afresh_sel);
	 //小於總成數最小值XX%~~請重新選擇
	 exit;
 }


   //3.總代成數(畫面) + 代理成數(畫面) > 總代開下來的成數(s.winloss)
   if (($winloss_s*1+$winloss_a*1) > $up_winloss*1) {
	 echo $winloss_s." ".$winloss_a." > ".$up_winloss;
		   err_msg($tpl,$str_than_winloss.$up_name.$str_max_win."1");
		   //成數設定不可大於總代理最大成數
		 exit;
   }
 if (($wlgm["winloss_s"]*1+$wlgm["winloss_a"]*1) > $wlgm["up_winloss"]*1) {
		   err_msg($tpl,$LVar["GM"]." ".$str_than_winloss.$up_name.$str_max_win."2");
		   //成數設定不可大於總代理最大成數
		 exit;
   }

   //-----------------------------------




   //4.股東強佔，股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) != 股東成數(c.winloss)
   if (!chk_winloss_occupy($dbr,$sid,$winloss_c_post + $winloss_s + $winloss_a)) {
		   //echo "c=".$winloss_c_post." s=".$winloss_s." a=".$winloss_a."<br>";
	 $db->query("select winloss from corprator where id='".$cid."' and winloss_occupy='Y';",1);
		   err_msg($tpl,$LVar['Err_chk_co_winloss3'].$db->f('winloss')."%");
		   //股東+總代成數+代理成數必須等於XX%
		   exit;
   }

 if (!chk_other_winloss_occupy($dbr,$sid,$wlgm["winloss_c_post"] + $wlgm["winloss_s"] + $wlgm["winloss_a"],"gm")) {
		   //echo "c=".$winloss_c_post." s=".$winloss_s." a=".$winloss_a."<br>";
	 $db->query("select winloss from co_winloss where cid='".$cid."' and winloss_occupy='Y';",1);
		   err_msg($tpl,$LVar["GM"]." ".$LVar['Err_chk_co_winloss3'].$db->f('winloss')."%");
		   //股東+總代成數+代理成數必須等於XX%
		   exit;
   }
   //chk_fix8($dbr,$cid,$id,$winloss_bak);



   //5.股東最低佔成(c.winloss_min) <= 股東成數(畫面) + 總代成數(畫面) + 代理成數(畫面) <= 股東佔成上限(c.winloss)
   //1217,Leslie 新增股東最低佔成
   $total = util_floorNumber($winloss_c*1 + $winloss_s*1 + $winloss_a*1);
   $ret = chk_co_max_min($db, $sid, $total);
   if ($ret["err"]=="max") {
		   err_msg($tpl,$str_corprator."+".$str_su_agents."+".$str_agents.$str_bigger_than.$ret["winloss"].$str_prasent);
		   //股東+總代+代理大於max成
		 exit;
   }
   if ($ret["err"]=="min") {
		   err_msg($tpl,$str_corprator."+".$str_su_agents."+".$str_agents.$str_small.$ret["winloss"].$str_prasent);
		   //股東+總代+代理小於min成
		 exit;
   }

 $wlgm["total"] = util_floorNumber($wlgm["winloss_c"]*1 + $wlgm["winloss_s"]*1 + $wlgm["winloss_a"]*1);
 $wlgm["ret"] = chk_other_co_max_min($db, $sid, $wlgm["total"],"gm");
 if ($wlgm["ret"]["err"]=="max") {
	 err_msg($tpl,$LVar["GM"]." ".$str_corprator."+".$str_su_agents."+".$str_agents.$str_bigger_than.$wlgm["ret"]["winloss"].$str_prasent);
	 //股東+總代+代理大於max成
	 exit;
 }
 if ($wlgm["ret"]["err"]=="min") {
	 err_msg($tpl,$LVar["GM"]." ".$str_corprator."+".$str_su_agents."+".$str_agents.$str_small.$wlgm["ret"]["winloss"].$str_prasent);
	 //股東+總代+代理小於min成
	 exit;
 }

   $adddate=get_adddate();
   $qstr="insert into agents set sid='".$sid."',";
   $qstr.="aid='0',";
   $qstr.="top_aid = id,";
   $qstr.="up_aid = '0',";
   $qstr.="level = '0',";
   $qstr.="username='".$agname."',";
   $qstr.="password=PASSWORD('".$password."'),";
   $qstr.="passwd='".$repassword."',";
   $qstr.="alias='".addslashes($alias)."',";
   $qstr.="enable='Y',";
   $qstr.="type='1',";
   //$qstr.="maxcredit='".$maxcredit."',";
   $qstr.="cash='".$cash."',";
   $qstr.="winloss_sc='".$winloss_sc."',";
   //$qstr.="winloss_c='".$winloss_c."',";
   //畫面有加回補成數，寫回db要用原始值
   $qstr.="winloss_c='".$db_winloss_c."',";
   $qstr.="winloss_s='".$winloss_s."',";
   $qstr.="winloss_a='".$winloss_a."',";
   $qstr.="adddate='".$adddate."',";
   $qstr.="term_cash='".$term_cash."',";
   $qstr.="c_back='".$c_back."',";
   $qstr.="xratio='".$xratio."',";
   $qstr.="multiple='".$multiple."',";
   if ($currency)	$qstr.= "currency='".$currency."',";
   $qstr.="max_mem='9999'";
   $qstr.= ",grp='1';";
   $record_qstr=$qstr;
   $qstr.="SELECT LAST_INSERT_ID() AS acc_id;";
   $db->muti_query($qstr);
   $aid=$db->f('acc_id');

   $qstr = "UPDATE agents SET top_aid='".$aid."' where id = '".$aid."';";
   $db->query($qstr);

 $qstr_gm = "insert into ag_winloss set sid='".$sid."',  gtype='gm',  aid='".$aid."',";
 $qstr_gm.="winloss_sc='".$wlgm["winloss_sc"]."',";
 $qstr_gm.="winloss_c='".$wlgm["db_winloss_c"]."',";
 $qstr_gm.="winloss_s='".$wlgm["winloss_s"]."',";
 $qstr_gm.="winloss_a='".$wlgm["winloss_a"]."' ";
 $record_qstr.=$qstr_gm;
 $db->query($qstr_gm);

   $record_rid=ctrl_record($db,$REC_table,$uid,$REC_level,$REC_status,$REC_action,"新增 [代理商ID=".$aid."] 帳號及群組 的 [基本資料]");
 $ctrl_sub_str = "新增 [代理商ID=".$aid."] 帳號 : NAME=".$agname.", 所屬總代理 id=".$sid.", PW=".$password.", Alias=".$alias.", 可用點數=".$cash.", 總監佔成=".$winloss_sc.", 股東佔成=".$db_winloss_c.", 總代理佔成=".$winloss_s.", 代理商佔成=".$winloss_a.", 會員人數限制=".$max_mem.", 中國聯賽佔成=".$ga;
 $ctrl_sub_str.= "電動總監佔成=".$wlgm["winloss_sc"].", 電動股東佔成=".$wlgm["db_winloss_c"].", 電動總代理佔成=".$wlgm["winloss_s"].", 電動代理商佔成=".$wlgm["winloss_a"].",詳細設定群組=1";
   ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,$ctrl_sub_str,$record_qstr);

   $db->query("SELECT ".$aid." as aid,gtype,rtype,SC,SO,W_WAR,L_WAR FROM su_conf where sid='".$sid."'");
   $conf_data = $db->get_total_data();
   if($api=="isapi")$grp_max=6;
   else $grp_max=1;
   for($grp=1;$grp<=$grp_max;$grp++){
	   for ($j=0;$j < count($conf_data);$j++) {
		   $sql_sc=  "INSERT INTO ag_conf set ";
		   $sql_sc.= " aid='".$conf_data[$j]["aid"]."'";
		   $sql_sc.= ",gtype='".$conf_data[$j]["gtype"]."'";
		   $sql_sc.= ",rtype='".$conf_data[$j]["rtype"]."'";
		   $sql_sc.= ",SC='".$conf_data[$j]["SC"]."'";
		   $sql_sc.= ",SO='".$conf_data[$j]["SO"]."'";
		   $sql_sc.= ",W_WAR='".$conf_data[$j]["W_WAR"]."'";
		   $sql_sc.= ",L_WAR='".$conf_data[$j]["L_WAR"]."'";
		   $sql_sc.= ",grp='".$grp."'";
		   ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,"新增 [代理商ID=".$aid."]"."[".$conf_data[$j]["gtype"]."][".$conf_data[$j]["rtype"]."] 的 [詳細設定] [".$grp."]".", 所屬 [總代理ID=".$sid."]",$sql_sc);
		   $db->query($sql_sc);
	   }
   }

   if ($cash > 0)  updateCash($db,"agents",$aid,$sid,$cash,$cash,"RMB",$MEM_DATA['username'],$agname,"H","L","CTL");
}

// /app/control/admin/M/body_members_add.php
// id: {ID}
// enable: Y
// uid: 534dc10562ec7775
// memname: qquanto		//這才是真的塞進去的	
// langx: zh-tw
// mmid: 
// action: add
// cvalue: 10000
// maxcredit: 567			//金額
// cash: 0
// aid: 616
// searchname: qq
// username: anto
// password: a1234
// repassword: a1234
// alias: qquanto
// currency: RMB
// multiple: 77777			//最多可以贏的金額
// scso: 1					//固定1
// vip: 0
// OK: 新增

function memberAdd($enable, $memname, $cvalue, $maxcredit, $cash, $aid, $searchname, $username, $password, $alias, $currency, $multiple, $scso, $vip){
	if(empty($c_back)) $c_back='M';
	if(empty($xratio)) $xratio=0;
	if(empty($scso)) $scso=1;
	if(empty($multiple))  $multiple=0;
	$cur_value = $cvalue/10000;
	$cash = SetDecimal($cash,2);
	$pay_type=$pay_type;
	if($pay_type=='1'){
		$pay_type='1';
	}else {
		$pay_type='0';
	}

	//==========================================================================================================原本if裡面的東西
	// ===== Variable of Control_Record == Begin =====
	$REC_level='1';						// 超帳
	$REC_status='1';						// NOTE
	$REC_action='1';						// 新增
	$REC_table='record_ag';				// DB Table
	$REC_sub_table='record_ag_sub';	// DB sub_Table
	// ===== Variable of Control_Record == End =======
   $grp=1;
   $grp1=1;
   /*/檢查是否有己有人用此帳號*/
   chk_account("members",$dbr,$memname);
   chk_uplevel_cash("members",$aid,$dbr,($maxcredit*1+$cash*1)*$cur_value);

   $top_aid = getTop_aid($dbr,$aid);
   /*/日期時間*/
   $adddate=get_adddate();;
   $today_gmt=substr($adddate,0,10);
   $dbr->query("SELECT sid,winloss_sc,winloss_c,winloss_s,winloss_a,xratio,grp from agents where id='".$top_aid."'",1);
   $sid=$dbr->f('sid');
   $grp=$dbr->f('grp'); //除了api代理有差別外 其他預設都是1 api代理沒有平行代理
   $winloss_sc=$dbr->f('winloss_sc');
   $winloss_c=$dbr->f('winloss_c');
   $winloss_s=$dbr->f('winloss_s');
   $winloss_a=$dbr->f('winloss_a');
   $xratio_a=$dbr->f('xratio');
   $dbr->query("SELECT cid,xratio from su_agents where id='".$sid."'",1);
   $cid=$dbr->f('cid');
   $xratio_s=$dbr->f('xratio');
   $dbr->query("SELECT scid,xratio from corprator where id='".$cid."'",1);
   $scid=$dbr->f('scid');
   $xratio_c=$dbr->f('xratio');
   $dbr->query("SELECT xratio from su_corp where id='".$scid."'",1);
   $xratio_sc=$dbr->f('xratio');
   /*/新增*/
   $qstr = "INSERT INTO members set username='".$memname."',";
   $qstr .= "password=PASSWORD('".$password."'),";
   $qstr .= "passwd='".$password."',";
   $qstr .= "alias='".addslashes($alias)."',";
   $qstr .= "enable='Y',";
   $qstr .= "chk='0',";
   $qstr .= "top_aid='".$top_aid."',";
   $qstr .= "aid='".$aid."',";
   $qstr .= "maxcredit='".$maxcredit."',";
   $qstr .= "cash='".$cash."',";
   if($pay_type=="1"){
	   $qstr .= "cash_return='0',";
   }else {
	   $qstr .= "cash_return='8',";
   }
   $qstr .= "multiple='".$multiple."',";
   $qstr .= "scso='".$scso."',";
   $qstr .= "c_back='".$c_back."',";
   $qstr .= "xratio='".$xratio."',";
   $qstr .= "vip='".$vip."',";
   $qstr .= "adddate='".$adddate."',";
   $qstr .= "grp='".$grp."';";
	 $record_qstr=$qstr;
   $qstr.="SELECT LAST_INSERT_ID() AS acc_id;";
   $db->muti_query($qstr);
   $mid=$db->f('acc_id');
   $record_rid=ctrl_record($db,$REC_table,$uid,$REC_level,$REC_status,$REC_action,"新增 [會員ID=".$mid."] 帳號及群組 的 [基本資料]");
   ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,"新增 [會員ID=".$mid."] 帳號 :  NAME=".$memname.", PW=".$password.", Alias=".$alias.", 信用額度=".$maxcredit.", 可用點數=".$cash.", wagers=".$wagers.", 新增日期=".$adddate.", 預設詳細設定群組=".$grp,$record_qstr);

   $qstr = "INSERT INTO mem_winloss set mid='".$mid."',";
   $qstr .= "aid='".$top_aid."',";
   $qstr .= "sid='".$sid."',";
   $qstr .= "cid='".$cid."',";
   $qstr .= "scid='".$scid."',";
   $qstr .= "winloss_a='".$winloss_a."',";
   $qstr .= "winloss_s='".$winloss_s."',";
   $qstr .= "winloss_c='".$winloss_c."',";
   $qstr .= "winloss_sc='".$winloss_sc."',";
   $qstr .= "xratio_sc='".$xratio_sc."',";
   $qstr .= "xratio_c='".$xratio_c."',";
   $qstr .= "xratio_s='".$xratio_s."',";
   $qstr .= "xratio_a='".$xratio_a."',";
   $qstr .= "xratio_m='".$xratio."',";
   $qstr .= "currency='".$currency."',";
   $qstr .= "value='".$cvalue."',";
   $qstr .= "pay_type='".$pay_type."';";

   $db->query($qstr);
   ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,"新增 [會員ID=".$mid."] 帳號 : 所屬總監 id=".$scid.", 所屬股東=".$cid.", 所屬總代理=".$sid.", 所屬代理商 id=".$aid.", 總監佔成=".$winloss_sc.", 股東佔成=".$winloss_c.", 總代理佔成=".$winloss_s.", 代理商佔成=".$winloss_a.", 幣別=".$currency.", 兌換率=".$cvalue.", Pay_Type=".$pay.", ltype=".$type.", 群組=".$grp1.", 單場單注=".$scso.", 中國聯賽佔成=".$ga,$qstr);

   //重取預設幣值
   $dbr->query("select def from currency where code='".$currency."'",1);
   $creditvalue=$dbr->f('def');
   $creditvalue=$creditvalue/10000;

   $db->query("SELECT ".$mid." as mid,gtype,rtype,(CASE WHEN gtype='GM'and rtype='GM' THEN SC ELSE TRUNCATE(SC/".$creditvalue.",0) END)as SC,(CASE WHEN gtype='GM'and rtype='GM' THEN SO ELSE TRUNCATE(SO/".$creditvalue.",0) END)as SO ,W_WAR,L_WAR FROM ag_conf where aid='".$aid."' and grp='".$grp."';");
   $conf_data = $db->get_total_data();
   for($j=0;$j < count($conf_data);$j++){
	   $sql_sc=  "INSERT INTO mem_conf set ";
	   $sql_sc.= " mid='".$conf_data[$j]["mid"]."'";
	   $sql_sc.= ",gtype='".$conf_data[$j]["gtype"]."'";
	   $sql_sc.= ",rtype='".$conf_data[$j]["rtype"]."'";
	   $sql_sc.= ",SC='".$conf_data[$j]["SC"]."'";
	   $sql_sc.= ",SO='".$conf_data[$j]["SO"]."'";
	   $sql_sc.= ",W_WAR='".$conf_data[$j]["W_WAR"]."'";
	   $sql_sc.= ",L_WAR='".$conf_data[$j]["L_WAR"]."'";
	   ctrl_sub_record($db,$REC_sub_table,$record_rid,$uid,$REC_level,"新增 [會員ID=".$mid."]"."[".$conf_data[$j]["gtype"]."][".$conf_data[$j]["rtype"]."] 的 [詳細設定]".", 所屬 [代理商ID=".$aid."]",$sql_sc);
	   $db->query($sql_sc);
   }


   if($maxcredit*1+$cash > 0)  updateCash($db,"members",$mid,$aid,$maxcredit*1+$cash*1,($maxcredit*1+$cash*1)*$cur_value,$currency1,$MEM_DATA['username'],$memname,"H","L","CTL");
}
?>