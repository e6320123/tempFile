<?php
/**
gb2312�নbig5
*/
function gb2big5($Text){ 
	$fp = fopen(WEB_PATH."/lib/gb-big5.table", "r"); 
	
	
	$max=strlen($Text)-1; 
	for($i=0;$i<$max;$i++){ 
		$h=ord($Text[$i]); 
		if($h>=160){ 
			$l=ord($Text[$i+1]); 
			if($h==161 && $l==64){ 
				$gb=" "; 
			}else{ 
				fseek($fp,($h-160)*510+($l-1)*2); 
				$gb=fread($fp,2); 
			} 
			$Text[$i]=$gb[0]; 
			$Text[$i+1]=$gb[1]; 
			$i++; 
		} 
	} 
	fclose($fp); 
	return $Text; 
}

/**
big5�নgb2312
*/
function big52gb($Text){ 
	$fp = fopen(WEB_PATH."/lib/big5-gb.table", "r"); 
	
	
	$max=strlen($Text)-1; 
	for($i=0;$i<$max;$i++){ 
		$h=ord($Text[$i]); 
		if($h>=160){ 
			$l=ord($Text[$i+1]); 
			if($h==161 && $l==64){ 
				$gb=" "; 
			}else{ 
				fseek($fp,($h-160)*510+($l-1)*2); 
				$gb=fread($fp,2); 
			} 
			$Text[$i]=$gb[0]; 
			$Text[$i+1]=$gb[1]; 
			$i++; 
		} 
	} 
	fclose($fp); 
	return $Text; 
}
function echostr($text,$encodingtype){ 
	if ($encodingtype == "gb2312"){ 
		$t_tmp = big52gb("$text"); 
		return $t_tmp; 
	}else if($encodingtype == "big5"){  
		$t_tmp = gb2big5("$text"); 
		return $t_tmp; 
	}else{
		return $text; 
	} 
} 
?>