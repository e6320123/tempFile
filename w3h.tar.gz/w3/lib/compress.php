<?php
function DoCompress()
{
	global $dbFTR,$langx;
	//$dbFTR->query("select sw_flag from game_sw where rtype='CGZ'",1);
	//$sw_flag=$dbFTR->f("sw_flag");
	$sw_flag="1";
//檢查瀏覽器是否支援gzip壓縮格式
	if($sw_flag=="1")
	{
		//取出緩衝區裡的資料
		$gzip_contents = ob_get_contents();
		//清空緩衝區
		ob_end_clean();
		//將緩衝區的回傳資料使用gzip壓縮
		$gzip_contents = gzencode($gzip_contents, 9);
		//回應瀏覽器資料壓縮格式是使用gzip 
		//header("Content-Type: text/html");
		switch($langx)
		{
		  case "zh-tw":
		   $ch_set="charset=utf-8";
		   break;
		  case "zh-cn":
		   $ch_set="charset=utf-8";
		   break;
		  case "en-us":
		   $ch_set="charset=utf-8";
		   break;
		  case "th-tis":
		   $ch_set="charset=utf-8";
		   break;	
		}   	
		header("Content-Type: text/html; $ch_set");
		header("Content-Encoding: gzip");
		//輸出壓縮後的資料
		echo $gzip_contents;
		//return $gzip_contents;
	}
}
?>