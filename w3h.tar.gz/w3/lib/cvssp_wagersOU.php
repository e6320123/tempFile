<?php
/*
作用:解32個資料表 Table.wagersOU01~wagersOU01;
注意事項:
1.SQL語法中只針對wagersOU處理.
2.SQL語法中不能包含子查詢.

*/
 class report_X32 {
  var $OBJ_DB ;  //連線的db物件
  var $TXT_SQL ; //取值的SQL
  var $ARR_db = array();
  var $record = array();       // Current row record data
  //var $rec_id = -1; //指向的筆數
  var $row= -1; //指向的筆數

  var $ARR_select   = array(); //欄位名稱
  var $ARR_from     = array(); //應有的資料表
  var $ARR_where    = array(); //條件名稱
  var $ARR_orderby  = array(); //排序名稱
  var $ARR_key      = array(); //切開的WHERE
  var $ARR_tb_md    = array(); //切開的WHERE

  var $DATE_start   = "";
  var $DATE_end     = "";

  var $microtime_start =0;

  var $dbhost = DB_HOST;
  var $dbuser = DB_USER;
  var $dbpwd = DB_PWD;
  var $dbname = DB_NAME;
  var $lid = 0;                // Link ID for database connection
  var $qid = 0;                // Query ID for current query
  //var $row;                    // Current row in query result set
  //var $record = array();       // Current row record data
  var $error = "";             // Error Message
  var $errno = "";             // Error Number
  var $pflag=1;                //預設為 pconnect
  var $lastamount=0;           //最後query取得的資料筆數
  var $report_date = 0;                // Query ID for current query

function report_X32($ObjDB,$date_start,$date_end) {
	$this->microtime_start   = $this->use_microtime();
	//echo "X32_use_microtime:". $this->$microtime_start."<hr>\n";
	if (true) {
	//	echo "OKOK-----------<BR>";
		$this->OBJ_DB  = $ObjDB;
//		$this->OBJ_DB->query('select tb_md from tb_dup');
//		while ($this->OBJ_DB->next_record()) {
//			$this->ARR_tb_md[$this->OBJ_DB->f('tb_md')]=$this->OBJ_DB->f('tb_md');
//
//		}
		//$this->TXT_SQL = ltrim($TxtSql); //ltrim:去除字串起始處的空白
		$this->DATE_start = $date_start;
		$this->DATE_end   = $date_end;

		//$this->split_sql($this->TXT_SQL);
		$this->split_date($ObjDB , $date_start,$date_end);
		//$this->query($this->TXT_SQL);
	}
}

function split_sql($qstr) {
	$sql_strtoupper= strtolower($qstr); //將字串轉成小寫
	//echo "初始值:\n".$sql_strtoupper ."\n\n\n<hr><br>\n";
	$key_select   = "select ";
	$key_from  = " from ";
	$key_where = " where ";
	$key_groupby = " group by ";
	$key_orderby = " order by ";
	//$pos = stristr($strrpos,$chkWord );  //不分大小寫找出字串第一次出現的地方
	//$int_select = strpos($sql_strtoupper,$key_select );
	$int_from   = strpos($sql_strtoupper,$key_from );
	//$int_where  = strpos($sql_strtoupper,$key_where );
	//$int_groupby= strpos($sql_strtoupper,$key_groupby );
	//$int_orderby= strpos($sql_strtoupper,$key_orderby );
	$file_txt = substr($qstr,strlen($key_select),  ($int_from- strlen($key_select))   );//欄位名稱.

}

function split_date( $ObjDB,$date_start,$date_end ) {
        $intHaveInDate = 0;
        $arrHaveInDate = array();
        $ObjDB -> query("SHOW TABLES LIKE 'Wagerba%' ");
        while ($ObjDB->next_record() ) {
		$arrHaveInDate[ $intHaveInDate++ ] = $ObjDB ->f(0);
	}
        $arr_start = preg_split("[-]",$date_start);
        $today = getdate();//日期物件
        $day_rec = 0;
        for ($i=0;$i< 62;$i++) { //get 5 week
                $gmdate_ymd = date("Y-m-d",mktime(0,0,0,$arr_start[1],$arr_start[2]+$i,$arr_start[0]));
                $gmdate_md  = date("Ymd"   ,mktime(0,0,0,$arr_start[1],$arr_start[2]+$i,$arr_start[0]));
		//echo  $date_start. "__data:".  $gmdate_ymd . "---Hours:" .$today[hours] . "<br>\n";
	        if ( !in_array("Wagerba".$gmdate_md , $arrHaveInDate) )  continue ;
                $this->ARR_from[$day_rec++ ] = $gmdate_ymd;
                if ($gmdate_ymd >=$date_end) break;
        }
}

function query($qstr,$action=0) {
	$this->TXT_SQL = ltrim($TxtSql); //ltrim:去除字串起始處的空白
	//echo "<hr><b>SQL:</b><i>". $this->TXT_SQL."</i></id>";
	//echo "SQL:".strpos($qstr," wagersOU ")."<br>\n<hr>";
	$this -> row = -1; //歸零
	$ARR_db  = array();
	//if ( !strpos($qstr," wagersOU_all ") ) {	}

	$this->ARR_db = array();
	$all_data = array();
	$query_start = $this->use_microtime();
	if ( !preg_match("/ Wagerba /",$qstr)) { //Wagerbo,dt
		$this->OBJ_DB->query($qstr);
		$this->ARR_db = $this->OBJ_DB->get_total_data();
		//echo "<br> >>>>> Other < [Other] SQL::<br>".$qstr."<br>\n";
	} else {
		 //TABLE.wagerba
			for ($i=0; $i < count($this->ARR_from ); $i++) {
				$all_data_tmp  = array();
				if ($this->ARR_from[$i]<= $this->report_date)continue;
				$tmp_date_arr= preg_split("[-]",$this->ARR_from[$i]);
				//$day2 = substr($this->ARR_from[$i] , -2);
				$year2 = $tmp_date_arr[0];
				$month2 = $tmp_date_arr[1];
				$day2 = $tmp_date_arr[2];
				//echo "month2=>".$month2;
//				if ($this->ARR_tb_md[$month2.$day2]) {
//					$day2=$this->ARR_tb_md[$month2.$day2];
//				}
				$sql_tmp = str_replace("Wagerba", "Wagerba".$year2.$month2.$day2,$qstr );
			//	echo "<br> >>>>> ".$i." <<<<<< [". $this->ARR_from ."] SQL::<br>".$sql_tmp."<br>\n";
			//echo "<!--";
			//	echo "OU==>".$sql_tmp."<br>";
			//echo "-->";
				$this->OBJ_DB->query($sql_tmp);
				$all_data_tmp = $this->OBJ_DB->get_total_data();
				$this->ARR_db = array_merge((array)$this->ARR_db, (array)$all_data_tmp);
			}
	}
	//echo "thisQUERY_RUN_TIME:<b>". ($this->use_microtime() - $query_start)   ."</b><br>\n";
	if ($action) $this->next_record();
	return true;
}

function next_record() {
	$this->row ++;
	//echo "----row:".$this->row ."__2zzz:".count($this->ARR_db) ."__3zzz:".   $this->ARR_db[$this->row]['gold'] ."<br>";
	if ( $this->row >= count($this->ARR_db) ) {
		//echo "<b>DD1:". $this->row ."__DD2:". count($this->ARR_db) ."</br>";
		 return false;
	} else {
		$this->record = $this->ARR_db[$this->row] ;
	}
	return true;
}

function f($field_name) {
	return stripslashes($this->ARR_db[$this->row][$field_name]);
}


function close() {
	//echo "run[". (1*$this->use_microtime()- $this->$microtime_start) ."]<br>\n";
	$this->OBJ_DB->close();
}

function get_total_data() {
	return $this->ARR_db;
}

function num_rows() {
	return count($this->ARR_db);
}

function use_microtime() {
	$arr_microtime = preg_split("[ ]",microtime());
	return $arr_microtime[0]+$arr_microtime[1];
}


}
