<?php
/*
showerror()		//秀錯誤訊息-------------
show_game_type()        //顯示球賽類別-----------
ShowPicData()		//秀投手資料
ShowRadio()
FT_ShowRadio
BK_ShowRadio
showLeague()		//取得聯盟名稱函數
Js_Opener_Reload()	//js開視窗重讀data
Write_Ctl_Record()      //寫入操盤歷史檔
*/
//秀錯誤訊息
function showerror($title,$str,$link_page="javascript:history.go(-1);")//control
{
 $tpl = new FastTemplate(WEB_PATH_TPL);
 $tpl->define(array(main    => "lerror_ctl.tpl"));
 $tpl->assign( array( TITLE => "$title") );
 $tpl->assign( array( ERROR_STR => "$str") );
 $tpl->assign( array( LINK_PAGE => "$link_page") );
 $tpl->parse(MAIN,"main");
 $tpl->FastPrint();
}

//------秀投手資料------
function ShowPicData($picther_id,$db)//control
{
 $db->query("select picthers_mode,picthers_lname,picthers_bname from picthers where id=$picther_id",1);
 if($db->f('picthers_mode') == 'R') $mode = "右";
 else                               $mode = "左";
 if($db->f('picthers_lname') == "")
  return NULL;
 else 
  return "[".$db->f('picthers_bname')."&#8231$mode"."]";
}

//-------------------------------------------------------------------------------------------------
function ShowRadio($concede,$radio,$Flag=1)//control
{
 if($radio < 0) $showradio = $concede.$radio;
 else           $showradio = $concede."+".$radio;

 switch($showradio)
 {
  case "0+100":
   return "0";
   break;
  case "0+0":
   return "0";
   break;
  case "0-50":
   return "0 / 0.5";
   break;
  case "1+100":
   return "0.5";
   break;
  case "1+50":
   return "0.5 / 1";
   break;
 }
 switch($radio)
 {
  case 0:
   return $concede;
   break;
  case -50:
   return $concede." / ".$concede.".5";
   break;
  case -100:
   return $concede.".5";
   break;
  case 100:
   return intval($concede-1).".5";
   break;
  case 50:
   return intval($concede-1).".5 / ".$concede;
   break;
  default:
   return "賠率值錯誤";
 }
}

//-------------------------------------------------------------------------------------------------
function FT_ShowRadio($concede,$radio)//control
{
 if($radio < 0) $showradio = $concede.$radio;
 else           $showradio = $concede."+".$radio;

 switch($showradio)
 {
  case "0+100":
   return "0";
   break;
  case "0+0":
   return "0";
   break;
  case "0-50":
   return "0 / 0.5";
   break;
  case "1+100":
   return "0.5";
   break;
  case "1+50":
   return "0.5 / 1";
   break;
 }
 switch($radio)
 {
  case 0:
   return $concede;
   break;
  case -50:
   return $concede." / ".$concede.".5";
   break;
  case -100:
   return $concede.".5";
   break;
  case 100:
   return intval($concede-1).".5";
   break;
  case 50:
   return intval($concede-1).".5 / ".$concede;
   break;
  default:
   return "賠率值錯誤";
 }
}
//------------------------------------------------------------
function BK_ShowRadio($concede,$radio)//control
{
 if($radio < 0) $showradio = $concede.$radio;
 else           $showradio = $concede."+".$radio;

 switch($showradio)
 {
  case "0+100":
   return "0";
   break;
  case "0+0":
   return "0";
   break;
  case "0-50":
   return "0 / 0.5";
   break;
  case "1+100":
   return "0.5";
   break;
  case "1+50":
   return "0.5 / 1";
   break;
 }
 switch($radio)
 {
  case 0:
   return $concede;
   break;
  case -50:
   return $concede." / ".$concede.".5";
   break;
  case -100:
   return $concede.".5";
   break;
  case 100:
   return intval($concede-1).".5";
   break;
  case 50:
   return intval($concede-1).".5 / ".$concede;
   break;
  default:
   return "賠率值錯誤";
 }
}

//-------------------------------------------------------------------------------------------------
//取得聯盟名稱函數
function showLeague($lid,$ls=c,$gtype,$db){
	$db->query("SELECT sname_$ls FROM ".$gtype."_leagues WHERE id=".$lid,1);
	return $db->f("sname_$ls");
}
//-------------------------------------------------------------------------------------------------
//js開視窗重讀data
function Js_Opener_Reload(){
	$str="<script language=javascript>\n";
	$str.="opener.parent.body_var.location.reload();\n";
	$str.="window.close();\n";
	$str.="</script>\n";
	return $str;
}
//-------------------------------------------------------------------------------------------------
//=============================================
//--功能說明：寫入操盤歷史檔
//--$username:使用者帳號($PHP_AUTH_USER);
//--$table:更動之資料表名稱;
//--$fun_name:檔名;
//--$action:動作("A:新增,D:修改,M:刪除");
//--$memo:註解
//--$db:資料庫連線($db);
//--$ip:使用者IP($USER_IP);
//=============================================
function Write_Ctl_Record($username,$table,$fun_name,$action,$memo,$db,$ip){
    $today=getdate();
    $today_gmt=gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
    $now_gmt=gmdate("H:i:s",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
    $today=$today_gmt." ".$now_gmt;
    $sql="insert into ctl_record (username,t_name,action,fun_name,content,adddate,ip)";
    $sql.="values ('$username','$table','$action','$fun_name','$memo','$today','$ip')";
    $db->query($sql);
}
##################################################
function chk_gid($gidx,$gamez_db,$type=0){
	if($type==1)$gidx=preg_replace('/_1/','',$gidx);
	for($i=0;$i<count($gamez_db);$i++){
		if($gidx==$gamez_db[$i])return 1;
		//echo $gamez_db[$i]." : ".$gidx["g".$gamez_db[$i]]."<BR>";
	}
	return;
}

?>
