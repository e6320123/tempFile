<?php
// 寫紀錄至mv_mem
function rec_mv($db, $str) {
	$time_zone=12*60*60;
	$sql = "insert into mv_mem set content='".$str."',date=FROM_UNIXTIME(UNIX_TIMESTAMP( )-".$time_zone.")";
	$db->query($sql);
}

//關連值
function relation($db,$table,$filed,$id,$cons){
	if($id=='') return; //主要值
	$sql="select ".$filed." from ".$table." where ".$cons." in (".$id.")";
	//echo $sql;
	$db->query($sql);
	$ids="";
	$a=0;
	while($db->next_record()){
		 if($a==0) $ids=$db->f($filed);
		 else $ids.=",".$db->f($filed);
		 $a++;
	}
	return $ids;
}

//更新設定值
function update_conf($dbr,$dbw,$report,$relation,$conf_table,$filed){
		global $record_rid,$REC_sub_table,$uid,$REC_level;
		if($relation=='') return;//主要值
		$up_sql="";
		$grp="";
		for($x=0;$x < count($report);$x++){
			$sql="select * from ".$conf_table.$grp." ";
			$sql.="where ";
			$subsql="gtype='".$report[$x]['gtype']."' ";
			$subsql.="and rtype='".$report[$x]['rtype']."' ";
			$subsql.=" and ( ";
			$subsql.=" SO > ".$report[$x]['SO']." ";
			$subsql.="or SC > ".$report[$x]['SC']." ";
			$subsql.="or W_WAR > ".$report[$x]['W_WAR']." ";
			$subsql.="or L_WAR > ".$report[$x]['L_WAR']." ";
			$subsql.=" ) ";
			$subsql.="and ".$filed." in (".$relation.")";
			$sql.=$subsql;
			$dbr->query($sql);
			if($dbr->num_rows()!=0){
				$up_sql.="update ".$conf_table.$grp." set ";
				$up_sql.="SC='".$report[$x]['SC']."',";
				$up_sql.="SO='".$report[$x]['SO']."',";
				$up_sql.="W_WAR='".$report[$x]['W_WAR']."',";
				$up_sql.="L_WAR='".$report[$x]['L_WAR']."' ";
				$up_sql.="where ";
				$up_sql.=$subsql.";";
			}
		}
		if($up_sql!=""){
			$dbw->muti_query($up_sql);
			ctrl_sub_record($dbw,$REC_sub_table,$record_rid,$uid,$REC_level,"因 [帳號轉移], 自動修改各層級的退水值",$up_sql);
		}
}
//更新設定值
function update_mem_conf($dbr,$dbw,$report,$relation,$conf_table,$filed){
	global $record_rid,$REC_sub_table,$uid,$REC_level;
		if($relation=='') return;//主要值
		$up_sql="";
		$mem_id = explode(",",$relation);
		for($g=0;$g < count($mem_id);$g++){
			$sql="select value from mem_winloss where mid='".$mem_id[$g]."'";
			$dbr->query($sql,1);
			$cvalue =$dbr->f('value')/10000;
			if($cvalue < 0) $cvalue =1;
			for($x=0;$x < count($report);$x++){
				$sql="select * from ".$conf_table." ";
				$sql.="where ";
				$subsql="gtype='".$report[$x]['gtype']."' ";
				$subsql.="and rtype='".$report[$x]['rtype']."' ";
				$subsql.=" and ( ";
				$subsql.=" SO > ".($report[$x]['SO']/$cvalue)." ";
				$subsql.="or SC > ".($report[$x]['SC']/$cvalue)." ";
				$subsql.="or W_WAR > ".$report[$x]['W_WAR']." ";
				$subsql.="or L_WAR > ".$report[$x]['L_WAR']." ";
				$subsql.=" ) ";
				$subsql.="and ".$filed." in (".$mem_id[$g].")";

				$sql.=$subsql;
				//echo $sql."<br>";
				$dbr->query($sql);
				if($dbr->num_rows()!=0){
					$up_sql.="update ".$conf_table.$grp." set ";
					$up_sql.="SC='".($report[$x]['SC']/$cvalue)."',";
					$up_sql.="SO='".($report[$x]['SO']/$cvalue)."',";
					$up_sql.="W_WAR='".$report[$x]['W_WAR']."',";
					$up_sql.="L_WAR='".$report[$x]['L_WAR']."' ";
					$up_sql.="where ";
					$up_sql.=$subsql.";";
				}
			}
		}

		if($up_sql!=""){
			$dbw->muti_query($up_sql);
			ctrl_sub_record($dbw,$REC_sub_table,$record_rid,$uid,$REC_level,"因 [帳號轉移], 自動修改各層級的退水值",$up_sql);
		}
}
//當層的處理，要比較出那一個rtype 有做了更新
function process($dbr,$dbw,$conf_table_up,$conf_table,$filed_up,$filed,$ups,$id,$line=0){
	global $REC_sub_table,$record_rid,$uid,$REC_level;
	$z=0;
	if($line!=0){
	 	 $sql="select value from mem_winloss where mid='".$id."'";
		 $dbr->query($sql,1);
		 $cvalue = $dbr->f('value')/10000;
		 $orderby =" order by gtype,rtype";
	}else{
		 $cvalue =1;
		 $orderby =" order by gtype,rtype";
	}
	//echo
	$sql="select * from ".$conf_table_up." where ".$filed_up."='".$ups."'".$orderby;
	//echo $sql="select * from ".$conf_table_up.$grp." where ".$filed_up."='".$ups."'".$line.$orderby;exit;
	$dbr->query($sql);
	//$up_data = $dbr->get_total_data();
	while($dbr->next_record()){
		$up_data[$dbr->f('gtype')."_".$dbr->f('rtype')]["id"]=$dbr->f('id');
		$up_data[$dbr->f('gtype')."_".$dbr->f('rtype')]["cid"]=$dbr->f('cid');
		$up_data[$dbr->f('gtype')."_".$dbr->f('rtype')]["gtype"]=$dbr->f('gtype');
		$up_data[$dbr->f('gtype')."_".$dbr->f('rtype')]["rtype"]=$dbr->f('rtype');
		$up_data[$dbr->f('gtype')."_".$dbr->f('rtype')]["ltype"]=$dbr->f('ltype');
		$up_data[$dbr->f('gtype')."_".$dbr->f('rtype')]["SC"]=$dbr->f('SC');
		$up_data[$dbr->f('gtype')."_".$dbr->f('rtype')]["SO"]=$dbr->f('SO');
		$up_data[$dbr->f('gtype')."_".$dbr->f('rtype')]["W_WAR"]=$dbr->f('W_WAR');
		$up_data[$dbr->f('gtype')."_".$dbr->f('rtype')]["L_WAR"]=$dbr->f('L_WAR');
	}	
	$sql="select * from ".$conf_table.$grp." where ".$filed."='".$id."'".$orderby;
	$dbr->query($sql);
	$data = $dbr->get_total_data();
	$report=Array();
	$z=0;
	$sql_str="";

	for($i=0;$i < count($data);$i++){
		$flag = false;
		$tmp_idx=$data[$i]["gtype"]."_".$data[$i]["rtype"];

		if($up_data[$tmp_idx]['SC'] < $data[$i]['SC']*$cvalue && $up_data[$tmp_idx]['SC']){
			$flag = true;
		}
		if($up_data[$tmp_idx]['SO'] < $data[$i]['SO']*$cvalue && $up_data[$tmp_idx]['SO']){
			$flag = true; 
		}
		if($up_data[$tmp_idx]['W_WAR'] < $data[$i]['W_WAR'] && $up_data[$tmp_idx]['W_WAR']){
			$flag = true;
		}
		if($up_data[$tmp_idx]['L_WAR'] < $data[$i]['L_WAR'] && $up_data[$tmp_idx]['L_WAR']){
			$flag = true;
		}

		if($flag){ //報告, 那一個值做了更新, 並加上更新
		$report[$z] = Array(
					'id'=>$up_data[$tmp_idx]['id'],
					'cid'=>$up_data[$tmp_idx]['cid'],
					'gtype'=>$up_data[$tmp_idx]['gtype'],
					'rtype'=>$up_data[$tmp_idx]['rtype'],
					'SC'=>$up_data[$tmp_idx]['SC'],
					'SO'=>$up_data[$tmp_idx]['SO'],
					'W_WAR'=>$up_data[$tmp_idx]['W_WAR'],
					'L_WAR'=>$up_data[$tmp_idx]['L_WAR']
			);

			$sql_str.="update ".$conf_table.$grp." set ";
			$sql_str.="SC='".($up_data[$tmp_idx]['SC']/$cvalue)."',";
			$sql_str.="SO='".($up_data[$tmp_idx]['SO']/$cvalue)."',";
			$sql_str.="W_WAR='".$up_data[$tmp_idx]['W_WAR']."',";
			$sql_str.="L_WAR='".$up_data[$tmp_idx]['L_WAR']."'";
			$sql_str.="where id='".$data[$i]['id']."';";
			$z++;
		}

	}
	if($sql_str!=""){
		$dbw->muti_query($sql_str);
		ctrl_sub_record($dbw,$REC_sub_table,$record_rid,$uid,$REC_level,"修改相關退水設定",$sql_str);
	}
	return $report;
}
?>