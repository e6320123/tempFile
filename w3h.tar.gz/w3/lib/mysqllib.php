<?php

/*
eddy 20180424 優化新用法
new proc_DB($host,$user,$pwd,$dbname="")  $dbname可不帶

next_record() /next_name() / next_num()  欄位key   兩者都有/欄位名稱key/數字key
insert_id（）    取insert auto_increment id
num_rows ()     取select總筆數
errmsg()        取error訊息
query_rows()    取insert update delete 筆數
$this->errorend true/false 預設錯誤 exit;
$this->select_db($strdbname) OR $this->dbname=$strdbname;   切換DBNAME
$this->connect($connect_flag=0) connect_timeout 時間
 */
//$this->errmsg()   return string;
 class proc_DB
 {
  public $dbhost = "";
  public $dbuser = "";
  public $dbpwd = "";
  public $dbname = "";
  public $chkdb;
  public $errorend=true;          // SQL錯誤 exit;
  public $lid = 0;                // Link ID for database connection
  public $qid = 0;                // Query ID for current query
  public $row;                    // Current row in query result set
  public $record = array();       // Current row record data
  public $error = "";             // Error Message
  public $errno = "";             // Error Number
  public $pflag=1;                // pconnect
  public $lastamount=0;           // select query rows

  function __construct($host='',$user='',$pwd='',$dbname='')
  {
   if(!empty($host))
   {
    $this->dbname = $dbname;
    $this->dbhost = $host;
    $this->dbuser = $user;
    $this->dbpwd = $pwd;
   }
  }

  function connect($connect_flag=0)
  {
   if(!$this->lid)
   {
   
    $this->chkdb=$this->dbname;

    $mysqli = mysqli_init();
   // if($connect_flag){@$mysqli->options( MYSQLI_OPT_CONNECT_TIMEOUT, $connect_flag );}
    if($connect_flag){@mysqli_options($mysqli,MYSQLI_OPT_CONNECT_TIMEOUT,$connect_flag);}
    $this->lid =(@mysqli_real_connect($mysqli,$this->dbhost,$this->dbuser,$this->dbpwd,$this->dbname))?$mysqli:0;
    

    //$pflag=($connect_flag)?0:1;
    if(!$this->lid && $this->errorend){$this->halt("connect(" . $this->dbhost . "," . $this->dbuser . ")  failed.");}
   }
   return $this->lid;
  }

  function select_db($strdbname){
     $this->chkdb=$this->dbname=$strdbname;
     $chks=@mysqli_select_db($this->lid,$this->dbname);
     if (!$chks && $this->errorend){$this->halt("Cannot connect to database ".$this->$dbname); }
  }

  function query($qstr,$action=0)
  {
   if(empty($qstr))  return 0;
   if(!$this->connect())    return 0;
   if($this->qid)
   {
    @mysqli_free_result($this->qid);
    $this->qid = 0;
   }
   $qstr = str_replace('\\', '\\\\', $qstr);
   if($this->dbname && $this->dbname!=$this->chkdb)$this->select_db($this->dbname);
   $this->qid = @mysqli_query($this->lid,$qstr);
   if (!$this->qid && $this->errorend){$this->halt("Invalid SQL: ".$qstr);}
   $this->lastamount = @mysqli_num_rows($this->qid);
   $this->row   = 0;
   if($action){$this->next_record();}

   return $this->qid;
  }

  function muti_query($qstr)
  {
   if(empty($qstr))  return 0;
   if(!$this->connect())    return 0;
   if($this->qid)
   {
    @mysqli_free_result($this->qid);
    $this->qid = 0;
   }

   if($this->dbname && $this->dbname!=$this->chkdb)$this->select_db($this->dbname);
   $aqstr = explode(";",$qstr);
   for($i=0; $i<count($aqstr)-1; $i++)
   {
    $aqstr[$i] = str_replace('\\', '\\\\', $aqstr[$i]);

    $this->qid = @mysqli_query($this->lid,$aqstr[$i]);
    $this->row   = 0;
    if (!$this->qid && $this->errorend){$this->halt("Invalid SQL: ".$aqstr[$i]);}
   }
   $this->next_record();
   $lastamount = @mysqli_num_rows($this->qid);
   return $this->qid;
  }

 function query_rows(){return @mysqli_affected_rows($this->lid);}

 function insert_id($qstr="")
  {
  if($qstr)$this->query($qstr);
  return @mysqli_insert_id($this->lid);
  }
  function update_rows($qstr){
      $this->query($qstr);
      return @mysqli_affected_rows($this->lid);
  }
  function get_total_data($qfield='')
  {

   while($this->next_record())
   {
    if(empty($qfield)) {$all_data[] = $this->record;}
    else {$all_data[$this->record[$qfield]] = $this->record;}
   }
   return $all_data;
  }

  function next_num(){return $this->next_record(MYSQLI_NUM);}
  function next_name(){return $this->next_record(MYSQLI_ASSOC);}
  function next_record($rtype=MYSQLI_BOTH)
  {
   if(!$this->qid) {  return false; }
   $this->record = @mysqli_fetch_array($this->qid,$rtype);
   $this->row   += 1;

   if(is_array($this->record)){return true;
   }else
   {
    @mysqli_free_result($this->qid);
    $this->qid = 0;
    return false;
   }

  }

  function f($field_name) { return stripslashes($this->record[$field_name]); }


  function num_rows()
  {
   if($this->lid) return $this->lastamount;
   else return 0;
  }

  function halt($msg)
    {
     global $_SERVER,$MEM_DATA;
     $errmsg = $this->errmsg();
     // $this->error = @mysqli_error($this->lid);
     // $this->errno = @mysqli_errno($this->lid);
     //get stack trace
     try{
         throw new Exception("SQL Exception!!");
     }catch(Exception $e){
         $error_msg = $e;
     }
     $user="[".$msg."]";
     $IP_add=$_SERVER['REMOTE_ADDR'];
     $str_re=$_SERVER["REQUEST_URI"];
     $today=getdate();
     if(!is_dir(FILE_PATH."/log/error_log")){mkdir(FILE_PATH."/log/error_log",0777);}
     $dir_date=FILE_PATH."/log/error_log/".gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
     $file_date=gmdate("H",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
     if(!is_dir($dir_date)){mkdir($dir_date,0777);}
     $file_log=fopen($dir_date."/error_log.".$file_date.".log","a");
     fwrite($file_log,gmdate("i:s",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]))."\t".$_SERVER['REMOTE_ADDR']."\t$user"."\t".$_SERVER['HTTP_USER_AGENT']."\t".$_SERVER['HTTP_ACCEPT_LANGUAGE']."\t".$MEM_DATA['username']." - ".$str_re."\n");
     fwrite($file_log,"[SQL Exception: ".$errmsg."]\n".$error_msg."\n");
     fclose($file_log);
     //ctl use showerror
     showerror("System error","System error");
     exit;
    }

   function errmsg()
  {
   $this->error = @mysqli_error($this->lid);
   $this->errno = @mysqli_errno($this->lid);
   $this->errcon = @mysqli_connect_error($this->lid);
   return $this->errno.$this->error.$this->errcon;
  }


  function close()
  {
   if($this->qid)
   {
    @mysqli_free_result($this->qid);
    $this->qid = 0;
   }
   //if ($pflag) return;
   if($this->lid)
   {
    @mysqli_close($this->lid);
    $this->lid = 0;
   }
  }
  // function showerror($title,$str,$link_page) {
  //     include (WEB_PATH."/lib/loadtmplate.php");
  //     $tpl = new template(WEB_PATH_TPL."lerror_ctl.tpl");
  //     $tpl->assign("TITLE",$title);
  //     $tpl->assign("ERROR_STR",$str);
  //     $tpl->assign("LINK_PAGE",$link_page);
  //     $tpl->FastPrint();
  //   }
//=================================== 以下棄用 ===================================
  function sf($field_name)
  {
   global $vars, $default;

   if($vars["error"] and $vars["$field_name"])
    return stripslashes($vars["$field_name"]);
   else if($default["$field_name"])
    return stripslashes($default["$field_name"]);
   else return stripslashes($this->record[$field_name]);
  }

  function print_value($field_name)
  {
   print stripslashes($this->record[$field_name]);
  }

  function sp($field_name)
  {
    global $vars, $default;

   if($vars["error"] and $vars["$field_name"])
    print stripslashes($vars["$field_name"]);
   else if($default["$field_name"])
    print stripslashes($default["$field_name"]);
   else
    print stripslashes($this->record[$field_name]);
  }


  function record_count()
  {
    if($this->qid)
    {
    //$this->record = @mysqli_fetch_row($this->qid);
    return @count($this->record);
    }
    else return 0;
  }

  function record_list($num)
  {

  if ($this->qid) return @$this->qid->fetch_field_direct($num)->name;
  else return 0;
  }
 }