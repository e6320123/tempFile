<?php
// 踢人
/*
$level =0; //總監
$level =1; //股東
$level =2; //總代理
$level =3; //代理商
$level =4; //會員
*/
function kick_ur_ass($dbMain,$level,$id) {
	$dbw = new proc_DB(DB_HOST,DB_USER,DB_PWD,DB_NAME);
	$fileds_name=Array("scid","cid","sid","aid","mid");
	$table=Array('su_corp','corprator','su_agents','agents','members');
	$code=Array('sc','c','s','a');
	$dbM = $dbMain;
	$temps=$id;
	$temp_scid="";
	$temp_cid="";
	$temp_sid="";
	$temp_aid="";
	$id ="'".$id."'";
	$k_sql="";
	if ($level == "3")$id = getAGlevel($dbMain,'agents',$id);
	for ($i=$level;$i < 5;$i++) {
		//echo "i=".$i."\n";
		if ($i==$level) {
			$tmp_id="id";
		} else {
			$tmp_id=$fileds_name[$i-1];
		}
		$sql="select id as ".$fileds_name[$i]." from ".$table[$i]." where ".$tmp_id." in (".$id.");";
		$dbMain->query($sql);
		//echo $sql."<BR>";
		${"temp_".$fileds_name[$i]} = $dbMain->get_total_data();
		//ag 端
		//echo $i."------".$fileds_name[$i]."---".$temps."<br>";
//		if ($i!=4) {
//			//放通訊
//			//echo "AG--->080,".$temps.",".$code[$i]."---".AG_HOST_BLANCE.",".AG_PORT_BLANCE."<br>";
//			javaConnnection("080,".$temps.",".$code[$i],AG_IP,AG_PORT);
//			//exit;
//		}
		$temps="";
		//echo "===>".${"temp_".$fileds_name[$i]}."\n";
		if (${"temp_".$fileds_name[$i]}=="") break;
		for ($j=0;$j < count(${"temp_".$fileds_name[$i]});$j++) {
			$bak = $fileds_name[$i];
			if ($j==0) {
				$id="'".${"temp_".$bak}[$j][$bak]."'";
				$temps.=${"temp_".$bak}[$j][$bak];
			} else {
				$id.=" ,'".${"temp_".$bak}[$j][$bak]."'";
				$temps.="*".${"temp_".$bak}[$j][$bak];
			}
			if ($i!=4) {
				//主帳號
				$k_sql .= "INSERT login_" . $table[$i] . " SET `loginid` = '" . ${"temp_" . $bak}[$j][$bak] . "', `uid` = '', `username` = '', `logindate` = '', `langx` = '';";
				//子帳號
				$dbMain->query("SELECT `id` FROM `" . $table[$i] . "` WHERE `" . $fileds_name[$i] . "` = '" . ${"temp_" . $bak}[$j][$bak] . "';");
				while ($dbMain->next_record()) {
					$k_sql .= "INSERT login_" . $table[$i] . " SET `loginid` = '" . $dbMain->f("id") . "', `uid` = '', `username` = '', `logindate` = '', `langx` = '';";
				}
			}
			//echo $table[$i]."=====".$fileds_name[$i]."====".${"temp_".$bak}[$j][$bak]."<BR>";
		}
	}
	if ($k_sql)	$dbw->muti_query($k_sql);
	//echo $k_sql;
	// 會員層
	if ($temps!="") {
		//放通訊
		//echo "MEM--->080*".$temps."*".$code[$i]."<br>";
		javaConnnection('080,'.$temps.",m",MEMBER_DNS,MEMLOGIN_PORT);
	}
	//exit;
}

function getAGlevel($db,$table,$id) {
	$tmp = $id;
	$db->query("select top_aid from ".$table." where id = ".$id.";",1);
	$no = $db->f("top_aid")%10;
	$db->query("select no_aid as id from no_winloss_".$no." where up_aid = ".$id.";");
	while ($db->next_record()) {
		$tmp.= ",'".$db->f("id")."'";
	}
	return $tmp;
}


//改變狀態
function chg_state($dbMain,$level,$id,$state,$cons="",$ALLorONE="",$enable_layer="") {
	global $record_rid,$uid;
	$fileds_name=Array("scid","cid","sid","aid","mid");
	$table=Array('su_corp','corprator','su_agents','agents','members');
	$temps="";
	$dbM = $dbMain;
	$temp_id="";
	if ($level == "3" && $ALLorONE=="ALL")$id = " id in (".getAGlevel($dbMain,'agents',$id).")";
	else $id ="id = '".$id."'";
	$isLeave = (strpos($cons,"L")*1 > 0)? true:false;


	// ctrl_sub_record($dbMain,$dbTable,$record_rid,$userid,$level,$content,$sql_syntax)
	for ($i=$level;$i < 5;$i++) {
		//echo "level===>".$i."<br>";
 		$id_ary = array();

		if ($i==4) {
			 $sql = "select  id from ".$table[$i];
			 if ($level == 4) $sql .= " where ".$id.";";
			 else $sql .= " where ".$id.";";
			 //echo $sql."<br>";
			 $dbMain->query($sql);
			 $temp_id = $dbMain->get_total_data();
			 $bak=" id ";
		} else {
			$sql="select id from ".$table[$i]." where ".$id." ".$cons.";";
			//echo $sql."<br>";
			$dbMain->query($sql);
			$temp_id = $dbMain->get_total_data();
			$bak = $fileds_name[$i];


			if ($state=="Y"&&$isLeave) {		//禁止登入轉啟用時，要恢復原狀態
					$sql_enable = "enable=enable_last,enable_layer=enable_layer_last,enable_last='',enable_layer_last=''";
			} else {
					$sql_enable = "enable_last=enable,enable='".$state."',enable_layer_last=enable_layer,enable_layer='".$enable_layer."'";
			}

			$upsql="update ".$table[$i]." set ".$sql_enable." where ".$id." ".$cons.";";
			//echo "==>".$upsql;
			ctrl_sub_record($dbMain,"record_ag_sub",$record_rid,$uid,"1","由 [".rtnCLevel($level)."] 層往下修改 [".rtnCLevel($table[$i])."] 帳號的 [啟用狀態], (啟用狀態=".$state.")",$upsql);
			$dbMain->query($upsql);

			//echo "由 [".rtnCLevel($level)."] 層往下修改 [".rtnCLevel($table[$i])."] 帳號的 [啟用狀態], (啟用狀態=".$state.")<br>";
			//echo $upsql."<br>";
		}
		if ($ALLorONE=="ONE" && $i!=4)break;
		if ($temp_id=="") break;

		for ($j=0;$j < count($temp_id); $j++) {
				array_push($id_ary, "'".$temp_id[$j]["id"]."'");
		}

		if (count($id_ary)> 0)  $id=$bak." in (".join(",",$id_ary).")";
	}

	// 會員層
	if ($i > 4) {

				$base_count = 100;
				$count = ceil(count($id_ary)/$base_count);

				for ($k=0; $k < $count; $k++) {

						$output = array_slice($id_ary, $k*$base_count, $base_count, true);

						if ($state=="Y"&&$isLeave) {		//禁止登入轉啟用，要恢復原狀態
								$sql_enable = "enable=enable_last,enable_layer=enable_layer_last,enable_last='',enable_layer_last=''";
						} else {
								$sql_enable = "enable_last=enable,enable='".$state."',enable_layer_last=enable_layer,enable_layer='".$enable_layer."'";
						}

						$upsql="update members set ".$sql_enable." where ".$bak." in(".join(",",$output).") ".$cons.";";
						$dbMain->query($upsql);

						//echo $upsql."<br>";
				}
				ctrl_sub_record($dbMain,"record_ag_sub",$record_rid,$uid,"1","由 [".rtnCLevel($level)."] 層往下修改 [會員] 帳號的 [啟用狀態], (啟用狀態=".$state.")","修改會員帳號啟用狀態為:".$state.",".$upsql);
				//echo "由 [".rtnCLevel($level)."] 層往下修改 [會員] 帳號的 [啟用狀態], (啟用狀態=".$state.")","修改會員帳號啟用狀態為:".$state."<br>";
	}

}

function rtnCLevel($level) {
	switch($level) {
		case "0":	 		return "總監";		break;
		case "1": 			return "股東";		break;
		case "2": 			return "總代理";	break;
		case "3": 			return "代理商";	break;
		case "4": 			return "會員";		break;
		case "su_corp": 	return "總監";		break;
		case "corprator": 	return "股東";		break;
		case "su_agents": 	return "總代理";	break;
		case "agents": 		return "代理商";	break;
		case "mem_winloss":	return "會員";		break;
	}
}

//檢查是否可移轉
function chk_trans_up($db) {
	$qwer="select text from other_set where name='mv_mem'";
	$db->query($qwer,1);
	$chk=$db->f('text');
	if ($chk=="Y") return true;
	else return false;
}

//檢查是否可修改成數
function chk_chg_up1($db) {
	$qwer="select text from other_set where name='ctl1_edit_winloss'";
	$db->query($qwer,1);
	$chk=$db->f('text');
	if ($chk=="Y") return true;
	else return false;
}
function chk_chg_up2($db) {
	$qwer="select text from other_set where name='ctl2_edit_winloss'";
	$db->query($qwer,1);
	$chk=$db->f('text');
	if ($chk=="Y") return true;
	else return false;
}
//檢查報表是否正在結轉中
function chk_chg_rt($db) {
    $qwer="select text from other_set where name='report_date_run'";
    $db->query($qwer,1);
    $chk=$db->f('text');
    if ($chk=="N")return true;
    else return false;
}

//錯誤訊息輸出
function err_msg($tpl,$msg) {
	$tpl->define(array(main=>"err_msg.html"));
	$tpl->assign("ERRMSG",$msg);
	$tpl->parse(BODY,"main");
	$tpl->FastPrint("BODY");
}

//檢查信用額度 &&　會員人數
function chk_credit($dbM,$level,$id,$ups,$now_max,$now_mem) {
	$fileds_name=Array("scid","cid","sid","aid","mid");
	$table=Array('su_corp','corprator','su_agents','agents','mem_winloss');
	$up_level=Array('su_corp','corprator','su_agents','agents','members');
	//上一層
	if ($ups != 0) {
		$sql="select * from ".$table[$level-1]." where id = '".$ups."'";
		//echo $sql."<br>";
		$dbM->query($sql,1);
		$up_max = $dbM->f('maxcredit');
		$up_mem = $dbM->f('max_mem');
	}
	//上一層已經用掉
	//echo $id."<==id<br>";
	if ($id!='')  $id = " and id!='".$id."'";
	$sql="select sum(maxcredit) as total_max,sum(max_mem) as total_mem ";

	$sql.=" from ".$table[$level]." where ".$fileds_name[$level-1]." = '".$ups."'".$id;
	//echo $sql."<br>";
	$dbM->query($sql,1);
	$total_max = $dbM->f('total_max');
	$total_mem = $dbM->f('total_mem');
	// echo "(".$up_max." - ".$total_max." - ".$now_max.")";
	// echo $up_max ."<==上層-". $total_max ."<==己用-". $now_max."<==本次<br>";
	if (($up_max - $total_max - $now_max) < 0) {
		//echo "A";
		$err_msg=$GLOBALS['str_'.$up_level[$level]].$GLOBALS['str_credit'].$GLOBALS['str_over'].$GLOBALS['str_'.$up_level[$level-1]].$GLOBALS['str_credit']."!!";
		err_msg($GLOBALS['tpl'],$err_msg);
		exit;
	}
	//echo $up_mem ."<==上層-". $total_mem ."<==己用-". $now_mem."<==本次<br>";
	// if (($up_mem - $total_mem - $now_mem) < 0) {
	// 	//echo "B";
	// 	$err_msg=$GLOBALS['str_'.$up_level[$level]].$GLOBALS['str_mem_count'].$GLOBALS['str_over'].$GLOBALS['str_'.$up_level[$level-1]].$GLOBALS['str_mem_count']."!!";
	// 	err_msg($GLOBALS['tpl'],$err_msg);
	// 	exit;
	// }
}

//=================mem START===================
//檢查會員人數
function chk_mem($dbM,$level,$id,$ups,$now_mem) {
	$fileds_name=Array("scid","cid","sid","aid","mid");
	$table=Array('su_corp','corprator','su_agents','agents','members');
	$up_level=Array('su_corp','corprator','su_agents','agents','members');
	//上一層
	if ($ups != 0) {
			$sql="select * from ".$table[$level-1]." where id = '".$ups."'";
			//echo "<1>".$sql."<br>";
			$dbM->query($sql,1);
			$up_mem = $dbM->f('max_mem');
	}
	//上一層已經用掉
	//echo $id."<==id<br>";
	$sql = "";
	if ($id!='')  $id = " and id!='".$id."'";

	if ($level==4) {
			$sql="select count(id) as total_mem ";
	} else {
			$sql="select sum(max_mem) as total_mem ";
	}
	$sql.=" from ".$table[$level]." where ".$fileds_name[$level-1]." = '".$ups."'".$id;
	//echo "<2>".$sql."<br>";
	$dbM->query($sql,1);
	$total_mem = $dbM->f('total_mem');

	//echo $up_mem ."<==上層-". $total_mem ."<==己用-". $now_mem."<==本次<br>";
	// if (($up_mem - $total_mem - $now_mem) < 0) {
	// 	//echo "B";
	// 	$err_msg=$GLOBALS['str_'.$up_level[$level]].$GLOBALS['str_mem_count'].$GLOBALS['str_over'].$GLOBALS['str_'.$up_level[$level-1]].$GLOBALS['str_mem_count']."!!";
	// 	err_msg($GLOBALS['tpl'],$err_msg);
	// 	exit;
	// }
}
//=================mem END==================

//本層現金存入提出，update上層cash並寫記錄
function updateCash($db,$now_table,$id,$up_id,$cash,$up_cash,$currency,$ctl_user,$now_user,$pay_type,$up_type,$write_user) {
		$up_level=array("corprator"=>"su_corp","su_agents"=>"corprator","agents"=>"su_agents","members"=>"agents","lv_agents"=>"agents");
		// $ismem = "Y";
		$ismem = "N";
		$up_table = $up_level[$now_table];
		if ($now_table=="lv_agents") {
					$now_table="agents";
					$ismem = "N";
		}
		else if($now_table=="members"){
					$ismem = "Y";
		}
		

		if ($cash!=0&&$now_table!=null) {
				Write_Cash_Record($now_table,$ctl_user,$db,$id,$cash,"0",$currency,$pay_type,$write_user,$_SERVER["REMOTE_ADDR"],$up_id,"",$ismem);
		}

		if ($up_cash!=0&&$up_table!=null) {
				$qstr = "update ".$up_table." set cash=cash-".$up_cash." where id='".$up_id."' limit 1;";
				//echo "【update】".$qstr."<br>";
				$db->query($qstr,1);
				Write_Cash_Record($up_table,$ctl_user,$db,$up_id,$up_cash*-1,"0","RMB",$up_type,$write_user,$_SERVER["REMOTE_ADDR"],$id,$now_user,$ismem);
		}


}

//=================insert cash_record START===================
function Write_Cash_Record($table,$username,$db,$user_id,$cash,$maxcredit,$currency,$pay_type,$level,$ip,$pay_id,$pay_username,$ismem) {

		$db->query("select maxcredit,cash from ".$table." where id='".$user_id."'",1);
		$up_cash = $db->f("cash");
		$up_maxcredit = $db->f("maxcredit");

		$gold = (empty($maxcredit))?($cash):($maxcredit);
		$payway = $gold/ abs($gold);

		$qstr ="INSERT INTO cash_record_".$table." set user_id='".$user_id."',";
		$qstr.="username='".$username."(".$level.")',";
		$qstr.="gdate='".get_adddate()."',";
		$qstr.="gold='".abs($gold)."',";
		$qstr.="payway='".$payway."',";
		$qstr.="pay_type='".$pay_type."',"; 		 //1結帳(H)、2會員結帳(M)、3停用會員(P)、4刪除會員(D)
		$qstr.="pay_id='".$pay_id."',";
		$qstr.="pay_username='".$pay_username."',";
		$qstr.="pay_credit='".$up_maxcredit."',";
		$qstr.="pay_cash='".$up_cash."',";
		$qstr.="currency='".$currency."',";
		$qstr.="ismem='".$ismem."',";
		$qstr.="ip='".$ip."';";

		//echo "【cash_resord】".$qstr."<br>";
		$db->query($qstr,1);

}
//=================insert cash_record END===================


function get_adddate() {
	$today=getdate();
	$today_gmt=gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
	$now_gmt=gmdate("H:i:s",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
	$adddate=$today_gmt." ".$now_gmt;
	return $adddate;
}

function javaConnnection($command,$ip,$port,$back=false) {
	$get="";
	$fp =@fsockopen($ip, $port, $errno, $errstr, 5);
	if (!$fp) {
		//echo "<script>alert('kick member err');</script>";
	} else {
	   fwrite($fp, $command);
	   if ($back) {
		   while (!feof($fp)) {
		       $get.= fgets($fp, 128);
		   }
	   }
	   fclose($fp);
	}
	return $get;
}




//0923,Leslie 特殊總監
function get_fix_sc($dbr,$now_level,$id_ary) {

		$table=Array('corprator','su_agents','agents');
		$level=Array('scid','cid','sid');
		$tmp_ary = Array();
		$scid_ary = Array();
		$link_ary = Array();  //各層id直接對應到scid
		$sc_hash = Array();
		$data_hash = Array();
		$sql = "";




		//--------------------- 1.set conf data ---------------------
		$sql="select name,text from other_set where name in ('conf_winloss_max','conf_winloss_min','conf_gm_winloss_max','conf_gm_winloss_min');";
		$dbr->query($sql);
		while ($dbr->next_record()) {
				$name = str_replace("conf_","",$dbr->f('name'));
				$data_hash["conf"][$name] = $dbr->f('text');
		}
		$data_hash["conf"]["scid"] = "0";
		$data_hash["conf"]["fix8"] = "N";
		$data_hash["conf"]["winloss_fix8"] = "5";

		//nodata
		if (count($id_ary)==1&&$id_ary[0]==null) return $data_hash;

		//--------------------- 2.set level id link to scid ---------------------
		if ($now_level==0) { //sc

				$scid_ary = $id_ary;

				for ($i=0; $i < count($id_ary); $i++) {
						$link_ary[$now_level."_".$id_ary[$i]] = $now_level."_".$id_ary[$i];
				}

		} else if ($now_level==4) { //m

				$sql_ids = "'".join("','",$id_ary)."'";
				$sql = "select id,scid from mem_winloss where mid in(".$sql_ids.");";
				//echo $sql."<br>";
				$dbr->query($sql);

				while ($dbr->next_record()) {

						array_push($scid_ary, $dbr->f("scid"));

						$link_ary[$now_level."_"+$dbr->f("id")] = "0_".$dbr->f("scid");
				}

		} else { //a,s,c

				$tmp_ary = $id_ary;

				for ($i=$now_level-1; $i >=0; $i--) {

						$tmp_table = $table[$i];
						$tmp_leavel = $level[$i];


						$sql_ids = "'".join("','",$tmp_ary)."'";
						$tmp_ary = Array();
						$sql = "select id,".$tmp_leavel." as up_id from ".$tmp_table." where id in(".$sql_ids.");";
						//echo $sql."<br>";
						$dbr->query($sql);
						while ($dbr->next_record()) {

								array_push($tmp_ary, $dbr->f("up_id"));

								$link_ary[($i+1)."_".$dbr->f("id")] = $i."_".$dbr->f("up_id");
						}


				}

				$scid_ary = $tmp_ary;
		}



		//--------------------- 3.get sc data ---------------------
		$sql_ids = "'".join("','",$scid_ary)."'";
		$sql = "select id,fix8,winloss_max,winloss_fix8 from su_corp where id in(".$sql_ids.");";
		//echo $sql."<br>";
		$dbr->query($sql);
		while ($dbr->next_record()) {
				$id = $dbr->f('id');
				$sc_hash["0_".$id]["scid"] = $id;
				$sc_hash["0_".$id]["fix8"] = $dbr->f('fix8');
				$sc_hash["0_".$id]["winloss_max"] = $dbr->f('winloss_max');
				$sc_hash["0_".$id]["winloss_fix8"] = $dbr->f('winloss_fix8');
		}



		//--------------------- 4.set return hash ---------------------
		for ($i=0; $i < count($id_ary); $i++) {

				$id = $id_ary[$i];
				$org_id = $now_level."_".$id;
				$scid = get_fix_scid($now_level,$id,$link_ary);

				foreach ($sc_hash[$scid] as $key=> $value) {
						//echo $key."====".$value."<br>";
						$data_hash[$org_id][$key] = $sc_hash[$scid][$key];
				}


		}


		return $data_hash;
}

//各層id直接對應scid
function get_fix_scid($now_level, $id, $link_ary) {

		$tmp_id = $now_level."_".$id;
		for ($i=0; $i < $now_level; $i++) {

				$tmp_id = $link_ary[$tmp_id];
				if ($tmp_id==null) break;
		}
		return $tmp_id;
}

//sc的資料取不到時取conf
function get_fix_sc_f($hash, $id, $field) {
		$ret = $hash[$id][$field];
		if ($ret==null) $ret=$hash["conf"][$field];
		return $ret;
}

//取得公司的最大最小佔成數
function getCasinoWinloss($dbr,$now_level,$id) {

	/*
	$dbr->query("select text as max_winloss from other_set where name='winloss_max'",1);
	$max_winloss=$dbr->f('max_winloss');
	$dbr->query("select text as min_winloss from other_set where name='winloss_min'",1);
	$min_winloss=$dbr->f('min_winloss');
	*/

	//0923,Leslie 改讀總監上的winloss_max設定
	$sc_hash = get_fix_sc($dbr,$now_level,Array($id));

	$tmp_id = $now_level."_".$id;
	$max_winloss = get_fix_sc_f($sc_hash,$tmp_id,"winloss_max");
	$min_winloss = get_fix_sc_f($sc_hash,$tmp_id,"winloss_min");
	$gm_max_winloss = get_fix_sc_f($sc_hash,$tmp_id,"gm_winloss_max");
	$gm_min_winloss = get_fix_sc_f($sc_hash,$tmp_id,"gm_winloss_min");

	$win = Array($max_winloss,$min_winloss,$gm_max_winloss,$gm_min_winloss);
	return 	$win;
}



//取上層的xx;
function Get_up_ll($ident,$db1,$id) {
	$table=Array('su_corp','corprator','su_agents','agents','mem_winloss');
	$level=Array('scid','cid','sid','aid','mid');
	$cons = Array('',',winloss_sc ,winloss as winloss_c,fix8,winloss_min_sw,winloss_min',',winloss_sc ,winloss_c ,winloss as winloss_s',',winloss_sc ,winloss_c ,winloss_s ,winloss_a');
	$sa_fix8_str="";

	$sqls="select id,term_cash,username,xratio,multiple,currency,c_back ".$cons[$ident-1]." ";
	$sqls.=" from ".$table[$ident-1]." ";
	$sqls.="where  ";
	$sqls.=$level[$ident-1]."='0' ";
	$sqls.="and id ='".$id."'";
	//echo $sqls."<br>";
	$db1->query($sqls,1);
	$sid=$db1->f('id');
	$winloss_sc = $db1->f('winloss_sc');
	$winloss_c = $db1->f('winloss_c');
	$winloss_s = $db1->f('winloss_s');
	$winloss_a = $db1->f('winloss_a');
	$xratio = $db1->f('xratio');
	$multiple = $db1->f('multiple');
	$term_cash = $db1->f('term_cash');
	$currency = $db1->f('currency');
	$c_back = $db1->f('c_back');
	$fix8 = $db1->f('fix8');//只有股東有設--固定8成
	$winloss_min_sw = $db1->f('winloss_min_sw');
	$winloss_min = $db1->f('winloss_min');
	$head_str = "var datas_head='id,username,winloss_sc,winloss_c,winloss_s,winloss_a,term_cash,xratio,multiple,currency,c_back";
	$datas ="var level ='".$level[$ident-1]."';\n";
	$datas.="var datas = new Array();\n";
	if ($db1->num_rows()!=0) {
		$datas.="datas[0] = new Array('".$db1->f('id')."','".$db1->f('username')."',";
		$datas.="'".$winloss_sc."','".$winloss_c."','".$winloss_s."','".$winloss_a."','".$term_cash."','".$xratio."','".$multiple."','".$currency."','".$c_back."'";
		if ($ident==3) {
			$head_str.=",sc_back,c_back,sc_winloss_bak,c_winloss_bak";
			$rest = getAgRelaction($db1,$sid);
			$datas.=",'".$rest[0]."','".$rest[1]."','".$rest[2]."','".$rest[3]."'";
			$sa_fix8_str = ",'".getFix8SA($db1,$sid)."'";
			$sa_fix8_head = ",sa_fix8_str";
		}
		$head_str.=",null,null,null,null,fix8".$sa_fix8_head.",winloss_min_sw,winloss_min";
		$datas.=",'','','','','".$fix8."'".$sa_fix8_str.",'".$winloss_min_sw."','".$winloss_min."');\n";
	}
	$head_str.="';\n";
	return $head_str.$datas ;
}
function Get_Other_up_ll($ident,$db1,$id,$gtype) {
	$datas="";
	if ($ident>=2 && $ident <=4) {

		$table=Array('','co_winloss','su_winloss','ag_winloss');
		$level=Array('','cid','sid','aid');
		$cons = Array('',',winloss_sc ,winloss as winloss_c,fix8,winloss_min_sw,winloss_min',',winloss_sc ,winloss_c ,winloss as winloss_s',',winloss_sc ,winloss_c ,winloss_s ,winloss_a');

		$SQL="select ".$level[$ident-1]." ".$cons[$ident-1];
		$SQL.=" from ".$table[$ident-1]." ";
		$SQL.="where ";
		$SQL.=$level[$ident-1]."='".$id."' and gtype='".$gtype."' ";

		$db1->query($SQL,1);

		$sa_fix8_str="";
		$winloss_gm_sc = $db1->f('winloss_sc');
		$winloss_gm_c = $db1->f('winloss_c');
		$winloss_gm_s = $db1->f('winloss_s');
		$winloss_gm_a = $db1->f('winloss_a');
		$gm_fix8 = $db1->f('fix8');
		$winloss_gm_min_sw = $db1->f('winloss_min_sw');
		$winloss_gm_min = $db1->f('winloss_min');
		$head_str = "var gm_data_head='id,winloss_sc,winloss_c,winloss_s,winloss_a,fix8,winloss_min_sw,winloss_min";
		$datas.="var gm_data = new Array();\n";
		if ($db1->num_rows()!=0) {

			$datas.=" gm_data[0] = new Array('".$id."','".$winloss_gm_sc."','".$winloss_gm_c."','".$winloss_gm_s."','".$winloss_gm_a."','".$gm_fix8."','".$winloss_gm_min_sw."','".$winloss_gm_min."' ";
			if ($ident==3) {
				$head_str.=",sc_back,c_back,sc_winloss_bak,c_winloss_bak,sa_fix8_str";
				$rest = getOtherAgRelaction($db1,$id,$gtype);
				$datas.=",'".$rest[0]."','".$rest[1]."','".$rest[2]."','".$rest[3]."'";
				$sa_fix8_str = ",'".getOtherFix8SA($db1,$id,$gtype)."'";
				$datas.=$sa_fix8_str;
			}
			$datas.="); \n";
		}
	}
	$head_str.="';\n";
	return $head_str.$datas ;
}


//是否為總代理強制佔成
function getFix8SA($db,$sid) {
		$ret = "";
		$sql="select fix8 from su_agents where id='".$sid."' order by id desc limit 1;";
		$db->query($sql,1);

		if ($db->num_rows()!=0) {
				$ret = $db->f('fix8');
		}
		return $ret;
}
function getOtherFix8SA($db,$sid,$gtype) {
		$ret = "";
		$sql="select fix8 from su_winloss where sid='".$sid."' and gtype='".$gtype."' order by id desc limit 1;";
		$db->query($sql,1);

		if ($db->num_rows()!=0) {
				$ret = $db->f('fix8');
		}
		return $ret;
}

//取得上層的關系
function getAgRelaction($dbr,$sid) {
	$dbr->query("select cid,back,winloss_bak from su_agents where id='".$sid."' limit 1",1);
	$cid=$dbr->f('cid');
	$c_back=$dbr->f('back');
	$c_winloss_bak=$dbr->f('winloss_bak');
	$dbr->query("select back,winloss_bak from corprator where id='".$cid."' limit 1",1);
	$sc_back=$dbr->f('back');
	$sc_winloss_bak=$dbr->f('winloss_bak');
	$back = Array($sc_back,$c_back,$sc_winloss_bak,$c_winloss_bak);
	return $back;
}
function getOtherAgRelaction($dbr,$sid,$gtype) {
	$dbr->query("select cid,back,winloss_bak from su_winloss where gtype='".$gtype."' and sid='".$sid."' limit 1",1);
	$cid=$dbr->f('cid');
	$c_back=$dbr->f('back');
	$c_winloss_bak=$dbr->f('winloss_bak');
	$dbr->query("select back,winloss_bak from co_winloss where gtype='".$gtype."' and cid='".$cid."' limit 1",1);
	$sc_back=$dbr->f('back');
	$sc_winloss_bak=$dbr->f('winloss_bak');
	$back = Array($sc_back,$c_back,$sc_winloss_bak,$c_winloss_bak);
	return $back;
}
/*
function get_level_id_130204($db,$type,$id,$ltype="",$flage=":") {
	//echo count($id_arr);
	$ip_arr=explode($flage,$id);
	$tmp="";
	$sub_sql="";
	if ($ltype!="")$sub_sql=" and ltype='".$ltype."'";
	$type_lowtable=array("SC"=>"corprator","C"=>"su_agents","S"=>"agents","A"=>"mem_winloss");
	$type_id=array("SC"=>"scid","C"=>"cid","S"=>"sid","A"=>"aid");
	if ($type_lowtable[$type]=="mem_winloss")$level_id="mid";
	else $level_id="id";
	for ($i=0;$i<count($ip_arr);$i++) {
		$sql="select ".$level_id." as id from ".$type_lowtable[$type]." where ".$type_id[$type]."='".$ip_arr[$i]."'".$sub_sql;
		//echo $sql."<br>";
		$db->query($sql);
		while ($db->next_record()) {
			if ($tmp=="")$tmp=$db->f('id');
			else $tmp.=$flage.$db->f('id');
		}
	}
	//echo $tmp.":";
	return $tmp;
}
*/
//修正id帶空值時 直接回傳空值
function get_level_id($db,$type,$id,$ltype="",$flage=":") {
	//echo count($id_arr);
	$tmp="";
	if ($id!="") {
		$ip_arr=explode($flage,$id);
		$sub_sql="";
		if ($ltype!="")$sub_sql=" and ltype='".$ltype."'";
		$type_lowtable=array("SC"=>"corprator","C"=>"su_agents","S"=>"agents","A"=>"members");
		$type_id=array("SC"=>"scid","C"=>"cid","S"=>"sid","A"=>"aid");
		if ($type_lowtable[$type]=="mem_winloss")$level_id="mid";
		else $level_id="id";
		for ($i=0;$i<count($ip_arr);$i++) {
			$sql="select ".$level_id." as _id from ".$type_lowtable[$type]." where ".$type_id[$type]."='".$ip_arr[$i]."'".$sub_sql;
			//echo $sql."<br>";
			$db->query($sql);
			while ($db->next_record()) {
				if ($tmp=="")$tmp=$db->f('_id');
				else $tmp.=$flage.$db->f('_id');
			}
		}
	}
	//echo $tmp.":";
	return $tmp;
}
/*
$id 可以使用 1,2 的格式
一次刪四個conf table
*/
function del_conf($dbw,$conf_table,$filed,$id) {
	global $REC_sub_table,$record_rid,$uid,$REC_level;
	$grp=5;
	$del_qstr="DELETE FROM ".$conf_table." WHERE ".$filed." in('".$id."')";
	ctrl_sub_record($dbw,$REC_sub_table,$record_rid,$uid,$REC_level,"刪除群組 ".$conf_table,$del_qstr);
	$dbw->query($del_qstr);
}

//刪除的備份用
function backup_data($dbw,$level,$ids) {
	$table=Array('su_corp','corprator','su_agents','agents','members','mem_winloss');
	$back_db =DB_NAME."_bak";
	//$db = new proc_DB(DB_MAIN_W,DB_USER,DB_PWD,$back_db);
	//主資料
	$sqls="insert into ".$back_db.".".$table[$level]." ";
	$sqls.="select * from ".DB_NAME.".".$table[$level]." ";
	$sqls.="where id in (".$ids.")";
	$dbw->query($sqls);
	if ($leve==4) {
		$sub_sql=" insert into ".$back_db.".".$table[$level+1]." ";
		$sub_sql.="select * from ".DB_NAME.".".$table[$level+1]." ";
		$sub_sql.="where id in (".$ids.")";
		$dbw->query($sub_sql);
	}
}



//確認是否有人下注
function chk_ticket($dbr,$level,$id,$gArr) {
        $DB_ary["Ticket"] = new proc_DB(DB_TICKET_HOST_R,DB_USER_R,DB_PWD_R,DB_TICKET_NAME);
        $DB_ary["Wager"] = new proc_DB(DB_WAGERS_HOST_R,DB_USER_R,DB_PWD_R,DB_WAGERS_NAME);
        $fileds=Array("scid","cid","sid","aid","mid");
        $tableArr = Array("Ticket","Wager");
		if ($level == 3) {
			$aid = getAGlevel($dbr,"agents","'".$id."'");
			$sql="SELECT id as mid FROM members  WHERE ".$fileds[$level]." in (".$aid.")";
		} else {
			$sql="SELECT mid FROM mem_winloss  WHERE ".$fileds[$level]."='".$id."'";
		}
		$dbr->query($sql);
        //$recordcount=$dbr->num_rows();
        while ($dbr->next_record()) {
                $mmid=$dbr->f('mid');
                //先檢查TICKET

                for ($i=0;$i<count($tableArr);$i++) {

		                for ($m=0;$m<count($gArr);$m++) {
		                        $sql = "SELECT COUNT(id) AS num FROM ".$tableArr[$i].strtolower($gArr[$m])." WHERE mid='".$mmid."';";
		                        $DB_ary[$tableArr[$i]]->query($sql,1);
		                        $count+=$DB_ary[$tableArr[$i]]->f('num')*1;
		                }
		                if ($count > 0)  return false;

                }

        }
        return true;
}


//確認下層是否有未結算注單

function chk_no_result_ticket($dbr,$gameAry,$level,$id) {

		$DB_TICKET_R = new proc_DB(DB_TICKET_HOST_R,DB_USER_R,DB_PWD_R,DB_TICKET_NAME);

		$id_ary = Array();
		$id_ary["mid"] = Array();
		$fileds = Array("scid","cid","sid","aid","mid");
		$count = 0;


		//取所有會員
		$sql = "SELECT mid FROM mem_winloss WHERE ".$fileds[$level]."='".$id."'";
		//echo $sql."<br>";
		$dbr->query($sql);
		if ($dbr->num_rows()<=0)  return false;  //底下無會員

		while ($dbr->next_record()) {
				array_push($id_ary["mid"], "'".$dbr->f('mid')."'");
		}



		foreach ($gameAry as $key => $game) {

				$id_ary[$game] = Array();
				$DB_FT_R = new proc_DB(DB_HOST_FT,DB_USER,DB_PWD, getSwitchFT($game));

				$sql = "select id from ".strtoUpper($game)." where gover!='Y';";
				$DB_FT_R->query($sql);
				if ($DB_FT_R->num_rows()> 0) {

						while ($DB_FT_R->next_record()) {
								array_push($id_ary[$game], "'".$DB_FT_R->f('id')."'");
						}


						$sql = "select count(id) as total from Ticket".strtoLower($game)." where";
						$sql.= " baid in (".join(",",$id_ary[$game]).") and mid in (".join(",",$id_ary["mid"]).");";
						//echo $sql."<br>";
						$DB_TICKET_R->query($sql);
						while ($DB_TICKET_R->next_record()) {
								//echo "while===>".$DB_TICKET_R->f("total")."<br>";
								$count += $DB_TICKET_R->f("total")*1;
						}
						//echo "count===>".$count."<br>";

				}
		}

		return ($count > 0)? true:false;

}



//sum本層以下帳號的cash
function sum_low_cash($db,$id_ary,$now) {
		$table=Array('su_corp','corprator','su_agents','agents','members');
		$total_cash = 0;

		for ($i=$now; $i< count($table); $i++) {
				$level = $table[$i];
				$ids = $id_ary[$level];

				if ($ids!="") {
						if ($i!=4) {
								$sql_cash="select sum(maxcredit) as total_m, sum(cash) as total from ".$level." where id in(".$ids.");";
						} else {
								$sql_cash = "select sum(members.cash*(mem_winloss.value/10000)) as total_m,sum(members.maxcredit*(mem_winloss.value/10000)) as total from members,mem_winloss where members.id in(".$id_ary[$level].") and members.id=mem_winloss.mid;";
						}
						//echo "<!--".$sql_cash."-->";
						$db->muti_query($sql_cash);
						//echo "db->f(total)*1===>".$db->f("total")."---".($db->f("total")*1)."<br>";

						$total_cash+=($db->f("total")*1+$db->f("total_m")*1);
				}
		}
		return $total_cash;
}


//逐層將cash往上押(停用時)
function update_cash_toUpLevel($dbw,$dbr,$id,$now,$ctl_user) {
		$db = new proc_DB(DB_HOST,DB_USER,DB_PWD,DB_NAME);
		$table=Array('su_corp','corprator','su_agents','agents','members');
		$fileds=Array("scid","cid","sid","aid","mid");
		$ids = Array();

		$ids[$table[$now]] = "'".$id."'";


		//取得下層id
		for ($i=$now+1; $i< count($table); $i++) {

				$low_level = $table[$i];
				$level = $table[$i-1];
				if (empty($ids[$level]))  break;

				$sql="select id from ".$low_level." where ".$fileds[$i-1]." in(".$ids[$level].");";
				//echo "<!--取得下層id==>".$sql."-->";
				$dbr->query($sql);
				while ($dbr->next_record()) {
						$ids[$low_level].="'".$dbr->f("id")."',";
				}
				$ids[$low_level] = substr($ids[$low_level],0,-1);

		}


		for ($i=count($table)-1; $i>= $now ; $i--) {
				$up_level = ($i==$now)? $table[$i]:$table[$i-1];
				$level = $table[$i];
				$up_id = ($i==0)? "id":$fileds[$i-1];
				$id = ($i==$now)? "id":$fileds[$i-1];

				$cur_value = 1;
				if (empty($ids[$up_level]))  continue;

				if ($level=="members") {
						$sql = "SELECT members.".$up_id." as up_id,members.id as id,members.username as username,members.cash as cash,mem_winloss.value as cur_value,mem_winloss.currency as currency";
						$sql.= " FROM members,mem_winloss WHERE members.".$id." IN (".$ids[$up_level].") and mem_winloss.mid=members.id;";
				} else {
						$sql = "SELECT ".$up_id." as up_id,id,cash,username FROM ".$level;
						$sql.= " WHERE ".$id." IN (".$ids[$up_level].");";
				}

				//echo "<!--sum==>".$sql."-->";
				$dbw->query($sql);
				while ($dbw->next_record()) {
						$up_id = $dbw->f("up_id");
						$cash = $dbw->f("cash");
						$id = $dbw->f("id");
						$username = $dbw->f("username");
						$currency = ($level=="members")? $dbw->f("currency"):"RMB";
						$cur_value = ($level=="members")? $dbw->f("cur_value")/10000:1;

						//echo $level."(".$id.")給上層==>".$up_id.",cash=".($cash*$cur_value)."<br>";


						////$sql = "update ".$up_level." set cash=(cash+".$cash.") where id='".$up_id."' limit 1;";
						$sql = "update ".$level." set cash=0 where id='".$id."' limit 1;";
						//echo "【update】".$sql."<br>";
						$db->query($sql);


						updateCash($db,$level,$id,$up_id,$cash*-1,$cash*$cur_value*-1,$currency,$ctl_user,$username,"E","E","CTL");

				}
				//echo "=====================================<br>";
		}


		return;
}
//===========確認下層可用點數是否為0 start===========
function chk_lowlevel_no_cash($dbr,$now,$id) {
		$table=Array('su_corp','corprator','su_agents','agents','members');
		$fileds=Array("scid","cid","sid","aid","mid");

		$tmpAry = Array();
		$countAry = Array("ids"=>"","cash"=>0);

		$countAry["ids"] = $id;

		for ($i=$now; $i< count($table); $i++) {
				$up_id = ($i==$now)? "id":$fileds[$i-1];
				$tmpAry = getLevelCash($dbr,$table[$i],$up_id,$countAry["ids"]);
				$countAry["ids"] = $tmpAry["ids"];
				$countAry["cash"] += $tmpAry["cash"];
		}

		return ($countAry["cash"]!=0)? false:true;
}

function getLevelCash($dbr,$table,$now_id,$ids) {
		$tmpAry = Array("ids"=>"","cash"=>0);
		$sql="SELECT id,cash FROM ".$table."  WHERE ".$now_id." in(".$ids.");";
		//echo $sql."<br>";
		$dbr->query($sql);
		while ($dbr->next_record()) {
				$tmpAry["ids"].="'".$dbr->f("id")."',";
				$tmpAry["cash"]+=$dbr->f("cash")*1;
		}
		$tmpAry["ids"]=substr($tmpAry["ids"],0,-1);
		return $tmpAry;
}
//===========確認下層可用點數是否為0 end===========



function get_ip_arr($db,$type,$upid,$ltype="") {
	switch($type) {
		case "sc":
			$count=0;
			break;
		case "co":
			$count=1;
			break;
		case "su":
			$count=2;
			break;
		case "ag":
			$count=3;
			break;
	}
	// $level=array("su_corp","corprator","su_agents","agents","mem_winloss");
	$level=array("su_corp","corprator","su_agents","agents","members");
	$level_id=array("scid","cid","sid","aid");
	if ($level[$count+1]=="members") {
		$type_id="id";
		if ($ltype!="") {
			$sub_sql=" and ltype=".$ltype;
		} else {
			$sub_sql="";
		}
	} else {
		$type_id="id";
		$sub_sql="";
	}
	$db->query("select ".$type_id." as id from ".$level[$count+1]." where ".$level_id[$count]."='".$upid."'".$sub_sql);
	if ($db->num_rows()!=0) {
		$tmp_id=$db->get_total_data();
	}
	return $tmp_id;
}

//會員VALUE的取得
function get_value($db,$id) {
	$quer="select value from mem_winloss where mid='".$id."'";
	$db->query($quer,1);
	return $db->f('value');
}

// ctrl_record 使用 , ( 傳回 Record 搜尋的正確格式 )
function rtnGameType($gtype,$rtype) {
	$cGtype=$gtype;
	$cRtype=$rtype;
	return "[".$cGtype."][".$cRtype."]";
}
function UPDATE_WAGERS($up_sql) {
	$DB_TIC_W = new proc_DB(DB_TICKET_HOST,DB_USER,DB_PWD,DB_TICKET_NAME);
	$DB_WAGERS_W = new proc_DB(DB_WAGERS_HOST,DB_USER,DB_PWD,DB_WAGERS_NAME);
	$gtypeArr = array("ba","bo","ro","dt");
	for ($i=0;$i<count($gtypeArr);$i++) {
		$sql="UPDATE Ticket".$gtypeArr[$i]." ".$up_sql;
		$DB_TIC_W->query($sql);
		$sql="UPDATE Wager".$gtypeArr[$i]." ".$up_sql;
		$DB_WAGERS_W->query($sql);
	}
	$sql="UPDATE report ".$up_sql;
	$DB_WAGERS_W->query($sql);
	$sql="UPDATE report_rank ".$up_sql;
	$DB_WAGERS_W->query($sql);
	$DB_TIC_W->close();
	$DB_WAGERS_W->close();
}
function chkCurrency($level,$id,$dbr,$currency) {
	//return false;
	$fileds_name=Array("scid","cid","sid","aid","mid");
	$table=Array('su_corp','corprator','su_agents','agents','mem_winloss');
	$dbr->query("select currency from ".$table[$level+1]." where ".$fileds_name[$level]."='".$id."'");
	$sc_cur_Ary=explode(":",substr($currency,0,-1));
	while ($dbr->next_record()) {
		$tmp_currency=substr($dbr->f('currency'),0,-1);
		if (empty($currency)&&$tmp_currency) return true;
		if ($tmp_currency) {
			$Cur_Ary=explode(":",$tmp_currency);
			foreach ($Cur_Ary as $value) {
				//if (!preg_match("/".$value.":/",$currency)) return true;
				$tmp_count=0;
				for ($i=0;$i < count($sc_cur_Ary);$i++) {
					if ($sc_cur_Ary[$i]==$value)  $tmp_count++;
				}
				//echo $tmp_count."<br>";
				if ($tmp_count==0) return true;
			}
		}
	}
}
//改變結帳及額度回補
function Update_Reference($dbMain,$level,$id,$state,$field) {
	global $record_rid,$uid;
	$fileds_name=Array("scid","cid","sid","aid","mid");
	$table=Array('su_corp','corprator','su_agents','agents','mem_winloss');
	$id_ary = Array();
	$temps="";
	$dbM = $dbMain;
	$dbr = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);
	$temp_scid="";
	$temp_cid="";
	$temp_sid="";
	$temp_aid="";
	$id ="id = '".$id."'";

	for ($i=$level;$i < 5;$i++) {



		if ($i==4) {
			if ($field=='term_cash') break;
			$sql = "select mid as ".$fileds_name[$i]." from ".$table[$i];
			if ($level == 4) $sql .= " where m".$id;
			else $sql .= " where ".$id;
			//echo $sql."<br>";
			$dbr->query($sql);
			${"temp_".$fileds_name[$i]} = $dbr->get_total_data();
			$bak=" id ";
		} else {
			$sql="select id as ".$fileds_name[$i]." from ".$table[$i]." where ".$id." ";
			//echo $sql."<br>";
			$dbr->query($sql);
			${"temp_".$fileds_name[$i]} = $dbr->get_total_data();
			$bak = $fileds_name[$i];
			$upsql="update ".$table[$i]." set ".$field."='".$state."' where ".$id." ";
			//ctrl_sub_record($dbMain,"record_ag_sub",$record_rid,$uid,"1","由 [".rtnCLevel($level)."] 層往下修改 [".rtnCLevel($table[$i])."] 帳號的 [啟用狀態], (啟用狀態=".$state.")",$upsql);
			$dbMain->query($upsql);
		}
		if (${"temp_".$fileds_name[$i]}=="") break;


		$id_ary = Array();


		for ($j=0;$j < count(${"temp_".$fileds_name[$i]});$j++) {

			$tmp_id = ${"temp_".$fileds_name[$i]}[$j][$fileds_name[$i]];
			array_push($id_ary, "'".$tmp_id."'");

		}

		if (count($id_ary)> 0)  $id=" ".$bak." in(".join(",",$id_ary).") ";

		//echo "id=>".$id."<br>";



	}
	// 會員層


	if ($i > 4) {
		if ($id!="") {
			$upsql="update members set ".$field."='".$state."' where ";

			$base_count = 3;
			$count = ceil(count($id_ary)/$base_count);

			for ($x=0;$x < $count;$x++) {
					$out_ary = array_slice($id_ary, $x*$base_count, $base_count, true);

					$sql = $upsql." id in (".join(",",$out_ary).")";
					//echo $sql."<br>";
					$dbMain->query($sql);

			}

			//ctrl_sub_record($dbMain,"record_ag_sub",$record_rid,$uid,"1","由 [".rtnCLevel($level)."] 層往下修改 [會員] 帳號的 [啟用狀態], (啟用狀態=".$state.")","修改會員帳號啟用狀態為:".$state,$upsql);
		}



	}


	$dbr->close();
}



//是否為股東強佔 (股東最低佔成開，股東最高佔成=股東最低佔成)
function checkOccupy($sw,$max,$min) {
		$ret = "N";
		$sw = format_winloss_sw($sw);
		if ($sw=="Y") {

				$max = format_winloss($max);
				$min = format_winloss($min);
				if ($max==$min) {
						$ret="Y";
				}
		}
		return $ret;
}

//winloss_min_sw Y/N
function format_winloss_sw($sw) {
		return ($sw=="Y")?"Y":"N";

}

//winloss 0-100
function format_winloss($winloss, $isNum=false) {
		$wl = $winloss*1;
		$ret = (0<=$wl && $wl<=100)? $winloss:"0";
		return ($isNum)? $ret*1:$ret;

}



//無條件捨去
function util_floorNumber($num) {
		return floorNumber($num, 2);
}

//無條件捨去 b:位數
function floorNumber($num, $b) {

		$t = 1;
		$base = 1;
		$ret = 0;
		$msg = "";

		$b = floor(abs($b));
		$t = pow(10, $b);
		$base = ($num < 0)? -1:1;

		$num = abs($num);
		$ret = (floor(($num*$t)+0.00000001)/$t)*$base;


		$msg.="before=".$num.",after=".$ret."<br>";
		//echo "<!--".$msg."-->";

		return $ret;
}

function get_conf_coin($dbr,$gtype) {
	$ret = Array();
	if ($gtype=="GM") {
		//$gm_qstr="SELECT * FROM other_set WHERE name in('GM_RMB_maxcoinsize','GM_RMB_mincoinsize','GM_RMB_coinsizeLimit')";
		$gm_qstr="SELECT * FROM other_set WHERE name in('GM_RMB_coinsizeLimit')";
		$dbr->query($gm_qstr);
		while ($dbr->next_record()) {
			$ret[$dbr->f("name")] = $dbr->f("text");
		}
	}
	return $ret;
}

function roundByArray($ary,$val,$isFloor=true) {// max is floor   min is roof
	/*
	ary{
		index 0,1,2,3,4
		value 2,4,6,8,10
	}
	val isFloor
	1  true =>2  false=>2
	3  true =>2  false=>4
	5  true =>4  false=>6
	9	 true =>8  false=>10
	11 true =>10  false=>10
	*/
	if (in_array($val,$ary))return $val;
	if ($val < $ary[0]) return $ary[0];
	for ($i=1;$i<count($ary)-1;$i++) {
		if ( $val < $ary[$i+1] ) return ($isFloor)?$ary[$i]:$ary[$i+1];
	}
	return $ary[$i];
}

//
// function get_layer_coin($dbr,$gtype,$layer,$id,$up_layer,$up_id) {
// 	$ret = array();
// 	if ($gtype=="GM") {
// 		$gm_qstr="SELECT * FROM ".$layer."_coin WHERE user_id ='".$id."' and gtype='gm' ";
// 		$dbr->query($gm_qstr);
// 		while ($dbr->next_record()) {
// 			$tmp=Array();
// 			$tmp["key"] = $dbr->f("type");
// 			$tmp["value"] = $dbr->f("size");
// 			$ret[] = $tmp;
// 		}
// 		if ($up_layer!="") {
// 			$gm_qstr="SELECT * FROM ".$up_layer."_coin WHERE user_id ='".$up_id."' and gtype='gm' ";
// 			$dbr->query($gm_qstr);
// 			while ($dbr->next_record()) {
// 				$tmp=Array();
// 				$tmp["key"] = "up_".$dbr->f("type");
// 				$tmp["value"] = $dbr->f("size");
// 				$ret[] = $tmp;
// 			}
// 		}
// 	}
// 	return $ret ;
// }

?>
