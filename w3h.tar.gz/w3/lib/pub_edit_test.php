<?php
//=================確認上層會員限制和信用額度START==================
function chk_uplevel_credut($type,$maxcredit,$max_mem,$db1,$upid,$id=""){

	$uptype_id=array("corprator"=>"scid","su_agents"=>"cid","agents"=>"sid","members"=>"aid");
	$up_level=array("corprator"=>"su_corp","su_agents"=>"corprator","agents"=>"su_agents","members"=>"agents");

	$db1->query("select maxcredit,max_mem from ".$up_level[$type]." where id='".$upid."'",1);
	//echo "select maxcredit,max_mem from ".$up_level[$type]." where id='".$upid."'<br>";
	$scmaxcredit=$db1->f('maxcredit');
	$scmaxmem=$db1->f('max_mem');
	if($id==""){
		$subsql="";
	}else{
		$subsql="and id<>'".$id."'";
	}

	$db1->query("select sum(maxcredit) as sc_maxcredit,sum(max_mem) as sc_max_mem from ".$type." where ".$uptype_id[$type]."='".$upid."'".$subsql,1);
	$sc_maxcredit=$db1->f('sc_maxcredit');
	$sc_max_mem=$db1->f('sc_max_mem');



	if($maxcredit+$sc_maxcredit > $scmaxcredit){
		$err_msg=$GLOBALS['str_'.$type].$GLOBALS['str_credit'].$GLOBALS['str_over'].$GLOBALS['str_'.$up_level[$type]].$GLOBALS['str_credit']."!!";
		err_msg($GLOBALS['tpl'],$err_msg);
		exit;
	}
	//echo $max_mem." + ".$sc_max_mem." > ".$scmaxmem."<br>";
	// if($max_mem+$sc_max_mem > $scmaxmem){
	// 	$err_msg=$GLOBALS['str_'.$type].$GLOBALS['str_mem_count'].$GLOBALS['str_over'].$GLOBALS['str_'.$up_level[$type]].$GLOBALS['str_mem_count']."!!";
	// 	err_msg($GLOBALS['tpl'],$err_msg);
	// 	exit;
	// }
}
//=================確認上層會員限制和信用額度END=====================
//=================確認下層會員限制和信用額度START===================
function chk_lowlevel_credut($type,$id,$db1,$maxcredit,$max_mem){
	$today=getdate();
	$today_gmt=gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));

	$type_id=array("su_corp"=>"scid","corprator"=>"cid","su_agents"=>"sid");
	$low_level=array("su_corp"=>"corprator","corprator"=>"su_agents","su_agents"=>"agents","agents"=>"members");
	if($type=="agents"){
		$db1->query("select SUM(members.maxcredit*mem_winloss.value) as sc_maxcredit,count(mem_winloss.mid) as sc_max_mem  from members,mem_winloss where mem_winloss.aid ='".$id."' AND members.id=mem_winloss.mid ",1);
		$sc_maxcredit=$db1->f('sc_maxcredit');
		$sc_max_mem=$db1->f('sc_max_mem');
		$db1->query("select sum(gold*value) as useterm from cash_record_members,mem_winloss where cash_record_members.user_id=mem_winloss.mid and mem_winloss.aid='".$id."' and cash_record_members.gdate like '".$today_gmt."%' and cash_record_members.pay_type = 'H' and cash_record_members.payway = '1'",1);
		$useterm = round($db1->f("useterm")/10000);
		$sc_maxcredit = round($sc_maxcredit / 10000)+$useterm;
	}else{
		$db1->query("select SUM(maxcredit)as sc_maxcredit,SUM(max_mem)as sc_max_mem  from ".$low_level[$type]." where ".$type_id[$type]." ='".$id."'",1);
		$sc_maxcredit=$db1->f('sc_maxcredit');
		$sc_max_mem=$db1->f('sc_max_mem');
		//$db1->query("select sum(gold*value) as useterm from cash_record_members,mem_winloss where cash_record_members.mid=mem_winloss.mid and mem_winloss.".$type_id[$type]." ='".$id."' and cash_record_members.gdate like '".$today_gmt."%' and cash_record_members.pay_type = 'H' and cash_record_members.payway = '1'",1);
		//$useterm = round($db1->f("useterm")/10000);
		//$sc_maxcredit = $sc_maxcredit+$useterm;
	}
	if($sc_maxcredit > $maxcredit){
		if($type=="agents"){
			$err_msg=$GLOBALS['str_creditamendment'];
			err_msg($GLOBALS['tpl'],$err_msg);
			exit;
	 	}else{
	 		$err_msg=$GLOBALS['str_'.$type].$GLOBALS['str_credit'].$GLOBALS['str_small'].$GLOBALS['str_'.$low_level[$type]].$GLOBALS['str_credit']."!!";
			err_msg($GLOBALS['tpl'],$err_msg);
			exit;
		}
	}
	// if($sc_max_mem > $max_mem){
	// 	$err_msg=$GLOBALS['str_'.$type].$GLOBALS['str_mem_count'].$GLOBALS['str_small'].$GLOBALS['str_'.$low_level[$type]].$GLOBALS['str_mem_count']."!!";
	// 	err_msg($GLOBALS['tpl'],$err_msg);
	// 	exit;
	// }
}
//=================確認下層會員限制和信用額度END==================

//=================mem START===================
function chk_lowlevel_mem($type,$id,$db1,$max_mem){
    //echo "chk_lowlevel 0<br>";
	
	$type_id=array("su_corp"=>"scid","corprator"=>"cid","su_agents"=>"sid");
	$low_level=array("su_corp"=>"corprator","corprator"=>"su_agents","su_agents"=>"agents","agents"=>"members");
    //echo "chk_lowlevel 1<br>";
	if($type=="agents"){
        //echo "chk_lowlevel 2<br>";
        $sql="select count(mem_winloss.mid) as sc_max_mem  from members,mem_winloss where mem_winloss.aid ='".$id."' AND members.id=mem_winloss.mid ";
        //echo "sql = ".$sql."<br>";
		$db1->query("select count(mem_winloss.mid) as sc_max_mem  from members,mem_winloss where mem_winloss.aid ='".$id."' AND members.id=mem_winloss.mid ",1);
        
        $sc_max_mem=$db1->f('sc_max_mem');
	}else{
        //echo "chk_lowlevel 3<br>";
        $sql="select SUM(max_mem)as sc_max_mem  from ".$low_level[$type]." where ".$type_id[$type]." ='".$id."'";
        //echo "sql = ".$sql."<br>";
		$db1->query("select SUM(max_mem)as sc_max_mem  from ".$low_level[$type]." where ".$type_id[$type]." ='".$id."'",1);
		$sc_max_mem=$db1->f('sc_max_mem');
	}
    //echo "chk_lowlevel 4<br>";
	// if($sc_max_mem > $max_mem){
	// 	$err_msg=$GLOBALS['str_'.$type].$GLOBALS['str_mem_count'].$GLOBALS['str_small'].$GLOBALS['str_'.$low_level[$type]].$GLOBALS['str_mem_count']."!!";
	// 	err_msg($GLOBALS['tpl'],$err_msg);
	// 	exit;
	// }
}
//=================mem END==================

function get_self_cash($db,$level,$id){
		$table=Array('su_corp','corprator','su_agents','agents','members');
		$db->query("select cash from ".$table[$level]." where id='".$id."' order by id desc;",1);

		$cash = ($db->num_rows()> 0)? $db->f('cash'):0;

		if($level==4){
				$db->query("select value from mem_winloss where mid='".$id."' order by id desc;",1);
				$value = $db->f("value")/10000;
				$cash*=$value;
		}

		return $cash;
}

//=================cash START===================
function chk_uplevel_cash($type,$up_id,$db1,$chk_cash){

	$type_id=array("corprator"=>"scid","su_agents"=>"cid","agents"=>"sid","members"=>"aid");
	$up_level=array("corprator"=>"su_corp","su_agents"=>"corprator","agents"=>"su_agents","members"=>"agents");

	$get_upcash_sql="select cash as up_cash from ".$up_level[$type]." where id='".$up_id."' order by id desc;";
	echo "get_upcash_sql=".$get_upcash_sql."<br>";
	$db1->query($get_upcash_sql,1);  //取得上層cash
	$up_cash = $db1->f('up_cash');
	echo "chk_cash=".$chk_cash."<br>";
	echo "up_cash=".$up_cash."<br>";

	if($chk_cash*1 > $up_cash*1){
            header("Content-Type:text/html; charset=utf-8");
	 		$err_msg=$GLOBALS['str_'.$type].$GLOBALS['str_new_cash'].$GLOBALS['str_over'].$GLOBALS['str_'.$up_level[$type]].$GLOBALS['str_new_cash']."!!";
			err_msg($GLOBALS['tpl'],$err_msg);
			exit;
	}

}
//=================cash END==================


//=================確認代理商會員限制和信用額度START===================
function M_chk_uplevel_credut($now_max,$db1,$aid,$maxcredit,$id=""){
	$today=getdate();
	$today_gmt=gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
	$DB_TIC_R = new proc_DB(DB_TICKET_HOST_R,DB_USER_R,DB_PWD_R,DB_TICKET_NAME);
	$db1->query("select maxcredit,max_mem from agents where id='".$aid."'",1);
	$scmaxcredit=$db1->f('maxcredit');
	$scmaxmem=$db1->f('max_mem');
	if($id==""){
		$subsql="";
		$subsql1="";
	}else{
		$subsql="and members.id<>'".$id."'";
		$subsql1="and id<>'".$id."'";
	}

	$db1->query("select SUM(members.maxcredit*mem_winloss.value) as a_max_sum from members,mem_winloss where mem_winloss.aid='".$aid."' and mem_winloss.mid=members.id ".$subsql,1);
	//echo "select SUM(members.maxcredit*mem_winloss.value) as a_max_sum  from members,mem_winloss where mem_winloss.aid='".$aid."' and mem_winloss.mid=members.id ".$subsql."<br>";
	$sc_maxcredit=$db1->f('a_max_sum');
	$sc_maxcredit=round($sc_maxcredit / 10000);
	$db1->query("select sum(gold*value) as useterm from cash_record_members,mem_winloss where cash_record_members.user_id=mem_winloss.mid and mem_winloss.aid='".$aid."' and cash_record_members.gdate like '".$today_gmt."%' and cash_record_members.pay_type = 'H' and cash_record_members.payway = '1'",1);
	$useterm = round($db1->f("useterm")/10000);
	$db1->query("select id from mem_winloss where aid='".$aid."' ".$subsql1,1);
	$sc_max_mem=$db1->num_rows();
	if($id==""){$sc_max_mem=$sc_max_mem+1;}
	$now_max= round($now_max / 10000);

	if($now_max+$sc_maxcredit+$useterm > $scmaxcredit){

		$err_msg=$GLOBALS['str_members'].$GLOBALS['str_credit'].$GLOBALS['str_over'].$GLOBALS['str_agents'].$GLOBALS['str_credit']."!!";
		err_msg($GLOBALS['tpl'],$err_msg);
		exit;
	}
	//echo $sc_max_mem." > ".$scmaxmem;exit;
	if($sc_max_mem > $scmaxmem){
		$err_msg=$GLOBALS['str_members'].$GLOBALS['str_mem_count'].$GLOBALS['str_over'].$GLOBALS['str_agents'].$GLOBALS['str_mem_count']."!!";
		err_msg($GLOBALS['tpl'],$err_msg);
		exit;
	}
	if ($id){
		$db1->query("select cash from members where id=".$id,1);
		if ($db1->f("cash")+$maxcredit < 0){
			err_msg($GLOBALS['tpl'],$GLOBALS['str_more_gold']);
			exit;
		}
	}
}
//=================確認代理商會員限制和信用額度END===================
//=========================確認帳號是否使用START==========================
function chk_account($type,$db1,$username,$id=""){
	//echo "type=".$type."<br>";
	//echo "username=".$username."<br>";
	//echo "id=".$id."<br>";
	if($id==""){
		$subsql="";//echo "chk_account!!  1<br>";
	}else{
		$subsql=" and id <>'".$id."'";//echo "chk_account!!  2<br>";
	}
	//echo "chk_account!!  3<br>";
	if($type=="members") $sql_pre = " and prefix=0 ";
    else $sql_pre = " ";
    $sql="select id from ".$type." where username='".$username."' ".$subsql.$sql_pre;
    echo "sql = ".$sql."<br>";
	$db1->query("select id from ".$type." where username='".$username."' ".$subsql.$sql_pre,1);
	if($db1->num_rows() > 0 ){
		echo "chk_account!!  4<br>";
		$err_msg=$GLOBALS["LVar"]['Err_account'];
		err_msg($GLOBALS['tpl'],$err_msg);
		exit;
	}
}
//=========================確認帳號是否使用END==========================
//=========================股東強制站成判斷============================
function chk_co_winloss($db,$id,$winloss_c){ //return  true false
	$suag_str = Array();
	//$suag_all = "";

	$qstr="select * from su_agents where cid =".$id." and sid=0 and winloss_c + winloss != ".$winloss_c." limit 1";
	$db->query($qstr);
	if($db->num_rows() > 0) return true;
	$db->query("SELECT id, back, winloss_bak FROM su_agents WHERE  `cid` =".$id." and sid=0");
	while($db->next_record()) {
		if($db->f("back")=="Y"){
			$suag_str[($db->f("winloss_bak"))] .= $db->f("id").",";
		}
		else $suag_str[0].= $db->f("id").",";
		//$suag_all .= $db->f("id").",";
	}
	foreach ($suag_str as $winloss_bak => $id) {
    //echo "\$suag_str[$winloss_bak] => $id.\n<br>";
    $id = substr($id,0,strlen($id)-1);
    if($winloss_bak == 0) $qstr = "SELECT * FROM agents WHERE sid in (".$id.") and aid=0 and (winloss_s + winloss_a + winloss_c != ".$winloss_c.") and level='0' limit 1";
		else $qstr = "SELECT * FROM agents WHERE sid in (".$id.") and aid=0 and (winloss_s + winloss_a + winloss_c < ".($winloss_c - $winloss_bak)."  or  winloss_s + winloss_a + winloss_c > ".$winloss_c.") and level='0' limit 1";
		// echo $qstr."<br>";
		$db->query($qstr);
		// echo $db->num_rows()."<br>";
		if($db->num_rows() > 0) return true;
	}
	return false;
}
function chk_other_co_winloss($db,$id,$winloss_c,$gtype){ //return  true false
	$suag_str = Array();
	//$suag_all = "";

	$qstr="select * from su_winloss where gtype='".$gtype."' and cid =".$id." and winloss_c + winloss != ".$winloss_c." limit 1";
	$db->query($qstr);
	if($db->num_rows() > 0) return true;
	$db->query("SELECT id, back, winloss_bak,sid FROM su_winloss WHERE  `cid` =".$id." ");
	while($db->next_record()) {
		if($db->f("back")=="Y"){
			$suag_str[($db->f("winloss_bak"))] .= $db->f("sid").",";
		}
		else $suag_str[0].= $db->f("sid").",";
		//$suag_all .= $db->f("id").",";
	}
	foreach ($suag_str as $winloss_bak => $id) {
    //echo "\$suag_str[$winloss_bak] => $id.\n<br>";
    $id = substr($id,0,strlen($id)-1);
    if($winloss_bak == 0) $qstr = "SELECT * FROM ag_winloss WHERE sid in (".$id.") and (winloss_s + winloss_a + winloss_c != ".$winloss_c.") limit 1";
		else $qstr = "SELECT * FROM ag_winloss WHERE sid in (".$id.") and (winloss_s + winloss_a + winloss_c < ".($winloss_c - $winloss_bak)."  or  winloss_s + winloss_a + winloss_c > ".$winloss_c.") limit 1";
		//echo $qstr."<br>";
		$db->query($qstr);
		if($db->num_rows() > 0) return true;
	}
	return false;
}
//=========================股東強制佔成判斷END==========================

//=========================股東最低最高佔成判斷(股東層)============================
function chk_winloss_max_min_co($db, $cid, $winloss_max, $winloss_min, $winloss_min_sw){

		$back_ary = Array();
		//$a_ary = Array();
		$sid_ary = Array();
		$ret = "";
		$sid_str = "";
		//$count = 0;

		$qstr="select id,back,winloss_bak from su_agents where cid='".$cid."' and sid='0';";
		$db->query($qstr);
		while($db->next_record()) {

				$sid = $db->f("id");
				$back = $db->f("back");
				$winloss_bak = $db->f("winloss_bak");

				array_push($sid_ary, "'".$sid."'");
				$back_ary[$sid] = ($back=="Y")? $winloss_bak*1:0;
		}

		/*
		if(count($sid_ary) > 0){
				$sid_str = join(",", $sid_ary);


				$qstr="select (winloss_c + winloss_s + winloss_a) as total,id as aid,sid from agents where sid in(".$sid_str.") and aid='0';";
				//echo "qstr=====>".$qstr."<br>";
				$db->query($qstr);
				while($db->next_record()) {

						$aid = $db->f("aid");
						$a_ary[$count]  = Array();
						$a_ary[$count]["sid"] = $db->f("sid");
						$a_ary[$count]["total"] = $db->f("total")*1;

						$count++;
				}



				for($i=0; $i< count($a_ary); $i++){

						//echo "i=====>".$i;
						//echo "sid=====>".$a_ary[$i]["sid"]."<br>";
						//echo "total=====>".$a_ary[$i]["total"]."<br>";

						$sid = $a_ary[$i]["sid"];
						$back = $back_ary[$sid];  //股東回補

						//echo "total===>".$total."<br>";
						//echo "back===>".$back."<br>";
						//echo "total===>".$total."<br>";

						$total = $a_ary[$i]["total"];


						//有股東回補下
						if($back > 0){

								//勾股東強佔
								if($winloss_min_sw=="Y"&&$winloss_max==$winloss_min){

										$rest = $winloss_max*1-$total*1;

								//未勾股東強佔
								}else{

										$tmp_winloss = ($winloss_min > 0)? $winloss_min:$$winloss_max;
										$rest = $tmp_winloss*1-$total*1;
								}

								//有剩餘成數
								if($rest > 0){

										if($rest > $back){
												$total+=$back;
										}else{
												$total+=$rest;
										}

								}

						}


						if($total > $winloss_max){
								$ret = "max";
								break;
						}
						if($total < $winloss_min){
								$ret = "min";
								break;
						}

				}

		}
		*/
		//return $ret;
		return chk_max_min($db, $sid_ary, $back_ary, $winloss_max, $winloss_min, $winloss_min_sw);
}
function chk_other_winloss_max_min_co($db, $cid, $winloss_max, $winloss_min, $winloss_min_sw,$gtype){

		$back_ary = Array();
		//$a_ary = Array();
		$sid_ary = Array();
		$ret = "";
		$sid_str = "";
		//$count = 0;

		$qstr="select id,back,winloss_bak,sid from su_winloss where gtype='".$gtype."' and cid='".$cid."' ;";
		$db->query($qstr);
		while($db->next_record()) {

				$sid = $db->f("sid");
				$back = $db->f("back");
				$winloss_bak = $db->f("winloss_bak");

				array_push($sid_ary, "'".$sid."'");
				$back_ary[$sid] = ($back=="Y")? $winloss_bak*1:0;
		}
		return chk_other_max_min($db, $sid_ary, $back_ary, $winloss_max, $winloss_min, $winloss_min_sw,$gtype);
}
//=========================股東最低最高佔成判斷(股東層)END==========================

//=========================股東最低最高佔成判斷(總代層)============================
function chk_winloss_max_min_su($db, $sid, $winloss_max, $winloss_min, $winloss_min_sw, $chk_winloss_bak){

		$back_ary = Array();
		//$a_ary = Array();
		$sid_ary = Array();
		$ret = "";
		$sid_str = "";
		//$count = 0;
		$cid = "";

		$qstr="select cid,back,winloss_bak from su_agents where id='".$sid."' and sid='0' order by id desc limit 1;";
		$db->query($qstr,1);
		if($db->num_rows() > 0){

				$cid = $db->f("cid");
				$back = $db->f("back");
				//$winloss_bak = $db->f("winloss_bak");

				array_push($sid_ary, "'".$sid."'");
				$back_ary[$sid] = ($back=="Y")? $chk_winloss_bak*1:0;
		}else{
				return "nouser";
		}



		/*
		if(count($sid_ary) > 0){
				$sid_str = join(",", $sid_ary);


				$qstr="select (winloss_c + winloss_s + winloss_a) as total,id as aid,sid from agents where sid in(".$sid_str.") and aid='0';";
				//echo "qstr=====>".$qstr."<br>";
				$db->query($qstr);
				while($db->next_record()) {

						$aid = $db->f("aid");
						$a_ary[$count]  = Array();
						$a_ary[$count]["sid"] = $db->f("sid");
						$a_ary[$count]["total"] = $db->f("total")*1;

						$count++;
				}



				for($i=0; $i< count($a_ary); $i++){

						//echo "i=====>".$i;
						//echo "sid=====>".$a_ary[$i]["sid"]."<br>";
						//echo "total=====>".$a_ary[$i]["total"]."<br>";

						$sid = $a_ary[$i]["sid"];
						$back = $back_ary[$sid];  //股東回補

						//echo "total===>".$total."<br>";
						//echo "back===>".$back."<br>";
						//echo "total===>".$total."<br>";

						$total = $a_ary[$i]["total"];


						//有股東回補下
						if($back > 0){

								//勾股東強佔
								if($winloss_min_sw=="Y"&&$winloss_max==$winloss_min){

										$rest = $winloss_max*1-$total*1;

								//未勾股東強佔
								}else{

										$tmp_winloss = ($winloss_min > 0)? $winloss_min:$$winloss_max;
										$rest = $tmp_winloss*1-$total*1;
								}

								//有剩餘成數
								if($rest > 0){

										if($rest > $back){
												$total+=$back;
										}else{
												$total+=$rest;
										}

								}

						}


						if($total > $winloss_max){
								$ret = "max";
								break;
						}
						if($total < $winloss_min){
								$ret = "min";
								break;
						}

				}

		}
		*/

		return chk_max_min($db, $sid_ary, $back_ary, $winloss_max, $winloss_min, $winloss_min_sw);
		//return $ret;
}
function chk_other_winloss_max_min_su($db, $sid, $winloss_max, $winloss_min, $winloss_min_sw, $chk_winloss_bak,$gtype){

		$back_ary = Array();
		//$a_ary = Array();
		$sid_ary = Array();
		$ret = "";
		$sid_str = "";
		//$count = 0;
		$cid = "";

		$qstr="select cid,back,winloss_bak from su_winloss where sid='".$sid."' and gtype='".$gtype."' order by id desc limit 1;";
		$db->query($qstr,1);
		if($db->num_rows() > 0){

				$cid = $db->f("cid");
				$back = $db->f("back");
				//$winloss_bak = $db->f("winloss_bak");

				array_push($sid_ary, "'".$sid."'");
				$back_ary[$sid] = ($back=="Y")? $chk_winloss_bak*1:0;
		}else{
				return "nouser";
		}



		/*
		if(count($sid_ary) > 0){
				$sid_str = join(",", $sid_ary);


				$qstr="select (winloss_c + winloss_s + winloss_a) as total,id as aid,sid from agents where sid in(".$sid_str.") and aid='0';";
				//echo "qstr=====>".$qstr."<br>";
				$db->query($qstr);
				while($db->next_record()) {

						$aid = $db->f("aid");
						$a_ary[$count]  = Array();
						$a_ary[$count]["sid"] = $db->f("sid");
						$a_ary[$count]["total"] = $db->f("total")*1;

						$count++;
				}



				for($i=0; $i< count($a_ary); $i++){

						//echo "i=====>".$i;
						//echo "sid=====>".$a_ary[$i]["sid"]."<br>";
						//echo "total=====>".$a_ary[$i]["total"]."<br>";

						$sid = $a_ary[$i]["sid"];
						$back = $back_ary[$sid];  //股東回補

						//echo "total===>".$total."<br>";
						//echo "back===>".$back."<br>";
						//echo "total===>".$total."<br>";

						$total = $a_ary[$i]["total"];


						//有股東回補下
						if($back > 0){

								//勾股東強佔
								if($winloss_min_sw=="Y"&&$winloss_max==$winloss_min){

										$rest = $winloss_max*1-$total*1;

								//未勾股東強佔
								}else{

										$tmp_winloss = ($winloss_min > 0)? $winloss_min:$$winloss_max;
										$rest = $tmp_winloss*1-$total*1;
								}

								//有剩餘成數
								if($rest > 0){

										if($rest > $back){
												$total+=$back;
										}else{
												$total+=$rest;
										}

								}

						}


						if($total > $winloss_max){
								$ret = "max";
								break;
						}
						if($total < $winloss_min){
								$ret = "min";
								break;
						}

				}

		}
		*/

		return chk_other_max_min($db, $sid_ary, $back_ary, $winloss_max, $winloss_min, $winloss_min_sw,$gtype);
		//return $ret;
}
//=========================股東最低最高佔成判斷(總代層)END==========================


function chk_max_min($db, $sid_ary, $back_ary, $winloss_max, $winloss_min, $winloss_min_sw){

		$a_ary = Array();
		$ret = "";
		$sid_str = "";
		$count = 0;

		if(count($sid_ary) > 0){
				$sid_str = join(",", $sid_ary);


				$qstr="select (winloss_c + winloss_s + winloss_a) as total,id as aid,sid from agents where sid in(".$sid_str.") and aid='0' and level='0';";
				// echo "qstr=====>".$qstr."<br>";
				$db->query($qstr);
				while($db->next_record()) {

						$aid = $db->f("aid");
						$a_ary[$count]  = Array();
						$a_ary[$count]["sid"] = $db->f("sid");
						$a_ary[$count]["total"] = $db->f("total")*1;

						$count++;
				}



				for($i=0; $i< count($a_ary); $i++){

						//echo "i=====>".$i;
						//echo "sid=====>".$a_ary[$i]["sid"]."<br>";
						//echo "total=====>".$a_ary[$i]["total"]."<br>";

						$sid = $a_ary[$i]["sid"];
						$total = $a_ary[$i]["total"];
						$back = $back_ary[$sid];  //股東回補


						//echo "back===>".$back."<br>";
						//echo "total===>".$total."<br>";
						//echo "winloss_max===>".$winloss_max."<br>";
						//echo "winloss_min===>".$winloss_min."<br>";




						//有股東回補下
						if($back > 0){

								//勾股東強佔
								if($winloss_min_sw=="Y"&&$winloss_max==$winloss_min){

										$rest = $winloss_max*1-$total*1;

								//未勾股東強佔
								}else{

										$tmp_winloss = ($winloss_min > 0)? $winloss_min:$$winloss_max;
										$rest = $tmp_winloss*1-$total*1;
								}

								//有剩餘成數
								if($rest > 0){

										if($rest > $back){
												$total+=$back;
										}else{
												$total+=$rest;
										}

								}

						}

						//echo "rest===>".$rest."<br>";
						//echo "total===>".$total."<br>";

						if($total > $winloss_max){
								$ret = "max";
								break;
						}
						if($total < $winloss_min){
								$ret = "min";
								break;
						}

				}

		}


		return $ret;
}
function chk_other_max_min($db, $sid_ary, $back_ary, $winloss_max, $winloss_min, $winloss_min_sw,$gtype){

		$a_ary = Array();
		$ret = "";
		$sid_str = "";
		$count = 0;


		if(count($sid_ary) > 0){
				$sid_str = join(",", $sid_ary);


				$qstr="select (winloss_c + winloss_s + winloss_a) as total,aid,sid from ag_winloss where gtype='".$gtype."' and sid in(".$sid_str.") ;";
				// echo "qstr=====>".$qstr."<br>";
				$db->query($qstr);
				while($db->next_record()) {

						$aid = $db->f("aid");
						$a_ary[$count]  = Array();
						$a_ary[$count]["sid"] = $db->f("sid");
						$a_ary[$count]["total"] = $db->f("total")*1;

						$count++;
				}



				for($i=0; $i< count($a_ary); $i++){

						//echo "i=====>".$i;
						//echo "sid=====>".$a_ary[$i]["sid"]."<br>";
						//echo "total=====>".$a_ary[$i]["total"]."<br>";

						$sid = $a_ary[$i]["sid"];
						$total = $a_ary[$i]["total"];
						$back = $back_ary[$sid];  //股東回補


						//echo "back===>".$back."<br>";
						//echo "total===>".$total."<br>";
						//echo "winloss_max===>".$winloss_max."<br>";
						//echo "winloss_min===>".$winloss_min."<br>";




						//有股東回補下
						if($back > 0){

								//勾股東強佔
								if($winloss_min_sw=="Y"&&$winloss_max==$winloss_min){

										$rest = $winloss_max*1-$total*1;

								//未勾股東強佔
								}else{

										$tmp_winloss = ($winloss_min > 0)? $winloss_min:$$winloss_max;
										$rest = $tmp_winloss*1-$total*1;
								}

								//有剩餘成數
								if($rest > 0){

										if($rest > $back){
												$total+=$back;
										}else{
												$total+=$rest;
										}

								}

						}

						//echo "rest===>".$rest."<br>";
						//echo "total===>".$total."<br>";

						if($total > $winloss_max){
								$ret = "max";
								break;
						}
						if($total < $winloss_min){
								$ret = "min";
								break;
						}

				}

		}


		return $ret;
}

?>
