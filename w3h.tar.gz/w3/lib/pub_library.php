<?php
include("pub_rtype.php");
/*
 get_userid()		//以亂數取得UID------
 Close_All_db()		//關閉所有DB連線------
 loginx()		//會員登入檢查------
 js_showerror()		//秀js error
 Chg_Mcy()		//將指定幣別轉換成人民幣------
 Chg_Mcy_rec()		//將指定幣別(歷史檔)轉換成人民幣------
 Chg_cur_self()		//將人民幣轉換成指定幣別------
 Write_Ratio_Record()	//寫入賠率歷史檔
 show_messenge()	//秀訊息
 ShowTeamData()		//顯示隊伍名稱------
 ShowPicther()		//顯示 picther type
 now_currency_value()	//回傳目前此匯率之值
 ShowRadio_R()		//讓分賠率-------------------
 ShowRadio_OU()		//------顯示高低分賠率------
 ShowRadioFT_R()	//------顯示足球讓球------
 Update_Wagers_flag()   //------更新FT_wagers最後一筆-----
 getCounterData()	// 讀取 CounterServer 資料
 SetDecimal()		// 設定小數位(四捨五入)
 get_conf_rtype_sql()	//組合各玩法rtype取詳設值的sql語法
 get_rtype_sql()	//組合各弄法rtype取注單的sql語法
 Access_log()
 getAccessLogMsg()
 chkCtlDfWinloss() //預設成數開關
*/
//===========================================================
//共用之function
//===========================================================

//------以亂數取得UID------
function get_userid() {
	if (empty($userid)) {
		mt_srand((double)microtime()*1000000);
//		$userid = crypt(uniqid(mt_rand()).mt_rand());
		$userid = uniqid(mt_rand()).mt_rand();
		$userid=sprintf("%x",rand()).sprintf("%x",rand());
	}
	return $userid;
}
//------關閉所有DB連線------
function Close_All_db() {
	global $db,$dbFT,$dbFTw,$dbFTR;

	if (isset($db)) $db->close();
	if (isset($dbFT)) $dbFT->close();
	if (isset($dbFTR)) $dbFTR->close();
	if (isset($dbFTw)) $dbFTw->close();
}
//------會員登入檢查------
//$login=0 登入踢出
//$login=1 登入不踢出
function chk_ip($ipx) {
        return true;
	if (UNDER_BIG_IP == 'Y') {
		$DB_MAIN_R = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);
		$DB_MAIN_R->query("SELECT id from ip_list where ip='$ipx'",1);
		if ($DB_MAIN_R->f('id')) {$DB_MAIN_R->close();return true;}
		$DB_MAIN_R->close();
	} else {
	 	$r_file = FILE_PATH."/log/chk_ip.txt";
	 	$open_file = @file($r_file);
		for ($i=0;$i<count($open_file);$i++) {
			$tmp = explode (",",$open_file[$i]);
			if ($ipx==$tmp[0])return true;
		}
	}
/*	$IP_TXT=WEB_PATH."/conf/maintain_IP.txt";	// 查詢 IP 是否屬於系統維護用 IP
	$maintain_IP=@file($IP_TXT);
	for ($j=0;$j<count($maintain_IP);$j++) {
		$temp_IP=explode(",",$maintain_IP[$j]);
		if ($ipx==$temp_IP[0]) return true;
	}
	return false;
*/
	$DB_MAIN_S_IP = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME); // 查詢 IP 是否屬於系統維護用 IP
	$DB_MAIN_S_IP -> query("SELECT id from ip_list_maintain  where IP = '".$ipx."'");
	if ($DB_MAIN_S_IP->get_total_data() != null) {
		$DB_MAIN_S_IP -> close();
		return true;
	}
	$DB_MAIN_S_IP -> close();
	return false;
}
function loginx($table,$username,$passwd,$userid,$login=0,$langx,$login_tb='') {
	global $PHP_SELF,$log;
	if (!empty($langx)) $langx_page = "?langx=".$langx;
	switch($table)
	{
	 case "super_admin":
	  $go_page=BROWSER_IP."/"; break;
	 case "admin":
	  $go_page=BROWSER_IP."/"; break;
		case "dealer":
		$go_page=BROWSER_IP."/dealer_index.php"; break;
	}
	if ($table=="dealer")$table="admin";
	$user_ip=get_ip();
	$success_str[0] = "SUCCESS";
	$success_str[1] = $userid;
	$err_str[0] = "ERROR";
	$err_str[1] = "<script>window.open('$go_page','_top')</script>";

	if ($table=='admin' || $table=='super_admin') {
			//auth..修改...10/23
					if (!chk_ip(REMOTE_ADDR)) {
						if ($langx=='zh-tw') {
							echo "<html>";
							echo "<head>";
							echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
							echo "</head>";
							echo "IP不合法.<br>";
							echo "您所在的<font style=\"background-color: #3399FF\"><B>IP</B></font>位置:<font style=\"background-color: #3399FF\"><B>".REMOTE_ADDR."</B></font>.<br>";
							echo "不允許進入，請連絡相關人員.<br>";
							echo "</html>";
						} elseif ($langx=='zh-cn') {
							echo "<html>";
							echo "<head>";
							echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
							echo "</head>";
							echo "IP不合法.<br>";
							echo "您所在的<font style=\"background-color: #3399FF\"><B>IP</B></font>弇离:<font style=\"background-color: #3399FF\"><B>".REMOTE_ADDR."</B></font>.<br>";
							echo "不允许进入，请连络相关人员.<br>";
							echo "</html>";
						} elseif ($langx=='en-us') {
							echo "<html>";
							echo "<head>";
							echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
							echo "</head>";
							echo "IP illegal. <br>";
							echo "This is your <font style=\"background-color: #3399FF\"><B>IP</B></font> adr : <font style=\"background-color: #3399FF\"><B>".REMOTE_ADDR."</B></font>.<br>";
							echo "It is an illegal one to login the webside. <br>";
							echo "Pls contect the webmaster. <br>";
							echo "</html>";
						}
						exit;
					}
	}
	if ($username=="" || $passwd=="") {
		echo "<SCRIPT language=\"JavaScript\">\n";
		echo "alert('Plaese input username/passwd and try again!!');\n";
		echo "</SCRIPT>\n";
		return $err_str;
	} else {
		if (strtoupper(substr($username,0,3))=="SBC" && $login_tb=="") {
			echo "<SCRIPT language=\"JavaScript\">\n";
			echo "alert('Plaese select Table and try again!!');\n";
			echo "</SCRIPT>\n";
			return $err_str;
		}
		$username=str_replace('=','',$username);
    $username=str_replace('--','',$username);
    $username=str_replace(',','',$username);
    $username=str_replace('%','',$username);
    $username=stripcslashes($username);
    $passwd=stripcslashes($passwd);
		$today = getdate();
		$now_gmt = gmdate("Y-m-d H:i:s",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
		$db = new proc_DB(DB_HOST,DB_USER,DB_PWD,DB_NAME);
		$db->query("SELECT * FROM $table WHERE username='".$username."' AND password=PASSWORD('".$passwd."') AND `enable`='Y' ");
		//帳號密碼判斷正確
		if ($db->next_record()) {
			$tmp_str = $db->record;

			$db->query("SELECT * FROM login_$table WHERE loginid='".$tmp_str["id"]."' order by id desc",1);
			//判斷該帳號是否在線上
			if ($db->num_rows())
			{
				// while ($db->next_record())
				// {
				// 	$login_data = $db->record;
				// 	if ($db->f('uid') == $userid)
				// 		break;
				// }
				//判斷是否為不同uid登入
				$login_data = $db->record;
				if ($login_data["uid"] != $userid) {
					// if (($table=="admin" || $table=="super_admin") && $now_gmt<$login_data["logindate"]) {
					// 	echo "<SCRIPT language=\"JavaScript\">\n";
					// 	echo "alert('Plaese wait 3 minutes and try again!!');\n";
					// 	echo "</SCRIPT>";
					// 	$db->close();
					// 	return $err_str;
					// }
					// if ($login == 0) //踢出
					// {
					// 	$db->query("DELETE FROM login_$table WHERE loginid='".$tmp_str["id"]."'");
					// }
					$qstr = "INSERT login_$table SET loginid='".$tmp_str["id"]."',uid='$userid',username='".$tmp_str["username"]."'";
					$qstr .= ",IP='".$_SERVER['REMOTE_ADDR']."'";
					$qstr .= ",logindate=ADDDATE('".$now_gmt."',INTERVAL 0 MINUTE),lastdate='$now_gmt',langx='$langx'";
					$db->query($qstr);
					$success_str[2] = $tmp_str["id"];
					$success_str[3] = $tmp_str["username"];
					$success_str[4] = $tmp_str["type"];
				}
				else {	//同一uid登入

					return $err_str;
				}
			} else {	//目前該帳號不在線上

				//檢查uid是否有不同的loginid在使用
				$db->query("SELECT * FROM login_$table WHERE uid='$userid'");
				if ($db->next_record()) {
					//重新產生uid
					$new_uid = get_userid();
					$success_str[1] = $new_uid;
				}
				$success_str[2] = $tmp_str["id"];
				$success_str[3] = $tmp_str["username"];
				$success_str[4] = $tmp_str["type"];
				$qstr = "INSERT login_$table SET loginid='".$tmp_str["id"]."',uid='".$success_str[1]."',username='".$tmp_str["username"]."'";
				$qstr .= ",IP='".$user_ip."'";
				$qstr .= ",logindate=ADDDATE('".$now_gmt."',INTERVAL 0 MINUTE),lastdate='$now_gmt',langx='$langx'";
				$db->query($qstr);

//				if (strtoupper(substr($username,0,3))=="SBC")$db->query("update tb_user set name_e='".$tmp_str["name_e"]."',name_c='".$tmp_str["name_c"]."',name_g='".$tmp_str["name_g"]."' where tbid=".$login_tb);
			}
			$db->close();	                
			return $success_str;
	  }else{	//沒這個會員
			echo "<SCRIPT language=\"JavaScript\">\n";
			echo "alert('LOGIN ERROR!!\\nPlaese check username/passwd and try again!!');\n";
			echo "</SCRIPT>\n";
			$db->close();
			return $err_str;
		}
	}
}
//------會員uid檢查是否已登入在線上------
function check_login($table,$uid,$langx) {
	global $PHP_SELF,$log;
//	if (!empty($langx)) $langx_page = "?langx=".$langx;
	switch($table) {
	 case "super_admin":
	  $go_page=BROWSER_IP."/"; break;
	 case "admin":
	  $go_page=BROWSER_IP."/"; break;
		case "dealer":
 	  $go_page=BROWSER_IP."/dealer_index.php"; break;
	}
	if ($table=="dealer")$table="admin";
//	$success_str[0] = "SUCCESS";
	$err_str[0] = "ERROR";
	$err_str[1] = "<script>window.open('$go_page','_top')</script>";

	$db = new proc_DB(DB_HOST_R,DB_USER,DB_PWD,DB_NAME);
	$db->query("SELECT id,loginid,username,langx FROM login_$table WHERE uid='$uid' limit 1");
	//該uid已在線上
	if ($db->next_record())
	{
        //Access_log($db->f('username'),$uid);
		$uname = $db->f('username');
		$tableid = $db->f('id');
		$loginid = $db->f('loginid');
		$langx = $db->f('langx');
		$today = getdate();
		$now_gmt = gmdate("Y-m-d H:i:s",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
		//更新使用者最後檢查登入時間
		//$db->query("UPDATE login_$table SET lastdate='$now_gmt' WHERE id='$tableid'");
		//讀取使用者基本資料
		$db->query("SELECT id,loginid,username,langx FROM login_$table WHERE id > ".$tableid." and  loginid = ".$loginid."  order by id desc");
		if($db->next_record()){
			return $err_str;
		}
		
		$db->query("SELECT * FROM $table WHERE id='$loginid'",1);
		$tmp_str = $db->record;
		$tmp_str["langx"] = $langx;
		$db->close();
		//寫入紀錄檔-------------
		//---------------------------------
                if ($table=='admin' || $table=='super_admin') {
                        if (!chk_ip(REMOTE_ADDR)) {
                        	if ($langx=='zh-tw') {
	                        		echo "<html>";
						echo "<head>";
						echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
	                        		echo "</head>";
	                        		echo "IP不合法.<br>";
	                        		echo "您所在的<font style=\"background-color: #3399FF\"><B>IP</B></font>位置:<font style=\"background-color: #3399FF\"><B>".REMOTE_ADDR."</B></font>.<br>";
	                        		echo "不允許進入，請連絡相關人員.<br>";
	                        		echo "</html>";
	                        	} elseif ($langx=='zh-cn') {
	                        		echo "<html>";
						echo "<head>";
						echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
	                        		echo "</head>";
	                        		echo "IP不合法.<br>";
	                        		echo "您所在的<font style=\"background-color: #3399FF\"><B>IP</B></font>弇离:<font style=\"background-color: #3399FF\"><B>".REMOTE_ADDR."</B></font>.<br>";
	                        		echo "不允许进入，请连络相关人员.<br>";
	                        		echo "</html>";
	                        	} elseif ($langx=='en-us') {
	                        		echo "<html>";
						echo "<head>";
						echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
	                        		echo "</head>";
	                        		echo "IP illegal. <br>";
	                        		echo "This is your <font style=\"background-color: #3399FF\"><B>IP</B></font> adr : <font style=\"background-color: #3399FF\"><B>".REMOTE_ADDR."</B></font>.<br>";
	                        		echo "It is an illegal one to login the webside. <br>";
	                        		echo "Pls contect the webmaster. <br>";
	                        		echo "</html>";
	                        	}
                        	exit;
                        }
                }
		return $tmp_str;
	}
	else	//該uid上未登入或已被踢出,返回登入頁
	{
		//global $PHP_SELF;
		//echo $PHP_SELF." KICK";exit;
		$db->close();
		return $err_str;
	}
}


//========================秀js error======================
//$str:錯誤訊息
//$goto:轉換至何頁
//========================秀js error======================
function js_showerror($str,$goto="javascript:history.go(-1)")//control
{
  global $str_meta;
  $s="<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
  $s.= "<script language=javascript>\n";
  $s.= "alert ('".$str."');\n";
  $s.= "document.location='".$goto."';\n";
  $s.= "</script>\n";
  echo $s;
}

//========================轉換幣值======================
//$code:幣值代碼
//$total:金額
//$flag:計算方式(0:預設匯率,1:目前匯率)
//$db:資料庫連線
//$tmp:傳回人民幣值
//========================轉換幣值======================
//------將指定幣別轉換成人民幣------
function Chg_Mcy($code,$total,$db,$flag=0) {
  $qstr="select * from currency where code='$code'";
  $db->query($qstr,1);
  if ($flag==0) {
    $ratio=$db->f('def');
  } else {
    $ratio=$db->f('value');
  }
  $tmp = sprintf("%.2f",$total*$ratio);
  return $tmp;
}
//------將指定幣別(歷史檔)轉換成人民幣------
function Chg_Mcy_rec($code,$date,$total,$db) {
  $qstr="select value from currency_record where code='$code' and ";
  $qstr.="s_date <= '$date' and e_date > '$date' ";
  $db->query($qstr,1);
  $ratio=$db->f('value');
  $tmp = sprintf("%.3f",$total*$ratio);
  return $tmp;
}

//------將人民幣轉換成指定幣別------
function Chg_cur_self($code,$total,$db,$flag=0) {
  $qstr="select * from currency where code='$code'";
  $db->query($qstr,1);
  if ($flag==0) {
    $ratio=$db->f('def');
  } else {
    $ratio=$db->f('value');
  }
  $tmp=$total/$ratio;
  $tmp=floor($tmp);
  return $tmp;
}

//=============================================
//--功能說明：寫入賠率歷史檔
//--$username:使用者帳號($PHP_AUTH_USER);
//--$gid:遊戲自動編號;
//--$ltype:盤口代碼;(0:更新所有盤口)
//--$rtype:玩法代碼;
//--$game_type:球賽類別;
//--$type:變更方式(A:自動,M:修改);
//--$dbra:資料庫連線($dbFT,$dbBK);
//=============================================
function Write_Ratio_Record($username,$gid,$ltype,$rtype,$game_type,$type,$dbra) {
   $today=getdate();
   $today_gmt=gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
   $now_gmt=gmdate("H:i:s",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
   $today=$today_gmt." ".$now_gmt;

   if ($game_type=="FT")
   {
   	 $dbname="ratio_record";
   } else {
         $dbname=$game_type."_ratio_record";
   }

   $sql="select * from ".$game_type."_param ";
   if ($ltype!="0") {
   	$sql.="where gid='$gid' and ltype='$ltype' and rtype='$rtype' ";
   } else {
   	$sql.="where gid='$gid' and rtype='$rtype' ";
   }
   $dbra->query($sql);
   while ($dbra->next_record()) {
      $ins_sql.="insert into ".$dbname." (gid,ltype,rtype,concede,ratio,ioratio,type,username,adddate)";
      $ins_sql.=" values ('$gid','".$dbra->f('ltype')."','$rtype','".$dbra->f("concede")."','".$dbra->f("ratio")."','".$dbra->f("ioratio")."','$type','$username','$today');";
   }
   $dbra->muti_query($ins_sql);
   $rtype = substr($rtype,0,-1);
   $dbFT = $dbra;
}
//秀訊息
function show_messenge($str)//control
{
  $s= "<script language=javascript>\n";
  $s.= "alert ('".$str."');\n";
  $s.= "</script>\n";
  echo $s;
}

//回傳目前此匯率之值
function now_currency_value($code,$db) {
   $db->query("select value from currency where code='$code'",1);
   return $db->f('value');
}


function parse_currency($currency) {
	 switch($currency)
                      {
                      case "RMB":
                             return "人民幣 -> 人民幣";
                             break;
                      case "HKD":
                             return "人民幣 -> 港幣";
                             break;
                      case "USD":
                             return "人民幣 -> 美金";
                             break;
                      case "MYR":
                             return "人民幣 -> 馬幣";
                             break;
                      case "SGD":
                             return "人民幣 -> 新幣";
                             break;
                      case "THB":
                             return "人民幣 -> 泰銖";
                             break;
                      case "GBP":
                             return "人民幣 -> 英磅";
                             break;
                      case "JPY":
                             return "人民幣 -> 日幣";
                             break;
                      case "EUR":
                             return "人民幣 -> 歐元";
                             break;
                      case "IND":
                             return "人民幣 -> 印尼盾";
                             break;
                      default:
                              return "人民幣 -> 人民幣";
                             }
 }

function chk_var($check_str) {
	//echo $check_str;
	$chk_test=strlen($check_str);
        $check_str=str_replace('=','',$check_str);
        $check_str=str_replace('--','',$check_str);
        //$check_str=str_replace(',','',$check_str);
        //$check_str=str_replace('%','',$check_str);
        $check_str=stripcslashes($check_str);
        //echo "---".$check_str;exit;
        if ($chk_test!=strlen($check_str))return 0;
        else return 1;
}
function open_js($filename) {
	$ret = "";
	$open_file = @file($filename);
	if ($open_file[0]) {
		for ($i=0;$i < count($open_file);$i++) {
			$ret .= $open_file[$i];
		}
	}
	return $ret;
//	return "<script>\n".$ret."</script>\n";
}

function getCounterData($code, $gtype, $gid, $wtype) {
	$errno = 30;
	$errstr = "Connect time out !";

	$fp = fsockopen(CS_IP, CS_PORT, $errno, $errstr, 5);
	$cmd = $code."|".$gtype."|".$gid."|".$wtype."\r\n";
	if ($fp) {
		fwrite($fp, $cmd) or die(exit);
		$get = "";
		while (!feof($fp)) {
			$get .= fgets($fp, 128);
		}
		fclose($fp);
	}
	return $get;
}
// =========== NEW = BEGIN =================================================================================
function ctrl_record($dbMain,$dbTable,$userid,$level,$status,$action,$content) {
	Global $MEM_DATA;
	$user_ip=get_ip();
	$time_zone=12*60*60;
	$content=preg_replace("/'/","",$content);
	$content=preg_replace("/;/","<br>",$content);
	$qstr ="INSERT INTO ".$dbTable." SET ";
	$qstr.="username='".$MEM_DATA["username"]."',";
	$qstr.="level='".$level."',";
	$qstr.="userid='".$MEM_DATA["id"]."',";
	$qstr.="status='".$status."',";
	$qstr.="action='".$action."',";
	$qstr.="content='".$content."',";
	$qstr.="adddate=FROM_UNIXTIME(UNIX_TIMESTAMP( )-".$time_zone."),";
	$qstr.="IP='".$user_ip."';";
	$qstr.="SELECT LAST_INSERT_ID() AS record_rid;";
	$dbMain->muti_query($qstr);
	$record_rid=$dbMain->f('record_rid');
	return $record_rid;
}

function ctrl_sub_record($dbMain,$dbTable,$record_rid,$userid,$level,$content,$sql_syntax) {
	Global $MEM_DATA;
	$content=preg_replace("/'/","",$content);
	$content=preg_replace("/;/","<br>",$content);
	$sql_syntax=preg_replace("/'/","",$sql_syntax);
	$sql_syntax=preg_replace("/;/","<br>",$sql_syntax);
	$qstr ="INSERT INTO ".$dbTable." SET ";
	$qstr.="rid='".$record_rid."',";
	$qstr.="username='".$MEM_DATA["username"]."',";
	$qstr.="fun_name='".substr($_SERVER["SCRIPT_FILENAME"],strrpos($_SERVER["SCRIPT_FILENAME"],'/'))."',";
	$qstr.="content='".$content."',";
	$qstr.="sql_syntax='".$sql_syntax."';";
	$dbMain->query($qstr);
}

function SetDecimal($number,$point) {
	$flag = pow(10,$point);
//	$diff = 1/pow(10,($point+1));
//	$keep = 1;
//	if ($number < 0) {
//		$keep = -1;
//	}
//	$number = $keep*(floor(abs($number)*$flag+$diff)/$flag);
	$number = round($number*$flag)/$flag;
	return sprintf("%.0".$point."f",$number);
}

function get_conf_rtype_sql($gtype,$rtype,$last) {
	$sql = " gtype = '".$gtype."' and rtype like '".$rtype."%' ".$last;
	$rtype_2w = substr($rtype,0,2);
	if ($gtype == "BO") {
		if ($rtype_2w == "CT") {
			$num = substr($rtype,2)*1;
			if ($num == 9) {
				$sql=" gtype = '".$gtype."' and (rtype='CT9' or rtype='CT10' or rtype='CT11' or rtype='CT12') ".$last;
			} else {
				$sql=" gtype = '".$gtype."' and (rtype='CT".$num."' or rtype='CT".(21-$num)."') ".$last;
			}
		} else if ($rtype_2w == "RP") {
			if ($rtype == "RP16") {
				$sql=" gtype = '".$gtype."' and rtype='".$rtype."' ".$last;
			} else {
				$sql=" gtype = '".$gtype."' and rtype like '".$rtype."_' ".$last;
			}
		}
	} else if ($gtype == "RO") {
		if ($rtype == "I") {
			$sql=" gtype = '".$gtype."' and (rtype like 'I%' or rtype like 'Z%') ".$last;
		} else if ($rtype == "E13") {
			$sql=" gtype = '".$gtype."' and (rtype='E13' or rtype='E14') ".$last;
		} else if ($rtype == "E") {
			$sql=" gtype = '".$gtype."' and rtype like 'E%' and rtype!='EOE' and rtype!='EOO' and rtype!='E13' and rtype!='E14' ".$last;
		} else if ($rtype == "J") {
			$sql=" gtype = '".$gtype."' and rtype like 'J%' and rtype!='J0' ".$last;
		} else if ($rtype == "J0") {
			$sql=" gtype = '".$gtype."' and rtype='J0' ".$last;
		}
	}
	return $sql;
}

function get_rtype_sql($gtype,$rtype) {
	$sql = "rtype='".$rtype."'";
	$rtype_2w = substr($rtype,0,2);
	if ($gtype == "BO") {
		if ($rtype_2w != "OU" && $rtype_2w != "EO") {
			$sql="rtype like '".$rtype_2w."%'";
		}
	} else if ($gtype == "RO") {
		if ($rtype == "I") {
			$sql="(rtype like 'I%' or rtype like 'Z%')";
		} else if ($rtype == "E13") {
			$sql="(rtype='E13' or rtype='E14')";
		} else if ($rtype == "E") {
			$sql="(rtype like 'E%' and rtype!='EOE' and rtype!='EOO' and rtype!='E13' and rtype!='E14')";
		} else if ($rtype == "J") {
			$sql="(rtype like 'J%' and rtype!='J0')";
		} else if ($rtype == "J0") {
			$sql="rtype='J0'";
		} else {
			$sql="rtype like '".$rtype."%'";
		}
	}
	return $sql;
}
/**
 * 編碼
 */
function encode($Str) {
	$trans = "";
	$rev = "";
	$getcode = "";
	$i =0;
	for ($i=0; $i < strlen($Str); $i++) {
		$trans.= strtoupper(dechex((255 - ord(substr($Str,$i,1)))));
	}
	$i = 0;
	for ($i=0; $i< strlen($trans); $i++) {
		$rev = substr($trans,$i,1).$rev;
	}
	$getcode = substr($rev,5,strlen($rev)-5).substr($rev,0,5);
	return $getcode;
}
 /**
  * 解碼
  */
function decode($getstr) {
	$gettrans = "";
	$destr = "";
	$getrev = "";
	$i =0;
	$getrev = substr($getstr,strlen($getstr) - 5, 5).substr($getstr , 0, strlen($getstr) - 5);
	for ($i=0; $i < strlen($getrev); $i++) {
		$gettrans = substr($getrev , $i, 1).$gettrans;
	}
	$i =0;
	for ($i=0; $i < strlen($gettrans); $i=$i+2) {
		$destr.= Chr(255 - hexdec(substr($gettrans,$i, 2)));
	}
	return $destr;
}
function get_ip() {
	// if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
	//    $user_ip = $_SERVER['HTTP_CLIENT_IP'];
	// } else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
	//    $user_ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
	// } else {
	//    $user_ip= $_SERVER['REMOTE_ADDR'];
	// }
	$user_ip= $_SERVER['REMOTE_ADDR'];
	return $user_ip;
}

//操盤帳號取開放桌次
function get_table_open($id="",$db="",$level="",$gtype=""){
	return "None"; //先不用這功能
	$def = "";
	if($gtype=="")$gtype="BA";
	if($db==""||$id==""||$level=="") return "1";
	
	$maxTbale = get_table_count($gtype,$db);
	//預設全桌
	for($i=1;$i<=$maxTbale*1;$i++){
		if($def!="")$def.=",";
		$def .= $i;
	}
	$sql = "select * from ".$level."_right_table where ".$level."id ='".$id."'";
	$db->query($sql,1);
	$content = $db->f("content");
	if(!$content)$content= "ALL";
	if($content=="ALL") $openTable = $def;
	else  $openTable=$content;
	
	return str_replace(","," ",$openTable);
	
}
//取最大桌數
function get_table_count($gtype,$db=""){
	$gtype = strtoupper($gtype);
	$sql = "select max(tbid) as max from ".$gtype."_lobby where server_no='1' ;";
	$db->query($sql,1);
	$num = $db->f("max");
	return $num;
}
$root_self=$_SERVER['DOCUMENT_ROOT'].$_SERVER['PHP_SELF'];
function Access_log($name,$uid){
        global $root_self;
        $USER_IP=REMOTE_ADDR;
        //$USER_PHP =$HTTP_SERVER_VARS['PHP_SELF'];
        $today = getdate();
        $today_gmt = gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
        $time_gmt = gmdate("H:i:s",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
        $time_hours = gmdate("H",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));

        //$msg = $today_gmt." ".$time_gmt.",".$name.",".$uid.",".$USER_IP.",".BROWSER_IP.",".$root_self;
        // 2017-09-11 AccessLog中加入php的參數
        // 2017-09-18 AccessLog由機器寫入至DB會缺少資料，因此寫 getAccessLogMsg($root_self,$flag) 控制原先寫法與新寫法
        $param = getAccessLogMsg($root_self,true);
        if($param!=""){
                $msg = $today_gmt." ".$time_gmt.",".$name.",".$uid.",".$USER_IP.",".BROWSER_IP.",".$root_self."?".$param;
        }else{
                $msg = $today_gmt." ".$time_gmt.",".$name.",".$uid.",".$USER_IP.",".BROWSER_IP.",".$root_self;
        }

        if(!is_dir("/home/log")){mkdir("/home/log",0777);}
        $fp = fopen ("/home/log/Access".$today_gmt."_".$time_hours.".log","a");
        fwrite ($fp,$msg."\n");
        fclose ($fp);
}


function getAccessLogMsg($root_self,$flag){
        $param = "";
        if($flag){
                if(preg_match("/get_v_live.php/",$root_self)){
                    return "";
                }
                foreach($_REQUEST as $key => $val){
                        if (!empty($_COOKIE[$key])) continue;
                        $param.=$key."=".$val."&";
                }
                if(substr($param,-1,1)=="&") $param = substr($param,0,strlen($param)-1);
                return $param;
        }else{
                return "";
        }

}

//亂數表
function random_str($len){
    $word = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    for($i=0; $i < $len; $i++){
        $ran .= $word[rand() % 62];
        // echo rand() % $len."\n";
    }
    return $ran;
}
//預設成數開關
function chkCtlDfWinloss($dbr){
	$sql = "select * from other_set where name='ctl_df_winloss' limit 0,1;";
	$dbr->query($sql,1);
	$text=$dbr->f("text");
	return $text;
}
?>