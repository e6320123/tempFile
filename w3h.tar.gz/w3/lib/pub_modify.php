<?php
/*
update_conf		更新mem_conf_1 ag_conf_1 ...的設定值 .
get_up_level_id		取得上層的id值
chg_winloss		將winloss更新為預設值(轉移會員時)
chk_chg_up		檢查是否可以修改佔成數 1為true , 0為false .
chk_chg_rt		檢查是否可以修改佔成數 N為true , Y為false .(Y代表正在轉報表)
chk_down_set		更新會員的詳細設定值 .
chk_oldpassword		檢查舊密碼
*/
//=================更新memwinloss裡的層級ID  START============================

function update_conf($db,$uid,$type,$id){
	$ip_tmp=explode(":",$id);
	if($id=="")return true;
	//echo $type;exit;
	switch($type){
			case "co":
			$count=1;
			$use=4;
			$id_typ="C";
			$sub_tab=",ltype";
			break;
			case "su":
			$count=2;
			$use=4;
			$id_typ="S";
			$sub_tab=",ltype";
			break;
			case "ag":
			$count=3;
			$use=4;
			$id_typ="A";
			$sub_tab=",ltype";
			break;
			case "mem":
			$count=4;
			$use=1;
			//$id_typ="SC";
			$sub_tab="";
			break;
	}
	$value=1;
	$level=array("sc","co","su","ag","mem");
	$level_id=array("scid","cid","sid","aid","mid");

	for($j=0;$j<count($ip_tmp);$j++){
		$value=(get_value($db,$ip_tmp[$j])/10000);
		$quer_d="delete  from ".$level[$count]."_conf where ".$level_id[$count]."='".$ip_tmp[$j]."'";
		//echo $quer_d."<br>";exit;
		$quer="insert into ".$level[$count]."_conf SELECT '' as id,".$ip_tmp[$j]." as ".$level_id[$count].",gtype,";
		$quer.="rtype".$sub_tab.",floor(SC/".$value."),floor(SO/".$value."),W_WAR,L_WAR FROM ".$level[$count-1]."_conf where ".$level_id[$count-1]."='".$uid."' ";



		//echo $quer_d."<br>";
		//echo $quer."<br>";exit;
		$db->query($quer_d);
		//$db->close();
		$db->query($quer);
		if($level[$count]!="mem"){
			//echo $level[$count];
			$ip_tmp2=get_level_id($db,$id_typ,$ip_tmp[$j]);
			update_conf($db,$ip_tmp[$j],$level[$count+1],$ip_tmp2);
		}
	}
	//exit;
	return true;


}

function get_up_level_id($db,$level,$id,$upid){
	if($level=="mem_winloss") $levelid="mid";
	else $levelid="id";
	$quer="select ".$upid." from ".$level." where ".$levelid."='".$id."'";
	$db->query($quer,1);
	return $db->f($upid);
}


function update_wn($dbr,$dbw,$type,$id,$upid,$winloss_sc,$winloss_c,$winloss_s,$winloss_a){
	$ip_tmp=explode(":",$id);
	if($id=="")return true;

	//$level=array("sc","co","su","ag","mem");
	$level_id=array("scid","cid","sid","aid","mid");
	$comp_ary=array("su_corp","corprator","su_agents","agents","mem_winloss");
				  echo $winloss_sc."<br>";
					echo $winloss_c."<br>";
					echo $winloss_s."<br>";
					echo $winloss_a."<br>";
					echo "<br>";
				for($j=0;$j<count($ip_tmp);$j++){
					$quer="select id,winloss_sc,winloss_c,winloss_s,winloss_a from ".$comp_ary[$type]." where id='".$ip_tmp[$j]."'";
					echo $quer."<br>";
					$dbr->query($quer,1);
					echo $dbr->f('winloss_sc')."<br>";
					echo $dbr->f('winloss_c')."<br>";
					echo $dbr->f('winloss_s')."<br>";
					echo $dbr->f('winloss_a')."<br>";
					echo "<br>";

				}
					exit;
					return true;


}

function move_member($ltype,$lid,$dbmw){	//移動所屬上層資料時，作記錄
	if($ltype=="" || $lid=="")return true;
	$today=getdate();
	$today_gmt=gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
	$mid="";$aid="";$sid="";$cid="";$scid="";
	$Select_SQL="";
	$content_SQL="";
	$ltype_na="";
	switch($ltype){
		case "mem":	$mid=$lid;	$ltype_na="mid";  break;
		case "ag":	$aid=$lid;	$ltype_na="aid";  break;
		case "su":	$sid=$lid;	$ltype_na="sid";  break;
		case "co":	$cid=$lid;	$ltype_na="cid";  break;
	}
	if($mid!=""){
		$Select_SQL="SELECT aid FROM mem_winloss WHERE mid='".$mid."' ;";
		$dbmw->query($Select_SQL,1);	$aid= $dbmw->f('aid');
	}if($aid!=""){
		$Select_SQL="SELECT sid FROM agents WHERE id='".$aid."' ;";
		$dbmw->query($Select_SQL,1);	$sid= $dbmw->f('sid');
	}if($sid!=""){
		$Select_SQL="SELECT cid FROM su_agents WHERE id='".$sid."' ;";
		$dbmw->query($Select_SQL,1);	$cid= $dbmw->f('cid');
	}if($cid!=""){
		$Select_SQL="SELECT scid FROM corprator WHERE id='".$cid."' ;";
		$dbmw->query($Select_SQL,1);	$scid=$dbmw->f('scid');
	}
	if($scid!="" && $ltype!="sc")	$content_SQL.="scid=".$scid;
	if($cid!=""  && $ltype!="co")	$content_SQL.=",cid=".$cid;
	if($sid!=""  && $ltype!="su")	$content_SQL.=",sid=".$sid;
	if($aid!=""  && $ltype!="ag")	$content_SQL.=",aid=".$sid;
	$InsertSql="INSERT INTO mv_mem ( `id` , `mv_type` , `mv_id` , `content` , `date` ) VALUES ('', '".$ltype_na."', '".$lid."', '".$content_SQL."', '".$today_gmt."');";
	$dbmw->query($InsertSql,1);
}
function chk_down_set($type,$w_war,$l_war,$so,$sc,$allW_WAR,$allL_WAR,$allSO,$allSC,$id,$db,$gtype,$rtype,$use,$grp=1){
	global $REC_sub_table,$record_rid,$userid,$REC_level;
	$type_conf=array("corprator"=>"co_conf","su_agents"=>"su_conf","agents"=>"ag_conf","members"=>"mem_conf");
	$type_id=array("corprator"=>"cid","su_agents"=>"sid","agents"=>"aid","members"=>"mid");
	if($type=='members' && $gtype!="GM" && $rtype!="GM"){
		$memvalue=get_value($db,$id)/10000;
		if($memvalue==0)$memvalue=1;
	}else{
		$memvalue=1;
	}
	$sc = floor($sc/$memvalue);
	$so = floor($so/$memvalue);
	$sub= array();
	$sql="select SC,SO,W_WAR,L_WAR from ".$type_conf[$type];
	$sql.=" where ".$type_id[$type]."='".$id."'";
	$sql.=" and ".get_conf_rtype_sql($gtype,$rtype,"");
	$db->query($sql,1);
	
	$all_arr = array("W_WAR","L_WAR","SC","SO");
	if($w_war < $db->f('W_WAR')) $sql_W_WAR = "W_WAR='".$w_war."',";
	if($l_war < $db->f('L_WAR')) $sql_L_WAR = "L_WAR='".$l_war."',";
	//這層最大值<下層最大值 || 下層最大值<這層最小值
	//這層最小值>下層最小值 || 下層最小值>這層最大值
	if($sc < $db->f('SC')|| $db->f('SC')<$so) $sql_SC = "SC='".$sc."',";
	if($so > $db->f('SO')|| $db->f('SO')>$sc) $sql_SO = "SO='".$so."',";
	$allsql_W_WAR = " W_WAR='".$w_war."' where W_WAR>='".$w_war."' ";
	$allsql_L_WAR = " L_WAR='".$l_war."' where L_WAR>='".$l_war."' ";
	$allsql_SC = " SC='".$sc."' where SC>='".$sc."' ";
	$allsql_SO = " SO='".$so."' where SO<='".$so."' ";
	$sql = "";
	
	for($i=0;$i<count($all_arr);$i++){
		$str_all = $all_arr[$i];
		$all = ${"all".$str_all};
		if($all == 'Y'){
			$sql.="update ".$type_conf[$type]." set ".${"allsql_".$str_all}."and gtype='".$gtype."' and ".$type_id[$type]."='".$id."';"; //改全部玩法設定值
		}else{
			$sql_single_war.=${"sql_".$str_all}; //改單一玩法設定值的欄位
			
		}
	}
	if($sql_single_war != ""){
		$sql.= "update ".$type_conf[$type]." set ".substr($sql_single_war,0,-1)." where ".get_conf_rtype_sql($gtype,$rtype," and ".$type_id[$type]."='".$id."'").";";
		
	}

	if($sql != ""){
  		$db->muti_query($sql);
          	ctrl_sub_record($db,$REC_sub_table,$record_rid,$userid,$REC_level,"修改 ".$type." id=".$id." 的詳細設定",$sql);
  		if($type=='members'){
  			javaConnnection('080,'.$id.',ok',MEMBER_DNS,MEMLOGIN_PORT);
  		}
	}
//	if(($so/$memvalue) > $db->f('SO')){$sub[]="SO='".floor($so/$memvalue)."'";}
//	if(($sc/$memvalue) < $db->f('SC')){$sub[]="SC='".floor($sc/$memvalue)."'";}
//	if($w_war < $db->f('W_WAR')){$sub[]="W_WAR='".$w_war."'";}
//	if($l_war < $db->f('L_WAR')){$sub[]="L_WAR='".$l_war."'";}

//	if(count($sub)!=0){
//		$sql="update ".$type_conf[$type]." set ".implode(",",$sub);
//		$sql.=" where ".$type_id[$type]."='".$id."'";
//		$sql.=" and ".get_conf_rtype_sql($gtype,$rtype,"");
//  		$db->query($sql);
//          	ctrl_sub_record($db,$REC_sub_table,$record_rid,$userid,$REC_level,"修改 ".$type." id=".$id." 的詳細設定",$sql);
//  		if($type=='members'){
//  			javaConnnection('080,'.$id.',ok',MEMBER_DNS,MEMLOGIN_PORT);
//  		}
//	}
}

// function chk_down_coin_set($type,$gtype,$coin_ary,$id,$db){
// 	global $REC_sub_table,$record_rid,$userid,$REC_level;
// 	if($gtype == "GM"){
// 		$rtype = Array("max","min");
// 		$type_conf=array("corprator"=>"co_coin","su_agents"=>"su_coin","agents"=>"ag_coin","members"=>"mem_coin");
// 		$sql="select type,size from ".$type_conf[$type];
// 		$sql.=" where user_id = '".$id."'";
// 		$sql.=" and gtype = '".$gtype."';";
// 		$db->query($sql);
// 		$insert_sql ="";
// 		while($db->next_record()){
// 			$db_type = $db->f("type");
// 			$db_size = $db->f("size");
// 			if(  ($db_type=="max" && $coin_ary[$db_type] < $db_size)
// 					|| ($db_type=="min" && $coin_ary[$db_type] > $db_size) ){
// 				$insert_sql .= "update ".$type_conf[$type]." set size = ".$coin_ary[$db_type];
// 				$insert_sql .= " where user_id = '".$id."' and gtype='".$gtype."' and type = '".$db_type."' ";
// 			}
// 		}
// 		if($insert_sql!="") {
// 			ctrl_sub_record($db,$REC_sub_table,$record_rid,$userid,$REC_level,"修改 ".$type." id=".$id." 的詳細設定",$insert_sql);
// 			$db->muti_query($insert_sql);
// 		}
// 	}
// }
function chk_oldpassword($type,$db1,$oldpassword,$id){

		$db1->query("select id from ".$type." where password=PASSWORD('".$oldpassword."') and id ='".$id."'",1);
		if($db1->num_rows() == 0 ){

			$err_msg=$GLOBALS["LVar"]['Err_oldpassword'];
			err_msg($GLOBALS['tpl'],$err_msg);
		exit;
		}

}
?>
