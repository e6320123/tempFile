<?php
include("../conf/config_admin_nouid.php");
include("../lib/pub_edit.php");
include("../lib/pub_admin.php");

$dbr_BA1 = new proc_DB(BA1_DB_HOST_R,DB_USER,DB_PWD,BA1_DB_NAME);
$db = new proc_DB(DB_HOST_R,DB_USER,DB_PWD,DB_NAME);

function add_i_before_username($username){
	return "i".$username;
}

$scid = "";
$useScid = "N";


$sc_id_ary = array();
if($useScid == "Y"){
	$tmpSql = "select id, username from su_corp where id ='".$scid."';";//scid為空 找BA1 sc主帳號的id,username
	// echo $tmpSql."<br>\n";
	$dbr_BA1->query($tmpSql, 1);
	$sc_id = $dbr_BA1->f("id");
	$sc_username = $dbr_BA1->f("username");
	$ori_sc_username = $sc_username;
	$j = 0;
	while(true){
		$db->query("select * from su_corp where  username='".$sc_username."';");//找BA2 sc是否與BA1 sc的username同名
		if($db->num_rows()!=0){//不為空  代表有同名
			$j ++;
			$sc_username = add_i_before_username($sc_username);//加i
		}else{//改完不同名就印出
			echo "sc\t,\t".$sc_id."\t,\t".$ori_sc_username."\t,\t".$sc_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}else{
	$tmpSql = "select id, username from su_corp where 1;";//找其它BA1 sc主帳號的id,username
	// echo $tmpSql."<br>\n";
	$dbr_BA1->query($tmpSql);
	$ba1_acc_sc_num = $dbr_BA1->num_rows();
	$ba1_acc_sc_data = $dbr_BA1->get_total_data();
	for ($i=0; $i < $ba1_acc_sc_num; $i++) {
		$sc_id = $ba1_acc_sc_data[$i]["id"];
		$sc_username = $ba1_acc_sc_data[$i]["username"];
		$sc_id_ary[] = $sc_id;
		$ori_sc_username = $sc_username;
		$j = 0;
		while(true){
			$db->query("select * from su_corp where  username='".$sc_username."';");
			if($db->num_rows()!=0){
				$j ++;
				$sc_username = add_i_before_username($sc_username);
			}else{
				echo "sc\t,\t".$sc_id."\t,\t".$ori_sc_username."\t,\t".$sc_username."\t,\t".$j."<br>\n";
				break;
			}
		}
	}
}

$tmpSql = "select id, username from su_corp where scid in (".join(",",$sc_id_ary).");";
echo $tmpSql."<br>\n";
$dbr_BA1->query($tmpSql);
$ba1_acc_sc_num = $dbr_BA1->num_rows();
$ba1_acc_sc_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_sc_num; $i++) {
	$sc_id = $ba1_acc_sc_data[$i]["id"];
	$sc_username = $ba1_acc_sc_data[$i]["username"];
	$ori_sc_username = $sc_username;
	$j = 0;
	while(true){
		$db->query("select * from su_corp where  username='".$sc_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$sc_username = add_i_before_username($sc_username);
		}else{
			echo "sc\t,\t".$sc_id."\t,\t".$ori_sc_username."\t,\t".$sc_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}

$co_id_ary = array();
if($useScid == "Y"){
	$tmpSql = "select id, username from corprator where scid ='".$scid."';";
}else{
	$tmpSql = "select id, username from corprator where scid in (".join(",",$sc_id_ary).");";
}
// echo $tmpSql."<br>\n";
$dbr_BA1->query($tmpSql);
$ba1_acc_co_num = $dbr_BA1->num_rows();
$ba1_acc_co_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_co_num; $i++) {
	$co_id = $ba1_acc_co_data[$i]["id"];
	$co_username = $ba1_acc_co_data[$i]["username"];
	$co_id_ary[] = $co_id;
	$ori_co_username = $co_username;
	$j = 0;
	while(true){
		$db->query("select * from corprator where  username='".$co_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$co_username = add_i_before_username($co_username);
		}else{
			echo "co\t,\t".$co_id."\t,\t".$ori_co_username."\t,\t".$co_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}

$tmpSql = "select id, username from corprator where cid in (".join(",",$co_id_ary).");";
$dbr_BA1->query($tmpSql);
$ba1_acc_co_num = $dbr_BA1->num_rows();
$ba1_acc_co_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_co_num; $i++) {
	$co_id = $ba1_acc_co_data[$i]["id"];
	$co_username = $ba1_acc_co_data[$i]["username"];
	$ori_co_username = $co_username;
	$j = 0;
	while(true){
		$db->query("select * from corprator where  username='".$co_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$co_username = add_i_before_username($co_username);
		}else{
			echo "co\t,\t".$co_id."\t,\t".$ori_co_username."\t,\t".$co_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}

$sa_id_ary = array();
$tmpSql = "select id, username from su_agents where cid in (".join(",",$co_id_ary).");";
// echo $tmpSql."<br>\n";
$dbr_BA1->query($tmpSql);
$ba1_acc_sa_num = $dbr_BA1->num_rows();
$ba1_acc_sa_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_sa_num; $i++) {
	$sa_id = $ba1_acc_sa_data[$i]["id"];
	$sa_username = $ba1_acc_sa_data[$i]["username"];
	$sa_id_ary[] = $sa_id;
	$ori_sa_username = $sa_username;
	$j = 0;
	while(true){
		$db->query("select * from su_agents where  username='".$sa_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$sa_username = add_i_before_username($sa_username);
		}else{
			echo "sa\t,\t".$sa_id."\t,\t".$ori_sa_username."\t,\t".$sa_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}


$tmpSql = "select id, username from su_agents where sid in (".join(",",$sa_id_ary).");";
$dbr_BA1->query($tmpSql);
$ba1_acc_sa_num = $dbr_BA1->num_rows();
$ba1_acc_sa_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_sa_num; $i++) {
	$sa_id = $ba1_acc_sa_data[$i]["id"];
	$sa_username = $ba1_acc_sa_data[$i]["username"];
	$ori_sa_username = $sa_username;
	$j = 0;
	while(true){
		$db->query("select * from su_agents where  username='".$sa_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$sa_username = add_i_before_username($sa_username);
		}else{
			echo "sa\t,\t".$sa_id."\t,\t".$ori_sa_username."\t,\t".$sa_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}


$ag_id_ary = array();
$tmpSql = "select id, username from agents where sid in (".join(",",$sa_id_ary).");";
// echo $tmpSql."<br>\n";
$dbr_BA1->query($tmpSql);
$ba1_acc_ag_num = $dbr_BA1->num_rows();
$ba1_acc_ag_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_ag_num; $i++) {
	$ag_id = $ba1_acc_ag_data[$i]["id"];
	$ag_username = $ba1_acc_ag_data[$i]["username"];
	$ag_id_ary[] = $ag_id;

	$ori_ag_username = $ag_username;
	$j = 0;
	while(true){
		$db->query("select * from su_agents where  username='".$ag_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$ag_username = add_i_before_username($ag_username);
		}else{
			echo "ag\t,\t".$ag_id."\t,\t".$ori_ag_username."\t,\t".$ag_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}

$tmpSql = "select id, username from agents where aid in (".join(",",$ag_id_ary).");";
// echo $tmpSql."<br>\n";
$dbr_BA1->query($tmpSql);
$ba1_acc_ag_num = $dbr_BA1->num_rows();
$ba1_acc_ag_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_ag_num; $i++) {
	$ag_id = $ba1_acc_ag_data[$i]["id"];
	$ag_username = $ba1_acc_ag_data[$i]["username"];
	$ori_ag_username = $ag_username;
	$j = 0;
	while(true){
		$db->query("select * from su_agents where  username='".$ag_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$ag_username = add_i_before_username($ag_username);
		}else{
			echo "ag\t,\t".$ag_id."\t,\t".$ori_ag_username."\t,\t".$ag_username."\t,\t".$j."<br>\n";
			break;
		}
	}
}

$tmpSql = "select id, username from members where aid in (".join(",",$ag_id_ary).");";
// echo $tmpSql."<br>\n";
$dbr_BA1->query($tmpSql);
$ba1_acc_mem_num = $dbr_BA1->num_rows();
$ba1_acc_mem_data = $dbr_BA1->get_total_data();
for ($i=0; $i < $ba1_acc_mem_num; $i++) {
	$mem_id = $ba1_acc_mem_data[$i]["id"];
	$mem_username = $ba1_acc_mem_data[$i]["username"];

	$ori_mem_username = $mem_username;
	$j = 0;
	while(true){
		$db->query("select * from members where  username='".$mem_username."';");
		if($db->num_rows()!=0){
			$j ++;
			$mem_username = add_i_before_username($mem_username);
		}else{
			echo "mem\t,\t".$mem_id."\t,\t".$ori_mem_username."\t,\t".$mem_username."\t,\t".$j."<br>\n";
			break;
		}
	}
} 



?>