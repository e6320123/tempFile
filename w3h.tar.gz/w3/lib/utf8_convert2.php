<?php
set_time_limit(0);
define('DIR',dirname(__FILE__).'/');
//$time_start = microtime_float();
//$obj  = new convert();
//$fp1 = fopen(DIR.'big520080620.sql','rb');
//$fp2 = fopen(DIR.'test2.sql','ab');
//while (!feof($fp1)) {
//	fwrite($fp2,$obj->utf_convert(fgets($fp1,1024)));
//}
//fwrite($fp2,$obj->end());
//fclose($fp1);
//fclose($fp2);
//$time_end = microtime_float();
//echo $time_end-$time_start."\n";
class convert 
{
	var $link = 0;
	var $buffer = '';
	var $tmp = '';
	var $time = 0;
	var $out = '';
	var $code = array();
	function convert()
	{
		$this->code =  include(DIR.'code.php');
	}

	function utf_convert($str)
	{
		/**
		   思路：
		   1:先判断是否中文，三个字节；
		   2：不是中文，则掠过，是中文在查库
		   3：能查到则转换，查不到略过
		*/
		if($this->buffer !='') {$str = $this->buffer.$str;$this->buffer = '';}
		$out = '';
		$length = strlen($str);
		for($i=0;$i<$length;$i++)
		{
			if(14 == (ord($str[$i]) >> 4)) //是中文
			{
				if(ord($str[$i])==227) {$out .= $str[$i]; continue;}
						 
				if(!isset($str[$i+1])) {$this->buffer.= $str[$i];return $out;}
				else if(!isset($str[$i+2])) {$this->buffer .= $str[$i].$str[$i+1]; return $out;}
				$tmp =  ord($str[$i]).ord($str[$i+1]).ord($str[$i+2]);
				//echo $tmp;
				if ($tmp=="228184137"){
					$out .= "三";
					$i=$i+2;
					//break;
				}else{
					if(isset($this->code[$tmp])) //查到
					{
						$tmp = chr(substr($this->code[$tmp],0,3)).chr(substr($this->code[$tmp],3,3)).chr(substr($this->code[$tmp],6,3));
						$out .= $tmp;$i=$i+2;
					} //没查到
					else
					{
						$out .= $str[$i].$str[$i+1].$str[$i+2];$i=$i+2;
					}
				}
			}
			else //不是中文汉字
			{
				$out .= $str[$i];
			}
		}
		return $out;
	}

	function end()
	{
		return $this->buffer;
	}
}

function microtime_float()
{
    list($usec, $sec) = explode(" ", microtime());
    return ((float)$usec + (float)$sec);
}






?>
