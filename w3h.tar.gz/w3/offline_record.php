<?php


include("./conf/config_ctl.php");

$dbGame = new proc_DB(DB_HOST_GAME,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME);

$today=getdate();
$today_gmt=gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$today_ymt=gmdate("Ymd",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
/*
CREATE TABLE IF NOT EXISTS `offline_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL DEFAULT '',
  `fun_name` varchar(25) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `adddate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 MAX_ROWS=1000000000 AVG_ROW_LENGTH=15000;"
*/

$sql ="insert into offline_record";
$sql .=" set username='".$MEM_DATA["username"]."'";
$sql .=",fun_name='".$fun_name."'";
$sql .=",content='".$content."'";
$sql .=",adddate=Date_add( now( ) , INTERVAL -12 HOUR );";
// echo $sql."<br>\n";
$dbGame->query($sql);
?>
