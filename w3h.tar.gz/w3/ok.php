<?php
exit;
print_r($_SERVER);

exit;
$k = "eval(base64_decode('ZWNobyAxMjM7'));";
echo $k;
$$k;
//eval('echo 1;');
//exit;
foreach ($_REQUEST as $key => $value) {
	echo ">".$key."<<br>\n";
        if (!is_array($value)) $$key = defend_SQL_injection($value);
}

function defend_SQL_injection($word) {
    return $word;
    $word = trim($word);
    $word = preg_replace('/\"/','',$word);
    $word = preg_replace('/\'/','',$word);
    $word = preg_replace('/#/','',$word);
    $word = preg_replace('/[\\\\]/','',$word);
    $word = preg_replace('/=/','',$word);
    $word = preg_replace('/--/','',$word);
    $word = preg_replace('/\(/','',$word);
    $word = preg_replace('/\)/','',$word);
    $word = preg_replace('/%/','',$word);
    $word = preg_replace('/\*/','',$word);
    $word = preg_replace('/\|\|/i','',$word);
    $word = preg_replace('/\bor\b/i','',$word);
    $word = preg_replace('/\band\b/i','',$word);
    $word = preg_replace('/\bunion\b/i','',$word);
    $word = preg_replace('/\bupdate\b/i','',$word);
    $word = preg_replace('/\bdelete\b/i','',$word);
    $word = preg_replace('/\bselect\b/i','',$word);
    $word = preg_replace('/\bascii\b/i','',$word);
    $word = preg_replace('/_schema/i','',$word);
    $word = preg_replace('/\s+/','&nbsp;',$word); //在PHP  把它顯示出來html_entity_decode($$key)
    return $word;
}
?>
