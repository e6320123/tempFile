<?php
// exit;
include("./conf/config_ctl.php");
$dbGame = new proc_DB(DB_HOST_GAME,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME);


$reload_sql  = " update reload_username set reload='N' where username LIKE  'video5' ";
echo $reload_sql;
$dbGame->query($reload_sql);

// $sql = "drop table offlineRecord";
// echo $sql;
// $dbGame->query($sql);
// $sql="CREATE TABLE IF NOT EXISTS `ping_record` (
//   `id` bigint(20) NOT NULL AUTO_INCREMENT,
//   `username` varchar(10) NOT NULL DEFAULT '',
//   `content` text NOT NULL,
//   `adddate` datetime NOT NULL,
//   PRIMARY KEY (`id`),
//   KEY (`username`)
// ) ENGINE=MyISAM DEFAULT CHARSET=utf8 MAX_ROWS=1000000000 AVG_ROW_LENGTH=15000;";
// echo $sql;
// $dbGame->query($sql);
/*
drop table reload_username;
CREATE TABLE IF NOT EXISTS `reload_username` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL DEFAULT '',
  `reload` enum('Y','N') NOT NULL DEFAULT 'Y',
  `adddate` datetime NOT NULL,
  `lastdate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 MAX_ROWS=1000000000 AVG_ROW_LENGTH=15000;
*/
?>
