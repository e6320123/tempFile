<?php


include("./conf/config_ctl.php");

// $match=preg_match("/(am|ph)video([1-9]|1[0-9]|2[0-3])$/",$username,$matches);
$match=preg_match("/^(am|ph)video([1-9]|[1-9][0-9])$/",$username,$matches);

if($match && $matches[2]*1 >= 25){
  $dbGame = new proc_DB(DB_HOST_GAME3,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME_3); 
}
else if($match && $matches[2]*1 > 10){
  $dbGame = new proc_DB(DB_HOST_GAME2,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME);
}else{
  $dbGame = new proc_DB(DB_HOST_GAME,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME);
}


$today=getdate();
$today_gmt=gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$today_ymd=gmdate("Ymd",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
/*
CREATE TABLE IF NOT EXISTS `ping_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `adddate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 MAX_ROWS=1000000000 AVG_ROW_LENGTH=15000;
*/




$sql = "";
$table = "ping_record_".$today_ymd;
$sql =  "CREATE TABLE IF NOT EXISTS ".$table." LIKE `ping_record`;";
// echo $sql."<br>\n";
$dbGame->query($sql);


$sql ="insert into ".$table;
$sql .=" set username='".$MEM_DATA["username"]."'";
$sql .=",content='".$nowtime." ".$content."'";
$sql .=",adddate=Date_add( now( ) , INTERVAL -12 HOUR );";
// echo $sql."<br>\n";
$dbGame->query($sql);
?>
