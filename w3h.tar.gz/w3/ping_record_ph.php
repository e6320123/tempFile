<?php


// include("./conf/config_ctl.php");
// include("./conf/config_ctl.php");
if(empty($_SERVER['DOCUMENT_ROOT'])) $server_root = $_SERVER["PWD"];
else $server_root = $_SERVER['DOCUMENT_ROOT'];

include substr($server_root,0,strlen($server_root)-3)."/config/pub_config_ctl.php";
include WEB_PATH."/lib/mysqllib.php";

foreach ($_REQUEST as $key => $value) {
    if(is_array($value))   {
      foreach($value as $mkey => $mval){
        $value[$mkey] = defend_SQL_injection($mval);
      }
      try{
        $$key = $value;
      }catch(Exception $e){
        $$key = "";
      }
    }else{
      try{
        $$key = defend_SQL_injection($value);
      }catch(Exception $e){
        $$key = "";
      }
    }
}

$match=preg_match("/(am|ph)video([1-9]|1[0-9]|2[0-3])$/",$username,$matches);

if($match && $matches[2]*1 > 10){
  $dbGame = new proc_DB(DB_HOST_GAME2,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME);
}else{
  $dbGame = new proc_DB(DB_HOST_GAME,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME);
}


$uid= $uid;
$username = $username;
$content = $content;
$nowtime = $nowtime;

$MEM_DATA["username"] = $username;

$today=getdate();
$today_gmt=gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$today_ymd=gmdate("Ymd",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
/*
CREATE TABLE IF NOT EXISTS `ping_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `adddate` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY (`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 MAX_ROWS=1000000000 AVG_ROW_LENGTH=15000;
*/

$sql = "";
$table = "ping_record_".$today_ymd;
$sql =  "CREATE TABLE IF NOT EXISTS ".$table." LIKE `ping_record`;";
// echo $sql."<br>\n";
$dbGame->query($sql);


$sql ="insert into ".$table;
$sql .=" set username='".$MEM_DATA["username"]."'";
$sql .=",content='".$nowtime." ".$content."'";
$sql .=",adddate=Date_add( now( ) , INTERVAL -12 HOUR );";
// echo $sql."<br>\n";
$dbGame->query($sql);



function defend_SQL_injection($word) {
    $word = trim($word);
    $word = preg_replace('/\"/','',$word);
    $word = preg_replace('/\'/','',$word);
    $word = preg_replace('/#/','',$word);
    $word = preg_replace('/[\\\\]/','',$word);
    $word = preg_replace('/=/','',$word);
    $word = preg_replace('/--/','',$word);
    $word = preg_replace('/\(/','',$word);
    $word = preg_replace('/\)/','',$word);
    $word = preg_replace('/%/','',$word);
    $word = preg_replace('/\*/','',$word);
    $word = preg_replace('/\|\|/i','',$word);
    $word = preg_replace('/\bor\b/i','',$word);
    $word = preg_replace('/\band\b/i','',$word);
    $word = preg_replace('/\bunion\b/i','',$word);
    $word = preg_replace('/\bupdate\b/i','',$word);
    $word = preg_replace('/\bdelete\b/i','',$word);
    $word = preg_replace('/\bselect\b/i','',$word);
    $word = preg_replace('/\bascii\b/i','',$word);
    $word = preg_replace('/_schema/i','',$word);
    $word = preg_replace('/\s+/','&nbsp;',$word); //在PHP  把它顯示出來html_entity_decode($$key)
    return $word;
}

?>