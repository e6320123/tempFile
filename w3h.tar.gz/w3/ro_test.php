<?php
// echo phpinfo();
// exit;
//print_r($_SERVER);

//get uid by login id/mid/username
// include("../config/pub_config_ctl.php");
// exit;

// php-cgi -f ro_test.php uid=1bf096fd52e56728

include("../config/pub_config_ctl.php");
$WEB_PATH=WEB_PATH;
if(!empty($_SERVER["HOME"])){
    $WEB_PATH = $_SERVER["HOME"]."/w3";
}
include ($WEB_PATH."/lib/mysqllib.php");

$idstr_ary = Array();
$dbdata_ary = Array();
//$layer_ary = Array("sc"=>"su_corp","c"=>"corprator","s"=>"su_agents","a"=>"agents","al"=>"agents");
$map_layer_num = Array("sc","c","s","a","m");
$map_layer_table = Array("su_corp","corprator","su_agents","agents","members");

$fieldStr_ary = Array();
// winloss_max
$fieldStr_ary["sc"] = "id,username,winloss,winloss_bak,fix8,winloss_max,winloss_fix8";
// winloss_sc	winloss winloss_min(股東最低佔成)	winloss_min_sw(股東最低佔成) winloss_occupy(股東強制佔成) back("") winloss_bak(0) fix8(N)
$fieldStr_ary["c"] = "id,username,scid,winloss_sc,winloss,winloss_min,winloss_min_sw,winloss_occupy,back,winloss_bak,fix8";
// winloss_sc winloss_c winloss back(股東回歸成數) winloss_bak(股東回歸成數) fix8(總代理強制佔成)
$fieldStr_ary["s"] = "id,username,cid,winloss_sc,winloss_c,winloss,back,winloss_bak,fix8";
// winloss_sc winloss_c winloss_s winloss_a
$fieldStr_ary["a"] = "id,username,sid,winloss_sc,winloss_c,winloss_s,winloss_a";

$fieldStr_ary["m"] = "id,username,aid";
if(is_null($user_layer)) $user_layer = "a"; // sc/c/s/a/al
if(is_null($user_id)) $user_id = "28";//mid

$layer_num = array_search($user_layer,$map_layer_num);
$idstr_ary[$layer_num] = $user_id;


$dbMAIN_R = new proc_DB(DB_HOST_R,DB_USER_R,DB_PWD_R,DB_NAME);
// $sql = "select * from ".$map_layer_table[$layer_num]." where id ='".$user_id."' and  type=1 " ;
// echo $sql."<br>\n";
// $dbMAIN_R->query($sql,1);
// $dbdata_ary[$layer_num] = Array();
// $dbdata_ary[$layer_num][] =  $dbMAIN_R->record;
for($i=0;$i<count($map_layer_num);$i++){
    $v=$map_layer_num[$i];
    $next = $i+1;
    if($v=="m")continue;

    echo $i." ".$v."<br>\n";
    if($i >= $layer_num){
        $sql = "select * from ".$map_layer_table[$next]." where ".$v."id in (".$idstr_ary[$i].") " ;
        echo $sql."<br>\n";
        $dbMAIN_R->query($sql);
        $dbdata_ary[$next] = Array();
        $fieldStr = "id,username,scid,cid,sid,aid,mid";
        $str = Array();
        while($dbMAIN_R->next_record()){
            //print_r($dbMAIN_R->record);
            $record=$dbMAIN_R->record;
            $record = getDBArrayByFieldString($record,$fieldStr_ary[$map_layer_num[$next]]);
            $dbdata_ary[$next][] = $record;
            $str[] = $record["id"];
        }
        if(count($str)>0)$idstr_ary[$next]=implode(",",$str);
        // print_r($dbdata_ary[$i]);
    }
}
for($i=count($map_layer_num)-1;$i>=0;$i--){
    $v=$map_layer_num[$i];
    $v_1=$map_layer_num[$i-1];
    echo $i." ".$v."<br>\n";
    if($i <= $layer_num){
        $sql = "select * from ".$map_layer_table[$i]." where id =".$idstr_ary[$i]."";
        echo $sql."<br>\n";
        $dbMAIN_R->query($sql);
        $dbdata_ary[$i] = Array();
        $fieldStr = "id,username,scid,cid,sid,aid,mid";
        $str = Array();
        while($dbMAIN_R->next_record()){
            //print_r($dbMAIN_R->record);
            $record=$dbMAIN_R->record;
            $record = getDBArrayByFieldString($record,$fieldStr_ary[$v]);
            $dbdata_ary[$i][] = $record;
            $str[] = $record[$v_1."id"];
        }
        if(count($str)>0)$idstr_ary[$i-1]=implode(",",$str);
    }
}
//$dbdata_ary[] = $idstr_ary;

// foreach($map_layer_num as $k=>$v){

// }

echo "<script>\n";
echo "var aa=".json_encode($dbdata_ary).";\n";
echo "console.log(aa);\n";
echo "</script>\n";


function getAgLevelByAid($aid,$dbMAIN_R){
    $ret = Array();
    $sql = "select * from agents where top_aid=".$aid." and aid=0 and type = 1 order by level asc";
    $dbMAIN_R->query($sql);
    $fieldStr = "id,sid,aid,top_aid,up_aid,winloss_a";
    while($dbMAIN_R->next_record()){
        $db_data = getDBArrayByFieldString($dbMAIN_R->record,$fieldStr);
        $ret[$db_data["id"]] = Array();
        $ret[$db_data["id"]]["data"] = $db_data;
        if($db_data["up_aid"]!=0) {
            //if( !is_array($ret[$db_data["up_aid"]]) )  $ret[$db_data["up_aid"]] = Array();
            if(!is_array( $ret[$db_data["up_aid"]]["level_ag"] )) $ret[$db_data["up_aid"]]["level_ag"] = Array();
            $ret[$db_data["up_aid"]]["level_ag"][] = $db_data;
        }
    }
    return $ret;
}
function getDBArrayByFieldString($record,$str){
    $ret = Array();
    $ary=explode(",",$str);
    $len=count($ary);
    for($i=0;$i<$len;$i++){
        $key = $ary[$i];
        $ret[$key] = $record[$key];
    }
    return $ret;
}

?>
<html>
<head>
</head>
<body>
    
</body>
</html>
<?php
exit;
//以下uid測試
echo hexdec("1b");
echo "<br>\n";
echo hexdec("5e5");
exit;

$uid="1547004621550m1bl5e5";
$uid =  uiddecode($uid);

	$tableid=substr(strstr($uid,'l'),1);
	$uidx=substr($uid,0,(strlen($uid)-strlen($tableid)-1));
	$mid=substr(strstr($uidx,'m'),1);
echo $uid."<br>\n";
echo $tableid."<br>\n";
echo $uidx."<br>\n";
echo $mid."<br>\n";

function uiddecode($uid){
    //global $ip;
    $ip="0.0.0.0";
    $ips=preg_split("[\.]",$ip);
    $ip_num=0;
    for ($i=0;$i<count($ips);$i++){
        $ip_num=$ip_num+$ips[$i]*1;
    }
    echo substr($uid,strrpos ($uid, "m")+1,strrpos ($uid, "l")-strrpos ($uid, "m")-1);
    echo "<br>\n";
    echo $uid;
    echo "<br>\n";
    echo strrpos ($uid, "m")+1;
    echo "<br>\n";
    echo strrpos ($uid, "l")-strrpos ($uid, "m")-1;
    echo "<br>\n";
    $n_memid=hexdec(substr($uid,strrpos ($uid, "m")+1,strrpos ($uid, "l")-strrpos ($uid, "m")-1))-$ip_num;
     $n_lid=substr(strrchr ($uid, "l"),1);
     $n_uid=substr($uid,0,strrpos ($uid, "m"));

    return $n_uid."m".$n_memid."l".(hexdec($n_lid)-$ips[3]*1);

}
exit;
$today=getdate();
$WEB_TIME_ZONE = 0;
$today_gmt=gmdate("Y-m-d h:i:s",mktime($today[hours]+$WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
$today_ymd=gmdate("Ymd",mktime($today[hours]+$WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
echo $today_gmt;
exit;
$path= substr($_SERVER['PWD'],0,strlen($_SERVER['PWD'])-3);
echo $path;
echo $_SERVER['PWD'];
print_r($_SERVER);
print_r($_GET);
exit;

//IP測試
// $test_ip_ary = Array(//"127.0.0.1",
// "10.10.10.10","11.10.10.10",
// "172.16.0.1","172.31.255.255","172.32.2.2",
// "192.168.0.1","192.168.255.255","192.169.0.1",
// "0");
// 
// foreach($test_ip_ary as $key=>$val){
//     echo $val." => ".(isIP($val,true)?"true":"false")."<br>\n";
// }
// 
echo getIPAddress();

function isIP($ip,$isPublic){
    if(filter_var($ip,FILTER_VALIDATE_IP)){
        //IF IPV6 ::1
        if(preg_match("/:/",$ip)) return false;
        //IF PRIVATE NETWORK
        if($isPublic){
            
            $ip_ary = preg_split("/\./",$ip);
            $ip_a = $ip_ary[0]*1;
            $ip_b = $ip_ary[1]*1;
            $ip_c = $ip_ary[2]*1;
            $ip_d = $ip_ary[3]*1;
            //IF 0.0.0.0 
            if($ip == "0.0.0.0") return false;
            //IF 255.255.255.255 
            if($ip == "255.255.255.255") return false;
            //IF 127.0.0.1 
            if($ip_a==127) return false;
            //10.0.0.0 ~ 10.255.255.255: 16,777,216
            if($ip_a==10) return false;
            //172.16.0.0 ~ 172.31.255.255: 1,048,576
            if($ip_a==172 && $ip_b >= 16 && $ip_b <= 31) return false;
            //192.168.0.0 ~ 192.168.255.255: 65,536
            if($ip_a==192 && $ip_b == 168) return false;
        }
        return true;
    }
    return false;
}
function getIPAddress(){
    $IP = trim($_SERVER["REMOTE_ADDR"]);
    $RealIP = trim($_SERVER["HTTP_X_REAL_IP"]);
    $ForwardedIP = trim($_SERVER["HTTP_X_FORWARDED_FOR"]);
    if($RealIP != "" && $RealIP != $IP){
        if(isIP($RealIP,true))$IP=$RealIP;
    }
    if($ForwardedIP!= "" && $ForwardedIP != $IP)
    {
        if(preg_match("/,/",$ForwardedIP))
        {
            $IP_ary = preg_split("/,/",$ForwardedIP);
            if(isIP($IP_ary[0],true))$IP = $IP_ary[0];
        }else{
            if(isIP($ForwardedIP,true))$IP=$ForwardedIP;
        }
    }
    return $IP;
}

exit;
?>