<?php
$flag_de = false;
$flag_en = false;
$cmd=$_REQUEST["cmd"];
$ret = "null";

if(!empty($cmd)){
    $ip="192.168.201.99";
    $port="28000";
    if($flag_en)$cmd = encode($cmd);
    $ret=javaConnnection($cmd,$ip,$port,true);
    if($flag_de){
        echo $ret."<br>\n";
        $ret=decode($ret);
    }
}
echo $ret."<br>\n";
echo "<script>\n";
echo "var obj = ".trim($ret)."\n";
echo "console.log(obj)\n";
echo "</script>\n";
function javaConnnection($command,$ip,$port,$back=false){
	$fp =fsockopen($ip, $port, $errno, $errstr, 5);
	if (!$fp) {
		//echo "<script>alert('server error');</script>";
	} else {
		fwrite($fp, $command."\n");
		if($back){
			while (!feof($fp)) {
				$get.= fgets($fp, 128);
			}
     	}
		fclose($fp);
 	}
	return $get;
}
function encode($Str) {
	$trans = "";
	$rev = "";
	$getcode = "";
	$i =0;
	for ($i=0; $i < strlen($Str); $i++) {
		$trans.= strtoupper(dechex((255 - ord(substr($Str,$i,1)))));
	}
	$i = 0;
	for ($i=0; $i< strlen($trans); $i++) {
		$rev = substr($trans,$i,1).$rev;
	}
	$getcode = substr($rev,5,strlen($rev)-5).substr($rev,0,5);
	return $getcode;
}
 /**
  * 解碼
  */
function decode($getstr) {
	$gettrans = "";
	$destr = "";
	$getrev = "";
	$i =0;
	$getrev = substr($getstr,strlen($getstr) - 5, 5).substr($getstr , 0, strlen($getstr) - 5);
	for ($i=0; $i < strlen($getrev); $i++) {
		$gettrans = substr($getrev , $i, 1).$gettrans;
	}
	$i =0;
	for ($i=0; $i < strlen($gettrans); $i=$i+2) {
		$destr.= Chr(255 - hexdec(substr($gettrans,$i, 2)));
	}
	return $destr;
}
?>