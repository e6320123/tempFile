 <?php 
 include("./conf/config_ctl.php");
 if(!isset($start))$start=0;
 if(!isset($len))$len=1;
 if(!isset($tbid))$tbid = "";
 if(!isset($isresult))$isresult = "Y";
 $len=min($len,10);
 define("WEB_TIME_ZONE",-4);
 $today=getdate();
 $today_gmt=gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
 if(!isset($ymd))$ymd=gmdate("Ymd",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));

 
 
 $dbGame = new proc_DB(DB_HOST_GAME_R,DB_USER_GAME,DB_PWD_GAME,DB_NAME_GAME);
 $sql = "select * from pic_".$ymd;
 $sql .= " where id > ".$start.""; 
 if($tbid != "") $sql .= " and tbid='".$tbid."'";
 if($isresult == "Y")$sql .= " and result not in ('notStopTime','stopTime') ";
 $sql .= " limit 0,".$len; 
 // echo $sql;
 $dbGame->query($sql);
 
 while($dbGame->next_record()){
   $id=$dbGame->f("id");
   $dbtbid=$dbGame->f("tbid");
   $btid=$dbGame->f("btid");
   $gmid=$dbGame->f("gmid");
   $gid=$dbGame->f("gid");
   $result=$dbGame->f("result");
   $adddate=$dbGame->f("adddate");
   $img=$dbGame->f("content");
   echo "<div>";
   echo "<span>".$id." ".$adddate." ".$dbtbid."_".$gmid." result=".$result."</span>";
   echo "</div>";
   echo "<div>";
   echo "<img src=".$img.">";
   echo "</div>";
 }
 echo "<button onclick=\"document.location.href='/show_pic.php?uid=".$uid."&len=".$len."&start=".$id."&tbid=".$tbid."&ymd=".$ymd."&isresult=".$isresult."';\">next</button>";
 ?>