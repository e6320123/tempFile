<?php 
/*
foreach ($_REQUEST as $key => $value) {
        echo $key." ".$value."<br>\n";
        if(!is_array($value) && empty($_COOKIE[$key])) {
         echo $key." ".$value."<br>\n";
	 $$key = defend_SQL_injection($value); 
	 echo $$key." ".$value."<br>\n";
        }
}
*/
$url = $_REQUEST["url"];

if(strpos($url, "\"") >= 0){
	$urlAry=split("\"",$url);
	$url = $urlAry[0];
}

echo  "POS".strpos($url, "\"")."<br>";

echo "AAA".$url;
exit;

foreach ($_REQUEST as $key => $value) {
	echo $key." ".$value."<br>\n";
	if(is_array($value))   {
	  foreach($value as $mkey => $mval){
	    $value[$mkey] = defend_SQL_injection($mval);
	  }
	  try{
	    $$key = $value;
	  }catch(Exception $e){
	    $$key = "";
	  }
	}else{
	  try{
	    $$key = defend_SQL_injection($value);
	  }catch(Exception $e){
	    $$key = "";
	  }
	}
	echo $key." ".$value."<br>\n";
}
function defend_SQL_injection($word){
        $word = trim($word);
	$word = preg_replace('/\"/','',$word);
	$word = preg_replace('/\'/','',$word);
	$word = preg_replace('/#/','',$word);
	$word = preg_replace('/[\\\\]/','',$word);
	$word = preg_replace('/=/','',$word);
	$word = preg_replace('/--/','',$word);
	$word = preg_replace('/\(/','',$word);
	$word = preg_replace('/\)/','',$word);
	$word = preg_replace('/%/','',$word);
	$word = preg_replace('/\*/','',$word);
	$word = preg_replace('/\|\|/i','',$word);
	$word = preg_replace('/\bor\b/i','',$word);
	$word = preg_replace('/\band\b/i','',$word);
	$word = preg_replace('/\bunion\b/i','',$word);
	$word = preg_replace('/\bupdate\b/i','',$word);
	$word = preg_replace('/\bdelete\b/i','',$word);
	$word = preg_replace('/\bselect\b/i','',$word);
	$word = preg_replace('/\bascii\b/i','',$word);
	$word = preg_replace('/_schema/i','',$word);
	$word = preg_replace('/\s+/','&nbsp;',$word); //在PHP  把它顯示出來html_entity_decode($$key)
	return $word;
}
echo ">>>".$text."<<<";
?>