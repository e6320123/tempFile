<?php

$methodname = $_GET["name"];
if($methodname=="") exit(0);
$time_start = microtime(true);


$today = getdate();
$now_gmt = gmdate("Y-m-d H:i:s",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
$now_gmt_for_game_set = gmdate("Y-m-d H:i:s",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
$now_date = gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
$now_date_for_game_set = gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
$ftime =$now_date;
$shoeBixJson = "";
//轉桌號ID
$machineId = $_GET["machineId"];
$machineId = substr($machineId,0,2).substr($machineId,-2);
$tbid = $tbmap[$machineId];

//記錄來源
$source_data = $_SERVER["REQUEST_URI"];

echo "<?xml version=\"1.0\" encording=\"utf-8\"?><response name=\"".$methodname."\" result=\"0\"></response>";

//BSB 沒有實作
if($methodname=="setTableBetLimit")
{
    $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)
    $currency = $_GET["currency"]; //Currency type (PHP, HKD, USD)
    $maxBet  = $_GET["maxBet"]; //Maximum Bet limit (25000000)
    $miniBet = $_GET["miniBet"];//Minimum Bet limit (100000)
    $maxSide  = $_GET["maxSide"]; //Maximum Side Bet limit (TIE, Banker-pair, Player-pair)
    $miniSide  = $_GET["miniSide"]; //Minimum Side Bet limit (TIE, Banker-pair, Player-pair)

    $data_Limit = array(
        "gold_max_P"=> $maxBet ,
        "gold_min_P" => $miniBet,
        "gold_max_BP" => $maxSide,
        "gold_min_BP"=> $miniSide,
        "gold_max_T"=> $maxSide,
        "gold_min_T"=> $miniSide
	 );
	 
    $data_array = array(
        "method" => "set",
        "command"=>"set",
        "game_time" => transTime($occurDateTime),
        "data"=>$data_Limit,
        "status"=> "1",
        "table_no"=> $machineId
     );
	 $json = json_encode($data_array);
	 echo $json;
}
//時間中間的空白轉成 T , 並加上毫秒 000
function transTime($times)
{
   return str_replace(" ","T",$times).".000";
}


exit(0);
?>
