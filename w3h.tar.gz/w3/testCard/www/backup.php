<?php

$methodname = $_GET["name"];
if($methodname=="") exit(0);
$time_start = microtime(true);


include("./mysqllib.php");
include("./config.php");

$today = getdate();
$now_gmt = gmdate("Y-m-d H:i:s",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$now_date = gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));

$ftime = date("Y-m-d");


//轉桌號ID
$machineId = $_GET["machineId"];
$machineId = substr($machineId,0,2).substr($machineId,-2);
$tbid = $tbmap[$machineId];

//記錄來源
$source_data = $_SERVER["REQUEST_URI"];
writeRec(FILEPATH,$machineId.".log",$source_data."\n",$ftime);


$logsql = "insert into sourcelog (`id` , `tbid`,`value` ,`date` ,`adddate`) ";
$logsql.= " values (null , '".$tbid."' , '".base64_encode($source_data)."' , '".$now_date."' , now()); ";
$dbw->insert_id($logsql);
echo "<?xml version=\"1.0\" encording=\"utf-8\"?><response name=\"".$methodname."\" result=\"0\"></response>";
//結果
if($methodname=="setBsbBaccaratPlayJournal")    //OKADA給的結果
{
    //$machineId = $_GET["machineId"];//Game table number(machine ID)
    $actionId = $_GET["actionId"];//Action ID ( 1:New, 2:Modify)
    $gamePlayJournalId = $_GET["gamePlayJournalId"]; // Game Journal ID (unique number)
    $result_id = $gamePlayJournalId;
    $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)
    $ShoeNo = $_GET["ShoeNo"]; //Shoe number
    $GameNo = $_GET["GameNo"]; //Game number 
    $Result = $_GET["result"]; //Game result ( 1:Banker, 2:Player, 3:Tie)
    $bankerPair = $_GET["bankerPair"];//Banker pair flag ( 0:Not occur, 1:Occur )
    $playerPair = $_GET["playerPair"];//player pair flag ( 0:Not occur, 1:Occur )
    $superSix = $_GET["superSix"];//超級六 免佣時的規則( 0:Not occur, 1:Occur )
    $bankerResultPoint = $_GET["bankerResultPoint"];//Banker result point ( 0 – 9 )
    $PlayerResultPoint = $_GET["PlayerResultPoint"];//Player result point ( 0 – 9 )
  
    $bankerCard1 = $_GET["bankerCard1"];//Banker first card suit and number (Note : #1)
    $bankerCard2 = $_GET["bankerCard2"];//Banker second card suit and number (Note : #1)
    $bankerCard3 = $_GET["bankerCard3"];//Banker third card suit and number (Note : #1)
    $playerCard1 = $_GET["playerCard1"];//Player first card suit and number (Note : #1)
    $playerCard2 = $_GET["playerCard2"];//Player second card suit and number(Note : #1)
    $playerCard3 = $_GET["playerCard3"];//Player third card suit and number(Note : #1)
    //Upper one character is suit: D=Diamond, H=Hearts, C=Clubs, S=Spades 
    //Lower on character is number (hex): 0 – 9, A=10, B=Jack, C=Queen, D=King 
    //Example: HB (jack of Hearts)
    //檢查是不是有重複的局
    if(!DEGUG){
        $dbr->query("select * from `BA` where id='".$result_id."'");
        if($dbr->num_rows() > 0 ){
            writeRec(FILEPATH,$ftime."_error.log","重複的結果id".$result_id."\n",$ftime);	
            exit(0);
        }
    }
    $status = 1;
    if($actionId == 1)      //有效資料
    {
        $cardlist = array();
        $player1 = transPoker( "1" , $playerCard1   , "P");
        if($player1 !="") $cardlist[] = $player1;
        
        $banker1 = transPoker( "2" , $bankerCard1  , "B");
        if($banker1 !="") $cardlist[] = $banker1;
        
        $player2 = transPoker( "3" , $playerCard2  , "P");
        if($player2 !="") $cardlist[] = $player2;
        
        $banker2 = transPoker( "4" , $bankerCard2  , "B");
        if($banker2 !="") $cardlist[] = $banker2;
        
        $player3 = transPoker( count($cardlist), $playerCard3  , "P");
        if($player3 !="") $cardlist[] = $player3;
        
        $banker3 = transPoker( count($cardlist) , $bankerCard3  , "B");
        if($banker3 !="") $cardlist[] = $banker3;
    }
    else
    {
        $cardlist= array();
        $status = 0;
    }
    
    $today_gmt=substr( $occurDateTime, 0 , 10 );
    $today=str_replace("-","", $today_gmt);
    $win_type = ($superSix=="0")? "" : "S6";            //S6 ：免佣6點莊贏
    if($Result == "0") $win = "B";
    if($Result == "1") $win = "P";
    if($Result == "2") $win = "T";

    $resultstr = "";
    if(count($cardlist)  <= 4) $resultstr.="UN,";
    else $resultstr.="OV,";
    if($win=="T")$resultstr.="MN,";
    if($win=="P")$resultstr.="MC,";
    if($win=="B")$resultstr.="MH,";
    if($bankerPair == "1")$resultstr.="HP,";
    else $resultstr.="NO,";
    if($playerPair == "1")$resultstr.="CP";
    else $resultstr.="NO";


    $gamelist = array(      //給自動荷官的格式
        array(
            "game_time" => transTime($occurDateTime),
            "status"=>"1",
            "cardlist"=>$cardlist,
            "game_no"=>$GameNo,
            "active_game_no"=>$GameNo,
            "win"=>$win,
            "id"=>$result_id,
            "shoe_of_the_day"=>$ShoeNo ,
            "game_set"=>getDateShoes($today ,addZero($tbid ,2), addZero($ShoeNo,2)), //日期加靴號
            "win_type"=>$win_type,
            "player_pair"=>$playerPair,
            "method"=>"gameresult",
            //"table_no"=> $machineId,
            "table_no"=> $machineId,
            "banker_pair"=>$bankerPair
        )
    );
    $data_array = array(
        "method" => "gameinforesult",
        "gamelist" => $gamelist
    );

    $json = json_encode($data_array);
    

    $sql = "insert into BA (`id` , `tbid`,`btid`,`gmid`,";
    $sql.= " `bdb_id`,`bdb_gmid`,`bdb_status`,`gopen`,`gover`,";
    $sql.= " `date`,`stime`,`etime`,`result`) ";
    $sql.= " values (".$result_id." ";
    $sql.= " , '".$tbid."' ";
    $sql.= " , '".$ShoeNo."' ";
    $sql.= " , '".$GameNo."' ";
    $sql.= " , '".$result_id."' ";
    $sql.= " , '".$GameNo."' ";
    $sql.= " , '".$status."' ";
    $sql.= " , 'Y' ";
    $sql.= " , 'Y' ";
    $sql.= " , '".$today_gmt."' ";
    $sql.= " , '".$now_gmt."' ";
    $sql.= " , '".$now_gmt."' ";
    $sql.= " , '".$resultstr."' ";
    $sql.= " ); ";
    println("insert BA:".$sql);
    $dbw->insert_id($sql);
    
    if($GameNo == "1")      //開第一局，要把gid 丟進BA 裡面
    {
        $upsql = "UPDATE BA_boot set `gid`=".$result_id." ";
        $upsql.=" where `tbid`=".$tbid." ";
        $upsql.=" and `btid`=".$ShoeNo." ";
        $upsql.=" and `date`='".$today_gmt."' ";
        println("update BA_boot:".$upsql);
        $dbw->insert_id($upsql);
    }
    $cardlen = count($cardlist);
    if($cardlen == 0 )$cardenable =  "N";
    else $cardenable = "Y";
    $cardstr ="0, 0, 0, 0, 0, 0,";
    if($cardenable== "Y") {
        $cardstr = "";
        for( $i = 0; $i < $cardlen; $i++)
        {
            $cardobj = $cardlist[$i];
            $delivery = $cardobj["delivery"];
            $suit = $cardobj["suit"];
            $rank = $cardobj["rank"];
            $porknum = tranPei( $suit ,$rank );
            $porknum = substr( $porknum , strlen($porknum) - 3);
            if($i==4 && $delivery=="B"){
                $cardstr.="0,";
            } 
            $cardstr.=$porknum.",";
        }
        if($cardlen==4)$cardstr.="0,0,";
        $len = count(explode("," , $cardstr));
        if($len==6) $cardstr.="0,";
    }
    $recsql = "INSERT INTO `BA_record` (`id`, `baid`, `card1`, `card2`, `card3`, `card4`, `card5`, `card6`, `enable`) VALUES ";
    $recsql.= "(".$result_id.",".$result_id.", ".$cardstr." '".$cardenable."')";
    $dbw->insert_id($recsql, true);
    println("BA_record:".$recsql);
}
//Junket 沒有實作
//開桌 / 關桌
if($methodname=="setTableOpenClose")        //桌子的開關
{
    //$machineId = $_GET["machineId"];//Game table number(machine ID)
    $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)
    $tradingDate = $_GET["tradingDate"]; //Gaming date (YYYY-MM-DD)
    $actionId = trim($_GET["actionId"]);//1:Open 2:Close 3:TemporaryClose 4:ReOpen 5 Rollover
    if($actionId == "5")        //遇到5  下一局就是第一靴 的某一局   ex 23靴4局   ->遇到此commnd -> 1靴5局
    {
        //送給自動荷官 更新BA 及 BA_boot 的同一桌的 gmid 的 shoes
        $sqlsel = "SELECT *  FROM  `BA_boot` ";
        $sqlsel.= " WHERE  `tbid` =".$tbid." ";
        $sqlsel.= " ORDER BY `id` DESC LIMIT 0 , 1"; 
        $dbr->query($sqlsel,1);
	if($dbr->num_rows() > 0)
        {
	    $old_btid = $dbr->f("btid");
            $gid = $dbr->f("gid");
            $game_set = $dbr->f("id");
            
	    $upsql = "UPDATE BA_boot set `btid`=1 ,`date`='".$tradingDate."' ";
            $upsql.=" where `id`=".$game_set." ";
	    println("update BA_boot:".$upsql);
            $dbw->insert_id($upsql, true);

            $upsql = "UPDATE BA set `btid`=1 ";
            $upsql.=" where `tbid`=".$tbid." ";
            $upsql.=" and  `id` >=".$gid." ";
            $upsql.=" and  `btid`=".$old_btid ." ";
            println("update BA :".$upsql);
            $dbw->insert_id($upsql, true);
            //產生資料
            $data_array = array(
                "method" => "correctgameset",
                "command"=>"CorrectNewGameSet",
                "old_shoe_of_the_day"=>$old_btid  ,
                "new_shoe_of_the_day"=>1 ,
                "game_time" => transTime($occurDateTime),
                "tradingDate" => $tradingDate,
                "status"=>"1",
                "table_no"=> $machineId,
                "game_set"=> $game_set //日期加桌號加靴號
            );
            $json = json_encode($data_array);
        }
        
    }
}
//BSB 沒有實作
// if($methodname=="setBetLimit")
// {
//     //$machineId = $_GET["machineId"];//Game table number(machine ID)
//     $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)
//     $currency = $_GET["currency"]; //Currency type (PHP, HKD, USD)
//     $maxBet  = $_GET["maxBet"]; //Maximum Bet limit (25000000)
//     $miniBet = $_GET["miniBet"];//Minimum Bet limit (100000)
//     $maxSide  = $_GET["maxSide"]; //Maximum Side Bet limit (TIE, Banker-pair, Player-pair)
//     $miniSide  = $_GET["miniSide"]; //Minimum Side Bet limit (TIE, Banker-pair, Player-pair)
// }

//BSB 沒有實作
// if($methodname=="setStartTimer")
// {
//     //$machineId = $_GET["machineId"];//Game table number(machine ID)
//     $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)
//     $Timer = $_GET["Timer"]; //  Start timer value (30)....30 sec, maximum 999 sec
// }

/////junket.php?name=setStopBet&machineId=66BAC03&actionId=1&occurDateTime=2018-12-24%2004:26:04
if($methodname=="setStopBet")
{
    $today = getdate();
    $now_gmt = gmdate("Y-m-d H:i:s",mktime($today["hours"]-4,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));

    if($_GET["actionId"] == 1){
        $dbimg_w = new proc_DB(DB_IMG_HOST_W,DB_IMG_USER,DB_IMG_PWD,DB_IMG_NAME);
        $occurDateTime = $_GET["occurDateTime"];
        $now_date = gmdate("Ymd",mktime($today["hours"]-4,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
        $bdb_btid = $_GET["ti_btid"];
        $bdb_gmid = $_GET["ti_gmid"];
        $bdb_id = $_GET["ti_gid"];
        $data_array = array(
            "method" => "stopbet",
            "command"=>"StopBet",
            "game_time" => transTime($occurDateTime),
            "bdb_id"=> $bdb_id ,
            "bdb_btid"=> $bdb_btid ,
            "bdb_gmid"=> $bdb_gmid,
            "status"=>"1",
            "table_no"=> $machineId
         );
         $json = json_encode($data_array);

        //新增 BA_boot
        $picsql = "INSERT INTO `pic_".$now_date."` (`id`, `tbid`, `btid`, `gmid`, `gid`, `result`, `content`, `pic_user`, `adddate`) VALUES ";
        $picsql.= " (null, ".$machineId.", ".$bdb_btid.", ".$bdb_gmid.", ".$bdb_id.", 'stopTime', 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABALDA4MChAODQ4SERATGCgaGBYWGDEjJR0oOjM9PDkzODdASFxOQERXRTc4UG1RV19iZ2hnPk1xeXBkeFxlZ2P/2wBDARESEhgVGC8aGi9jQjhCY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2NjY2P/wAARCAAtAKADASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAf/xAAUEAEAAAAAAAAAAAAAAAAAAAAA/8QAFAEBAAAAAAAAAAAAAAAAAAAAAP/EABQRAQAAAAAAAAAAAAAAAAAAAAD/2gAMAwEAAhEDEQA/AJ+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/2Q==','ShoeBox','".$now_gmt."') ";
        println("pic:".$bootsql);
    	try {
            $dbimg_w->insert_id($picsql);
        } catch (Exception $e) {
    	        echo 'Caught exception: ',  $e->getMessage(), "\n";
    		writeRec("/home/ba566/log/",$ftime."_Junket.log",$e->getMessage()."\n",$ftime);
	    }
    }
}
///junket.php?name=setShoeResult&machineId=70BAC04&actionId=1&occurDateTime=2018-12-24%2007:07:50&data={"banker_pair":"0","cardlist":[{"delivery":"P","sno":"1","rank":"9","suit":"H","time":"2018-12-24T15:56:34.000"},{"delivery":"B","sno":"2","rank":"5","suit":"D","time":"2018-12-24T15:56:34.000"},{"delivery":"P","sno":"3","rank":"8","suit":"C","time":"2018-12-24T15:56:34.000"},{"delivery":"B","sno":"4","rank":"2","suit":"C","time":"2018-12-24T15:56:34.000"}],"game_time":"2018-12-24T15:56:34.000","player_pair":"0","game_over":true,"win":"T","win_type":"","serial_no":"0","day":"2018-12-24","status":"1"}
if($methodname=="setShoeResult")
{
    $occurDateTime = $_GET["occurDateTime"];
}


if($methodname=="setShoeChange")
{
    //$machineId = $_GET["machineId"];//Game table number(machine ID)
    $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)
    $ShoeNo = $_GET["ShoeNo"]; //Shoe number
    $game_set = getDateShoes($occurDateTime , addZero($tbid ,2) , addZero($ShoeNo,2));
    //檢查是不是有重複的gameset   
    if(!DEGUG){
        $dbr->query("select * from `BA_boot` where `id`='".$game_set."'");
        if($dbr->num_rows() > 0) {
                if($dbr->num_rows() > 0 ){
                    writeRec(FILEPATH,$ftime."_error.log","重複的gameset id".$game_set."\n",$ftime);
                        exit(0);
                }
        }
    }
    

    $data_array = array(
        "method" => "newgameset",
        "command"=>"NewGameSet",
        "shoe_of_the_day"=>$ShoeNo ,
        "game_time" => transTime($occurDateTime),
        "status"=>"1",
        "table_no"=> $machineId,
        "game_set"=>$game_set //日期加靴號
     );

    $json = json_encode($data_array);

    $datetime = transTime($occurDateTime);
    $date = $datetime;
    if(strpos($datetime, "T") > -1)
    {
        $date  = substr($datetime, 0, 10);
    }
    //新增 BA_boot
    $bootsql = "INSERT INTO `BA_boot` (`id`, `tbid`, `btid`, `gid`, `date`) VALUES ";
    $bootsql.=" (".$game_set.", ".$tbid.", ".$ShoeNo.", 0, '".$date."')";
    println("BA_boot:".$bootsql);
    $dbw->insert_id($bootsql);

}

if($json!="")
{
    $log = $json."\n";
    if(!DEGUG ){
        $Respone = javaConnnection($json."\n" , "10.10.100.50" , "200".$tbid , true );
    }
    $log.=$Respone;
    
    $time_end = microtime(true);
    $processtime = $time_end - $time_start;
    writeRec("/home/ba566/log/",$ftime."_Junket.log",$log.$processtime."ms\n\n",$ftime);
    
    $logsql = "insert into outlog (`id` , `tbid`,`value` ,`date` ,`adddate`) ";
    $logsql.= " values (null , '".$tbid."', '".base64_encode($json)."'  , '".$now_date."'  , now()); ";
    println("output log :".$logsql);
    $dbw->insert_id($logsql);
}
exit(0);


?>
