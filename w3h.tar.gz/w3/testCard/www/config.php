<?php
ignore_user_abort(true);// 2017-05-05  強制設定不中斷
date_default_timezone_set("Asia/Taipei");
$global_vars = array(
    "DB_GAME_HOST_W"    =>  "10.0.5.183",
    "DB_GAME_HOST_R"    =>  "10.0.5.184",
    "DB_GAME_NAME"	    =>	"cobaGame",
    "DB_GAME_USER"      =>	"superco_java",
    "DB_GAME_PWD"       =>	"7dFGXdfxc7",
    "DB_SHOE_HOST_W"    =>  "10.0.5.183",
    "DB_SHOE_HOST_R"    =>  "10.0.5.184",
    "DB_SHOE_NAME"	    =>	"tibaGame",
    "DB_SHOE_USER"      =>	"superco_java",
    "DB_SHOE_PWD"       =>	"7dFGXdfxc7",
    "DB_IMG_HOST_W"    =>  "10.0.5.183",
    "DB_IMG_HOST_R"    =>  "10.0.5.184",
    "DB_IMG_NAME"	    =>	"baaGameimg",
    "DB_IMG_USER"      =>	"kang_img",
    "DB_IMG_PWD"       =>	"13bDflk26xl",
    "WEB_TIME_ZONE"     =>  +8 ,
    "FILEPATH"          => "/home/ba566/log/",
    "FILE_PATH"          => "/home/ba566",
    "DEGUG"             => true 
);
date_default_timezone_set("Asia/Taipei");
 while (list($key, $value) = each($global_vars)) 
 {
    define($key, $value);
 }
 // machineId ==> tbid
 $tbmap = array(
    "6601"=>"21", 
    "6602"=>"22",    
    "6603"=>"23",     
    "6604"=>"24",   
    "6605"=>"25", 
    "6606"=>"26", 
    "6607"=>"27", 
    "6608"=>"28", 
    "6701"=>"29", 
    "6801"=>"30", 
    "6901"=>"31", 
    "5001"=>"32", 
    "5002"=>"33", 
    "5003"=>"34", 
    "5004"=>"35", 
    "5005"=>"36", 
    "5006"=>"37", 
    "5007"=>"38", 
    "5008"=>"39", 
    "5301"=>"40",
    "7001"=>"41", 
    "7002"=>"42",    
    "7003"=>"43",     
    "7004"=>"44",   
    "7301"=>"45" 
);

$dbw = new proc_DB(DB_GAME_HOST_W,DB_GAME_USER,DB_GAME_PWD,DB_GAME_NAME);
$dbr = new proc_DB(DB_GAME_HOST_R,DB_GAME_USER,DB_GAME_PWD,DB_GAME_NAME);


//不足位數補 0
function addZero($num , $len)
    {
	$n = strlen($num);
        if($n >=  $len ) return $num;
        $m = $len - $n;
        while($m-- > 0)
        {
            $num="0".$num;
        }
        return $num;
    }


// 轉換牌號
function tranPei($suit, $num) {
    $pei = 0;
    // 指定花色
    switch ($suit) {
    case "H":
        $pei = 13;
        break;
    case "D":
        $pei = 26;
        break;
    case "C":
        $pei = 39;
    default:
    }

    // 指定數字
    switch ($num) {
    case "J":
        $pei += 11;
        break;
    case "Q":
        $pei += 12;
        break;
    case "K":
        $pei += 13;
        break;
    default:
        $pei += $num*1;
    }
    $peiStr = (($pei / 10 + $pei % 10 + 9) % 10) . "009" . (($pei < 10) ? "0" : "") . $pei;
    return $peiStr;
}


/**
 * Upper one character is suit: D=Diamond, H=Hearts, C=Clubs, S=Spades 
 * Lower on character is number (hex): 0 – 9, A=10, B=Jack, C=Queen, D=King 
 * 轉格式
 */
function transPoker($sno , $str_poker , $delivery)
{
    if(empty($str_poker)) return "";
    $suit = substr( $str_poker, 0 , 1 );
    $rank = substr( $str_poker, 1 , 1 );
    if($rank=="A") $rank = "10";
    if($rank=="B") $rank = "J";
    if($rank=="C") $rank = "Q";
    if($rank=="D") $rank = "K";
    $ret = array("rank"=>$rank, "sno"=>$sno, "suit"=>$suit, "delivery"=>$delivery);
    return $ret;
}

//時間中間的空白轉成 T , 並加上毫秒 000
function transTime($times)
{
   return str_replace(" ","T",$times).".000";
}

//使用時間格式取得 獨立的 日期{年2,月2,日2,桌號2,靴號2}
function getDateShoes($occurDateTime , $tbid , $ShoeNo)
{
    $today=substr( $occurDateTime, 2 , 8 );
    $today=str_replace("-","", $today);
    return $today.$tbid.$ShoeNo;
}

//連向Server的連線
function javaConnnection($command,$ip,$port,$back=false){
    $get="";
    $fp = fsockopen($ip, $port, $errno, $errstr, 5);
    if (!$fp) {
        return "Server error";
        //echo "<script>alert('$errno:$errstr');</script>";
    } else {
        fwrite($fp, $command."\n");
        if($back){
            while (!feof($fp)) {
                $get.= fgets($fp, 256);
                if(strpos($get , "\n") > -1) break;
                //echo $get;
            }
        }
        fclose($fp);
    }
    return $get;
}

//除錯時列印資料
function println($str)
{
    if(DEGUG) 
        echo $str."\n";
}
//寫  log 記錄
function writeRec($path ,$filename , $str ,$fname)
{
    if(DEGUG) 
        echo $str."\n";
    else{
        // global $path;
        if(!is_dir($path."/".$fname)){
            @mkdir($path."/".$fname);
        }
        $fp = fopen($path.$fname."/".$filename, 'a+');
        if($fp)
        {
            $time = date("Y-m-d H:i:s");
            $str = "[".$time."]".$str;
            fwrite($fp, $str);
            fclose($fp);
        }
    }
    
}

?>
