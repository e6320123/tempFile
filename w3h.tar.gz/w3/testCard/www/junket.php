<?php

$methodname = $_GET["name"];
if($methodname=="") exit(0);
$time_start = microtime(true);


include("./mysqllib.php");
include("./config.php");

$today = getdate();
$now_gmt = gmdate("Y-m-d H:i:s",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$now_gmt_for_game_set = gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$now_date = gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$now_date_for_game_set = gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$ftime = date("Y-m-d");


//轉桌號ID
$machineId = $_GET["machineId"];
$machineId = substr($machineId,0,2).substr($machineId,-2);
$tbid = $tbmap[$machineId];

//記錄來源
$source_data = $_SERVER["REQUEST_URI"];
writeRec(FILEPATH,$machineId.".log",$source_data."\n",$ftime);


$logsql = "insert into sourcelog (`id` , `tbid`,`value` ,`date` ,`adddate`) ";
$logsql.= " values (null , '".$tbid."' , '".base64_encode($source_data)."' , '".$now_date."' , now()); ";
$dbw->insert_id($logsql);
echo "<?xml version=\"1.0\" encording=\"utf-8\"?><response name=\"".$methodname."\" result=\"0\"></response>";
//結果
if($methodname=="setBsbBaccaratPlayJournal")    //OKADA給的結果
{
    $dbw = new proc_DB(DB_GAME_HOST_W,DB_GAME_USER,DB_GAME_PWD,DB_GAME_NAME);
    $dbr = new proc_DB(DB_GAME_HOST_R,DB_GAME_USER,DB_GAME_PWD,DB_GAME_NAME);

    //$machineId = $_GET["machineId"];//Game table number(machine ID)
    $actionId = $_GET["actionId"];//Action ID ( 1:New, 2:Modify)
    $gamePlayJournalId = $_GET["gamePlayJournalId"]; // Game Journal ID (unique number)
    $result_id = $gamePlayJournalId;
    $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)

    $Year = substr( $occurDateTime, 0 , 4 );
    $Month = substr( $occurDateTime, 5 , 2);
    $Date = substr( $occurDateTime, 8 , 2);
    $HH = substr( $occurDateTime, 11 , 2);
    $MM = substr( $occurDateTime, 14 , 2);
    $SS = substr( $occurDateTime, 17 , 2);
    $occurDateTime = gmdate("Y-m-d H:i:s",mktime($HH+WEB_TIME_ZONE,$MM,$SS,$Month,$Date,$Year));

    $ShoeNo = $_GET["ShoeNo"]; //Shoe number
    $GameNo = $_GET["GameNo"]; //Game number 
    $Result = $_GET["result"]; //Game result ( 1:Banker, 2:Player, 3:Tie)
    $bankerPair = $_GET["bankerPair"];//Banker pair flag ( 0:Not occur, 1:Occur )
    $playerPair = $_GET["playerPair"];//player pair flag ( 0:Not occur, 1:Occur )
    $superSix = $_GET["superSix"];//超級六 免佣時的規則( 0:Not occur, 1:Occur )
    $bankerResultPoint = $_GET["bankerResultPoint"];//Banker result point ( 0 – 9 )
    $PlayerResultPoint = $_GET["PlayerResultPoint"];//Player result point ( 0 – 9 )
  
    $bankerCard1 = $_GET["bankerCard1"];//Banker first card suit and number (Note : #1)
    $bankerCard2 = $_GET["bankerCard2"];//Banker second card suit and number (Note : #1)
    $bankerCard3 = $_GET["bankerCard3"];//Banker third card suit and number (Note : #1)
    $playerCard1 = $_GET["playerCard1"];//Player first card suit and number (Note : #1)
    $playerCard2 = $_GET["playerCard2"];//Player second card suit and number(Note : #1)
    $playerCard3 = $_GET["playerCard3"];//Player third card suit and number(Note : #1)
    //Upper one character is suit: D=Diamond, H=Hearts, C=Clubs, S=Spades 
    //Lower on character is number (hex): 0 – 9, A=10, B=Jack, C=Queen, D=King 
    //Example: HB (jack of Hearts)
    //檢查是不是有重複的局
    if(!DEGUG){
        $dbr->query("select * from `BA` where id='".$result_id."'");
        if($dbr->num_rows() > 0 ){
            writeRec(FILEPATH,$ftime."_error.log","重複的結果id".$result_id."\n",$ftime);	
            exit(0);
        }
    }
    $status = 1;
    if($actionId == 1)      //有效資料
    {
        $cardlist = array();
        $player1 = transPoker( "1" , $playerCard1   , "P");
        if($player1 !="") $cardlist[] = $player1;
        
        $banker1 = transPoker( "2" , $bankerCard1  , "B");
        if($banker1 !="") $cardlist[] = $banker1;
        
        $player2 = transPoker( "3" , $playerCard2  , "P");
        if($player2 !="") $cardlist[] = $player2;
        
        $banker2 = transPoker( "4" , $bankerCard2  , "B");
        if($banker2 !="") $cardlist[] = $banker2;
        
        $player3 = transPoker( count($cardlist), $playerCard3  , "P");
        if($player3 !="") $cardlist[] = $player3;
        
        $banker3 = transPoker( count($cardlist) , $bankerCard3  , "B");
        if($banker3 !="") $cardlist[] = $banker3;
    }
    else
    {
        $cardlist= array();
        $status = 0;
    }
    
    $today=str_replace("-","", $now_date_for_game_set);
    $win_type = ($superSix=="0")? "" : "S6";            //S6 ：免佣6點莊贏
    if($Result == "0") $win = "B";
    if($Result == "1") $win = "P";
    if($Result == "2") $win = "T";

    $resultstr = "";
    if(count($cardlist)  <= 4) $resultstr.="UN,";
    else $resultstr.="OV,";
    if($win=="T")$resultstr.="MN,";
    if($win=="P")$resultstr.="MC,";
    if($win=="B")$resultstr.="MH,";
    if($bankerPair == "1")$resultstr.="HP,";
    else $resultstr.="NO,";
    if($playerPair == "1")$resultstr.="CP";
    else $resultstr.="NO";


    $gamelist = array(      //給自動荷官的格式
        array(
            "game_time" => transTime($occurDateTime),
            "status"=>"1",
            "cardlist"=>$cardlist,
            "game_no"=>$GameNo,
            "active_game_no"=>$GameNo,
            "win"=>$win,
            "id"=>$result_id,
            "shoe_of_the_day"=>$ShoeNo ,
            "game_set"=>getDateShoes($today ,addZero($tbid ,2), addZero($ShoeNo,2)), //日期加靴號
            "win_type"=>$win_type,
            "player_pair"=>$playerPair,
            "method"=>"gameresult",
            //"table_no"=> $machineId,
            "table_no"=> $machineId,
            "banker_pair"=>$bankerPair
        )
    );
    $data_array = array(
        "method" => "gameinforesult",
        "gamelist" => $gamelist
    );
    $json = json_encode($data_array);

    $sql = "insert into BA (`id` , `tbid`,`btid`,`gmid`,";
    $sql.= " `bdb_id`,`bdb_gmid`,`bdb_status`,`gopen`,`gover`,";
    $sql.= " `date`,`stime`,`etime`,`result`) ";
    $sql.= " values (".$result_id." ";
    $sql.= " , '".$tbid."' ";
    $sql.= " , '".$ShoeNo."' ";
    $sql.= " , '".$GameNo."' ";
    $sql.= " , '".$result_id."' ";
    $sql.= " , '".$GameNo."' ";
    $sql.= " , '".$status."' ";
    $sql.= " , 'Y' ";
    $sql.= " , 'Y' ";
    $sql.= " , '".$now_date_for_game_set."' ";
    $sql.= " , '".$now_gmt."' ";
    $sql.= " , '".$now_gmt."' ";
    $sql.= " , '".$resultstr."' ";
    $sql.= " ); ";
    println("insert BA:".$sql);
    try {
        $dbw->insert_id($sql);
    }catch(Exception $e){
        writeRec("/home/ba566/log/",$ftime."_insert_BA.log","BA 寫入錯誤 ".$e->getMessage()."\n",$ftime);
    }

    if($GameNo == "1")      //開第一局，要把gid 丟進BA 裡面
    {
        $upsql = "UPDATE BA_boot set `gid`=".$result_id." ";
        $upsql.=" where `tbid`=".$tbid." ";
        $upsql.=" and `btid`=".$ShoeNo." ";
        $upsql.=" and `date`='".$now_date_for_game_set."' ";
        println("update BA_boot:".$upsql);
        $dbw->insert_id($upsql);
    }
    $cardlen = count($cardlist);
    if($cardlen == 0 )$cardenable =  "N";
    else $cardenable = "Y";
    $cardstr ="0, 0, 0, 0, 0, 0,";
    if($cardenable== "Y") {
        $cardstr = "";
        for( $i = 0; $i < $cardlen; $i++)
        {
            $cardobj = $cardlist[$i];
            $delivery = $cardobj["delivery"];
            $suit = $cardobj["suit"];
            $rank = $cardobj["rank"];
            $porknum = tranPei( $suit ,$rank );
            $porknum = substr( $porknum , strlen($porknum) - 3);
            if($cardlen== 5 && $i==4 && $delivery=="B"){
                $cardstr.="0,";
            }
            $cardstr.=$porknum.",";
        }
        if($cardlen==4)$cardstr.="0,0,";
        $len = count(explode("," , $cardstr));
        if($len==6) $cardstr.="0,";
    }
    $recsql = "INSERT INTO `BA_record` (`id`, `baid`, `card1`, `card2`, `card3`, `card4`, `card5`, `card6`, `enable`) VALUES ";
    $recsql.= "(".$result_id.",".$result_id.", ".$cardstr." '".$cardenable."')";
    try {
        $dbw->insert_id($recsql, true);
    } catch (Exception $e) {
        writeRec("/home/ba566/log/",$ftime."_Junket.log","BA_record 寫入錯誤 ".$e->getMessage()."\n",$ftime);
    }
    println("BA_record:".$recsql);
}
//Junket 沒有實作
//開桌 / 關桌
if($methodname=="setTableOpenClose")        //桌子的開關
{
    $dbw = new proc_DB(DB_GAME_HOST_W,DB_GAME_USER,DB_GAME_PWD,DB_GAME_NAME);
    $dbr = new proc_DB(DB_GAME_HOST_R,DB_GAME_USER,DB_GAME_PWD,DB_GAME_NAME);

    //$machineId = $_GET["machineId"];//Game table number(machine ID)
    $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)

    $Year = substr( $occurDateTime, 0 , 4 );
    $Month = substr( $occurDateTime, 5 , 2);
    $Date = substr( $occurDateTime, 8 , 2);
    $HH = substr( $occurDateTime, 11 , 2);
    $MM = substr( $occurDateTime, 14 , 2);
    $SS = substr( $occurDateTime, 17 , 2);
    $occurDateTime = gmdate("Y-m-d H:i:s",mktime($HH+WEB_TIME_ZONE,$MM,$SS,$Month,$Date,$Year));

    $tradingDate = $_GET["tradingDate"]; //Gaming date (YYYY-MM-DD)
    $actionId = trim($_GET["actionId"]);//1:Open 2:Close 3:TemporaryClose 4:ReOpen 5 Rollover
    if($actionId == "5")        //特別注意：遇到5  下一局就是第一靴 的某一局   ex 23靴4局   ->遇到此commnd -> 1靴5局
    {
        $dbimg_w = new proc_DB(DB_IMG_HOST_W,DB_IMG_USER,DB_IMG_PWD,DB_IMG_NAME);
        //送給自動荷官 更新BA 及 BA_boot 的同一桌的 gmid 的 shoes
        $sqlsel = "SELECT *  FROM  `BA_boot` ";
        $sqlsel.= " WHERE  `tbid` =".$tbid." ";
        $sqlsel.= " ORDER BY `id` DESC LIMIT 0 , 1"; 
        $dbr->query($sqlsel,1);
        if($dbr->num_rows() > 0)
        {
	        $old_btid = $dbr->f("btid");
            $gid = $dbr->f("gid");
            $game_set = $dbr->f("id");
            
	        $upsql = "UPDATE BA_boot set `btid`=1 ,`date`='".$now_date_for_game_set."' ";
            $upsql.=" where `id`=".$game_set." ";
	        println("update BA_boot:".$upsql);
            $dbw->insert_id($upsql, true);

            $upsql = "UPDATE BA set `btid`=1 ";
            $upsql.=" where `tbid`=".$tbid." ";
            $upsql.=" and  `id` >=".$gid." ";
            $upsql.=" and  `btid`=".$old_btid ." ";
            println("update BA :".$upsql);
            $dbw->insert_id($upsql, true);
            //產生資料
            $data_array = array(
                "method" => "correctgameset",
                "command"=>"CorrectNewGameSet",
                "old_shoe_of_the_day"=>$old_btid  ,
                "new_shoe_of_the_day"=>1 ,
                "game_time" => transTime($now_gmt_for_game_set),
                "tradingDate" => $now_date_for_game_set,
                "status"=>"1",
                "table_no"=> $machineId,
                "game_set"=> $game_set //日期加桌號加靴號
            );
            $json = json_encode($data_array);

            $pre_date = gmdate("Ymd",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"] -1 ,$today["year"]));
            $newImgDate=str_replace("-","", $now_date_for_game_set);

            $picTableSql =  "CREATE TABLE IF NOT EXISTS `pic_".$newImgDate."` LIKE `pic`;";
            try {
                $dbimg_w->insert_id($picTableSql);
            } catch (Exception $e) {
            	writeRec("/home/ba566/log/",$ftime."_Junket.log","建立圖片table錯誤 ".$e->getMessage()."\n",$ftime);
            }

            $picsql = "INSERT IGNORE INTO `pic_".$newImgDate."` SELECT null, `tbid`, 1, `gmid`, `gid`, `result`, `content`, `pic_user`, `adddate` FROM `pic_".$pre_date."` where `tbid`=".$machineId." and `btid`=".$old_btid ." ;";
            writeRec("/home/ba566/log/",$ftime."_QuantoDebug.log","SQL!!!    ".$picsql."\n",$ftime);
            try {
                $dbimg_w->insert_id($picsql);
            } catch (Exception $e) {
            	writeRec("/home/ba566/log/",$ftime."_Junket.log","搬移圖片錯誤 ".$e->getMessage()."\n",$ftime);
            }
        }
    }
}
//BSB 沒有實作
// if($methodname=="setBetLimit")
// {
//     //$machineId = $_GET["machineId"];//Game table number(machine ID)
//     $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)
//     $currency = $_GET["currency"]; //Currency type (PHP, HKD, USD)
//     $maxBet  = $_GET["maxBet"]; //Maximum Bet limit (25000000)
//     $miniBet = $_GET["miniBet"];//Minimum Bet limit (100000)
//     $maxSide  = $_GET["maxSide"]; //Maximum Side Bet limit (TIE, Banker-pair, Player-pair)
//     $miniSide  = $_GET["miniSide"]; //Minimum Side Bet limit (TIE, Banker-pair, Player-pair)
// }

//BSB 沒有實作
// if($methodname=="setStartTimer")
// {
//     //$machineId = $_GET["machineId"];//Game table number(machine ID)
//     $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)
//     $Timer = $_GET["Timer"]; //  Start timer value (30)....30 sec, maximum 999 sec
// }

/////junket.php?name=setStopBet&machineId=66BAC03&actionId=1&occurDateTime=2018-12-24%2004:26:04
if($methodname=="setStopBet")       //靴盒   停止下注   （自動荷官會轉成487給gameserver）
{
    $dbw = new proc_DB(DB_SHOE_HOST_W,DB_SHOE_USER,DB_SHOE_PWD,DB_SHOE_NAME);
    $dbr = new proc_DB(DB_SHOE_HOST_R,DB_SHOE_USER,DB_SHOE_PWD,DB_SHOE_NAME);
    $today = getdate();
    $now_gmt = gmdate("Y-m-d H:i:s",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
    
    if($_GET["actionId"] == 1){
        $dbimg_w = new proc_DB(DB_IMG_HOST_W,DB_IMG_USER,DB_IMG_PWD,DB_IMG_NAME);
        $occurDateTime = $_GET["occurDateTime"];
        $now_date = gmdate("Ymd",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
        $bdb_btid = $_GET["ti_btid"];
        $bdb_gmid = $_GET["ti_gmid"];
        $bdb_id = $_GET["ti_gid"];
        $data_array = array(
            "method" => "stopbet",
            "command"=>"StopBet",
            "game_time" => transTime($occurDateTime),
            "bdb_id"=> $bdb_id ,
            "bdb_btid"=> $bdb_btid ,
            "bdb_gmid"=> $bdb_gmid,
            "status"=>"1",
            "table_no"=> $machineId
         );
         $json = json_encode($data_array);

        //新增 BA_boot
        //跟影像識別的 搶insert  靠  gid & result 去做unique.

        $picsql = "INSERT INTO `pic_".$now_date."` (`id`, `tbid`, `btid`, `gmid`, `gid`, `result`, `content`, `pic_user`, `adddate`) VALUES ";
        $picsql.= " (null, ".$machineId.", ".$bdb_btid.", ".$bdb_gmid.", ".$bdb_id.", 'stopTime', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAKAAAAAtCAYAAAAp4WArAAANI0lEQVR4Xu3cBYws240G4D/MzBtm5mQ3zMxRmJmZmWk3UZiZmVnZDTMzo4IbZmZ90XFyUre6u7qn5857UlkavTvddcjnt/3brnkHySyzBvZQAwfZw7XnpWcNZAbgDII91cAMwD1V/7z4DMAZA3uqgRmAe6r+efEZgDMG9lQDUwB4mCSHSPKrJH9ruz14ksMm+UP76Q9xyCR/TfLnPT3ZvPiBQgNTAPiAJPdNcqIk32ynOluSjyS5cZJnDk561SRXTHKfJD9PcvMk30/yjC1o5HRJHpzk9EleneQeSf60hXnnKfZIA8sA6Dve7KttbyftLvv6SZ6V5DxJ3tft/ShJPprkJEmOl+SE7fs7Jnn0Ds7IC18rydMHc9jHc3cw7zx0jzWwCIAHS/LhJGeZsL//bp7Io9dtgLhZkqcluUWSJyW5YJJ3Tphr7JFTNa93pSRfTnLLJKdO8vj28DWSvKyF/Q2XONAPO3qSa7ZTvDDJTw4sJ1oEQN7r2xMPAQAvSUIJn0vy6yRnT/KzJG9OcvHmDb87cb567NBJrpLkee2DRyV5eJIfNM/8P0lu3767cwP679ZcY93HnfGYST6/7sBdfl4kek/j6fb3+11eb2z6wyU5TaNmk5dfxQEf2Lic8Pv1Nitw8Y6821O6lXg9v+OAL09yrMb9Ppjk3Gt4qCMnOX+S2ya5UJIfJrlRA/NfuvUkQXdr/NTHr09yvySfmHz69R68axKgL4Nbb/TuPn2rJE9o+7v77i41OvvFkjw5yf82XEzewjIA4n9fazOdouN/12sJxbmSfKB9f9wk32l8j8f7TRLf44dT+d+Jk1yqAYoVlwjdr1hwIlYHFL3cM4kw9K3JWlj94JFaQuXJMyb59Ooh++0Jd/jWZqxXSPLa/bbyvxZ6dhJ8fG3jXAbAkyX5ypLD8HC8k5KMBOPWLft9TRszhf8Ze+a28Tt0az00CSBNlUcksV/Zd4nM/aWNN06dZ9Fz9vjx9uURW6jb6ZzbGn/sJP/fJsOXv7StiSfOsyPjXAZARN+FHjTJg9pmHtY4Ho6BkxE8TRJATt6yZvNO4X+XTfK6NhavwvFYM754jCSSoSnyyyTCs1Cg/IMmkMckucugJsmz89hCvTBu7I+7S6z11D79ELSClSv9XLt9pia6iHMeoVEQnvynSb7X1hk7izMeqlGU4m7Wtcf/aJzX+EVrjfE/hn2Ctgdj/UwpV1mXY7HuH1tUk9BU/bf2X3v2+xm6SHic7pz2Oxy3z/lXcUADAIGnk4GednCZAOdzIgTjijZe/M/niOnhk7CUoyZ5f3vWdy7oke1yccXftrGAsa7Yo9BvrEvBH3lSACNKOZdMcpskFxiZXDbveQV3IqQA3SIRhnlGRfcSXhhXvMnIIHzaGkMgFYAY8Q2S4NJoi0Swl+LWw6l7/qdme8PGn9GmEnejioC7jwmdXb0ZLOPp5f/aeaoG7LuqAy9Rzz8MYGUiOwZAvAqXKDl+Ep6PlPX7N8DgXw5GeElhjxT/G9ug+ShkkQiblL2uKFLLwseEt+MN8VeCm/K8Ojk4K2AS4BHOyeMaWBftw1krMvCqdFNFed78lc1YeWVJGJEoWKMHYQFI2co8gC+J+1ASYBBhGDG5XEu2ak89/0OBhGBntI9vJDllK1t5nmG5l88ODmSMyCMauRf6919eUBPBHtz1lVtkMryPemP64ZTcx0qvOwZAXYYpJFtRuLf0yyR5Y9tN8T+KNJdOCFeuNKNc0Gez/QF4SM9RFk+wyoVTEg9KeFkecEx0TMq7nS/Jp7q5Xbqa4k3buvbQtxFX8T86dN4ntoUZJHDXHMIVkD22fX+OBi6/9gDyu4tW5+wzecV9gEKHhhfb8z/jPXf/gYGLWm9v0aZ3Ep7npXg43vJerdD/o06BIppCPwMaK/ozbHdKNkrOxgB4tVbXu0SzFtahyOkgPIbOiE1/rHE0Ho37Xpf/jQGlXDsvxFOskgIHACnbjAmPrjZJXGIlSf2zl07yhvYBPoZGlPBsz28lJkAbCu/5pvbhmRq4h8/gZEDpWaUjOiU9gBgqb6nOORSX+8n2YenZrxW+/Vtnihcc44q6SC9oVEp3CtdEiYDr8q2RQOdjjsHdvrjNrxzWyyrjHLuPf/tsDIA6FxR9tHYYClHf4YJZBAA6qEuVMHDXY/xPmONteo60akPFuxSYHXqVoApP7WqPY8/LWn/RvhjyvHoe+QZUon/dy7ISAw+g3CNMMdxKxsb2QWcMpTeWHkB9WWs43l1IlIhLLzBW+FajNVdlw8PxZ20tUp/zqM5YuuYdRa9FSY5uGGfjjjmbXlYZ56r72+eVfGFM+KNICsUPvtC9dKBOJ8xWD1ic/8wC/je1/tdvcjf4H+/D41SZx2UJh5IhZ1sUtu1rVYmhvB/v9V8rOhB14QrFVbssANG3GtoiYy1qYk/67PhdH76r9bnownsA0gfaoWePW95uRe3wnM0Z8JbOMNU4V4LPA0MPWPyPF2SpPBgPwyMqCHv75U5JpNt4XZHRMf63bv9X600WuIlQjgx6kfBU+GqFvnqOsfkMVx2rny0LMcpTCuTCutAkBC4T5SGZsCyVV+0BJAEoCjA2R1+T5Q2VdvrwjcMtq9kWxdAtksjgdO9dU9H2702kklXGOWn6IQCL/y0bjP/JHCUIQCq0bIP/TdrwDh+iNF6bB5d08CYljE2C1MuyEFPRwvMMd5hd9vMI0aiLspMS0LsGAFpVsigeJlzSvQSnwjfvi3suS9hk2AwQteH9edsXtZ62FtoUEYar8+X5HfM/kwwB+J+N+/lOIVSmqwNw726HsiTuuy5gp/xPSFIu2KloQY0lGIvm5XEVrF2EmptzClW9LON/fa3T+GUvW6hJvq1lsS6Ot+7537LuipDJ6AFXxKm2ZIVvpR21zUWCt1VbUiKpRCRhA0S0RHlqE9kx/xsDYL+RUlBfG+u/n8r/lErwIyWGIUnuM9RNlNCP6csb9Tmrl9VKlr64YAEZvt7xkGSvCjGVkJlW12jR/MK/DgoA9aG6AGR8JQZjW7xIA6DvivpwHG9JctEkz1lCXTzHwJWgGKgSkUwXB3Wv+J9655gYK/Hknb0TMDTujfu//WLlAXmzal/V91y9koG60ru7QUoxCPxU/idTdQFjlXwWKXThcLglQZC1jghug+8QXgRZ1yMWUggvVkVtHZvKFGu7CtOItrPI5IeiA8DLA2H/XqPnysD8Gxiro1JzAE3tTYiUQA3F/uwXf1KYxnHxzmH9j4GOdSlcvmoCD9vrb1j/A/LK9Ps94OHCdp2nCvXak7ivuRnG2J9PWM+ZRAYcv3ceveNYVHoaUce+HxUA6xWrKYMqi5vK/xRHEe/+la5ah4VJAK7T6lQ+L8+il4w8F7fxzp9aFSC+o01QrUDW3Xdvan7hitWrgeGqdUkSCIAFiOryDAupOCGuRlQDAJ336N+1A1pGSoDInynYr/mdQ9IBnMIeIyhjGQKIN9PBqBqgsOuVNMkgI7RHIK463TCJ8L21am8MC5+vxIgOXtVdbn/fMmjPFQg5I9WOMii9XpWOXkS1ohwqARIa515WURjFVgEQT+h5GHIu+4X+UnBNoARAUSx5Ff+r17RYP4salhnwEHxEramq/1Xq6d831E1AgCmub+XVywxC7djfnPQvOyi/8MSKzIBNsSXDC/L5WKY4XAfIeOV6c1wSIzowkoooDPAhrXRS6/UvEFy4836M2v5k1pUgMTx3UcV0c1T4VupiHBIqd4FK8Mx+J+6Iccuw+yKzvrgOUhXWGYgMGXDpptZeFDmGBmStyrCnOLF/PrPoZYRN+J96EeVXpZ8XcEAkuS8zeKvYurhZNaspscIZYqx1xjtW6Hfgag/iQaVMl4PLKC3gmKywD8P2AFxoRPVTewVp3gOl1txQ7M9YmWOByRmt04vOgvJE3yf3PQ+uPce7DUPc8AVSgHPu83YTA7Y3jvSEh8KbGWM/gMc7Fug868UMXo0HXfRCABBq+3mJd/gCAmDzgEWFhuu7Pxhx1wBLrD/8m52VYFwEwFIQ6ywO0U82xv+KLAtDXqN34QCof+kCcaieN63c3AYPCLUsfii4mPoZLgek9uKn3nzZYKl9hghdQpP5RYghZ6wBfQLRv0DKy+N8wi++1Xu8KfuTSeOK1rX+yhcB2qQ4t4yebvThOQI8f7/IGAB7gryoPjXkfzarvIAz9dYk/Hi2PIwwz7p2S3iddUoxu7WPZfPu9Quke3HmhWuOARAPEHpYsn7ssEFtDPIuRAFY37hXaGWJRG9x3T9EOkApZ5c2U9yS992rPyDapaOtP+2UF1LXn3UesUwDe/0HRAeo25kBuH+vYxH/27+7OACtNgNw/16GrNz/4oRoaW4zCdq/J9nSajMAt6TIeZrNNDADcDO9zaO2pIEZgFtS5DzNZhqYAbiZ3uZRW9LADMAtKXKeZjMNzADcTG/zqC1pYAbglhQ5T7OZBmYAbqa3edSWNDADcEuKnKfZTAN/B4gKGVvznwDEAAAAAElFTkSuQmCC','ShoeBox','".$now_gmt."') ";
        println("pic:".$bootsql);
    	try {
            $dbimg_w->insert_id($picsql);
        } catch (Exception $e) {
    		writeRec("/home/ba566/log/",$ftime."_Junket.log","寫入圖片錯誤 ".$e->getMessage()."\n",$ftime);
	    }
    }
}
///junket.php?name=setShoeResult&machineId=70BAC04&actionId=1&occurDateTime=2018-12-24%2007:07:50&data={"banker_pair":"0","cardlist":[{"delivery":"P","sno":"1","rank":"9","suit":"H","time":"2018-12-24T15:56:34.000"},{"delivery":"B","sno":"2","rank":"5","suit":"D","time":"2018-12-24T15:56:34.000"},{"delivery":"P","sno":"3","rank":"8","suit":"C","time":"2018-12-24T15:56:34.000"},{"delivery":"B","sno":"4","rank":"2","suit":"C","time":"2018-12-24T15:56:34.000"}],"game_time":"2018-12-24T15:56:34.000","player_pair":"0","game_over":true,"win":"T","win_type":"","serial_no":"0","day":"2018-12-24","status":"1"}
if($methodname=="setShoeResult")        //靴盒   來的結果
{
    $dbw = new proc_DB(DB_SHOE_HOST_W,DB_SHOE_USER,DB_SHOE_PWD,DB_SHOE_NAME);
    $dbr = new proc_DB(DB_SHOE_HOST_R,DB_SHOE_USER,DB_SHOE_PWD,DB_SHOE_NAME);
    $today = getdate();
    $now_gmt = gmdate("Y-m-d H:i:s",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
    //限制找尋的日期 三天前
    $beforeday = 3;
    $limit_day = gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"] - $beforeday,$today["year"]));
    $occurDateTime = $_GET["occurDateTime"];
    if($_GET["actionId"] == 1){
        $status = 1;
        $ShoeNo = 0;
        $game_set = 0;
        $shoe_first_gid = 0;
        $GameNo = 0;
        $obj = json_decode($_GET["data"]);
       
        if(!DEGUG){
            //取最後一靴
            $selsql = "select * from `BA_boot` ";
            $selsql.= " where `tbid`='".$tbid."' ";
            $selsql.= " and `date` > '".$limit_day ."' ";
            $selsql.= " order by `id` desc ";
            $selsql.= " limit 0,1 ";
            $dbr->query(  $selsql ,1 );
            //tbid	btid	gid
            if($dbr->num_rows() > 0 ){
                $game_set= $dbr->f("id");
                $ShoeNo = $dbr->f("btid");
                $shoe_first_gid = $dbr->f("gid");
            }
            if($shoe_first_gid != 0){
                //取最後一靴的gmid
                $selsql = "select * from `BA` ";
                $selsql.= " where `tbid`='".$tbid."' ";
                $selsql.= " and `id` >='".$shoe_first_gid."' ";
                $selsql.= " and `date` > '".$limit_day ."' ";
                $selsql.= " order by `id` desc";
                $dbr->query($selsql,1);
                if($dbr->num_rows() > 0 ){
                    $GameNo = $dbr->f("gmid");
                }
            }else{
                $ShoeNo = 1;
            }
        }
        //test
        // $GameNo=1;
        // $game_set="1812282104";
        // $ShoeNo="4";
        // $shoe_first_gid="999998";

        //如果select 不到，就相當於換天，就換靴
        $GameNo+=1;
        $data = trim($_GET["data"]);
        if($data ==""){
            writeRec("/home/ba566/log/",$ftime."_Junket.log","data 傳入變數為空錯誤\n",$ftime);
            exit(0);
        } 

        $win = $obj->{'win'};
        $win_type = $obj->{'win_type'};
        $bankerPair= $obj->{'banker_pair'};
        $playerPair= $obj->{'player_pair'};
        $today_gmt=substr( $occurDateTime, 0 , 10 );
        $today=str_replace("-","", $today_gmt);
        $win_type = ($superSix=="0")? "" : "S6";

        $resultstr = "";
        $cardlist = $obj->{'cardlist'};
        if(count($cardlist)  <= 4) $resultstr.="UN,";
        else $resultstr.="OV,";
        if($win=="T")$resultstr.="MN,";
        if($win=="P")$resultstr.="MC,";
        if($win=="B")$resultstr.="MH,";
        if($bankerPair == "1")$resultstr.="HP,";
        else $resultstr.="NO,";
        if($playerPair == "1")$resultstr.="CP";
        else $resultstr.="NO";

        //寫入
        $sql = "insert into BA (`id` , `tbid`,`btid`,`gmid`,";
        $sql.= " `bdb_id`,`bdb_gmid`,`bdb_status`,`gopen`,`gover`,";
        $sql.= " `date`,`stime`,`etime`,`result`) ";
        $sql.= " values (null ";
        $sql.= " , '".$tbid."' ";
        $sql.= " , '".$ShoeNo."' ";
        $sql.= " , '".$GameNo."' ";
        $sql.= " , '0' ";
        $sql.= " , '".$GameNo."' ";
        $sql.= " , '".$status."' ";
        $sql.= " , 'Y' ";
        $sql.= " , 'Y' ";
        $sql.= " , '".$today_gmt."' ";
        $sql.= " , '".$now_gmt."' ";
        $sql.= " , '".$now_gmt."' ";
        $sql.= " , '".$resultstr."' ";
        $sql.= " ); ";
        println("insert BA:".$sql);
        try{
            $result_id = $dbw->insert_id($sql);
        }catch(Exception $e){
            writeRec("/home/ba566/log/",$ftime."_insert_BA_shoeBox.log","BA 寫入錯誤 ".$e->getMessage()."\n",$ftime);
        }
        //test
        //$result_id="123456789";
        //更新 BA_boot 第一局的資料
        if($GameNo == "1")
        {
            $upsql = "UPDATE BA_boot set `gid`=".$result_id." ";
            $upsql.=" where `tbid`=".$tbid." ";
            $upsql.=" and `btid`=".$ShoeNo." ";
            $upsql.=" and `date`='".$today_gmt."' ";
            println("update BA_boot:".$upsql);
            $dbw->insert_id($upsql);
        }

        $cardlen = count($obj->{'cardlist'});
        if($cardlen == 0 )$cardenable =  "N";
        else $cardenable = "Y";
        $cardstr ="0, 0, 0, 0, 0, 0,";
        if($cardenable== "Y") {
            $cardstr = "";
            for( $i = 0; $i < $cardlen; $i++)
            {
                $cardobj = $obj->{'cardlist'}[$i];//$cardlist[$i];
                //$cardobj->{'sno'}
                $delivery = $cardobj->{"delivery"};
                $suit = $cardobj->{"suit"};
                $rank = $cardobj->{"rank"};
                $porknum = tranPei( $suit ,$rank );
                $porknum = substr( $porknum , strlen($porknum) - 3);
                if($cardlen== 5 && $i==4 && $delivery=="B"){
                    $cardstr.="0,";
                } else{
                    $cardstr.=$porknum.",";
                }
                
            }
            if($cardlen==4)$cardstr.="0,0,";
            $len = count(explode("," , $cardstr));
            if($len==6) $cardstr.="0,";
        }
        $recsql = "INSERT INTO `BA_record` (`id`, `baid`, `card1`, `card2`, `card3`, `card4`, `card5`, `card6`, `enable`) VALUES ";
        $recsql.= "(".$result_id.",".$result_id.", ".$cardstr." '".$cardenable."')";
        try {
            println("BA_record:".$recsql);
            $dbw->insert_id($recsql, true);
        } catch (Exception $e) {
            writeRec("/home/ba566/log/",$ftime."_Junket.log","BA_record 寫入錯誤 ".$e->getMessage()."\n",$ftime);
        }
        
        $gamelist = array(
            array(
                "game_time" => transTime($occurDateTime),
                "status"=>"1",
                "cardlist"=>$obj->{'cardlist'},
                "game_no"=>$GameNo,
                "active_game_no"=>$GameNo,
                "win"=>$obj->{'win'},
                "id"=>$result_id,
                "shoe_of_the_day"=>$ShoeNo ,
                "game_set"=>getDateShoes($today ,addZero($tbid ,2), addZero($ShoeNo,2)), //日期加靴號
                "win_type"=>$obj->{'win_type'},
                "method"=>"gameresult",
                "table_no"=> $machineId,
                "player_pair"=>$obj->{'playerPair'},
                "banker_pair"=>$obj->{'bankerPair'}
            )
        );
        $data_array = array(
            "method" => "gameinforesult",
            "gamelist" => $gamelist
        );
        $json = json_encode($data_array);
        $json = "";
    }
}
//junket.php?name=setNewShoes&machineId=70BAC04&actionId=1&occurDateTime=2018-12-24%2007:07:50&data={"api_key":"COD_IJP_KEY","table_no":"2001","computer_name":"CDMDTGAP1SW","game_set":"646006","shoe_of_the_day":"3","game_time":"2018-03-31T02:06:33.073","status":"1"}
if($methodname=="setNewShoes")      //靴盒  換靴
{
    $dbw = new proc_DB(DB_SHOE_HOST_W,DB_SHOE_USER,DB_SHOE_PWD,DB_SHOE_NAME);
    $dbr = new proc_DB(DB_SHOE_HOST_R,DB_SHOE_USER,DB_SHOE_PWD,DB_SHOE_NAME);
    $occurDateTime = $_GET["occurDateTime"];
    $status = 1;
    $ShoeNo = 0;
    $game_set = 0;
    $shoe_first_gid = 0;
    $GameNo = 0;
    if($_GET["actionId"] == 1){
        $today = getdate();
        $now_gmt = gmdate("Y-m-d H:i:s",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
        
        $datetime = transTime($occurDateTime);
        $date = $datetime;
        if(strpos($datetime, "T") > -1)
        {
            $date  = substr($datetime, 0, 10);
        }
        //檢查是不是有重複的gameset   
        if(!DEGUG){
            //取最後一靴
            $selsql = "select * from `BA_boot` ";
            $selsql.= " where `tbid`='".$tbid."' ";
            $selsql.= " and `date` >= '".$date."' ";
            $selsql.= " order by `id` desc ";
            $selsql.= " limit 0,1 ";
            $dbr->query(  $selsql ,1 );
            //tbid	btid	gid
            if($dbr->num_rows() > 0 ){
                $game_set= $dbr->f("id");
                $ShoeNo = $dbr->f("btid");
                $shoe_first_gid = $dbr->f("gid");
            }
            $ShoeNo++; 
        }
        
        
        $game_set = getDateShoes($occurDateTime , addZero($tbid ,2) , addZero($ShoeNo,2));

        $data_array = array(
            "method" => "newgameset",
            "command"=>"NewGameSet",
            "shoe_of_the_day"=>$ShoeNo ,
            "game_time" => transTime($occurDateTime),
            "status"=>$status,
            "table_no"=> $machineId,
            "game_set"=>$game_set //日期加靴號
        );
        $json = json_encode($data_array);
        $json = "";
        //新增 BA_boot
        $bootsql = "INSERT INTO `BA_boot` (`id`, `tbid`, `btid`, `gid`, `date`) VALUES ";
        $bootsql.=" (".$game_set.", ".$tbid.", ".$ShoeNo.", 0, '".$date."')";
        println("BA_boot:".$bootsql);
        try{
            $dbw->insert_id($bootsql);
        }catch(Exception $e){
            writeRec("/home/ba566/log/",$ftime."_insert_BAboot_shoeBox.log","BA boot 寫入錯誤 ".$e->getMessage()."\n",$ftime);
        }
    }
}


if($methodname=="setShoeChange")        //BSB  換靴code
{
    $dbw = new proc_DB(DB_GAME_HOST_W,DB_GAME_USER,DB_GAME_PWD,DB_GAME_NAME);
    $dbr = new proc_DB(DB_GAME_HOST_R,DB_GAME_USER,DB_GAME_PWD,DB_GAME_NAME);

    //$machineId = $_GET["machineId"];//Game table number(machine ID)
    $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)

    $Year = substr( $occurDateTime, 0 , 4 );
    $Month = substr( $occurDateTime, 5 , 2);
    $Date = substr( $occurDateTime, 8 , 2);
    $HH = substr( $occurDateTime, 11 , 2);
    $MM = substr( $occurDateTime, 14 , 2);
    $SS = substr( $occurDateTime, 17 , 2);
    $occurDateTime = gmdate("Y-m-d H:i:s",mktime($HH+WEB_TIME_ZONE,$MM,$SS,$Month,$Date,$Year));

    $ShoeNo = $_GET["ShoeNo"]; //Shoe number
    $today_game_set=str_replace("-","", $now_date_for_game_set);
    $game_set = getDateShoes($today_game_set , addZero($tbid ,2) , addZero($ShoeNo,2));              //自己編的
    //檢查是不是有重複的gameset   
    if(!DEGUG){
        $dbr->query("select * from `BA_boot` where `id`='".$game_set."'");
        if($dbr->num_rows() > 0) {
            if($dbr->num_rows() > 0 ){
                writeRec(FILEPATH,$ftime."_error.log","重複的gameset id".$game_set."\n",$ftime);
                exit(0);
            }
        }
    }
    $data_array = array(
        "method" => "newgameset",
        "command"=>"NewGameSet",
        "shoe_of_the_day"=>$ShoeNo ,
        "game_time" => transTime($now_gmt_for_game_set),
        "status"=>"1",
        "table_no"=> $machineId,
        "game_set"=>$game_set //日期加靴號
     );

    $json = json_encode($data_array);

    $datetime = transTime($now_date_for_game_set);
    $date = $datetime;
    if(strpos($datetime, "T") > -1)
    {
        $date  = substr($datetime, 0, 10);
    }
    //新增 BA_boot
    $bootsql = "INSERT INTO `BA_boot` (`id`, `tbid`, `btid`, `gid`, `date`) VALUES ";
    $bootsql.=" (".$game_set.", ".$tbid.", ".$ShoeNo.", 0, '".$date."')";
    println("BA_boot:".$bootsql);
    try{
        $dbw->insert_id($bootsql);
    }catch(Exception $e){
        writeRec("/home/ba566/log/",$ftime."_insert_BAboot_bsb.log","BA boot 寫入錯誤 ".$e->getMessage()."\n",$ftime);
    }
}

if($json!="")
{
    $log = $json."\n";
    if(!DEGUG ){
        $Respone = javaConnnection($json."\n" , "10.10.100.50" , "200".$tbid , true );      //傳送到 autodealer，會根據port轉到正確的ip，在杜拜
    }
    $log.=$Respone;
    
    $time_end = microtime(true);
    $processtime = $time_end - $time_start;
    writeRec("/home/ba566/log/",$ftime."_Junket.log",$log.$processtime."ms\n\n",$ftime);
    
    $logsql = "insert into outlog (`id` , `tbid`,`value` ,`date` ,`adddate`) ";
    $logsql.= " values (null , '".$tbid."', '".base64_encode($json)."'  , '".$now_date."'  , now()); ";
    println("output log :".$logsql);
    $dbw->insert_id($logsql);
}
exit(0);


?>
