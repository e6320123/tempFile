<?php

$methodname = $_GET["name"];
if($methodname=="") exit(0);
$time_start = microtime(true);


include("./mysqllib.php");
include("./config.php");

$today = getdate();
$now_gmt = gmdate("Y-m-d H:i:s",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$now_gmt_for_game_set = gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$now_date = gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$now_date_for_game_set = gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$ftime = date("Y-m-d");

//結果
if($methodname=="setBsbBaccaratPlayJournal")    //OKADA給的結果
{
    $actionId = $_GET["actionId"];//Action ID ( 1:New, 2:Modify)
    $gamePlayJournalId = $_GET["gamePlayJournalId"]; // Game Journal ID (unique number)
    $result_id = $gamePlayJournalId;
    $occurDateTime = $_GET["occurDateTime"]; //Occurred datetime on a game table.(YYYY-MM-DD hh:mm:ss)
    $ShoeNo = $_GET["ShoeNo"]; //Shoe number
    $GameNo = $_GET["GameNo"]; //Game number 
    $Result = $_GET["result"]; //Game result ( 1:Banker, 2:Player, 3:Tie)
    $bankerPair = $_GET["bankerPair"];//Banker pair flag ( 0:Not occur, 1:Occur )
    $playerPair = $_GET["playerPair"];//player pair flag ( 0:Not occur, 1:Occur )
    $superSix = $_GET["superSix"];//超級六 免佣時的規則( 0:Not occur, 1:Occur )
    $bankerResultPoint = $_GET["bankerResultPoint"];//Banker result point ( 0 – 9 )
    $PlayerResultPoint = $_GET["PlayerResultPoint"];//Player result point ( 0 – 9 )
  
    $bankerCard1 = $_GET["bankerCard1"];//Banker first card suit and number (Note : #1)
    $bankerCard2 = $_GET["bankerCard2"];//Banker second card suit and number (Note : #1)
    $bankerCard3 = $_GET["bankerCard3"];//Banker third card suit and number (Note : #1)
    $playerCard1 = $_GET["playerCard1"];//Player first card suit and number (Note : #1)
    $playerCard2 = $_GET["playerCard2"];//Player second card suit and number(Note : #1)
    $playerCard3 = $_GET["playerCard3"];//Player third card suit and number(Note : #1)

    $status = 1;
    if($actionId == 1)      //有效資料
    {
        $cardlist = array();
        $player1 = transPoker( "1" , $playerCard1   , "P");
        if($player1 !="") $cardlist[] = $player1;
        
        $banker1 = transPoker( "2" , $bankerCard1  , "B");
        if($banker1 !="") $cardlist[] = $banker1;
        
        $player2 = transPoker( "3" , $playerCard2  , "P");
        if($player2 !="") $cardlist[] = $player2;
        
        $banker2 = transPoker( "4" , $bankerCard2  , "B");
        if($banker2 !="") $cardlist[] = $banker2;
        
        $player3 = transPoker( count($cardlist), $playerCard3  , "P");
        if($player3 !="") $cardlist[] = $player3;
        
        $banker3 = transPoker( count($cardlist) , $bankerCard3  , "B");
        if($banker3 !="") $cardlist[] = $banker3;
    }
    else
    {
        $cardlist= array();
        $status = 0;
    }
    
    $win_type = ($superSix=="0")? "" : "S6";            //S6 ：免佣6點莊贏
    if($Result == "0") $win = "B";
    if($Result == "1") $win = "P";
    if($Result == "2") $win = "T";

    $resultstr = "";
    if(count($cardlist)  <= 4) $resultstr.="UN,";
    else $resultstr.="OV,";
    if($win=="T")$resultstr.="MN,";
    if($win=="P")$resultstr.="MC,";
    if($win=="B")$resultstr.="MH,";
    if($bankerPair == "1")$resultstr.="HP,";
    else $resultstr.="NO,";
    if($playerPair == "1")$resultstr.="CP";
    else $resultstr.="NO";


    $cardlen = count($cardlist);
    if($cardlen == 0 )$cardenable =  "N";
    else $cardenable = "Y";
    $cardstr ="0, 0, 0, 0, 0, 0,";
    if($cardenable== "Y") {
        $cardstr = "";
        for( $i = 0; $i < $cardlen; $i++)
        {
            $cardobj = $cardlist[$i];
            $delivery = $cardobj["delivery"];
            $suit = $cardobj["suit"];
            $rank = $cardobj["rank"];
            $porknum = tranPei( $suit ,$rank );
            $porknum = substr( $porknum , strlen($porknum) - 3);
            if($cardlen== 5 && $i==4 && $delivery=="B"){
                $cardstr.="0,";
            }
            $cardstr.=$porknum.",";
        }
        if($cardlen==4)$cardstr.="0,0,";
        $len = count(explode("," , $cardstr));
        if($len==6) $cardstr.="0,";
    }
    $recsql = "INSERT INTO `BA_record` (`id`, `baid`, `card1`, `card2`, `card3`, `card4`, `card5`, `card6`, `enable`) VALUES ";
    $recsql.= "(".$result_id.",".$result_id.", ".$cardstr." '".$cardenable."')";
    echo $recsql;
}
exit(0);


?>
