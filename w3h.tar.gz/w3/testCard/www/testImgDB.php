<?php

$methodname = $_GET["name"];
if($methodname=="") exit(0);
$time_start = microtime(true);


include("./mysqllib.php");
include("./config.php");

$today = getdate();
$now_gmt = gmdate("Y-m-d H:i:s",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$now_gmt_for_game_set = gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$now_date = gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$now_date_for_game_set = gmdate("Y-m-d",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
$ftime = date("Y-m-d");

$old_date = $_GET["oldDate"];

if($old_date != $now_date_for_game_set){
                $old_date_for_check=str_replace("-","", $old_date);
                for($minusDay = 1;;$minusDay ++){
                    $pre_date = gmdate("Ymd",mktime($today["hours"]+WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"] -$minusDay ,$today["year"]));
                    if($old_date_for_check *1 <= $pre_date *1){
                        $newImgDate=str_replace("-","", $now_date_for_game_set);
                        $picTableSql =  "CREATE TABLE IF NOT EXISTS `pic_".$newImgDate."` LIKE `pic`;";
                        
                        $picsql = "INSERT IGNORE INTO `pic_".$newImgDate."` SELECT null, `tbid`, 1, `gmid`, `gid`, `result`, `content`, `pic_user`, `adddate` FROM `pic_".$pre_date."` where `tbid`=".$machineId." and `btid`=".$old_btid ." ;";
                	echo $picsql."<br>";    
		}else{
                        break;
                    }
                }
            }

exit(0);
?>
