
<?php
    set_time_limit(600);
    define("FILE_PATH", substr($_SERVER['DOCUMENT_ROOT'],0,strlen($_SERVER['DOCUMENT_ROOT'])-3));
    define("WEB_TIME_ZONE", -4);
    $today=getdate();
	if(!is_dir(FILE_PATH."/log/test_log")){mkdir(FILE_PATH."/log/test_log",0777);}
	$dir_date=FILE_PATH."/log/test_log/".gmdate("Y-m-d",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
	$file_date=gmdate("H",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]));
	if(!is_dir($dir_date)){mkdir($dir_date,0777);}
	$file_log=fopen($dir_date."/test_log.".$file_date.".log","a");
	fwrite($file_log,gmdate("i:s",mktime($today[hours]+WEB_TIME_ZONE,$today[minutes],$today[seconds],$today[mon],$today[mday],$today[year]))."\t".$_SERVER['REMOTE_ADDR']."\t$user"."\t".$_SERVER['HTTP_USER_AGENT']."\t".$_SERVER['HTTP_ACCEPT_LANGUAGE']."\t".$MEM_DATA['username']." - ".$str_re."\n");
	
	
	
	
	$startTime = mktime();
	fwrite($file_log,"[START : ".$startTime."]\n");


	for($i = 0;;$i++){
		$now = mktime();
		if($now*1 - $startTime*1 > 50){
			break;
		}
		sleep(1);
	}
	fwrite($file_log,"[END : ".$now."]\n");
    fclose($file_log);
    

    echo "REPORT FINISH";
exit;

?>