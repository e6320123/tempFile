<?php
include "../../conf/conf_ctl.php";
include "../../lib/pub_card_library.php";

// =======================================參數======================================================
//DB連線物件
$DB_MAIN = $UTIL->getDB("DB_HOST_R", "DB_USER_R", "DB_PWD_R", "DB_NAME");
$DB_MAIN_W = $UTIL->getDB("DB_HOST", "DB_USER", "DB_PWD", "DB_NAME");
//時間
$today = getdate();
$date = gmdate("Y-m-d", mktime($today["hours"] + $global_vars["WEB_TIME_ZONE"], $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
$cardDate = $UTIL->getYearMonth($date);
//亂數
$rand = rand(1, 10000);
//目前單位
$unit = 10000;
//群組下會員
// $midAry = $UTIL->getGroupMid();
// =======================================功能區======================================================
if ($action == "") {
    include "../../tpl/alert_reconnect.html";
}
exit;
