<?php
include "../../conf/conf_ctl.php";
$PRI_TYPE = "B00";
include "../../conf/pri_ctl.php"; //驗證頁面權限

// =======================================參數======================================================
//DB連線物件
$DB_MAIN = $UTIL->getDB("DB_HOST_R", "DB_USER_R", "DB_PWD_R", "DB_NAME");
$DB_MAIN_W = $UTIL->getDB("DB_HOST", "DB_USER", "DB_PWD", "DB_NAME");
//時間
$today = getdate();
$date = gmdate("Y-m-d", mktime($today["hours"] + $global_vars["WEB_TIME_ZONE"], $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
$cardDate = $UTIL->getYearMonth($date);
//亂數
$rand = rand(1, 10000);
//目前單位
$unit = 10000;
//群組下會員
// $midAry = $UTIL->getGroupMid();
// =======================================功能區======================================================
if ($action == "") {
    include "../../tpl/choice_table.html";
} else if ($action == "getOnload") {
    $dataAry = array();
    //控端哪一群組
    $DB_MAIN->query("SELECT `pri_id` FROM `team_pri_user` WHERE `usertype` = 'cm' AND `userid` = " . $MEM_DATA["id"] . " ;");
    while ($DB_MAIN->next_record()) {
        $group = $DB_MAIN->f("pri_id");
    }
    //群組開放桌次
    $DB_MAIN->query("SELECT `pri_value` FROM `team_pri_set` WHERE `pri_id` = " . $group . " AND `pri_type` = 'table' ;");
    while ($DB_MAIN->next_record()) {
        $dataAry[$DB_MAIN->f("pri_value")] = array(
            "tbid" => $DB_MAIN->f("pri_value"),
            "enable" => "Y",
        );
    }
    //繞出所有桌次
    $sql = "SELECT * FROM `BA_lobby` WHERE `tbid` != 0 ;";
    $DB_MAIN->query($sql);
    while ($DB_MAIN->next_record()) {
        if (is_null($dataAry[$DB_MAIN->f("tbid")])) {
            $dataAry[$DB_MAIN->f("tbid")] = array(
                "tbid" => $DB_MAIN->f("tbid"),
                "enable" => "N",
            );
        }
        $dataAry[$DB_MAIN->f("tbid")]["name"] = $DB_MAIN->f("name_e");
    }

    $out = array();
    $out["data"] = $UTIL->multi_array_sort($dataAry, "tbid", SORT_REGULAR, SORT_ASC);
    $out["msg"] = "success";
    echo json_encode($out);
}
// =======================================關閉======================================================
$DB_MAIN->close();
$DB_MAIN_W->close();
exit;
