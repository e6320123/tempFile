<?php

$rand = rand(1, 10000);
include "../../tpl/content.html";
exit;
