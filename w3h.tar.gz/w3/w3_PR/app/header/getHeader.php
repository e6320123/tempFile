<?php
include "../../conf/conf_ctl.php";
include "../../lib/pub_card_library.php";

//DB連線物件
$DB_MAIN = $UTIL->getDB("DB_HOST_R", "DB_USER_R", "DB_PWD_R", "DB_NAME");
$DB_MAIN_W = $UTIL->getDB("DB_HOST", "DB_USER", "DB_PWD", "DB_NAME");

if ($action == "getOnload") { //初始資料
    //群組
    $pri_id = 0;
    $sql = "SELECT `pri_id` ";
    $sql .= "FROM `team_pri_user` ";
    $sql .= "WHERE `usertype` = 'cm' ";
    $sql .= "AND `userid` = " . $MEM_DATA["id"] . " ;";
    $DB_MAIN->query($sql);
    while ($DB_MAIN->next_record()) {
        $pri_id = $DB_MAIN->f("pri_id");
    }
    //同群組操盤帳號
    $useridAry = array();
    $sql = "SELECT `userid` ";
    $sql .= "FROM `team_pri_user` ";
    $sql .= "WHERE `pri_id` = '" . $pri_id . "' ";
    $sql .= "AND  `usertype` = 'cm' ;";
    $DB_MAIN->query($sql);
    while ($DB_MAIN->next_record()) {
        $useridAry[] = $DB_MAIN->f("userid");
    }

    //資料
    $dataAry = array();
    $sql = "SELECT `username` FROM `admin` WHERE (`type` LIKE '%10%' OR `type` LIKE '%11%') AND `id` IN ('" . implode("','", $useridAry) . "') ORDER BY `username`";
    $DB_MAIN->query($sql);
    if ($DB_MAIN->num_rows() > 0) {
        while ($DB_MAIN->next_record()) {
            $dataAry[] = $DB_MAIN->f("username");
        }
    }

    $out["msg"] = "success";
    $out["data"] = $dataAry;
    echo json_encode($out);
} else if ($action == "chgUser") { //變更使用者
    //1.檢查newPR底下是否有未關閉會員 如果有則回錯誤
    //2.將oldPR底下卡號轉移至newPR底下
    //(1)usecash卡片使用的operator要修改
    //(2)cardrecord卡片異動紀錄  opertype: H=交接

    //資料
    $dataAry = array();
    $dataAry["newPR"] = $newPR;
    $dataAry["oldPR"] = $oldPR;

    $setAry = array();
    $setAry["operator"] = $newPR;
    $checkAry = getSeatCard($setAry);

    if (COUNT($checkAry) > 0) {
        $out["msg"] = "str_header_chage_to_manay_members";
        $out["data"] = $dataAry;
        echo json_encode($out);
        return;
    }

    $setAry = array();
    $setAry["operator"] = $oldPR;
    $checkAry = getSeatCard($setAry);

    foreach ($checkAry as $key => $data) {
        $usecashid = $data["usecashid"];
        $mid = $data["mid"];
        $cardno_id = $data["id"];
        $sql = "UPDATE `usecash` SET `operator` = '" . $newPR . "' WHERE `id` = " . $usecashid . " ;";
        $sql .= "INSERT INTO `cardrecord` (`cardno_id` ,`mid` ,`opertype` ,`value` ,`operator` ,`adddate`) VALUES (";
        $sql .= "'" . $cardno_id . "', '" . $mid . "', 'H', '" . json_encode($dataAry) . "', '" . $newPR . "', NOW());";
        $DB_MAIN_W->muti_query($sql);
    }

    $LOGIN_DATA = $LOGIN_OBJ->loginx($uid, $langx, $newPR, "password", "Y");
    //判斷登入是否發生錯誤
    if ($LOGIN_DATA["LOGIN"] == "ERROR") {
        echo $LOGIN_DATA["DATA"];
        exit;
    }

    $out["msg"] = "success";
    $out["data"]["oldPR"] = $oldPR;
    $out["data"]["newPR"] = $newPR;
    $out["data"]["username"] = $LOGIN_DATA["login_username"];
    $out["data"]["uid"] = $LOGIN_DATA["uid"];
    $out["data"]["id"] = $LOGIN_DATA["login_id"];
    $out["data"]["PRI_DATA"] = $LOGIN_DATA["permission"];
    echo json_encode($out);
}
exit;
