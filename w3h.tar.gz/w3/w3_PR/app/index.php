<?php
include "../conf/conf_ctl.php";

$langx = $langx;
$username = $MEM_DATA["username"];
$uid = $uid;
$id = $MEM_DATA["id"];
$logintype = $logintype;
$ip = $_SERVER["REMOTE_ADDR"];
$station = "TC";
$PRI_DATA = $MEM_DATA["permission"];

$rand = rand(1, 10000);
include "../tpl/index.html";
