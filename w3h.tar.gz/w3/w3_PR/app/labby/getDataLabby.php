<?php
include "../../conf/conf_ctl.php";
//$PRI_TYPE = "B00";
//include "../../conf/pri_ctl.php"; //驗證頁面權限

$action = $action;
$uid = $uid;
$username = $username;
$tbid = $tbid;

// =======================================參數======================================================
//DB連線物件
$DB_MAIN = $UTIL->getDB("DB_HOST_R", "DB_USER_R", "DB_PWD_R", "DB_NAME");
$DB_MAIN_W = $UTIL->getDB("DB_HOST", "DB_USER", "DB_PWD", "DB_NAME");
$today = getdate();
$today_gmt = gmdate("Y-m-d", mktime($today["hours"] + $WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
$now_gmt = gmdate("H:i:s", mktime($today["hours"] + $WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
$out["msg"] = "fail";
if($action == "getIp"){	//取得IP
    $portdata = Array();
    $sql = "SELECT * FROM BA_lobby WHERE name_c ='".$tbid."'  and server_no='1' and tbid>0 ;";
    $DB_MAIN->query($sql);
    if ($DB_MAIN->next_record()) {
        $portdata["tbname"] = $DB_MAIN->f("name_c");
        $portdata["tbid"] = $DB_MAIN->f("tbid");
        $ip=$DB_MAIN->f("ip");
        $portdata["debug1"] = $ip;
        $portdata["debug2"] = is_ip($ip);
        $portdata["debug3"] = DOMAIN_NAME;
        if (!is_ip($ip) ||is_ip($ip) == 0) {
            $ip.=DOMAIN_NAME;
        }
        $portdata["ip"] = $ip;
        $portdata["port"] = $DB_MAIN->f("port");
        $portdata["ssl_port"] = $DB_MAIN->f("ssl_port");
        $portdata["s_server_port"] = BA_LObbY_S_PORT;       //從mem抓來的code
        $portdata["server_port"] = BA_LObbY_PORT;
        $out["serverInfos"] = $portdata;
        $out["msg"] = "success";
    }
}else if($action == "getPlayerNum_OneTable"){
    // DB內的 php_ip 跟server_port是讓PHP 連結game server用的
    // $dbr->query("select php_ip,server_port from ".$game_type."_lobby where tbid=".$tbid." and lobby_type='".$lobby_type."';",1);
	// $ip=$dbr->f("php_ip");
    // $server_port=$dbr->f("server_port");
    
    // 連結 Lobby server 要從confing取得
    $phpToLobbyIp = BA_LObbY_IP;
    $phpToLobbyPort = BA_LObbY_PORT;
    $command="711,getTableCount,".$tbid;
    //712,getTableCount,桌號,全部Server_no人數
    $back=javaConnnection($command,$phpToLobbyIp,$phpToLobbyPort,true);
    $back=explode(",",substr($back,0,-1));
    if($back[0] == "712"){
        $result["tbid"] = $back[2];
        $result["num"] = $back[3];
        $out["result"] = $result;
        $out["msg"] = "success";
    }
}else if($action == "getPlayerNum_AllTable"){
    $phpToLobbyIp = BA_LObbY_IP;
    $phpToLobbyPort = BA_LObbY_PORT;
    $command="713,getTableAllCount";
    $back=javaConnnection($command,$phpToLobbyIp,$phpToLobbyPort,true);
    //714,getTableAllCount,桌號|人數@桌號|人數@....
    $totalResult = Array();
    $back=explode(",",substr($back,0,-1));
    if($back[0] == "714"){
        $allTbInfos = $back[2];
        $TbAry=explode("@",substr($allTbInfos,0,-1));
        for($j=0;$j<count($TbAry);$j++){
            $eachTb = $TbAry[$j];
            $eachTbAry=explode("|",substr($eachTb,0,-1));
            $result["tbid"] = $eachTbAry[0];
            $result["num"] = $eachTbAry[1];
            array_push($totalResult,$result);
        }
        $out["result"] = $totalResult;
        $out["msg"] = "success";
    }
}else if($action == "retime"){
    $USER_IP=$_SERVER['REMOTE_ADDR'];
    $starttime = $starttime;
	$endTime = $endTime;
	$during = $during;
	$type = $type;
	$table_name = "ctl_ring_record";
	$startDate = date("Y-m-d H:i:s",$starttime);
	$endDate = date("Y-m-d H:i:s",$endTime);
	$today = $today_gmt . " " . $now_gmt;
	$sql = "insert into " . $table_name . " (username,action,start_time,during_time,tbid,adddate,ip)";
	$sql .= "values ('".$MEM_DATA['username']."','".$type."','".$startDate."','".$during."','".$tableNo."','".$today."','".$USER_IP."')";
	$DB_MAIN_W->query($sql);
    $out["result"] = "OK";
    $out["msg"] = "success";
}
echo json_encode($out);

function javaConnnection($command,$ip,$port,$back=false){
	//echo "<script>alert('".$command."');</script>";
	if (CASINO == "SI") {return "";}
	$get="";
	$fp =fsockopen($ip, $port, $errno, $errstr, 5);
	if (!$fp) {
		//echo "<script>alert('server error');</script>";
	} else {
		fwrite($fp, $command."\n");
		if($back){
			while (!feof($fp)) {
				$get.= fgets($fp, 128);
			}
     		}
		fclose($fp);
 	}
	return $get;
}

function is_ip($gonten) {
	$ip = explode(".",$gonten);
	for ($i=0;$i<count($ip);$i++)
	{
		if ($ip[$i]*1>255) {
			return false;
		}
	}
	return preg_match("/^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/",$gonten);
}
