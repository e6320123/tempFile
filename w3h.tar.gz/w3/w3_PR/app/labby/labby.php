<?php
include "../../conf/conf_ctl.php";

$rand = rand(1, 10000);
include "../../tpl/vip_table.html";
exit;
