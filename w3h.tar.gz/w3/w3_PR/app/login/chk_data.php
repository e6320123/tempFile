<?php
$NOT_LOGIN = "Y";
include "../../conf/conf_ctl.php";

//====== 宣告變數
$langx = $langx; // 語系
$username = $username; // 登入帳號
$password = $password; // 登入密碼

//開始登入動作
$LOGIN_DATA = $LOGIN_OBJ->loginx($uid, $langx, $username, $password, "N");

//判斷登入是否發生錯誤
if ($LOGIN_DATA["LOGIN"] == "ERROR") {
    echo $LOGIN_DATA["DATA"];
    exit;
}

$uid = $LOGIN_DATA["uid"];
$logintype = $LOGIN_DATA["login_type"];
$id = $LOGIN_DATA["login_id"];
$username = $LOGIN_DATA["login_username"];

$aPath = "/w3_PR/app/index.php";
$parame = "?uid=" . $uid . "&langx=" . $langx . "&logintype=" . $logintype;

echo "<script>self.location.href = '" . BROWSER_IP . $aPath . $parame . "';</script>";
exit;
