<?php
$NOT_LOGIN = "Y";
include "../../conf/conf_ctl.php";

if ($langx == null || $langx == "") {
    $langx = "zh-cn";
}

$rand = rand(1, 10000);
include "../../tpl/login.html";
exit;
