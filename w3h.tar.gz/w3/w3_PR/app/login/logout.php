<?php
$uid = $uid;
$langx = $langx;
$active = $active;
$NOT_LOGIN = "Y";
include "../../conf/conf_ctl.php";
include "../../conf/" . $langx . "_ctl.php";

if ($active == "blance") {
    $msg = "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
    $msg .= "<script language=javascript>\n";
    $msg .= "alert('" . $LVar["ERROR_LOGOUT"] . "');\n";
    $msg .= "top.logout='Y';\n";
    $msg .= "top.location.href='" . BROWSER_IP_PR . "/';\n";
    $msg .= "</script>\n";
    echo $msg;
    exit;
} else if ($active == "pri_error") {
    $msg = "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
    $msg .= "<script language=javascript>\n";
    $msg .= "alert('" . $LVar["ERROR_PRI_LOGOUT"] . "');\n";
    $msg .= "top.logout='Y';\n";
    $msg .= "top.location.href='" . BROWSER_IP_PR . "/';\n";
    $msg .= "</script>\n";
    echo $msg;
    exit;
} else {
    $DB_MAIN_W = $UTIL->getDB("DB_HOST", "DB_USER", "DB_PWD", "DB_NAME");
    $DB_MAIN_W->query("DELETE FROM `login_admin` WHERE `uid` = '" . $uid . "';");
    $DB_MAIN_W->close();
    $msg = "<script language=javascript>\n";
    $msg .= "top.logout='Y';\n";
    $msg .= "top.location.href='" . BROWSER_IP_PR . "/';\n";
    $msg .= "</script>\n";
    echo $msg;
    exit;
}
