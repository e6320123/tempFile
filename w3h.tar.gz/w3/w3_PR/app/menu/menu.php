<?php

$rand = rand(1, 10000);
include "../../tpl/menu.html";
exit;
