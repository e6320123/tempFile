<?php
//開始------定義程式公用參數------
include substr($_SERVER['DOCUMENT_ROOT'], 0, strlen($_SERVER['DOCUMENT_ROOT']) - 3) . "/config/pub_config_ctl.php";
//結束------定義程式公用參數------

if ($langx == "") {
    $langx = "zh-cn";
}

//開始------加入共用含括檔------
include WEB_PATH . "/w3_PR/conf/" . $langx . "_ctl.php";
include WEB_PATH . "/w3_PR/lib/class.pub_library.php";
include WEB_PATH . "/w3_PR/lib/class.login_method.php";
include WEB_PATH . "/w3_PR/lib/class.mysqllib_new.php";
//結束------加入共用含括檔------

//開始------定義基本工具------
$UTIL = new pub_library($global_vars);
$LOGIN_OBJ = new login_method($global_vars);
//結束------定義基本工具------

//開始------定義程式傳入參數------
foreach ($_REQUEST as $key => $value) {
    if (!is_array($value)) {
        $$key = $UTIL->defend_SQL_injection($value);
        $_POST[$key] = $$key;
    }
}
//結束------定義程式傳入參數------

ignore_user_abort(true); //不管client有沒斷線,php一定會執行到完

//開始------操盤者登入------
//產生獨立uid
if ($uid == "") {
    $uid = $LOGIN_OBJ->get_userid($uid);
}

$tmp_path = end(explode("/", dirname($PHP_SELF)));

//判斷目前是否為靜態網頁,是否需進行登入動作
if ($NOT_LOGIN == "Y") {
    $web_type = "S";
} else if ($tmp_path != "control" || $type == "first_login") {
    $MEM_DATA = $LOGIN_OBJ->check_login($logintype, $uid, $langx);
    //是否有傳回操盤者資料
    if ($MEM_DATA == null) {
        exit;
    }
    $web_type = "D";
} else { //靜態網頁不做登入動作
    $web_type = "S";
    switch (basename($PHP_SELF)) {
        case "newlogin.php":
        default:
            $MEM_DATA = $LOGIN_OBJ->check_login($logintype, $uid, $langx);
            if ($MEM_DATA == null) {
                exit;
            }

            break;
    }
}
//判斷登入是否發生錯誤
if ($MEM_DATA[0] == "ERROR") {
    $go_page = BROWSER_IP . "/w3_PR/app/login/logout.php?langx=" . $langx . "&active=blance";
    echo "<script>top.logout='Y';window.open('" . $go_page . "','_self')</script>";
    exit;
}

//結束------操盤者登入與語系處理------
