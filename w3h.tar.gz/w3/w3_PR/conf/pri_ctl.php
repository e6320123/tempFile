<?php
//檢查權限
if ($PRI_TYPE != null) {
    if ($MEM_DATA["permission"][$PRI_TYPE]["enable"] == "N") {
        $go_page = BROWSER_IP . "/w3_PR/app/login/logout.php?langx=" . $langx . "&active=pri_error";
        echo "<script>window.open('" . $go_page . "','_self')</script>";
        exit;
    }
}
