//基本
var uid = top.uid;//UID
var langx = top.langx;//語言
var util = top.util;//通用工具
var id = top.id;//id
var listenEvt = top.listenEvt;//動作工具
var langStr = top.langStr;//語系
var tableAry = null;
//工具
var listenUtil = null;//監聽動作
var phpUtil = null;//php作動
var viewUtil = null;//顯示動作

function init() {
    doSet();
}

function doSet() {
    //監聽事件
    listenUtil = new listenEvent();
    //畫面呈現
    viewUtil = new showView();
    // PHP事件
    phpUtil = new phpEvent();
    phpUtil.getOnload();
}

//監聽事件
function listenEvent() {
    var self = this;
    //建立監聽事件(動態)
    self.addListenEvent = function (str) {
        var table = document.getElementsByName(str);
        for (var i = 0; i < table.length; i++) listenEvt.addOnClick(table[i].id, table[i], this, str);
    }
    //監聽事件回應
    self.listenCenter = function (eventName, obj) {
        if (obj.object == "table") {
            var tmp_tid = obj.div.getAttribute("data-type");
            top.tid = tmp_tid;
            parent.changeMain("fill_order", "fill_order");
        }
    }
}
//PHP事件
function phpEvent() {
    var self = this;
    var aPath = "/w3_PR/app/choice_table/choice_table.php";
    //初始資料
    self.getOnload = function () {
        var parame = "&action=getOnload";
        util.addPostPHP("getOnload", aPath, parame, this);
    }
    //PHP事件回應
    self.phpDataCenter = function (eventName, phpData) {
        var obj = phpData;
        if (eventName == "getOnload") { //初始資料
            if (obj["msg"] == "success") {
                tableAry = obj["data"];
                viewUtil.setData();
            } else if (obj["msg"]) {
                alert(langStr[obj["msg"]]);
            }
        }
    }
}
//畫面控制
function showView() {
    var self = this;
    //設定資料
    self.setData = function () {
        var divShow = util.getSpan(document, "div_table");
        var contentStr = "";
        for (var i = 0; i < tableAry.length; i++) {
            var mData = tableAry[i];
            var xmp_table = util.getSpan(document, "xmp_table").innerHTML;
            xmp_table = xmp_table.replace(/\*NAME\*/gi, mData["name"]);
            xmp_table = xmp_table.replace("*CLASS*", (mData["enable"] == "Y") ? "btn_coloryellow" : "btn_colorgary");
            xmp_table = xmp_table.replace("*DISABLED*", (mData["enable"] == "Y") ? "" : "disabled");
            xmp_table = xmp_table.replace("*TBID*", mData["tbid"]);
            contentStr += xmp_table;
        }
        divShow.innerHTML = contentStr;
        listenUtil.addListenEvent("table");
    }
}