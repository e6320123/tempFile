function init() {
    parent.changeMain("labby", "labby");
}