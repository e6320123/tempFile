//基本
var uid = top.uid;//UID
var langx = top.langx;//語言
var util = top.util;//通用工具
var id = top.id;//id
var listenEvt = top.listenEvt;//動作工具
var langStr = top.langStr;//語系
//工具
var phpUtil = null;//php作動
var listenUtil = null;//監聽動作
var viewUtil = null;//顯示動作
var ping = null;//偵測網路
var timer = null;

function init() {
    doSet();
}

function doSet() {
    //PHP事件
    phpUtil = new phpEvent();
    phpUtil.getOnload();
    //監聽事件
    listenUtil = new listenEvent();
    listenUtil.addHyperLink();
    //畫面呈現
    viewUtil = new showView();
    //偵測網路
    ping = new PingTool();
    timer = netWorkTimer();
    //網路連線
    window.addEventListener("online", function () {
        alert("網路連線!!!");
        timer = netWorkTimer();
    });
    //網路斷線
    window.addEventListener("offline", function () {
        if (timer != null) {
            ping.close();
            clearTimeout(timer);
            timer = null;
        }
        alert("網路斷線!!!");
        util.setClassName(util.getSpan(document, "div_header_no_wifi"), "fc_wifi_none");
        util.setHidden(util.getSpan(document, "div_header_wifi"), true);
    });
}
//建立偵測
function netWorkTimer() {
    return setInterval(
        function () {
            var ms = ping.init(window.location.host + "/", null);
            if (ms > 0 && ms <= 1000) { //很好
                util.setHidden(util.getSpan(document, "div_header_wifi"), false);
                util.setClassName(util.getSpan(document, "div_header_no_wifi"), "fc_wifi_img");
                util.setClassName(util.getSpan(document, "div_header_wifi_signal"), "fc_wifi_signal_good");
            } else if (ms > 1000) { //不好
                util.setHidden(util.getSpan(document, "div_header_wifi"), false);
                util.setClassName(util.getSpan(document, "div_header_no_wifi"), "fc_wifi_img");
                util.setClassName(util.getSpan(document, "div_header_wifi_signal"), "fc_wifi_signal_bad");
            }
        }, 5000);
}
//監聽事件
function listenEvent() {
    var self = this;
    //建立監聽事件(靜態)
    self.addHyperLink = function () {
        listenEvt.addOnClick("menu", util.getSpan(document, "btn_header_menu"), this, null);
        listenEvt.addSelectOnChange("sel_now_username", util.getSpan(document, "sel_fill_username"), this, null);
    }
    //監聽事件回應
    self.listenCenter = function (eventName, obj) {
        if (eventName == "menu") {
            parent.changeMenuView();
        } else if (eventName == "sel_now_username") {
            if (confirm(langStr["str_header_sure_to_commit_data"])) {
                var newPR = util.getSpan(document, "sel_fill_username").value;
                phpUtil.chgUser(top.username, newPR);
            } else {
                util.getSpan(document, "sel_fill_username").value = top.username;
            }
        }
    }
}
//畫面控制
function showView() {
    var self = this;
    //設定資料
    self.setData = function (obj) {
        var dom = util.getSpan(document, "sel_fill_username");
        var ary = obj["data"];
        dom.length = 0;
        for (var i = 0; i < ary.length; i++) {
            dom.options.add(new Option(ary[i], ary[i]));
        }
        dom.value = top.username;
    }
}
//PHP事件
function phpEvent() {
    var self = this;
    var aPath = "/w3_PR/app/header/getHeader.php";
    //初始資料
    self.getOnload = function () {
        var parame = "&action=getOnload";
        util.addPostPHP("getOnload", aPath, parame, this);
    }
    //切換公關
    self.chgUser = function (oldPR, newPR) {
        var parame = "&action=chgUser&oldPR=" + oldPR + "&newPR=" + newPR;
        util.addPostPHP("chgUser", aPath, parame, this);
    }
    //PHP事件回應
    self.phpDataCenter = function (eventName, phpData) {
        var obj = phpData;
        if (eventName == "getOnload") { //初始資料
            // util.log("收到初始資料PHP回應");
            if (obj["msg"] == "success") {
                viewUtil.setData(obj);
            } else if (obj["msg"]) {
                alert(langStr[obj["msg"]]);
                parent.closePlug();
            }
        } else if (eventName == "chgUser") { //切換公關
            // util.log("收到切換公關PHP回應");
            if (obj["msg"] == "success") {
                var str = langStr["str_header_chage_PR"];
                str = str.replace("*OLD*", obj["data"]["oldPR"]);
                str = str.replace("*NEW*", obj["data"]["newPR"]);
                alert(str);
                top.username = obj["data"]["username"];
                top.uid = obj["data"]["uid"];
                top.id = obj["data"]["id"];
                top.PRI_DATA = obj["data"]["PRI_DATA"];

                //刷新menu
                parent.window.layout_content.src = parent.window.layout_content.src;
                parent.window.layout_menu.src = parent.window.layout_menu.src;
            } else if (obj["msg"]) {
                var str = langStr[obj["msg"]];
                str = str.replace("*NEW*", obj["data"]["newPR"]);
                alert(str);
                util.getSpan(document, "sel_fill_username").value = obj["data"]["oldPR"];
                parent.closePlug();
            }
        }
    }
}