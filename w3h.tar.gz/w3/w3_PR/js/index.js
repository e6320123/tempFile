//基本
var util = null;//通用工具
var listenEvt = null;//動作工具
var langStr = null;//語系

function init() {
    //登入方式
    if (navigator.userAgent.indexOf("Android") > -1) {
        top.device = "android";
    } else if (navigator.userAgent.indexOf("iPhone") > -1 || navigator.userAgent.indexOf("iPad") > -1) {
        top.device = "ios";
    } else {
        top.device = "pc";
    }

    //工具
    top.util = new Util();
    top.listenEvt = new ListenEvent();
    var langClass = new LangString();
    top.langStr = langClass.GetLS(top.langx);
    top.document.title = top.langStr["ctl_ba3"];

    util = top.util;//通用工具
    listenEvt = top.listenEvt;//動作工具
    langStr = top.langStr;//語系
}

//通知 iframe 動作
function callHeaderFrame(eventName, frameData) {
    var headerV = document.getElementById("layout_header");
    if (headerV.contentWindow.frameCenter) headerV.contentWindow.frameCenter(eventName, frameData);
}

function callMenuFrame(eventName, frameData) {
    var menuV = document.getElementById("layout_menu");
    if (menuV.contentWindow.frameCenter) menuV.contentWindow.frameCenter(eventName, frameData);
}

function callMainFrame(eventName, frameData) {
    var mainV = document.getElementById("layout_content");
    if (mainV.contentWindow.frameCenter) mainV.contentWindow.frameCenter(eventName, frameData);
}

function callMainRefresh() {
    var mainV = document.getElementById("layout_content");
    if (mainV.contentWindow.refresh) mainV.contentWindow.refresh();
}

//顯示隱藏Menu
function changeMenuView(str) {
    var dom = util.getSpan(document, "left_menu_show");
    if (str == undefined || str == null) {
        if (dom.className == "layout_menu") {
            util.setClassName(dom, "layout_menu active");
        } else {
            util.setClassName(dom, "layout_menu");
        }
    } else {
        util.setClassName(dom, str);
    }
}

//切換畫面
function changeMain(folder, file, parame) {
    // showLoading();
    if (parame == undefined || parame == null) parame = "";
    //清除舊頁面request
    util.cleanXMLRequest();
    var mainV = util.getSpan(document, "layout_content");
    if (folder == "") {
        mainV.src = "../app/" + file + ".php?uid=" + top.uid + "&langx=" + top.langx + parame;
    } else {
        mainV.src = "../app/" + folder + "/" + file + ".php?uid=" + top.uid + "&langx=" + top.langx + parame;
    }

    frameOnload = function () {
        // closeLoading();
        if (mainV.attachEvent) mainV.detachEvent('onload', frameOnload);
        // slideMenuListen();
    };

    if (mainV.attachEvent) {
        mainV.attachEvent('onload', frameOnload);
    } else {
        mainV.onload = frameOnload;
    }
}

//使用json物件更換語系 預設語系帶中文(如果語系是空值)
function load_art(doc, artjson, langx) {
    if (langx == '') langx = "zh-cn";
    var json = artjson[langx];
    var bod = doc.body.innerHTML;
    for (var key in json) {
        bod = bod.replace(new RegExp('\\\*' + key + '\\\*', 'gi'), json[key]);
    }
    doc.body.innerHTML = bod;
    doc.body.style.display = "";
}

//偵測水平滑動 叫出menu
function slideMenuListen() {
    var mainV = document.getElementById("layout_content");
    if (mainV.contentWindow) {
        var mx = 50; //控制水平滑動距離大於多少時 觸發
        var my = 50; //控制上下滑動距離低於多少時 觸發
        var nStartY, nStartX, nChangY, nChangX = 0;//存放 ontouchstart/ontouchend 位置
        mainV.contentWindow.document.body.ontouchstart = function (e) {
            nStartY = e.targetTouches[0].pageY;
            nStartX = e.targetTouches[0].pageX;
        };
        mainV.contentWindow.document.body.ontouchend = function (e) {
            nChangY = e.changedTouches[0].pageY;
            nChangX = e.changedTouches[0].pageX;
            if (Math.abs(nStartX - nChangX) > Math.abs(nStartY - nChangY) && Math.abs(nStartY - nChangY) < my && Math.abs(nStartX - nChangX) > mx && nStartX < nChangX) {
                changeMenuView("layout_menu");
            }
            if (Math.abs(nStartX - nChangX) > Math.abs(nStartY - nChangY) && Math.abs(nStartY - nChangY) < my && nStartX > nChangX) {
                changeMenuView("layout_menu active");
            }
        };
    }
}

function loadPlug(folder, file, adata) {
    loadFrame("latout_alert", folder, file, adata);
}

function showPlug() {
    util.setHidden(util.getSpan(document, "alert_show"), false);
}

function closePlug() {
    util.setHidden(util.getSpan(document, "alert_show"), true);
}

function loadFrame(fname, folder, file, adata) {
    // showLoading();
    var fnameV = document.getElementById(fname);
    if (folder == "") {
        fnameV.src = "../app/" + file + ".php?uid=" + top.uid + "&langx=" + top.langx;
    } else {
        fnameV.src = "../app/" + folder + "/" + file + ".php?uid=" + top.uid + "&langx=" + top.langx;
    }

    frameOnload = function () {
        if (fnameV.contentWindow.setData) {
            fnameV.contentWindow.setData(adata);
        }
        if (fnameV.attachEvent) {
            fnameV.detachEvent('onload', frameOnload);
        }
        //畫面設定完，需自己開 showPlug(); 與關閉closeLoading();
    };

    if (fnameV.attachEvent) {
        fnameV.attachEvent('onload', frameOnload);
    } else {
        fnameV.onload = frameOnload;
    }
}