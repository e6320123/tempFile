//基本
var uid = top.uid;//UID
var langx = top.langx;//語言
var util = top.util;//通用工具
var id = top.id;//id
var listenEvt = top.listenEvt;//動作工具
var langStr = top.langStr;//語系
//工具
var labbyUtil = null;//labby工具
var phpUtil = null;//php作動
var listenUtil = null;//監聽動作
var viewUtil = null;//顯示動作
//權限
var isCardManage = false;//現金卡管理
var isChooseCard = false;//Key單系統

function init() {
    doSet();
}

function doSet() {
    if (top.PRI_DATA["A00"]["enable"] == "Y") {
        isCardManage = true;
    }
    if (top.PRI_DATA["B00"]["enable"] == "Y") {
        isChooseCard = true;
    }
    //labby工具
    // labbyUtil = new labbyLib();
    //PHP事件
    // phpUtil = new phpEvent();
    //監聽事件
    listenUtil = new listenEvent();
    listenUtil.addHyperLink();
    //畫面呈現
    viewUtil = new showView();
    viewUtil.showBtn();
}

//監聽事件
function listenEvent() {
    var self = this;
    //建立監聽事件(靜態)
    self.addHyperLink = function () {
        if (isCardManage) {
            listenEvt.addOnClick("btn_labby_card_manage", util.getSpan(document, "btn_labby_card_manage"), this, null);
        }
        if (isChooseCard) {
            listenEvt.addOnClick("btn_labby_Key_Ticket", util.getSpan(document, "btn_labby_Key_Ticket"), this, null);
        }
    }
    //監聽事件回應
    self.listenCenter = function (eventName, obj) {
        if (eventName == "btn_labby_card_manage") {
            parent.changeMain("card_manage","card_manage");
        } else if (eventName == "btn_labby_Key_Ticket") {
            parent.changeMain("add_number", "add_number");
        }
    }
}

//畫面控制
function showView() {
    var self = this;
    //按鈕顯示
    self.showBtn = function () {
        if (isCardManage) {
            util.setHidden(util.getSpan(document, "btn_labby_card_manage"), false);
        }
        if (isChooseCard) {
            util.setHidden(util.getSpan(document, "btn_labby_Key_Ticket"), false);
        }
    }
}