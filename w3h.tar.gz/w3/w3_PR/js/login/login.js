//基本
var util = null;//通用工具
var listenEvt = null;//動作工具
var langStr = null;//語系
//工具
var loginUtil = null;//login工具
var phpUtil = null;//php作動
var listenUtil = null;//監聽動作
var checkUtil = null;//檢查資料
var viewUtil = null;//顯示動作

function init() {
    doSet();
}
function doSet() {
    util = new Util();
    listenEvt = new ListenEvent();
    var langClass = new LangString();
    langStr = langClass.GetLS(langx);

    //login工具
    loginUtil = new loginLib();
    // PHP事件
    phpUtil = new phpEvent();
    //監聽事件
    listenUtil = new listenEvent();
    listenUtil.addHyperLink();
    //檢查資料
    checkUtil = new chkData();
    //畫面呈現
    viewUtil = new showView();
    viewUtil.setData();
}
//監聽事件
function listenEvent() {
    var self = this;
    //建立監聽事件(靜態)
    self.addHyperLink = function () {
        listenEvt.addOnClick("btn_login_ok", util.getSpan(document, "btn_login_ok"), this, null);
        listenEvt.addOnInput("text_login_account_letter", util.getSpan(document, "text_login_account"), this, "input_letter");	//檢查輸入字元
        listenEvt.addSelectOnChange("text_login_account_result", util.getSpan(document, "text_login_account"), this, "input_result");	//檢查輸入結果
        listenEvt.addOnInput("text_login_password_letter", util.getSpan(document, "text_login_password"), this, "input_letter");	//檢查輸入字元
        listenEvt.addSelectOnChange("text_login_password_result", util.getSpan(document, "text_login_password"), this, "input_result");	//檢查輸入結果
    }
    //監聽事件回應
    self.listenCenter = function (eventName, obj) {
        //檢查輸入字元
        if (obj.object == "input_letter") {
            checkUtil.inputLetter(obj.div);
            return;
        }
        //檢查輸入結果
        if (obj.object == "input_result") {
            checkUtil.inputResult(obj.div);
            return;
        }

        if (eventName == "btn_login_ok") {//登入
            phpUtil.getLogin();
        }
    }
}
//畫面控制
function showView() {
    var self = this;
    //設定資料
    self.setData = function () {
        //記住帳號
        var uname = loginUtil.getCookie(document.cookie, "account");
        util.getSpan(document, "text_login_account").value = uname;
        if (uname == "") {
            util.selectText(util.getSpan(document, "text_login_account"));
        } else {
            util.selectText(util.getSpan(document, "text_login_password"));
            util.getSpan(document, "chkbox_login_remember_Acc").checked = true;
        }
        //Title
        top.document.title = langStr["ctl_ba3"];
    }
}
//PHP事件
function phpEvent() {
    var self = this;
    var aPath = "/w3_PR/app/login/chk_data.php";
    //登入
    self.getLogin = function () {
        var parame = "langx=" + langx;
        //檢查輸入資料
        if (!checkUtil.chkInput()) return;
        if (util.getSpan(document, "chkbox_login_remember_Acc").checked) {
            var obj = new Object();
            obj["_key"] = "account";
            obj["_value"] = util.getSpan(document, "text_login_account").value;
            loginUtil.setCoockie(obj);
        }
        parame += "&username=" + util.getSpan(document, "text_login_account").value + "&password=" + util.getSpan(document, "text_login_password").value;
        window.location.href = aPath + "?" + parame;
    }
}
//檢查資料
function chkData() {
    var self = this;
    var pass = new Object();
    var A_ZNUMS = /[A-Za-z0-9]+/;//限定英文跟數字

    //檢查輸入字元
    self.inputLetter = function (div) {
        var input = div.getAttribute("data-input");
        var val = div.value;
        //刪除非英文或數字字元
        if (input == "a_z_nums") {
            val = val.replace(/[^a-zA-Z0-9]/g, "");
        }
        if (div.value != val) div.value = val;
    }
    //檢查輸入結果
    self.inputResult = function (div) {
        var item = div.id;
        pass[div.id] = new Object();

        //如果輸入內容為空則跳過
        if (div.value == "") return;

        //帳號
        if (item == "text_login_account") {
            if (!(A_ZNUMS.test(div.value))) {//帳號必須為英數符號，請重新輸入!
                pass[div.id]["text"] = "ACCOUNT_LETTER_ERROR";
                self.modifyAlert(div.id);
                return false;
            } else {
                pass[div.id]["text"] = "PASS";
            }
        }
        //密碼
        if (item == "text_login_password") {
            if (!(A_ZNUMS.test(div.value))) {//密碼必須為英數符號，請重新輸入!
                pass[div.id]["text"] = "PASSWORD_LETTER_ERROR";
                self.modifyAlert(div.id);
                return false;
            } else {
                pass[div.id]["text"] = "PASS";
            }
        }
        return true;
    }
    //提示修改
    self.modifyAlert = function (item) {
        showMsg(pass[item]["text"]);
    }
    //檢查輸入資料
    self.chkInput = function () {
        //檢查基本資料是否空白
        var base_data = document.getElementsByName("base_data");
        for (var i = 0; i < base_data.length; i++) {
            var item = base_data[i].id;
            if (!pass[item]) pass[item] = new Object();

            if (base_data[i].value == "") {
                pass[item]["text"] = item.toUpperCase() + "_NULL_ERROR";
                self.modifyAlert(item);
                return false;
            } else if (pass[item]["text"] == item.toUpperCase() + "_NULL_ERROR") {
                pass[item]["text"] = "PASS";
            }
        }
        //帳號
        var div = util.getSpan(document, "text_login_account");
        if (typeof pass[div.id] == "undefined") {
            pass[div.id] = new Object();
        }
        if (!(A_ZNUMS.test(div.value))) {//帳號必須為英數符號，請重新輸入!
            pass[div.id]["text"] = "ACCOUNT_LETTER_ERROR";
            self.modifyAlert(div.id);
            return false;
        } else {
            pass[div.id]["text"] = "PASS";
        }
        //密碼
        var div = util.getSpan(document, "text_login_password");
        if (typeof pass[div.id] == "undefined") {
            pass[div.id] = new Object();
        }
        if (!(A_ZNUMS.test(div.value))) {//密碼必須為英數符號，請重新輸入!
            pass[div.id]["text"] = "PASSWORD_LETTER_ERROR";
            self.modifyAlert(div.id);
            return false;
        } else {
            pass[div.id]["text"] = "PASS";
        }
        //確認其他錯誤有無修正
        for (var item in pass) {
            var msg = pass[item];
            if (msg["text"] && msg["text"] != "PASS") {
                showMsg(msg["text"]);
                return false;
            }
        }
        return true;
    }
}
//錯誤訊息
function showMsg(motion) {
    var str = "";
    if (motion == null || motion == "") {
        return;
    } else if (motion == "TEXT_LOGIN_ACCOUNT_NULL_ERROR") {	//請輸入帳號
        str += langStr["str_login_account_null_error"];
    } else if (motion == "ACCOUNT_LETTER_ERROR") { //帳號數必須為英文數字，請重新輸入!
        str += langStr["str_login_account_letter_error"];
    } else if (motion == "TEXT_LOGIN_PASSWORD_NULL_ERROR") {//請輸入密碼
        str += langStr["str_login_password_null_error"];
    } else if (motion == "PASSWORD_LETTER_ERROR") { //密碼數必須為英文數字，請重新輸入!
        str += langStr["str_login_password_letter_error"];
    }
    alert(str);
}
//login工具
function loginLib() {
    var self = this;
    //取的Cookie
    self.getCookie = function (_cookie, _key) {
        var cookieAry = _cookie.split(";");
        for (var i = 0; i < cookieAry.length; i++) {
            var thisCookie = cookieAry[i].split("=");
            if (thisCookie[0].indexOf(_key) != -1) {
                return thisCookie[1];
            }
        }
        return "";
    }
    //寫入Cookie
    self.setCoockie = function (obj) {
        if (obj._key == null || obj._value == null) return;
        document.cookie = obj._key + "=" + obj._value + ";";

        return;
    }
}