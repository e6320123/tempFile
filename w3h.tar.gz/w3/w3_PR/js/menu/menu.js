//基本
var uid = top.uid;//UID
var langx = top.langx;//語言
var util = top.util;//通用工具
var id = top.id;//id
var listenEvt = top.listenEvt;//動作工具
var langStr = top.langStr;//語系
//工具
var menuUtil = null;//menu工具
var phpUtil = null;//php作動
var listenUtil = null;//監聽動作
var viewUtil = null;//顯示動作
//權限
var isCardManage = false;//現金卡管理
var isChooseCard = false;//選擇卡號
var isDetail = false;//詳細資料
var iscashout = false;//出碼
var isCardDetail = false;//卡片紀錄
var isBetDetail = false;//下注明細
var isBetfix = false; //補單刪單

function init() {
    doSet();
}

function doSet() {
    if (top.PRI_DATA["A00"]["enable"] == "Y") {
        isCardManage = true;
    }
    if (top.PRI_DATA["B00"]["enable"] == "Y") {
        isChooseCard = true;
    }
    if (top.PRI_DATA["C00"]["enable"] == "Y") {
        isDetail = true;
    }
    if (top.PRI_DATA["D00"]["enable"] == "Y") {
        iscashout = true;
    }
    if (top.PRI_DATA["E00"]["enable"] == "Y") {
        isCardDetail = true;
    }
    if (top.PRI_DATA["F00"]["enable"] == "Y") {
        isBetDetail = true;
    }
    if (top.PRI_DATA["G00"]["enable"] == "Y") {
        isBetfix = true;
    }
    //menu工具
    // menuUtil = new menuLib();
    //PHP事件
    // phpUtil = new phpEvent();
    //監聽事件
    listenUtil = new listenEvent();
    listenUtil.addHyperLink();
    //畫面呈現
    viewUtil = new showView();
    viewUtil.showBtn();
}

//監聽事件
function listenEvent() {
    var self = this;
    //建立監聽事件(靜態)
    self.addHyperLink = function () {
        if (isCardManage) {
            listenEvt.addOnClick("btn_menu_card_manage", util.getSpan(document, "btn_menu_card_manage"), this, "menu");
        }
        if (isChooseCard) {
            listenEvt.addOnClick("btn_menu_choice_card", util.getSpan(document, "btn_menu_choice_card"), this, "menu");
        }
        if (isDetail) {
            listenEvt.addOnClick("btn_menu_detail_data", util.getSpan(document, "btn_menu_detail_data"), this, "menu");
        }
        if (iscashout) {
            listenEvt.addOnClick("btn_menu_maxcredit", util.getSpan(document, "btn_menu_maxcredit"), this, "menu");
        }
        if (isCardDetail) {
            listenEvt.addOnClick("btn_menu_card_record", util.getSpan(document, "btn_menu_card_record"), this, "menu");
        }
        if (isBetDetail) {
            listenEvt.addOnClick("btn_menu_bet_detail", util.getSpan(document, "btn_menu_bet_detail"), this, "menu");
        }
        if (isBetfix) {
            listenEvt.addOnClick("btn_menu_order_fix", util.getSpan(document, "btn_menu_order_fix"), this, "menu");
        }
        listenEvt.addOnClick("btn_menu_logout", util.getSpan(document, "btn_menu_logout"), this, "menu");
    }
    //監聽事件回應
    self.listenCenter = function (eventName, obj) {
        if (obj.object == "menu") {
            if (eventName == "btn_menu_card_manage") {
                parent.changeMenuView();
                parent.changeMain("card_manage", "card_manage");
            } else if (eventName == "btn_menu_choice_card") {
                parent.changeMenuView();
                parent.changeMain("add_number", "add_number");
            } else if (eventName == "btn_menu_detail_data") {
                parent.changeMenuView();
                parent.changeMain("detail", "detail");
            } else if (eventName == "btn_menu_maxcredit") {
                var obj = new Array();
                obj["static"] = "outcash";
                obj["primanager"] = true;
                parent.loadPlug("alert", "alert07", obj);
            } else if (eventName == "btn_menu_card_record") {
                parent.changeMenuView();
                parent.changeMain("card_detail", "card_detail");
            } else if (eventName == "btn_menu_bet_detail") {
                parent.changeMenuView();
                parent.changeMain("bet_detail", "bet_detail");
            } else if (eventName == "btn_menu_order_fix") {
                var obj = new Array();
                obj["cardno"] = "default";
                parent.loadPlug("fill_order", "order_fix", obj);
                // parent.changeMenuView();
                // parent.changeMain("fill_order", "order_fix");
            } else if (eventName == "btn_menu_logout") {
                var domain = window.location.origin;
                var page = window.location.pathname.substr(0, 7);
                parent.window.location.href = domain + page;
            }
        }
    }
}

//畫面控制
function showView() {
    var self = this;
    //按鈕顯示
    self.showBtn = function () {
        if (isCardManage) {
            util.setHidden(util.getSpan(document, "btn_menu_card_manage"), false);
        }
        if (isChooseCard) {
            util.setHidden(util.getSpan(document, "btn_menu_choice_card"), false);
        }
        if (isDetail) {
            util.setHidden(util.getSpan(document, "btn_menu_detail_data"), false);
        }
        if (iscashout) {
            util.setHidden(util.getSpan(document, "btn_menu_maxcredit"), false);
        }
        if (isCardDetail) {
            util.setHidden(util.getSpan(document, "btn_menu_card_record"), false);
        }
        if (isBetDetail) {
            util.setHidden(util.getSpan(document, "btn_menu_bet_detail"), false);
        }
        if (isBetfix) {
            util.setHidden(util.getSpan(document, "btn_menu_order_fix"), false);
        }
        util.setHidden(util.getSpan(document, "btn_menu_logout"), false);
    }
}