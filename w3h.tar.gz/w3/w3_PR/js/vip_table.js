var serverInfos = new Array();
var sock = null;//連Server
var cmd = null;//接收Server訊息
var userType = 'B';
var userTable = 0;
var tid = 0;
var sec_obj = null;
var betMsg_obj = null;
var freeGame_obj = null;
var timeAry = new Array();//時間均速	
var showMsg = null;
var countDownTimer = null;
var soundEnable = true;
var image_source = "cads.png";    //"cads_m.png"
var hasResult = "";
var calimage = null;
var VipStatus = 'N';
// var playerCount = 0;
var starttime = 0;
var bellType = "";
var countdownRing;
var inTableAlarm;
var outTableAlarm;
function init() {
    detect();
    util = new Util();
    phpEvent = new phpEvent();
    listenEvent = new ListenEvent();
    userTable = top.username.substring(0, top.username.length -1);
    userType = top.username.substring(top.username.length -1, top.username.length);
    util.getSpan(document, "titleTbName").innerHTML = userTable +"桌";
    showTableNum(0,0,0,0,0,0,0);
    phpEvent.getIP();
    cmd = new Gameroom_cmd();
    sock = new Socket();
    showMsg = new showMsgObj();

    countdownRing = document.createElement("audio");
    countdownRing.id = "countdown";
    countdownRing.src = "/images/CountDown1.mp3";


    inTableAlarm = document.createElement("audio");
    inTableAlarm.id = "inTableAlarm";
    inTableAlarm.src = "/images/bell-ringing.mp3";
    inTableAlarm.play();
    inTableAlarm.pause();  
    
    outTableAlarm = document.createElement("audio");
    outTableAlarm.id = "outTableAlarm";
    outTableAlarm.src = "/images/cartoon-gliss-bell-chime-01.mp3";
    outTableAlarm.play();
    outTableAlarm.pause();


    countDownTimer = new refreshThread();
    countDownTimer.start();

    calimage = new CardCalImage();
    calimage.loadimage("../../images/"+image_source+"");
    //util.getSpan(document, "testPeiImg")

    listenEvent.addOnClick("clickRandomConfirm", util.getSpan(document, "btn_confirm_diff"), this, null);
    listenEvent.addOnClick("clickRandomCancle", util.getSpan(document, "btn_cancle_diff"), this, null);
    listenEvent.addOnClick("clickShowRandom", util.getSpan(document, "fixRandomConfirm"), this, null);
    listenEvent.addOnClick("clickPeiDiv", util.getSpan(document, "showpoker"), this, null);
    listenEvent.addOnClick("clickMsgBar", util.getSpan(document, "msgBar"), this, null);
    listenEvent.addOnClick("voiceChange", util.getSpan(document, "vip_voiceBTN"), this, null);

    listenEvent.addOnClick("confirmReconnect", util.getSpan(document, "confirmReconnect"), this, null);
    listenEvent.addOnClick("cancleReconnect", util.getSpan(document, "cancleReconnect"), this, null);

    listenEvent.addOnClick("confirmBet", util.getSpan(document, "confirmBet"), this, null);
    listenEvent.addOnClick("cancleBet", util.getSpan(document, "btn_alert_close"), this, null);

    listenEvent.addOnClick("confirmFreeGame", util.getSpan(document, "confirmFreeGame"), this, null);
    listenEvent.addOnClick("cancleFreeGame", util.getSpan(document, "cancleFreeGame"), this, null);

    listenEvent.addOnClick("big_bell", util.getSpan(document, "big_bell"), this, null);
}

function sound_on(){
    soundEnable=true;
    countdownRing.play();
    countdownRing.pause();
    inTableAlarm.play();
    inTableAlarm.pause();
    outTableAlarm.play();
    outTableAlarm.pause();
}

function sound_off(){
    soundEnable=false;
}

//JS事件
function listenCenter(eventName, listenData) {
    //console.log("listenCenter "+ eventName);
    if (eventName.indexOf("clickRandomConfirm") != -1) {
        //點擊修改最大最小值
        var regExp = /^[\d]+$/;
        var diffMin = util.getSpan(document, "diffMin").value;
        var diffMax = util.getSpan(document, "diffMax").value;
        var baseMin = util.getSpan(document, "baseMin").value;
        var baseMax = util.getSpan(document, "baseMax").value;
        
        if(!regExp.test(diffMin) || !regExp.test(diffMax) || !regExp.test(baseMin) || !regExp.test(baseMax)){
            util.getSpan(document, "errorMsgModel").innerHTML = "輸入數值錯誤";
            return;
        }
        if(diffMin*1 > diffMax*1 || baseMin*1 > baseMax*1){
            util.getSpan(document, "errorMsgModel").innerHTML = "輸入數值錯誤";
            return;
        }
        util.getSpan(document, "chg_diff_div").style.display="none";
        setFixRandom(diffMin, diffMax, baseMin, baseMax);
    }
    if (eventName.indexOf("clickShowRandom") != -1) {
        util.getSpan(document, "errorMsgModel").innerHTML = "";
        util.getSpan(document, "chg_diff_div").style.display="";
    }
    if (eventName.indexOf("clickRandomCancle") != -1) {
        util.getSpan(document, "chg_diff_div").style.display="none";
    }
    if (eventName.indexOf("clickPeiDiv") != -1) {
        disappearSumNum();
    }
    if (eventName.indexOf("clickMsgBar") != -1) {
        showMsg.popMsg();
    }
    if (eventName.indexOf("confirmReconnect") != -1) {
        if(sock.ws_open == false){
            sock.reconnect();
        }
        util.getSpan(document, "reconnect_div").style.display="none";
    }
    if (eventName.indexOf("cancleReconnect") != -1) {
        util.getSpan(document, "reconnect_div").style.display="none";
    }
    if (eventName.indexOf("confirmBet") != -1) {
        hideBetConfirm();
        // clickConfirmBet();
    }
    if (eventName.indexOf("cancleBet") != -1) {
        hideBetConfirm();
    }
    if (eventName.indexOf("confirmFreeGame") != -1) {
        hideFreeGameConfirm();
        clickConfirmFreeGame("Y");
    }
    if (eventName.indexOf("cancleFreeGame") != -1) {
        hideFreeGameConfirm();
        clickConfirmFreeGame("N");
    }
    if (eventName.indexOf("big_bell") != -1) {
        var bigBell = document.getElementById("big_bell_bg");
        bigBell.style.display="none";
        bigBell.classList.remove("active");
        if(bellType == "IN"){
            phpEvent.recordClickBell("M");
            bellType = "";
            // setBell();
            clickBell();
        }
    }
    if (eventName.indexOf("voiceChange") != -1) {
        if(!util.getSpan(document, "vip_voiceBTN").checked){
            sound_on();
        }else{
            sound_off();
        }
    }
}


function detect(){
    isSecure = ('https:' == document.location.protocol);
    // console.log("isSecure "+isSecure);
    if(navigator.userAgent.indexOf("Safari")!= -1 && navigator.userAgent.indexOf("Chrome") == -1){
        // console.log("if 1");
        if(isSecure){
        // console.log("if 1 s");
        document.location.href="http://"+document.location.host;
        }
    }else{
        // console.log("else 1");
        if(isSecure){
        // console.log("else 1 !s");
        document.location.href="http://"+document.location.host;
        }
    }
}

function setFixRandom(min, max, basemin, basemax){
    //701,fixRandom,table,min,max
    var cmdCode = "701,fixRandom," + tid + ","+min + ","+ max+ ","+ basemin+ ","+ basemax;
    sock.sendToServer(cmdCode);
}

function sentRegist(){
    //111,register,username,mid,uid,tid,grp,語系,是否全桌(Y:全桌,N:單桌),是否為公關(Y:是,N:否)
    //111,register,roland,490,6b8de6be60b675d6,7,1,big5,Y,Y
    var cmdCode = "111,register," + top.username + "," + top.id + "," + top.uid + "," + tid + ",1,big5,Y,Y";
    sock.sendToServer(cmdCode);
}

function chgVipStatus(stat){
    VipStatus = stat;
}

function setPlayerCount(val){
    playerCount = document.getElementById("playerCountId").value;
    if(VipStatus == "Y"){
        if(playerCount*1 == 0){
            // if(val*1 >0){
            //     if(bellType == ""){
            //         var bigBell = document.getElementById("big_bell_bg");
            //         bigBell.style.display="";
            //         bigBell.classList.add("active");
            //         var date = new Date();
            //         starttime = date.getTime();
            //         bellType = "IN";
            //         if(soundEnable){
            //             inTableAlarm.pause();
            //             inTableAlarm.load();
            //             inTableAlarm.play();
            //         }
            //     }
            // }
        }
        // else if(val *1 == 0){
        //     if(playerCount*1 >0){
        //         var bigBell = document.getElementById("big_bell_bg");
        //         bigBell.style.display="none";
        //         bigBell.classList.remove("active");
        //         if(bellType == "IN"){
        //             phpEvent.recordClickBell("A");
        //         }
        //         bellType = "";
        //         if(soundEnable){
        //             outTableAlarm.pause();
        //             outTableAlarm.load();
        //             outTableAlarm.play();
        //         }
        //     }
        // }
    }
    util.getSpan(document, "vip_memimg").classList = "";
    util.getSpan(document, "vip_memimg").classList.add("vip_memimg");
    if(val*1 >0){
        util.getSpan(document, "vip_memimg").classList.add("Word_lightyellow");
    }
    // playerCount = val;
    document.getElementById("playerCountId").value = val;
}

function setBell(table){
    if(VipStatus == "Y"){            
        if(bellType == ""){
            var bigBell = document.getElementById("big_bell_bg");
            bigBell.style.display="";
            bigBell.classList.add("active");
            var date = new Date();
            starttime = date.getTime();
            bellType = "IN";
            if(soundEnable){
                inTableAlarm.pause();
                inTableAlarm.load();
                inTableAlarm.play();
            }
        }
    }
}

// 746 是否顯示呼叫公關
function callPr(tbid,dateTime,time){
    return;
    // var deadTime = util.getUTCTimestamp(dateTime,-4);
    // var waiterBtn =  util.getSpan(document,"call_waiter");
    // if( deadTime*1 > time*1 ){
    //     setBell();
    // }else{
    // }
}

function clickBell(){
    //747,callPrResponse,tbid,mid,username,2,Y/N,vib_username
    var cmdCode = "747,callPrResponse," + tid + "," + "0," + "0," + "2"+ ","+"Y," + top.username + "";
    sock.sendToServer(cmdCode);
}

function callPrResponse(tbid,type,allow){
    var bigBell = document.getElementById("big_bell_bg");
        bigBell.style.display="none";
        bigBell.classList.remove("active");
        bellType="";
}

function showTableNum(PTotal, TTotal, BTotal, BPTotal, PPTotal, BActual, PActual){
    util.getSpan(document, "tdBTotal").innerHTML = BTotal;
    util.getSpan(document, "tdBActual").innerHTML = "<span class='Word_darkred'>" +BActual+ "</span><br><span class='Word_blue'>" +PActual+"</span>";
    
    util.getSpan(document, "tdBPTotal").innerHTML = BPTotal;
    util.getSpan(document, "tdBPActual").innerHTML = 0;

    util.getSpan(document, "tdTTotal").innerHTML = TTotal;
    util.getSpan(document, "tdTActual").innerHTML = 0;

    util.getSpan(document, "tdPTotal").innerHTML = PTotal;
    // util.getSpan(document, "tdPActual").innerHTML = "<span class='Word_blue'>" +PActual+ "</span><br><span class='Word_darkred'>" +BActual+"</span>";
    util.getSpan(document, "tdPActual").innerHTML =  "<span class='Word_darkred'>" +BActual+ "</span><br><span class='Word_blue'>" +PActual+"</span>";
    
    util.getSpan(document, "tdPPTotal").innerHTML = PPTotal;
    util.getSpan(document, "tdPPActual").innerHTML = 0;
    
    // 不分開 莊 或 閒 的帳號 
    // util.getSpan(document, "trTitle").style.display = "none";
    // util.getSpan(document, "trB").style.display = "none";
    // util.getSpan(document, "trBP").style.display = "none";
    // util.getSpan(document, "trT").style.display = "none";
    // util.getSpan(document, "trP").style.display = "none";
    // util.getSpan(document, "trPP").style.display = "none";

    // if(userType == "B" || userType == "b"){
    // 	util.getSpan(document, "trTitle").style.display = "";
    // 	util.getSpan(document, "trB").style.display = "";
    // 	util.getSpan(document, "trBP").style.display = "";
    // 	util.getSpan(document, "trT").style.display = "";
        
    // }else if(userType == "P" || userType == "p"){
    // 	util.getSpan(document, "trTitle").style.display = "";
    // 	util.getSpan(document, "trP").style.display = "";
    // 	util.getSpan(document, "trPP").style.display = "";
    // }
}

function showBetConfirm(tmpObj){
    betMsg_obj = tmpObj;
    var tmpBetMsg = "確定是否下注<tt>"+ betMsg_obj["tableNo"]+"桌</tt><tt>"+ betMsg_obj["boot"]+"靴</tt><tt>"+ betMsg_obj["gmId"]+"局</tt><tt>莊"+ betMsg_obj["H"]+"元</tt><tt>閒"+ betMsg_obj["C"]+"元?</tt>";
    util.getSpan(document, "confirmBetMsg").innerHTML = tmpBetMsg;
    util.getSpan(document, "confirmBet_div").style.display="";
}


function hideBetConfirm(){
    util.getSpan(document, "confirmBet_div").style.display="none";
}

function showFreeGameConfirm(tmpObj){
    freeGame_obj = tmpObj;
    util.getSpan(document, "freegameMsg").innerHTML = "會員"+freeGame_obj["memName"] +"要求飛牌";
    util.getSpan(document, "freegame_div").style.display = "";
}

function hideFreeGameConfirm(){
    util.getSpan(document, "freegame_div").style.display="none";
}

function clickConfirmBet(){
//757,confirmBet,tableNO,boot,gmid,gid,H,C,P/B
    var cmdCode = "757,confirmBet," + betMsg_obj["tableNo"] + ","+betMsg_obj["boot"] + ","+ betMsg_obj["gmId"]+ ","+ betMsg_obj["gid"]+ ","+ betMsg_obj["H"]+ ","+ betMsg_obj["C"];
    if(userType == "B" || userType == "b"){
        cmdCode += ",B";
    }else if(userType == "P" || userType == "p"){
        cmdCode += ",P";
    }
    sock.sendToServer(cmdCode);
}

function clickConfirmFreeGame(status){
//761,freeGameChk,tableNO,username,Y/N
    var cmdCode = "761,freeGameChk," + freeGame_obj["tableNo"] + ","+freeGame_obj["memName"] + ","+ status;
    sock.sendToServer(cmdCode);
}

function disappearSumNum(){
    if(timerOfShowPei != ""){
        clearTimeout(timerOfShowPei);
    }
    util.getSpan(document, "showpoker").style.display = "none";
    //util.getSpan(document, "mc_sum").style.display = "none";
    //util.getSpan(document, "mh_sum").style.display = "none";
}

var timerOfShowPei = "";
function showSumNum(){
    util.getSpan(document, "showpoker").style.display = "block";
    //util.getSpan(document, "mc_sum").style.display = "block";
    //util.getSpan(document, "mh_sum").style.display = "block";
    if(timerOfShowPei != ""){
        clearTimeout(timerOfShowPei);
    }
    timerOfShowPei = setTimeout(function(){
        disappearSumNum();
    }, 3000);
}

function showPei(scanPei) {
    if (scanPei == "0|0|0|0|0|0") return;
    hideBetConfirm();
    var Pei = scanPei.split("|");
    var mc_tmp = 0;
    var mh_tmp = 0;
    var card = new Array();
    var pokerAry = new Array();
    for (var i = 1; i < 7; i++) {
        card.push(util.getSpan(document, "card_" + i));
        pokerAry.push(util.getSpan(document, "poker_" + i));
    }

    for (var i = 0; i < card.length; i++) {
        Pei[i]=Pei[i]*1;
        if(Pei[i] == 0 ) {
            card[i].style.display = "none";
            continue;
        }
        //取得 數字x 花樣y
        x = (Pei[i] % 13 != 0) ? Pei[i] % 13 : 13;
        y = Math.ceil(Pei[i] / 13) - 1;
        //點數加總
        if (i %2 == 0) {
            mc_tmp += (x < 10) ? x : 0;
        } else {
            mh_tmp += (x < 10) ? x : 0;
        }
        while (mc_tmp >= 10) mc_tmp -= 10;
        while (mh_tmp >= 10) mh_tmp -= 10;

        if(Pei[i] == 0 && card[i].value == Pei[i]) continue;

        card[i].style.display = "";
        card[i].value = Pei[i];
        calimage.getCardImage(x,y,pokerAry[i]);
    }
    util.getSpan(document, "mc_sum").innerHTML = mc_tmp;
    util.getSpan(document, "mh_sum").innerHTML = mh_tmp;
    
}

function setRandomValue(table,fixmin,fixmax,basemin,basemax){
    util.getSpan(document, "diffMin").value = fixmin;
    util.getSpan(document, "diffMax").value = fixmax;
    util.getSpan(document, "baseMin").value = basemin;
    util.getSpan(document, "baseMax").value = basemax;

    util.getSpan(document, "show_diffMin").innerHTML = fixmin;
    util.getSpan(document, "show_diffMax").innerHTML = fixmax;
    util.getSpan(document, "show_baseMin").innerHTML = basemin;
    util.getSpan(document, "show_baseMax").innerHTML = basemax;
}

function frameCenter(eventName, frameData){
    console.log(eventName+"   "+ frameData);
    if(eventName == "reconnect" && frameData == "Y"){
        if(sock.ws_open == false){
            sock.reconnect();
        }
    }else if(eventName == "showPing"){
        if(util.getSpan(document, "pingDiv").style.display == "none"){
            util.getSpan(document, "pingDiv").style.display = "";
        }else{
            util.getSpan(document, "pingDiv").style.display = "none";
        }
    }
}

function showtimeAry(){
    var text = "";
    if(timeAry.length > 0){
        for( var i = timeAry.length -1; i >= 0; i--){
            text += timeAry[i]["time"] + " delay: "+ timeAry[i]["delayms"]+"<br>";
        }
    }
    util.getSpan(document, "pingDiv").innerHTML = text;
}

function showResult(result) {
    var tmp = result.split("|");
    var tmpNum = 0;
    if(result != "-1,-1,-1,-1"){
        if(result.indexOf("MH") != -1){
            tmpNum = 0;
        }else if(result.indexOf("MN") != -1){
            tmpNum = 8;
        }else if(result.indexOf("MC") != -1){
            tmpNum = 4;
        }
        var isHP = false;
        var isCP = false;
        if(result.indexOf("HP") != -1){
            isHP = true;
        }
        if(result.indexOf("CP") != -1){
            isCP = true;
        }
        if(isHP && isCP){
            tmpNum = tmpNum +3;
        }else if(isHP){
            tmpNum = tmpNum +2;
        }else if(isCP){
            tmpNum = tmpNum +1;
        }
        
        util.getSpan(document, "animation_bkpl").classList = "";
        util.getSpan(document, "animation_bkpl").classList.add("animation");
        util.getSpan(document, "animation_bkpl").classList.add("new_bkpl_"+tmpNum);
        // if(hasResult !=""){
            showSumNum();
            // hasResult = "";
        // }
    }
}

//PHP事件
function phpEvent() {
    var self = this;
    var aPath = "getDataLabby.php";
    //取得IP
    self.getIP = function () {
        var parame = "&action=getIp";
        parame += "&uid=" + top.uid;
        parame += "&tbid=" + userTable;
        util.addPostPHP("getServerIp", aPath, parame, this);
    }

    //取得本桌資訊
    self.getTableInfo = function () {
        var parame = "&action=getPlayerNum_OneTable";
        parame += "&uid=" + top.uid;
        parame += "&tbid=" + userTable;
        util.addPostPHP("getTableInfo", aPath, parame, this);
    }

    //寫入多久按下鈴鐺
    self.recordClickBell = function (type) {
        var nowTime = new Date();
        var endTime = nowTime;
        var during = (endTime.getTime() - starttime)/1000; 
        var parame = "&action=retime";
        parame += "&uid=" + top.uid;
        parame +="&username="+top.username;
        parame += "&tableNo=" + tid;
        parame +="&type="+type;
        parame +="&starttime="+Math.ceil(starttime/1000);
        parame +="&endTime="+Math.ceil(endTime.getTime()/1000);
        parame +="&during="+during;
        util.addPostPHP("recordBellTimeReply", aPath, parame, this);
    }

    //PHP事件回應
    self.phpDataCenter = function (eventName, phpData) {
        var obj = phpData;
        if (eventName == "getServerIp") { //取得IP
            if (obj["msg"] == "success") {
                console.log(obj["serverInfos"]);
                serverInfos = obj["serverInfos"];
                tid = serverInfos["tbid"];
                var tableIP = serverInfos["ip"];
                var port = serverInfos["port"];
                sock.connect(tableIP, port);
            } else if (obj["msg"]) {
                alert(langStr[obj["msg"]]);
            }
        }else if (eventName == "getTableInfo") { //取得本桌資訊
            if (obj["msg"] == "success") {
                console.log(obj["result"]);
            } else if (obj["msg"]) {
                alert(langStr[obj["msg"]]);
            }
        }else if (eventName == "recordBellTimeReply") { //多久按下鈴鐺
            if (obj["msg"] == "success") {
                console.log(obj["result"]);
            }
        }
    }
}

//cmd
function Gameroom_cmd() {
    var self = this;
    var Table = null;
    var PlayerObj = null;
    //傳遞上層物件進來
    self.setGameroom = function (obj) {
        Table = obj.Table;
        PlayerObj = obj.Player;
    }

    //遠端命令執行
    self.Data_proc = function (ComeInData) {
        var arr = ComeInData.split(",");
        var code = arr[0];
        trace("Cmd Data_proc : " + ComeInData);
        //連線成功 000,connectSuccess
        if (code == "000") {
            util.getSpan(document, "reconnect_div").style.display="none";
            // parent.closePlug();
            sentRegist();
            return;
        }

        // 210,gameId
        if (code == "210") {
            util.getSpan(document, "titleTbName").innerHTML = userTable +"桌" + arr[4]+"靴" + arr[5]+"局";
            return;
        }

        // 220,timer
        if (code == "220") {
            setSec(arr[2]);
            //util.getSpan(document, "countDown").innerHTML = arr[2];
            return;
        }

        // 344,AllGameRoom
        if (code == "280") {
            var allTbInfos = arr[2].split("|");
            for(var i = 0; i < allTbInfos.length; i++){
                var tbInfos = allTbInfos[i].split("_");
                if(tbInfos[0] == tid){
                    chgVipStatus(tbInfos[3]);
                }
            }
            return;
        }
        
        // 392,vip_sw
        if (code == "392") {
            chgVipStatus(arr[2]);
            return;
        }

        // 344,allBetNoTest
        if (code == "344") {
            showTableNum(arr[2],arr[3],arr[4],arr[7],arr[8],arr[10],arr[11]);
            return;
        }

        // 402,scanPei
        if (code == "402") {
            showPei(arr[2]);
            return;
        }

        // 450,result
        if (code == "450") {
            // hasResult = arr[2];
            showResult(arr[2]);
            return;
        }

        //websocket ping 的回應
        if (code == "542") {
            var et = new Date().getTime();
            var nowTime = new Date().toLocaleString();
            var obj = new Array();
            var delayms = Number(et - arr[2]);
            obj["time"] = nowTime;
            obj["delayms"] = delayms;

            if (timeAry.length < 5) {
            	timeAry.push(obj);
            } else {
            	timeAry.shift();
            	timeAry.push(obj);
            }

            showtimeAry();
            // //統計五次的平均
            // var totalDelay = 0;
            // var delayList = "";
            // for (var i = 0; i < timeAry.length; i++) {
            // 	// var randon = Math.floor((Math.random() * 100) + 1); //測試用
            // 	totalDelay = totalDelay + timeAry[i]["delayms"] * 1;
            // 	delayList = delayList + timeAry[i]["time"] + "|ms=" + timeAry[i]["delayms"] + "</br>";
            // }
            // var totalDelay = totalDelay / timeAry.length;
            // var delayTestDiv = util.getSpan(document, "delaytest");//● 的控制
            // var delaylistView = util.getSpan(document, "delaylistView");
            // delaylistView.innerHTML = delayList;
            // //如果延遲 超過2秒 變紅色
            // if (totalDelay > 2000) delayTestDiv.style.color = "red";
            // else delayTestDiv.style.color = "green";
            // // console.log(totalDelay);
            return;
        }

        //590,syncTime
        if (code == "590") {
            setSec(arr[2]);
            return;
        }

        //702,fixRandomOK
        if (code == "702") {
            setRandomValue(arr[2],arr[3],arr[4],arr[5],arr[6]);
            return;
        }
        
        //722,getTableCount
        if (code == "722") {
            setPlayerCount(arr[3]);
            return;
        }

        //744,callPr,tbid,mid,username
        if(code=="744"){
            setBell(arr[2]);
            return;
        }

        //746,callPrNextTime,1,2019-01-21 04:23:43,1548058992239
        if(code=="746"){
            // callPr(arr[2],arr[3],arr[4]);
            return;
        }
        //748,callPr,tbid,mid,username
        if(code=="748"){
            callPrResponse(arr[2],arr[5],arr[6]);
            return;
        }

        //752,freeGame
        if (code == "752") {
            var tmpObj = new Object();
            tmpObj["type"] = "freegame";
            tmpObj["tableNo"] = arr[2];
            tmpObj["memName"] = arr[3];
            showMsg.addMsg(tmpObj);
            showFreeGameConfirm(tmpObj);
            // parent.loadPlug("alert", "alert_vip", tmpObj);
            return;
        }

        //754,tipMoney
        if (code == "754") {
            var tmpObj = new Object();
            tmpObj["type"] = "tipMoney";
            tmpObj["memName"] = arr[3];
            tmpObj["gold"] = arr[4];
            showMsg.addMsg(tmpObj);
            return;
        }

        //756,checkBet
        if (code == "756") {
            var tmpObj = new Object();
            tmpObj["type"] = "confirmBet";
            tmpObj["tableNo"] = arr[2];
            tmpObj["boot"] = arr[3];
            tmpObj["gmId"] = arr[4];
            tmpObj["gid"] = arr[5];
            tmpObj["H"] = arr[6];
            tmpObj["C"] = arr[7];
            showBetConfirm(tmpObj);
            clickConfirmBet();
            return;
        }

        //758,confirmBetOK/ confirmBetFail
        if (code == "758") {
            // hideBetConfirm();
            var tmpObj = new Object();
            tmpObj["type"] = "betStatus";
            tmpObj["tableNo"] = arr[2];
            tmpObj["boot"] = arr[3];
            tmpObj["gmId"] = arr[4];
            tmpObj["gid"] = arr[5];
            tmpObj["H"] = arr[6];
            tmpObj["C"] = arr[7];
            tmpObj["accType"] = arr[8];
            tmpObj["status"] = arr[9];
            if(tmpObj["status"] == "Y"){
                showMsg.addMsg(tmpObj);
            }
            return;
        }
        // 762,freeGameResponse,tableNO,username,Y/N
        if (code == "762") {
            // Table.flyInfo(arr[2],arr[4],arr[3]);
            hideFreeGameConfirm();
            return;
        }
        
        //連線失敗 999,close //999,connectLoss
        if (code == "999") {
            //parent.loadPlug("alert", "alert_reconnect", "");
            util.getSpan(document, "reconnect_div").style.display="";
            return;
        }
    }
}

function refreshThread(){
    var self = this;
    var pingStr="";
    var Interval_id = "";
    var seconds = 0;
    self.start = function(){
        clearInterval(Interval_id);
        Interval_id = setInterval(self.ping,1*1000);
    }
    self.getThis = function(name){
        return eval(name);
    }
    self.ping = function(content){
        var sec = getSec();
        sec--;
        if(sec*1 > 0){
            setSec(sec);
            if(sec*1 < 11){
                if(soundEnable){
                    countdownRing.pause();
                    countdownRing.load();
                    countdownRing.play();
                }
            }
        }else{
            clearInterval(Interval_id);
            setSec(seconds);
        }
    }
}

function setSec(num){
    if(num == "0"){
        util.setClassName(util.getSpan(document, "vip_colck_dot"), "");
    }else{
        util.setClassName(util.getSpan(document, "vip_colck_dot"), "vip_colck_dot");
    }

    if(!sec_obj)sec_obj = document.getElementById("countDown");
    if(sec_obj.innerHTML == "0"){
        sec_obj.innerHTML = num;
        countDownTimer.start();
    }else{
        sec_obj.innerHTML = num;
    }
}

function getSec(){
    if(!sec_obj)sec_obj = document.getElementById("countDown");
    return sec_obj.innerHTML*1;
}

function showMsgObj(){
    var self = this;
    //var showMsgAry = new Array();
    var showMsgInterval_id = "";

    self.showMsg = function(){
        var showMsgAry =  getJsonObj(document.getElementById("showMsgAryText").value);
        if(showMsgAry != null){
            var tmpStr = "";
            for(var i = showMsgAry.length -1; i >= 0 ; i --){
                tmpStr += ("<li>"+showMsgAry[i]+ "</li>");
            }
            if(tmpStr !=  ""){
                util.getSpan(document, "msgBarInner").innerHTML = tmpStr;
            }
        }
    }

    self.addMsg = function(obj){
        var showMsgAry =  getJsonObj(document.getElementById("showMsgAryText").value);
        if(showMsgAry == null){
            showMsgAry = new Array();
        }
        var tmpStr = "";
        if(obj["type"] == "freegame"){
            tmpStr += "會員<tt>"+ obj["memName"]+"</tt>要求飛牌";
        }else if(obj["type"] == "tipMoney"){
            tmpStr += "會員<tt>"+ obj["memName"]+"</tt>打賞小費<tt>" +obj["gold"] +"</tt>元";
        }else if(obj["type"] == "betStatus"){
            tmpStr += "下注<tt>"+ obj["tableNo"]+"桌</tt><tt>"+ obj["boot"]+"靴</tt><tt>"+ obj["gmId"]+"局</tt><tt>莊"+ obj["H"]+"元</tt><tt>閒"+ obj["C"]+"</tt>";
            if(obj["status"] == "Y"){
                tmpStr += "成功";
            }else{
                tmpStr += "失敗";
            }
        }
        if(showMsgAry.length > 200){
            showMsgAry.shift();
        }
        showMsgAry.push(tmpStr);

        document.getElementById("showMsgAryText").value = JSON.stringify(showMsgAry);
        self.showMsg();
    }

    self.popMsg =function(){
        // if(showMsgInterval_id != ""){
        //     clearInterval(showMsgInterval_id);
        // }
        //showMsgAry.length = 0;
        //self.showMsg();
    }

} 

function getJsonObj(str){
    try{
        return JSON.parse(str);
    }catch(e){
        return null;
    }
}

//畫圖
function CardCalImage() {
	var self = this;
    self.imageObj = null;
    self.x_diff = 0;
    self.y_diff = 0;
    var canvas = document.getElementById("imgGenerator");
	canvas.width = 106;
	canvas.height = 145;

	self.getCardImage = function(cardNum, cardFlower, image) {
		var datas = self.calculate(cardNum, cardFlower);
		self.cutImage(datas);
		image.src = self.retImage();
		canvas.style.display = "none";
	}

	//載圖
	self.loadimage = function(urls) {
        if(urls.indexOf("cads.png") != -1){
            self.x_diff = 106;
            self.y_diff = 145;
            self.imageObj = new Image();
		    self.imageObj.src = urls;
        }else if(urls.indexOf("cads_m.png") != -1){
            self.x_diff = 54;
            self.y_diff = 74;
            self.imageObj = new Image();
		    self.imageObj.src = urls;
        }else{
            alert("Image fail");
        }
	}

	//計算
	self.calculate = function(cardNum, cardFlower) {        //cardNum 1~13  cardFlower 0~3
        var x = (cardNum - 1) * (self.x_diff);
        var y = cardFlower * (self.y_diff);
        var datas = new Array();
        datas["x"] = x;
        datas["y"] = y;
		return datas;
	}

	//裁圖
	self.cutImage = function(datas) {
		var context = canvas.getContext('2d');
		context.clearRect(0, 0, canvas.width, canvas.height);
        context.drawImage(self.imageObj, datas.x, datas.y, canvas.width, canvas.height, 0, 0, canvas.width, canvas.height);
	}

	//複制圖片到Image
	self.copyImage = function(imagename) {
		var pngData = canvas.toDataURL();
		trace(pngData);
		var coin = util.getSpan(document, imagename);
		coin.src = pngData;
	}

	//返回圖片到Image
	self.retImage = function() {
		var pngData = canvas.toDataURL();
		return pngData;
	}
}