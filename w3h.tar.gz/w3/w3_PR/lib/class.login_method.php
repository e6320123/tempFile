<?php
class login_method
{
    public $PUBLIC_DEFINE = array();
    public $LVar = array();

    public function login_method($GLOBLE_DEFINE)
    {
        global $langx;

        if ($langx == "") {
            $langx = "zh-tw";
        }

        include WEB_PATH . "/conf/" . $langx . "_ctl.php";
        $this->PUBLIC_DEFINE = $GLOBLE_DEFINE;
        $this->LVar = $LVar;
    }

    //------以亂數取得UID------
    public function get_userid()
    {
        if (empty($userid)) {
            $userid = sprintf("%x", rand()) . sprintf("%x", rand());
        }
        return $userid;
    }

    //------會員登入檢查------
    public function chk_ip($ipx)
    {
        return true;
        // if (UNDER_BIG_IP == "S") {
        //     return true;
        // } elseif (UNDER_BIG_IP == "Y") {
        //     $DB_MAIN_R = new NewProc_DB($this->PUBLIC_DEFINE, DB_HOST_R, DB_USER_R, DB_PWD_R, DB_NAME);
        //     $DB_MAIN_R->query("SELECT id FROM ip_list WHERE ip = '$ipx'", 1);
        //     if ($DB_MAIN_R->f("id")) {
        //         $DB_MAIN_R->close();
        //         return true;
        //     }
        //     $DB_MAIN_R->close();
        // } else {
        //     $r_file = FILE_PATH . "/log/chk_ip.txt";
        //     $open_file = @file($r_file);
        //     for ($i = 0; $i < count($open_file); $i++) {
        //         $tmp = explode(",", $open_file[$i]);
        //         if ($ipx == $tmp[0]) {
        //             return true;
        //         }

        //     }
        // }

        // $DB_MAIN_S_IP = new NewProc_DB($this->PUBLIC_DEFINE, DB_HOST_R, DB_USER_R, DB_PWD_R, DB_NAME); // 查詢 IP 是否屬於系統維護用 IP
        // $DB_MAIN_S_IP->query("SELECT id FROM ip_list_maintain WHERE IP = '" . $ipx . "'");
        // if ($DB_MAIN_S_IP->get_total_data() != null) {
        //     $DB_MAIN_S_IP->close();
        //     return true;
        // }
        // $DB_MAIN_S_IP->close();
        // return false;
    }

    // fast : Y 不判斷密碼
    public function loginx($uid, $langx, $username, $passwd, $fast)
    {
        $logintype = "cm";

        if ($username == "" || $passwd == "") {
            return $this->echoErrorCode("INPUT");
        } else {
            //============= 帳密正規化 =============//
            $username = str_replace("=", "", $username);
            $username = str_replace("--", "", $username);
            $username = str_replace(",", "", $username);
            $username = str_replace("%", "", $username);
            $username = stripcslashes($username);
            $passwd = stripcslashes($passwd);

            $today = getdate();
            $now_gmt = gmdate("Y-m-d H:i:s", mktime($today["hours"] + WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
            $hash = array("outsource_ag" => "8", "cm" => "7", "super_admin" => "6", "sc" => "5", "sc2" => "4", "c" => "3", "s" => "2", "a" => "1");

            //百3控端使用DB登入
            $db = new NewProc_DB($this->PUBLIC_DEFINE, DB_HOST, DB_USER, DB_PWD, DB_NAME);

            $ltables = array("cm" => "admin", "sc" => "su_corp", "sc2" => "su2_corp", "c" => "corprator", "s" => "su_agents", "a" => "agents");
            $table = $ltables[$logintype];

            //判斷帳號密碼
            $sql = "SELECT * FROM " . $table;
            $sql .= " WHERE username = '" . $username . "'";
            if ($fast != "Y") {
                $sql .= " AND password = PASSWORD('" . $passwd . "')";
            }
            $db->query($sql, 1);

            //權限
            $type = $db->f("type");
            $priAry = explode("-", $type);
            //回傳錯誤訊息
            if ($db->num_rows() == 0) { //帳號/密碼錯誤，請重新輸入！
                return $this->echoErrorCode("0x006", $db, $logintype, $username, $now_gmt);
            } else if ($db->f("enable") == "N") { //您的帳戶已被停用，請聯繫您的上線開啓你的帳號。
                return $this->echoErrorCode("0x009", $db);
            } else if (!in_array("15", $priAry)) { //您的帳戶無公關系統之權限。
                return $this->echoErrorCode("PR_PRI", $db);
            }

            $userid = $db->f("id");
            $first_login = "N"; //該帳號是否為第一次登入

            $login_data["LOGIN"] = "SUCCESS";
            $login_data["uid"] = $uid;
            $login_data["login_type"] = $logintype;
            $login_data["login_id"] = $userid;
            $login_data["login_username"] = $username;
            $login_data["first_login"] = $first_login;
            $login_data["type"] = $type;
            $login_data["permission"] = $this->getUserAllPri($login_data);

            //檢查帳號是否在線
            $sql = "SELECT * FROM login_" . $table . " WHERE loginid = " . $userid . " AND logindate > '" . $now_gmt . "' ORDER BY id DESC LIMIT 1;";
            $db->query($sql);

            if ($db->num_rows()) {
                while ($db->next_record()) {
                    if ($db->f("uid") == $uid) {
                        break;
                    }
                }

                //判斷是否為不同 uid 登入
                if ($db->f("uid") != $uid) {
                    $this->updateLoginLog($db, $table, $userid, $uid, $username, $now_gmt, $langx, $first_login);
                } else { //相同 uid 登入
                    return $error_data;
                }
            } else { //目前帳號不在線
                //檢查uid是否重複
                $sql = "SELECT * FROM login_" . $table . " WHERE uid = '" . $uid . "'";
                $db->query($sql);

                if ($db->next_record()) {
                    //重新產生uid
                    $uid = $this->get_userid();
                    $login_data["uid"] = $uid;
                }
                $this->updateLoginLog($db, $table, $userid, $uid, $username, $now_gmt, $langx, $first_login);
            }

            if ($hash[$logintype] < 5) {
                $this->chkUpuserState($db, $logintype, $username);
            }

            if ($db != null) {
                $db->close();
            }

            return $login_data;
        }
    }

    //------會員uid檢查是否已登入在線上------
    public function check_login($logintype, $uid, $langx)
    {
        include WEB_PATH . "/conf/" . $langx . "_ctl.php";

        $logintype = "cm";

        $hash = array("outsource_ag" => "8", "cm" => "7", "super_admin" => "6", "sc" => "5", "sc2" => "4", "c" => "3", "s" => "2", "a" => "1");
        $ltables = array("cm" => "admin", "sc" => "su_corp", "sc2" => "su2_corp", "c" => "corprator", "s" => "su_agents", "a" => "agents");
        $table = $ltables[$logintype];
        $error_data[0] = "ERROR";
        $error_data[1] = "<script>window.open('" . BROWSER_IP_PR . "/','_top')</script>";

        $uidAry = explode("|", $uid);
        $dm5ServerIP = "624DB129B32C21FB"; //strtoupper(substr(md5("127.0.0.1"),8,16));

        if (strtoupper($uidAry[1]) == $dm5ServerIP) {
            $uidStr = $uid;
        } else {
            $uidStr = (count($uidAry) == 1) ? $uid : $uidAry[0] . "|" . strtoupper(substr(md5(REMOTE_ADDR), 8, 16));
        }

        //百3控端使用DB登入
        $db = new NewProc_DB($this->PUBLIC_DEFINE, DB_HOST, DB_USER, DB_PWD, DB_NAME);

        //抓uid loginid
        $sql = "SELECT * ";
        $sql .= "FROM `login_" . $table . "` ";
        $sql .= "WHERE `uid` = '" . $uid . "'";
        $sql .= "ORDER BY `id` DESC LIMIT 1;";
        $db->query($sql, 1);

        if ($db->num_rows() > 0) {
            //確認是否為最後一次登入
            $sql = "SELECT * ";
            $sql .= "FROM `login_" . $table . "` ";
            $sql .= "WHERE `loginid` = '" . $db->f("loginid") . "' ";
            $sql .= "ORDER BY `id` DESC LIMIT 1;";
            $db->query($sql, 1);

            //該uid已在線上
            if ($db->f("uid") == $uid) {
                $loginid = $db->f("loginid");
                $langx = $db->f("langx");

                //讀取使用者基本資料
                $sql = "SELECT * FROM `" . $table . "` WHERE `id` = " . $loginid;
                $db->query($sql, 1);
                $userdata = $db->record;
                $userdata["langx"] = $langx;
                $userdata["logintype"] = $logintype;
                $userdata["permission"] = $this->getUserAllPri($userdata);
                $db->close();
                return $userdata;
            }
        }

        //該uid尚未登入或已被踢出,返回登入頁
        $db->close();
        return $error_data;
    }

    //------登入記錄------
    public function updateLoginLog($db, $table, $userid, $uid, $username, $now_gmt, $langx, $first_login)
    {
        $qstr = "INSERT login_" . $table;
        $qstr .= " SET loginid = " . $userid;
        $qstr .= ", uid = '" . $uid . "'";
        $qstr .= ", username = '" . $username . "'";
        $qstr .= ", logindate = ADDDATE('" . $now_gmt . "', INTERVAL 0 MINUTE)";
        $qstr .= ", lastdate = '" . $now_gmt . "'";
        $qstr .= ", langx = '" . $langx . "'";
        $qstr .= ", IP = '" . REMOTE_ADDR . "'";
        $qstr .= ";";

        $db->muti_query($qstr);
    }

    //------檢查上線狀態------
    public function chkUpuserState($db = null, $logintype, $username)
    {
        global $LVar;
        $ltables = array("cm" => "admin", "sc" => "su_corp", "sc2" => "su2_corp", "c" => "corprator", "s" => "su_agents", "a" => "agents");
        $uperArr = array("sc2" => "sc", "c" => "sc2", "s" => "c", "a" => "s");
        $hash = array("" => 9, "outsource_ag" => 8, "cm" => 7, "super_admin" => 6, "sc" => 5, "sc2" => 4, "c" => 3, "s" => 2, "a" => 1);

        if ($hash[$logintype] < 5) {
            if ($db == null) {
                $db = new NewProc_DB($this->PUBLIC_DEFINE, DB_HOST, DB_USER, DB_PWD, DB_NAME);
            }

            $sql = "SELECT " . $uperArr[$logintype] . "id AS upid";
            $sql .= ", " . $logintype . "id AS subid";
            $sql .= ", enable, enable_pri FROM " . $ltables[$logintype];
            $sql .= " WHERE username = '" . $username . "'";
            $db->query($sql, 1);

            //非子帳號查詢上層狀態
            if ($db->f("subid") == 0) {
                $sql = "SELECT enable, enable_pri FROM " . $ltables[$uperArr[$logintype]];
                $sql .= " WHERE id = " . $db->f("upid");
                $db->query($sql, 1);
            }

            if ($db->f("enable") != $db->f("enable_pri")) {
                echo "<SCRIPT language=\"JavaScript\">\n";
                echo "alert('" . $LVar["ERROR_UPER_FORBIDON"] . "');\n";
                echo "</SCRIPT>\n";
            }
        }

        $db->close();
    }

    //------錯誤訊息處理------
    public function echoErrorCode($motion, $db = null, $logintype = "", $username = "", $now_gmt = "")
    {
        global $LVar;
        $ltables = array("" => "super_admin", "cm" => "admin", "sc" => "su_corp", "sc2" => "su2_corp", "c" => "corprator", "s" => "su_agents", "a" => "agents");
        $hash = array("" => 9, "outsource_ag" => 8, "cm" => 7, "super_admin" => 6, "sc" => 5, "sc2" => 4, "c" => 3, "s" => 2, "a" => 1);

        if ($motion == "0x006") { //"0x006"    帳號密碼錯誤
            if ($db != null) {
                $this->insertLoginErr($db, $ltables[$logintype], $hash[$logintype], $username, $now_gmt);
            }

        }

        if ($db != null) {
            $db->close();
        }

        echo "<SCRIPT language=\"JavaScript\">\n";
        echo "alert('" . $LVar["ERROR_" . $motion] . "');\n";
        echo "</SCRIPT>\n";

        $BROWSER_IP = BROWSER_IP_PR;
        if ($motion == "PR_PRI") { //沒有公關權限
            $BROWSER_IP = BROWSER_IP;
        }

        $error_data["LOGIN"] = "ERROR";
        $error_data["DATA"] = "<script>window.open('" . $BROWSER_IP . "/','_top')</script>";
        return $error_data;
    }

    //------錯誤登入記錄------
    public function insertLoginErr($db, $table, $type, $username, $now_gmt)
    {
        $timeAry = explode(",", $now_gmt);

        $qstr = "INSERT INTO logerr_" . $table;
        $qstr .= " SET type = " . $type;
        $qstr .= ", username = '" . $username . "'";
        $qstr .= ", logindate = '" . $timeAry[0] . "'";
        $qstr .= ", logintime = '" . $timeAry[1] . "'";
        $qstr .= ", IP = '" . REMOTE_ADDR . "'";
        $db->query($qstr);
    }

    //------Java連線------
    public function javaConnnection($command, $ip, $port, $back = false)
    {
        $get = "";
        $fp = fsockopen($ip, $port, $errno, $errstr, 5);
        if (!$fp) {
        } else {
            fwrite($fp, $command . "\n");
            if ($back) {
                while (!feof($fp)) {
                    $get .= fgets($fp, 128);
                }
            }
            fclose($fp);
        }
        return $get;
    }
    //權限使用
    public function getUserAllPri($MEM_DATA)
    {
        // A00 現金卡管理
        // B00 選擇卡號(Key單系統)
        // C00 詳細資料
        // D00 出碼
        // E00 卡片紀錄
        // F00 下注明細
        // G00 補單
        $PRI_DATA = array(
            "A00" => array(
                "name" => "現金卡管理",
                "enable" => "N",
            ),
            "B00" => array(
                "name" => "選擇卡號(Key單系統)",
                "enable" => "N",
            ),
            "C00" => array(
                "name" => "詳細資料",
                "enable" => "Y",
            ),
            "D00" => array(
                "name" => "出碼",
                "enable" => "Y",
            ),
            "E00" => array(
                "name" => "卡片紀錄",
                "enable" => "Y",
            ),
            "F00" => array(
                "name" => "下注明細",
                "enable" => "Y",
            ),
            "G00" => array(
                "name" => "補單",
                "enable" => "Y",
            ),
        );

        $ary = explode("-", $MEM_DATA["type"]);
        if (in_array("10", $ary)) {
            $PRI_DATA["B00"]["enable"] = "Y";
        }
        if (in_array("11", $ary)) {
            $PRI_DATA["A00"]["enable"] = "Y";
            $PRI_DATA["B00"]["enable"] = "Y";
        }

        return $PRI_DATA;
    }
}
