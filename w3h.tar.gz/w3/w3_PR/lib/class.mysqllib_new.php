<?php
// ===功能 : 新 mysql 物件 ===
include "mysqllib.php";

class NewProc_DB extends proc_DB{

	var $PUBLIC_DEFINE = Array();

	function NewProc_DB($GLOBLE_DEFINE,$host,$user,$pwd,$dbname){

		$this->PUBLIC_DEFINE = $GLOBLE_DEFINE;
		$this->dbname = $dbname;
		$this->dbhost = $host;
		$this->dbuser = $user;
		$this->dbpwd = $pwd;
	}


	function connect($connect_flag=0){
	   if($this->lid == 0){
			if ($connect_flag){
				$this->lid = mysql_connect($this->dbhost,$this->dbuser,$this->dbpwd);
				$pflag=0;
			}else{
				$this->lid = mysql_connect($this->dbhost,$this->dbuser,$this->dbpwd);
				$pflag=1;
			}

			if(!$this->lid) $this->halt("connect(" . $this->dbhost . "," . $this->dbuser . ",PASSWORD)  failed.");
			else @mysql_query("SET names 'utf8',character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8',character_set_database = 'utf8', character_set_server = 'utf8'", $this->lid);
			if (!@mysql_select_db($this->dbname,$this->lid)) {
				$this->halt("Cannot connect to database ".$this->dbname);
				return 0;
			}
	   }
	   return $this->lid;
	}


	function halt($msg){
		global $PHP_SELF;
		$WEB_TIME_ZONE = $this->PUBLIC_DEFINE["WEB_TIME_ZONE"];
		$FILE_PATH = $this->PUBLIC_DEFINE["FILE_PATH"];
		$HTTP_USER_AGENT = $this->PUBLIC_DEFINE["HTTP_USER_AGENT"];
		$HTTP_ACCEPT_LANGUAGE = $this->PUBLIC_DEFINE["HTTP_ACCEPT_LANGUAGE"];

		$this->error = @mysql_error($this->lid);
		$this->errno = @mysql_errno($this->lid);
		$user="[".$msg."]";
		$today=getdate();
		if(!is_dir($FILE_PATH."/log/error_log")){mkdir($FILE_PATH."/log/error_log",0777);}
		$dir_date=$FILE_PATH."/log/error_log/".gmdate("Y-m-d",mktime($today["hours"]+$WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
		$file_date=gmdate("H",mktime($today["hours"]+$WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]));
		if(!is_dir($dir_date)){mkdir($dir_date,0777);}
		$file_log=fopen($dir_date."/error_log.".$file_date.".log","a");
		fwrite($file_log,gmdate("i:s",mktime($today["hours"]+$WEB_TIME_ZONE,$today["minutes"],$today["seconds"],$today["mon"],$today["mday"],$today["year"]))."\t".$USER_IP."\t".$user."\t".$HTTP_USER_AGENT."\t".$HTTP_ACCEPT_LANGUAGE.$PHP_SELF."\n");
		fclose($file_log);

		$this->showerror("System error","System error");
		exit;
	}


	function showerror($title,$str,$link_page="javascript:history.go(-1);"){
		 include $this->PUBLIC_DEFINE["WEB_PATH"]."/w3_new/tpl/lerror_ctl.html";
	}

}

?>