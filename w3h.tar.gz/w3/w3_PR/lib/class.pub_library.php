<?php
class pub_library
{
    public $PUBLIC_DEFINE = array();

    public function pub_library($GLOBLE_DEFINE)
    {
        $this->PUBLIC_DEFINE = $GLOBLE_DEFINE;
    }

    //=============================================
    //--功能說明：寫入操盤歷史檔
    //--$username:使用者帳號($PHP_AUTH_USER);
    //--$table:更動之資料表名稱;
    //--$fun_name:檔名;
    //--$action:動作("A:新增,D:修改,M:刪除");
    //--$memo:註解
    //--$db:資料庫連線($db);
    //--$ip:使用者IP($USER_IP);
    //=============================================

    //給日期 回卡片年月份
    public function getYearMonth($date)
    {
        $day = $this->PUBLIC_DEFINE["CARD_SET_DAY"];
        $yearMonth = date("Ym", strtotime($date . " + $day day"));
        return $yearMonth;
    }

    //給日期 可以加減天數
    public function getOrderdateCalc($date, $day)
    {
        $orderdate = date("Y-m-d", strtotime($date . " $day day"));
        return $orderdate;
    }

    //給日期 回可讀取日期
    public function getReadMonth($yearMonth)
    {
        $num = (int) $this->PUBLIC_DEFINE["CARD_SET_DAY"];
        $readMonthAry = array();
        $date = substr($yearMonth, 0, 4) . "-" . substr($yearMonth, 4, 2) . "-01";
        $monthAry = $this->getMonthDay($date);

        $headerAry = array();
        for ($i = $num; $i > 0; $i--) {
            $headerAry[] = date("Y-m-d", strtotime($monthAry[0] . " - $i day"));
        }

        $footerAry = array();
        for ($i = 1; $i <= $num; $i++) {
            $footerAry[] = date("Y-m-d", strtotime($monthAry[COUNT($monthAry) - 1] . " + $i day"));
        }

        $readMonthAry = array_merge($readMonthAry, $headerAry);
        $readMonthAry = array_merge($readMonthAry, $monthAry);
        $readMonthAry = array_merge($readMonthAry, $footerAry);

        return $readMonthAry;
    }

    //給日期 回整月日期
    public function getMonthDay($date)
    {
        $firstDay = substr($date, 0, 8) . "01";
        $lastDay = date("Y-m-d", strtotime($firstDay . " +1 month -1 day"));
        $tmp_firstDay = strtotime($firstDay);
        $tmp_lastDay = strtotime($lastDay);

        $orderdateAry = array();
        while ($tmp_firstDay <= $tmp_lastDay) {
            $orderdateAry[] = date("Y-m-d", $tmp_firstDay);
            $tmp_firstDay = strtotime("+1 day", $tmp_firstDay);
        }
        return $orderdateAry;
    }

    //指定Key排序Array
    public function multi_array_sort($arr, $key, $type = SORT_REGULAR, $short = SORT_ASC)
    {
        if (!is_array($arr)) {
            return array();
        }
        if (COUNT($arr) == 0) {
            return $arr;
        }
        foreach ($arr as $k => $v) {
            $name[$k] = $v[$key];
        }
        array_multisort($name, $type, $short, $arr);
        return $arr;
    }

    //群組會員
    public function getGroupMid()
    {
        global $global_vars, $MEM_DATA;
        $midAry = array();
        $DB_MAIN_R = $this->getDB("DB_HOST_R", "DB_USER_R", "DB_PWD_R", "DB_NAME");
        //群組
        $sql = "SELECT `pri_id` ";
        $sql .= "FROM `team_pri_user` ";
        $sql .= "WHERE `usertype` = 'cm' ";
        $sql .= "AND `userid` = " . $MEM_DATA["id"] . " ;";
        $DB_MAIN_R->query($sql);
        while ($DB_MAIN_R->next_record()) {
            $pri_id = $DB_MAIN_R->f("pri_id");
        }
        //總監
        $su_corpAry = array();
        $sql = "SELECT `pri_value` ";
        $sql .= "FROM `team_pri_set` ";
        $sql .= "WHERE `pri_id` = '" . $pri_id . "' ";
        $sql .= "AND  `pri_type` = 'su_corp' ;";
        $DB_MAIN_R->query($sql);
        while ($DB_MAIN_R->next_record()) {
            $su_corpAry[] = $DB_MAIN_R->f("pri_value");
        }
        //會員
        if (COUNT($su_corpAry) > 0) {
            $sql = "SELECT `mid` ";
            $sql .= "FROM `mem_winloss` ";
            $sql .= "WHERE `scid` IN ('" . implode("','", $su_corpAry) . "'); ";
            $DB_MAIN_R->query($sql);
            while ($DB_MAIN_R->next_record()) {
                $midAry[] = $DB_MAIN_R->f("mid");
            }
        }
        return $midAry;
    }

    //============================== 以下沒有使用 ==============================

    public function Write_cardrecord($cardno_id, $mid, $active, $json, $db)
    {
        $sql = "INSERT INTO `cardrecord` SET ";
        $sql .= "`cardno_id` = '" . $cardno_id . "' , ";
        $sql .= "`mid` = " . $mid . " , ";
        $sql .= "`opertype` = '" . $active . "' , ";
        $sql .= "`value` = '" . json_encode($json) . "' , ";
        $sql .= "`operator` = " . $MEM_DATA["username"] . " , ";
        $sql .= "`adddate` = NOW() ; ";
        $db->query($sq);
    }

    public function Write_Ctl_Record($username, $table, $fun_name, $action, $memo, $db, $ip, $game_type = "")
    {
        $WEB_TIME_ZONE = $this->PUBLIC_DEFINE["WEB_TIME_ZONE"];
        $table_name = "ctl_record";

        if ($game_type != "") {
            $table_name = $game_type . "_ctl_record";
        }

        $today = getdate();
        $today_gmt = gmdate("Y-m-d", mktime($today["hours"] + $WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
        $now_gmt = gmdate("H:i:s", mktime($today["hours"] + $WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
        $today = $today_gmt . " " . $now_gmt;
        $sql = "insert into " . $table_name . " (username,t_name,action,fun_name,content,adddate,ip)";
        $sql .= "values ('$username','$table','$action','$fun_name','$memo','$today','$ip')";
        $db->query($sql);
    }

    public function Write_game_Ctl_Record($username, $table, $fun_name, $action, $memo, $db, $ip, $game_type = "")
    {
        $WEB_TIME_ZONE = $this->PUBLIC_DEFINE["WEB_TIME_ZONE"];
        $table_name = "game_ctl_record";

        if ($game_type != "") {
            $table_name = $game_type . "_game_ctl_record";
        }

        $today = getdate();
        $today_gmt = gmdate("Y-m-d", mktime($today["hours"] + $WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
        $now_gmt = gmdate("H:i:s", mktime($today["hours"] + $WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
        $today = $today_gmt . " " . $now_gmt;
        $sql = "insert into " . $table_name . " (username,t_name,action,fun_name,content,adddate,ip)";
        $sql .= "values ('$username','$table','$action','$fun_name','$memo','$today','$ip')";
        $db->query($sql);
    }

    public function Write_Ratio_Record_old_121018($username, $gid, $gameType, $wtype, $rtype, $ltype, $ratio, $action, $db)
    {
        $WEB_TIME_ZONE = $this->PUBLIC_DEFINE["WEB_TIME_ZONE"];
        $today = getdate();
        $today_gmt = gmdate("Y-m-d H:i:s", mktime($today["hours"] + $WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));

        $sql = "insert into " . $gameType . "_ratio_record SET";
        $sql .= " gid = '" . $gid . "',";
        $sql .= " wtype = '" . $wtype . "',";
        $sql .= " rtype = '" . $rtype . "',";
        $sql .= " ltype = '" . $ltype . "',";
        $sql .= " ratio = '" . $ratio . "',";
        $sql .= " type = '" . $action . "',";
        $sql .= " username = '" . $username . "',";
        $sql .= " adddate = '" . $today_gmt . "';";
        $db->query($sql);
    }

    public function Write_Ratio_Record($username, $gid, $phase, $t_id, $gameType, $wtype, $rtype, $ltype, $oldIor, $newIor, $action, $USER_IP, $db)
    {
        $WEB_TIME_ZONE = $this->PUBLIC_DEFINE["WEB_TIME_ZONE"];
        $today = getdate();
        $today_gmt = gmdate("Y-m-d H:i:s", mktime($today["hours"] + $WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));

        $sql = "insert into " . $gameType . "_ratio_record SET";
        $sql .= " t_id = '" . $t_id . "',";
        $sql .= " gid = '" . $gid . "',";
        $sql .= " phase = '" . $phase . "',";
        $sql .= " wtype = '" . $wtype . "',";
        $sql .= " rtype = '" . $rtype . "',";
        $sql .= " ltype = '" . $ltype . "',";
        $sql .= " ratio_old = '" . $oldIor . "',";
        $sql .= " ratio = '" . $newIor . "',";
        $sql .= " type = '" . $action . "',";
        $sql .= " username = '" . $username . "',";
        $sql .= " adddate = '" . $today_gmt . "',";
        $sql .= " IP = '" . $USER_IP . "';";
        $db->query($sql);
    }

    public function open_js($filename)
    {
        $ret = "";
        $open_file = @file($filename);
        if ($open_file[0]) {
            for ($i = 0; $i < count($open_file); $i++) {
                $ret .= $open_file[$i];
            }
        }
        return $ret;
        //return "<script>\n".$ret."</script>\n";
    }

    public function javaConnnection($command, $ip, $port, $back = false)
    {
        //echo "<script>alert('".$command."');</script>";
        //if (CASINO == "SI") {return "";}
        $get = "";
        $fp = fsockopen($ip, $port, $errno, $errstr, 5);
        if (!$fp) {
            //echo "<script>alert('server error');</script>";
        } else {
            fwrite($fp, $command . "\n");
            if ($back) {
                while (!feof($fp)) {
                    $get .= fgets($fp, 1024 * 8);
                    if (strpos($get, "\n") > -1) {
                        break;
                    }

                }
            }
            fclose($fp);
        }
        return $get;
    }

    public function defend_SQL_injection($word)
    {
        $word = str_replace('=', '', $word);
        $word = str_replace('--', '', $word);
        $word = str_replace('%', '', $word);
        $word = str_replace('\'', '', $word);
        $word = str_replace('\"', '', $word);
        $word = str_replace('\*', '', $word);
        $word = str_replace(' OR ', '', $word);
        $word = str_replace(' or ', '', $word);
        $word = str_replace('#', '', $word);
        //$word = str_replace('/','',$word);
        //$word = stripcslashes($word);

        return $word;
    }

    public function msprintf($type, $num, $arg = "")
    {

        if ($arg == "") {
            $dv = 0;
            $tmpnum = $num;
            if ($type == "%.02f") {
                $dv = 100;
            } else if ($type == "%.03f") {
                $dv = 1000;
            }
            if ($num < 0) {
                $tmpnum = $num * $dv * -1 + 0.0000001;
                $tmpnum = floor($tmpnum) / $dv * -1;
            } else {
                $tmpnum = $num * $dv + 0.0000001;
                $tmpnum = floor($tmpnum) / $dv;
            }
            return sprintf($type, $tmpnum, $arg);
        } else {
            return sprintf($type, $num, $arg);
        }
    }

    public function get_Game_DB($gameType, $DbType)
    {
        $P = $this->PUBLIC_DEFINE;

        $DbName = $P["DB_NAME_SH_" . $gameType];

        $DB = "";

        if ($DbType == "W") {
            $DB = new NewProc_DB($P, $P["DB_HOST_SH"], $P["DB_USER"], $P["DB_PWD"], $DbName);
        } else {
            $DB = new NewProc_DB($P, $P["DB_HOST_SH_R"], $P["DB_USER_R"], $P["DB_PWD_R"], $DbName);
        }

        return $DB;
    }

    public function getDB($host, $user, $pwd, $dbname)
    {
        $P = $this->PUBLIC_DEFINE;
        return new NewProc_DB($P, $P[$host], $P[$user], $P[$pwd], $P[$dbname]);
    }
    //Wager用
    public function getWagerDB($host, $user, $pwd, $dbname)
    {
        $P = $this->PUBLIC_DEFINE;
        return new NewProc_DB($P, $P[$host], $P[$user], $P[$pwd], $dbname);
    }
    //取Wager特定時間區間內的DB或名稱
    public function getWagerName($sdate, $edate, $mode)
    {
        $wager = $this->getDB("DB_WAGERS_HOST_R", "DB_USER_R", "DB_PWD_R", "DB_WAGERS_NAME");
        $sql = "SELECT db_name FROM  `report_dbname`  WHERE";
        $sql .= " id >= (SELECT id FROM  `report_dbname` WHERE sdate <= '" . $sdate . "' ORDER BY id DESC LIMIT 1)";
        $sql .= " AND id <= (SELECT id FROM  `report_dbname` WHERE edate >= '" . $edate . "' ORDER BY id ASC LIMIT 1)";
        $sql .= " AND team_ok = 'Y' ;";
        $wager->query($sql);
        while ($wager->next_record()) {
            if ($mode == "DB") {
                $outAry[] = $this->getWagerDB("DB_WAGERS_HOST_R", "DB_USER_R", "DB_PWD_R", $wager->f("db_name"));
            } else if ($mode == "NAME") {
                $outAry[] = $wager->f("db_name");
            }

        }
        return $outAry;
    }
    //取日期區間內所有日期
    public function date_range($first, $last)
    {
        $period = new DatePeriod(
            new DateTime($first),
            new DateInterval('P1D'),
            new DateTime($last)
        );
        foreach ($period as $date) {
            $dates[] = $date->format('Y-m-d');
        }

        $dates[] = $last;
        return $dates;
    }

    public function mkWagerDate()
    {
        $WEB_TIME_ZONE = $this->PUBLIC_DEFINE["WEB_TIME_ZONE"];
        $today = getdate();
        $now_gmt = gmdate("Y-m-d", mktime($today["hours"] + $WEB_TIME_ZONE, $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
        $now_gmt = preg_replace("/\-/", "", $now_gmt);
        return $now_gmt;
    }

    public function getLastPhaseData($gtype, $resulLen)
    {
        $DB = $this->get_Game_DB($gtype, "R");
        $dataAry = array();
        $outData = "";

        $sql = "select * from " . strtoupper($gtype) . "_result where phase = (select phase from " . strtoupper($gtype) . " where gover='Y' AND start_time <= NOW() order by id DESC LIMIT 1);";

        $DB->query($sql, 1);
        if ($DB->num_rows() > 0) {
            $dataAry["last_phase"] = $DB->f("phase");

            for ($i = 1; $i <= $resulLen; $i++) {
                $filds = "num" . $i;
                if ($i >= 10) {
                    $filds = "num0";
                }

                $dataAry["last_open"] .= $DB->f($filds) . ",";
            }
            $dataAry["last_open"] = substr($dataAry["last_open"], 0, strlen($dataAry["last_open"]) - 1);
        } else {
            $dataAry["last_phase"] = "no";
            $dataAry["last_open"] = "nodata";
        }

        $outData .= $dataAry["last_phase"] . "*" . $dataAry["last_open"];

        return $outData;
    }

    public function getDateForTableName($DB, $gtype, $gid)
    {
        $outD = "";

        $DB->query("select orderdate from " . $gtype . " where id='" . $gid . "' order by id DESC;", 1);
        $dataStr = $DB->f("orderdate");

        $unix_time = strtotime($dataStr);
        $tmpD = date("w", $unix_time);

        $outD = (($tmpD * 1) == 0) ? "7" : ("" . $tmpD);

        return $outD;
    }

    //檢查 log 資料夾是否存在
    public function ChkLogPath($today_gmt)
    {
        $FILE_PATH = $this->PUBLIC_DEFINE["FILE_PATH"];
        if (!is_dir($FILE_PATH . "/log/error_log")) {mkdir($FILE_PATH . "/log/error_log", 0777);}
        if (!is_dir($FILE_PATH . "/log/error_log/" . $today_gmt)) {mkdir($FILE_PATH . "/log/error_log/" . $today_gmt, 0777);}
    }
}
