<?php
// function getcardinfo($setAry = array())
// {
//     global $UTIL, $global_vars;
//     $mode = array("O"); //預設開卡中
//     $username = ""; //預設全繞 公關
//     $shoes = false; //預設不繞 繞靴
//     $time = true; //預設繞當月
//     $usecash = true; //預設執行 繞岀碼
//     $usecashNull = false; //預設關閉 取不到也塞值

//     if (!is_null($setAry["mode"])) {
//         $mode = $setAry["mode"];
//     }
//     if (!is_null($setAry["username"])) {
//         $username = $setAry["username"];
//     }
//     if (!is_null($setAry["shoes"])) {
//         $shoes = $setAry["shoes"];
//     }
//     if (!is_null($setAry["time"])) {
//         $time = $setAry["time"];
//     }
//     if (!is_null($setAry["usecash"])) {
//         $usecash = $setAry["usecash"];
//     }
//     if (!is_null($setAry["usecashNull"])) {
//         $usecashNull = $setAry["usecashNull"];
//     }

//     $unit = 10000; //目前單位
//     $DB_MAIN_R = $UTIL->getDB("DB_HOST_R", "DB_USER_R", "DB_PWD_R", "DB_NAME");
//     //時間
//     $today = getdate();
//     $date = gmdate("Y-m-d", mktime($today["hours"] + $global_vars["WEB_TIME_ZONE"], $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
//     $cardDate = $UTIL->getYearMonth($date);
//     $cardAry = array(); //所有可開卡的卡
//     $priCardAry = array();
//     $usecashidAry = array();
//     $PRcardAry = array();
//     $midAry = array();
//     $usernameAry = array();
//     // 繞出目前尚未開卡的卡 和已經開過的卡
//     $sql = "SELECT * FROM `cashcard` ";
//     $sql .= " WHERE `status` IN ('" . implode("' , '", $mode) . "') ";
//     if ($time) {
//         $sql .= " AND `year_month` = '" . $cardDate . "' ;";
//     }
//     $DB_MAIN_R->query($sql);
//     while ($DB_MAIN_R->next_record()) {
//         $tmp = array();
//         $tmp["cardno"] = $DB_MAIN_R->f("cardno"); //卡號
//         $tmp["mid"] = $DB_MAIN_R->f("mid");
//         $tmp["alias"] = $DB_MAIN_R->f("alias");
//         $tmp["currency"] = $DB_MAIN_R->f("currency");
//         $tmp["CR"] = $DB_MAIN_R->f("maxcredit") / $unit;
//         $tmp["balance"] = ($DB_MAIN_R->f("maxcredit") - $DB_MAIN_R->f("cashout") + $DB_MAIN_R->f("cash")) / $unit; //目前餘額
//         $tmp["cashout"] = $DB_MAIN_R->f("cashout") / $unit; //總出碼
//         $tmp["washing_cashcard"] = $DB_MAIN_R->f("washing") / $unit; //洗馬 cashcard
//         $tmp["status"] = $DB_MAIN_R->f("status"); //狀態
//         $tmp["cardno_id"] = $DB_MAIN_R->f("id"); //卡片編號
//         $tmp["year_month"] = $DB_MAIN_R->f("year_month"); //年月
//         $midAry[] = $DB_MAIN_R->f("mid");
//         $priCardAry[] = $DB_MAIN_R->f("id");
//         $cardAry[$DB_MAIN_R->f("id")] = $tmp;
//     }
//     //繞出指定公關 是否已有開卡  cashcard -> id  對應  usecash -> cardno_id
//     if (COUNT($priCardAry) > 0 && $usecash) {
//         // 繞出目前會員的username
//         $sql = "SELECT * FROM `members` ";
//         $sql .= " WHERE `id` IN (" . implode(",", $midAry) . ") ;";
//         $DB_MAIN_R->query($sql);
//         while ($DB_MAIN_R->next_record()) {
//             $usernameAry[$DB_MAIN_R->f("id")] = $DB_MAIN_R->f("username");
//         }
//         //將對應的username 放入物件
//         foreach ($cardAry as $key => $value) {
//             $cardAry[$key]["username"] = $usernameAry[$value["mid"]];
//         }
//         // 繞出目前公關已開的卡
//         // SELECT * FROM `usecash` JOIN (
//         //     SELECT `cardno_id`, MAX(`id`) AS `maxTime` FROM `usecash` GROUP BY `cardno_id`
//         // ) AS `temp` ON `id` IN (`temp`.`maxTime`);
//         $sql = "SELECT * FROM `usecash` JOIN ( SELECT `cardno_id`, MAX(`id`) AS `maxTime` FROM `usecash`";
//         $sql .= " WHERE `cardno_id` IN (" . implode(",", $priCardAry) . ") "; //目前有開卡的卡號
//         if ($username != "") { //空即是不指定 全繞取
//             $sql .= " AND `operator` = '" . $username . "'";
//         }
//         if (COUNT($mode) == 1 && in_array("O", $mode)) {
//             $sql .= " AND `closedate` = '0000-00-00 00:00:00' ";
//         }
//         $sql .= "  GROUP BY `cardno_id`";
//         $sql .= " ) AS `temp` ON `id` IN (`temp`.`maxTime`);";
//         $DB_MAIN_R->query($sql);
//         while ($DB_MAIN_R->next_record()) {
//             $cardno_id = $DB_MAIN_R->f("cardno_id");
//             $tmpobj = $cardAry[$cardno_id];
//             $tmpobj["usecashid"] = $DB_MAIN_R->f("id"); //本次出碼編號
//             $tmpobj["seatno"] = $DB_MAIN_R->f("seatno"); //座位
//             $tmpobj["washing_usecash"] = $DB_MAIN_R->f("washing") / $unit; //洗馬 usecash
//             $tmpobj["mudding"] = $DB_MAIN_R->f("mudding") / $unit; //泥瑪
//             $tmpobj["operator"] = $DB_MAIN_R->f("operator"); //公關帳號
//             $tmpobj["maxcredit"] = $DB_MAIN_R->f("maxcredit") / $unit; //本次出碼金額
//             $tmpobj["maxcredit_orderdate"] = substr($DB_MAIN_R->f("adddate"), 0, 10); //本次出碼日期
//             $tmpobj["open_start"] = $DB_MAIN_R->f("opendate"); //開卡(出碼時間)
//             $tmpobj["open_end"] = $DB_MAIN_R->f("closedate"); //關卡
//             $tmpobj["cash"] = $DB_MAIN_R->f("cash") / $unit; //上下數
//             $tmpobj["tip_d"] = $DB_MAIN_R->f("tip_d") / $unit; //小費TD
//             $tmpobj["tip_h"] = $DB_MAIN_R->f("tip_h") / $unit; //小費TH
//             $tmpobj["saveing"] = $tmpobj["cashout"] + $tmpobj["cash"] - ($tmpobj["tip_d"] + $tmpobj["tip_h"]); //存碼 = 出碼 + 上下數 - 小費

//             $usecashidAry[] = $DB_MAIN_R->f("id");
//             $PRcardAry[$cardno_id] = $tmpobj;
//         }

//         if ($usecashNull) {
//             foreach ($cardAry as $key => $ary) { //取不到也塞值
//                 if (is_null($PRcardAry[$key])) {
//                     $PRcardAry[$key] = $ary;
//                 }
//             }
//         }

//         if ($shoes) { // 繞出每個卡最後一靴
//             if (COUNT($PRcardAry) > 0) {
//                 $sql = "SELECT * FROM `cardshoe` ";
//                 $sql .= " WHERE `usecashid` IN (" . implode(",", $usecashidAry) . ") ";
//                 $sql .= " ORDER BY `id` ASC;";
//                 $DB_MAIN_R->query($sql);
//                 $usecashidAry = array();
//                 $orderdateAry = array();
//                 while ($DB_MAIN_R->next_record()) {
//                     $usecashidAry[$DB_MAIN_R->f("usecashid")][] = $DB_MAIN_R->f("cardshoe");
//                     $orderdateAry[$DB_MAIN_R->f("usecashid")][] = $DB_MAIN_R->f("orderdate");
//                 }
//                 foreach ($PRcardAry as $cardno_id => $tmpobj) {
//                     if (!is_null($usecashidAry[$tmpobj["usecashid"]])) {
//                         $PRcardAry[$cardno_id]["last_shoes"] = $usecashidAry[$tmpobj["usecashid"]];
//                         $PRcardAry[$cardno_id]["last_shoes_orderdate"] = $orderdateAry[$tmpobj["usecashid"]];
//                     }
//                 }
//             }
//         }
//         $cardAry = $PRcardAry;

//     }

//     $out = array();
//     $out = $cardAry;

//     return $out;
// }

//新版=========================================================

//取得卡片資料(出碼,洗碼,小費,收工,關卡)
function getCardData($setAry = array())
{
    global $UTIL, $global_vars;

    $thisMonthSwitch = true; //預設當月
    $usecashSwitch = true; //預設繞出碼
    $lastUsecashSwitch = false; //預設不繞最後一Shoes
    $modeAry = array("O"); //預設出碼中
    $operator = ""; //預設所有公關
    $midAry = $UTIL->getGroupMid(); //群組下會員

    if (!is_null($setAry["thisMonthSwitch"])) {
        $thisMonthSwitch = $setAry["thisMonthSwitch"];
    }
    if (!is_null($setAry["usecashSwitch"])) {
        $usecashSwitch = $setAry["usecashSwitch"];
    }
    if (!is_null($setAry["lastUsecashSwitch"])) {
        $lastUsecashSwitch = $setAry["lastUsecashSwitch"];
    }
    if (!is_null($setAry["modeAry"])) {
        $modeAry = $setAry["modeAry"];
    }
    if (!is_null($setAry["operator"])) {
        $operator = $setAry["operator"];
    }

    //目前單位
    $unit = 10000;
    $DB_MAIN_R = $UTIL->getDB("DB_HOST_R", "DB_USER_R", "DB_PWD_R", "DB_NAME");
    //時間
    $today = getdate();
    $date = gmdate("Y-m-d", mktime($today["hours"] + $global_vars["WEB_TIME_ZONE"], $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
    $cardDate = $UTIL->getYearMonth($date);
    $cardAry = array();
    $cardIdAry = array();
    //繞所有符合時間,狀態的卡
    $sql = "SELECT `members`.`username`, `cashcard`.* ";
    $sql .= "FROM `cashcard`, `members` ";
    $sql .= "WHERE `cashcard`.`status` IN ('" . implode("' , '", $modeAry) . "') ";
    $sql .= "AND `members`.`id` = `cashcard`.`mid` ";
    $sql .= "AND `members`.`id` IN (" . implode(",", $midAry) . ") ";
    if ($thisMonthSwitch) {
        $sql .= "AND `cashcard`.`year_month` = '" . $cardDate . "' ;";
    }
    $DB_MAIN_R->query($sql);
    while ($DB_MAIN_R->next_record()) {
        $tmp = array();
        $tmp["cardno"] = $DB_MAIN_R->f("cardno"); //卡號
        $tmp["username"] = $DB_MAIN_R->f("username"); //會員帳號
        $tmp["mid"] = $DB_MAIN_R->f("mid"); //會員編號
        $tmp["alias"] = $DB_MAIN_R->f("alias"); //暱稱
        $tmp["currency"] = $DB_MAIN_R->f("currency"); //幣別
        $tmp["CR"] = $DB_MAIN_R->f("maxcredit") / $unit; //CR
        $tmp["balance"] = ($DB_MAIN_R->f("maxcredit") - $DB_MAIN_R->f("cashout") + $DB_MAIN_R->f("cash")) / $unit; //目前餘額
        $tmp["cashout"] = $DB_MAIN_R->f("cashout") / $unit; //出碼
        $tmp["washing_cashcard"] = $DB_MAIN_R->f("washing") / $unit; //洗碼
        $tmp["status"] = $DB_MAIN_R->f("status"); //狀態
        $tmp["cardno_id"] = $DB_MAIN_R->f("id"); //卡片編號
        $tmp["year_month"] = $DB_MAIN_R->f("year_month"); //卡片所屬年月
        $cardAry[$DB_MAIN_R->f("id")] = $tmp;
        $cardIdAry[] = $DB_MAIN_R->f("id");
    }
    //繞出碼資訊
    if ($usecashSwitch && COUNT($cardIdAry) > 0) {
        $usecashIdAry = array();
        $cardAry2 = array();
        // 繞出目前公關已開的卡
        $sql = "SELECT * FROM `usecash` JOIN ( SELECT `cardno_id`, MAX(`id`) AS `maxTime` FROM `usecash`";
        $sql .= " WHERE `cardno_id` IN (" . implode(",", $cardIdAry) . ") "; //目前有開卡的卡號
        if ($operator != "") { //空即是不指定 繞所有公關
            $sql .= " AND `operator` = '" . $operator . "'";
        }
        // if (COUNT($modeAry) == 1 && in_array("O", $modeAry)) { //取尚未關卡出碼
        //     $sql .= " AND `closedate` = '0000-00-00 00:00:00' ";
        // }
        $sql .= "  GROUP BY `cardno_id`";
        $sql .= " ) AS `temp` ON `id` IN (`temp`.`maxTime`);";
        $DB_MAIN_R->query($sql);
        while ($DB_MAIN_R->next_record()) {
            $cardno_id = $DB_MAIN_R->f("cardno_id");
            $tmp = $cardAry[$cardno_id];
            $tmp["usecashid"] = $DB_MAIN_R->f("id"); //本次出碼編號
            $tmp["seatno"] = $DB_MAIN_R->f("seatno"); //座位
            $tmp["washing_usecash"] = $DB_MAIN_R->f("washing") / $unit; //洗馬 usecash
            $tmp["mudding"] = $DB_MAIN_R->f("mudding") / $unit; //泥瑪
            $tmp["operator"] = $DB_MAIN_R->f("operator"); //公關帳號
            $tmp["maxcredit"] = $DB_MAIN_R->f("maxcredit") / $unit; //本次出碼金額
            $tmp["maxcredit_orderdate"] = substr($DB_MAIN_R->f("adddate"), 0, 10); //本次出碼日期
            $tmp["open_start"] = $DB_MAIN_R->f("opendate"); //開卡(出碼時間)
            $tmp["open_end"] = $DB_MAIN_R->f("closedate"); //關卡
            $tmp["cash"] = $DB_MAIN_R->f("cash") / $unit; //上下數
            $tmp["tip_d"] = $DB_MAIN_R->f("tip_d") / $unit; //小費TD
            $tmp["tip_h"] = $DB_MAIN_R->f("tip_h") / $unit; //小費TH
            $tmp["saveing"] = $tmp["cashout"] + $tmp["cash"] - ($tmp["tip_d"] + $tmp["tip_h"]); //存碼 = 出碼 + 上下數 - 小費
            $cardAry2[$cardno_id] = $tmp;
            $usecashIdAry[] = $DB_MAIN_R->f("id");
        }
        $cardAry = $cardAry2;

        if (COUNT($usecashIdAry) == 0) {
            $cardAry = array();
        }
        //繞最後一靴資料
        if ($lastUsecashSwitch && COUNT($usecashIdAry) > 0) {
            $cardshoeAry = array();
            $sql = "SELECT * FROM `cardshoe` ";
            $sql .= " WHERE `usecashid` IN (" . implode(",", $usecashIdAry) . ") ";
            $sql .= " ORDER BY `id` DESC;";
            $DB_MAIN_R->query($sql);
            while ($DB_MAIN_R->next_record()) {
                $usecashid = $DB_MAIN_R->f("usecashid");
                $tmp = array();
                $tmp["shoes"] = $DB_MAIN_R->f("cardshoe");
                $tmp["orderdate"] = $DB_MAIN_R->f("orderdate");
                $cardshoeAry[$usecashid][] = $tmp;
            }
            foreach ($cardAry as $cardno_id => $ary) {
                $usecashid = $ary["usecashid"];
                if (!is_null($cardshoeAry[$usecashid])) {
                    $cardAry[$cardno_id]["cardShoes"] = $cardshoeAry[$usecashid];
                } else {
                    unset($cardAry[$cardno_id]);
                }
            }
        }
    }
    return $cardAry;
}

function getSeatCard($setAry = array())
{
    global $UTIL, $global_vars;

    $midAry = $UTIL->getGroupMid(); //群組下會員

    if (!is_null($setAry["operator"])) {
        $operator = $setAry["operator"];
    }

    //目前單位
    $unit = 10000;
    $DB_MAIN_R = $UTIL->getDB("DB_HOST_R", "DB_USER_R", "DB_PWD_R", "DB_NAME");
    //時間
    $today = getdate();
    $date = gmdate("Y-m-d", mktime($today["hours"] + $global_vars["WEB_TIME_ZONE"], $today["minutes"], $today["seconds"], $today["mon"], $today["mday"], $today["year"]));
    $cardDate = $UTIL->getYearMonth($date);
    $cardAry = array();
    $cardIdAry = array();
    //繞所有符合時間,狀態的卡
    $sql = "SELECT `members`.`username`, `cashcard`.* ";
    $sql .= "FROM `cashcard`, `members` ";
    $sql .= "WHERE `cashcard`.`status` IN ('O') ";
    $sql .= "AND `members`.`id` = `cashcard`.`mid` ";
    $sql .= "AND `members`.`id` IN (" . implode(",", $midAry) . "); ";
    $DB_MAIN_R->query($sql);
    while ($DB_MAIN_R->next_record()) {
        $tmp = array();
        $tmp["cardno"] = $DB_MAIN_R->f("cardno"); //卡號
        $tmp["username"] = $DB_MAIN_R->f("username"); //會員帳號
        $tmp["mid"] = $DB_MAIN_R->f("mid"); //會員編號
        $tmp["alias"] = $DB_MAIN_R->f("alias"); //暱稱
        $tmp["currency"] = $DB_MAIN_R->f("currency"); //幣別
        $tmp["CR"] = $DB_MAIN_R->f("maxcredit") / $unit; //CR
        $tmp["balance"] = ($DB_MAIN_R->f("maxcredit") - $DB_MAIN_R->f("cashout") + $DB_MAIN_R->f("cash")) / $unit; //目前餘額
        $tmp["cashout"] = $DB_MAIN_R->f("cashout") / $unit; //出碼
        $tmp["washing_cashcard"] = $DB_MAIN_R->f("washing") / $unit; //洗碼
        $tmp["status"] = $DB_MAIN_R->f("status"); //狀態
        $tmp["cardno_id"] = $DB_MAIN_R->f("id"); //卡片編號
        $tmp["year_month"] = $DB_MAIN_R->f("year_month"); //卡片所屬年月
        $cardAry[$DB_MAIN_R->f("id")] = $tmp;
        $cardIdAry[] = $DB_MAIN_R->f("id");
    }
    if (COUNT($cardIdAry) > 0) {
        $usecashAry = array();
        // 繞出目前公關已開的卡
        $sql = "SELECT * FROM `usecash` JOIN ( SELECT `cardno_id`, MAX(`id`) AS `maxTime` FROM `usecash`";
        $sql .= " WHERE `cardno_id` IN (" . implode(",", $cardIdAry) . ") "; //目前有開卡的卡號
        $sql .= "  GROUP BY `cardno_id`";
        $sql .= " ) AS `temp` ON `id` IN (`temp`.`maxTime`);";
        $DB_MAIN_R->query($sql);
        while ($DB_MAIN_R->next_record()) {
            if ($DB_MAIN_R->f("operator") == $operator) {
                $cardno_id = $DB_MAIN_R->f("cardno_id");
                $tmp = $cardAry[$cardno_id];
                $tmp["usecashid"] = $DB_MAIN_R->f("id"); //本次出碼編號
                $tmp["seatno"] = $DB_MAIN_R->f("seatno"); //座位
                $tmp["washing_usecash"] = $DB_MAIN_R->f("washing") / $unit; //洗馬 usecash
                $tmp["mudding"] = $DB_MAIN_R->f("mudding") / $unit; //泥瑪
                $tmp["operator"] = $DB_MAIN_R->f("operator"); //公關帳號
                $tmp["maxcredit"] = $DB_MAIN_R->f("maxcredit") / $unit; //本次出碼金額
                $tmp["maxcredit_orderdate"] = substr($DB_MAIN_R->f("adddate"), 0, 10); //本次出碼日期
                $tmp["open_start"] = $DB_MAIN_R->f("opendate"); //開卡(出碼時間)
                $tmp["open_end"] = $DB_MAIN_R->f("closedate"); //關卡
                $tmp["cash"] = $DB_MAIN_R->f("cash") / $unit; //上下數
                $tmp["tip_d"] = $DB_MAIN_R->f("tip_d") / $unit; //小費TD
                $tmp["tip_h"] = $DB_MAIN_R->f("tip_h") / $unit; //小費TH
                $tmp["saveing"] = $tmp["cashout"] + $tmp["cash"] - ($tmp["tip_d"] + $tmp["tip_h"]); //存碼 = 出碼 + 上下數 - 小費
                $usecashAry[$cardno_id] = $tmp;
            }
        }
        if (COUNT($usecashAry) == 0) {
            $cardAry = array();
        } else {
            $cardAry = $usecashAry;
        }
    }
    return $cardAry;
}
