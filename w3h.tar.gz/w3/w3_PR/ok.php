<?php
echo "machine:" . $_SERVER['SERVER_ADDR'] . "<br>";
$WEB_PATH = explode("/", $_SERVER['DOCUMENT_ROOT']);
$muser = $WEB_PATH[2];
echo "muser:" . $muser . "<br>";
exit;
